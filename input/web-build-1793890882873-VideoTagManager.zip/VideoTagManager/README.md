# Video Tag Manager - Android App

Advanced video gallery + player app with full tagging system.

## Features Implemented

1. **Storage permission** (READ_MEDIA_VIDEO / READ_EXTERNAL_STORAGE) – mandatory on first launch, scans MediaStore
2. **Delete to Trash** from player (middle-right FAB) – **no confirmation** as requested
3. **Tag system** – create / add / delete tags, search & filter by tag
4. **Player top tags row** – all tags + “+ Tag”, one-tap to tag currently playing video
5. **Share** (single + multi)
6. **Swipe gestures** – right→left = next, left→right = previous
7. **Tag-wise multi-select share**
8. **Untagged** special filter
9. **Settings circular pie chart** (MPAndroidChart) – tag-wise distribution
10. **Multi-select** – delete / share / tag in one go

### Advanced Player (ExoPlayer / Media3)
- Custom controller
- Speed button placeholder
- Picture-in-Picture support declared
- Fullscreen
- Gesture swipe for next/prev

## How to Build

1. Open the project in **Android Studio** (Hedgehog or newer recommended)
2. Let it sync Gradle
3. If wrapper jar is missing/corrupt:  
   `gradle wrapper --gradle-version 8.9`
4. Run on device/emulator (minSdk 26)

### Permissions
App will request storage / media video permission on first launch.

## Project Structure

```
app/
  src/main/java/com/videotag/manager/
    data/          → Room entities, Dao, Repository, Database
    ui/            → MainActivity, Fragments, Adapters
    player/        → PlayerActivity (ExoPlayer + gestures + tags)
    VideoTagApp.kt
  res/             → layouts, themes, menus
```

## Notes / Next Improvements
- Player next/prev currently finishes activity for simplicity – improve by keeping full VideoEntity list
- Add more ExoPlayer features: brightness/volume overlay, double-tap seek, lock, subtitle, audio track
- Permanent delete from trash + restore
- Better tag color picker
- Search bar in Videos tab
- FileProvider already configured for sharing

Built for the feature list you provided + solid advanced player base.
