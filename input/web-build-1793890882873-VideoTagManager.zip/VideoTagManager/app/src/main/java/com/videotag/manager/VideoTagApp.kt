package com.videotag.manager

import android.app.Application
import com.videotag.manager.data.VideoRepository

class VideoTagApp : Application() {
    lateinit var repository: VideoRepository
        private set

    override fun onCreate() {
        super.onCreate()
        repository = VideoRepository(this)
    }
}
