package com.videotag.manager.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(tableName = "videos")
data class VideoEntity(
    @PrimaryKey val id: Long,               // MediaStore _ID
    val path: String,
    val displayName: String,
    val duration: Long = 0L,
    val size: Long = 0L,
    val dateAdded: Long = 0L,
    val mimeType: String = "video/*",
    val isInTrash: Boolean = false,
    val trashTime: Long = 0L
)

@Entity(tableName = "tags")
data class TagEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val color: Int = 0xFF00C853.toInt(),
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "video_tags",
    primaryKeys = ["videoId", "tagId"],
    foreignKeys = [
        ForeignKey(
            entity = VideoEntity::class,
            parentColumns = ["id"],
            childColumns = ["videoId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = TagEntity::class,
            parentColumns = ["id"],
            childColumns = ["tagId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("videoId"), Index("tagId")]
)
data class VideoTagCrossRef(
    val videoId: Long,
    val tagId: Long
)

data class TagWithCount(
    val id: Long,
    val name: String,
    val color: Int,
    val count: Int
)

data class VideoWithTags(
    val video: VideoEntity,
    val tags: List<TagEntity>
)
