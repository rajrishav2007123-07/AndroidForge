package com.videotag.manager.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface VideoDao {

    // ---------- Videos ----------
    @Query("SELECT * FROM videos WHERE isInTrash = 0 ORDER BY dateAdded DESC")
    fun getAllVideos(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE isInTrash = 1 ORDER BY trashTime DESC")
    fun getTrashVideos(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE id = :id")
    suspend fun getVideoById(id: Long): VideoEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVideos(videos: List<VideoEntity>)

    @Update
    suspend fun updateVideo(video: VideoEntity)

    @Query("UPDATE videos SET isInTrash = 1, trashTime = :time WHERE id = :id")
    suspend fun moveToTrash(id: Long, time: Long = System.currentTimeMillis())

    @Query("UPDATE videos SET isInTrash = 1, trashTime = :time WHERE id IN (:ids)")
    suspend fun moveToTrashMultiple(ids: List<Long>, time: Long = System.currentTimeMillis())

    @Query("UPDATE videos SET isInTrash = 0, trashTime = 0 WHERE id = :id")
    suspend fun restoreFromTrash(id: Long)

    @Query("DELETE FROM videos WHERE id = :id")
    suspend fun permanentlyDelete(id: Long)

    @Query("DELETE FROM videos WHERE isInTrash = 1")
    suspend fun emptyTrash()

    // ---------- Tags ----------
    @Query("SELECT * FROM tags ORDER BY name ASC")
    fun getAllTags(): Flow<List<TagEntity>>

    @Query("SELECT * FROM tags WHERE id = :id")
    suspend fun getTagById(id: Long): TagEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertTag(tag: TagEntity): Long

    @Query("DELETE FROM tags WHERE id = :id")
    suspend fun deleteTag(id: Long)

    @Query("""
        SELECT t.id, t.name, t.color, COUNT(vt.videoId) as count
        FROM tags t
        LEFT JOIN video_tags vt ON t.id = vt.tagId
        LEFT JOIN videos v ON vt.videoId = v.id AND v.isInTrash = 0
        GROUP BY t.id
        ORDER BY t.name ASC
    """)
    fun getTagsWithCount(): Flow<List<TagWithCount>>

    // ---------- Cross Ref ----------
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addTagToVideo(crossRef: VideoTagCrossRef)

    @Query("DELETE FROM video_tags WHERE videoId = :videoId AND tagId = :tagId")
    suspend fun removeTagFromVideo(videoId: Long, tagId: Long)

    @Query("SELECT tagId FROM video_tags WHERE videoId = :videoId")
    suspend fun getTagIdsForVideo(videoId: Long): List<Long>

    @Query("""
        SELECT v.* FROM videos v
        INNER JOIN video_tags vt ON v.id = vt.videoId
        WHERE vt.tagId = :tagId AND v.isInTrash = 0
        ORDER BY v.dateAdded DESC
    """)
    fun getVideosByTag(tagId: Long): Flow<List<VideoEntity>>

    @Query("""
        SELECT v.* FROM videos v
        WHERE v.isInTrash = 0 AND v.id NOT IN (SELECT videoId FROM video_tags)
        ORDER BY v.dateAdded DESC
    """)
    fun getUntaggedVideos(): Flow<List<VideoEntity>>

    @Query("SELECT COUNT(*) FROM videos WHERE isInTrash = 0 AND id NOT IN (SELECT videoId FROM video_tags)")
    fun getUntaggedCount(): Flow<Int>

    @Transaction
    @Query("SELECT * FROM videos WHERE id = :videoId")
    suspend fun getVideoWithTags(videoId: Long): VideoWithTags?
}
