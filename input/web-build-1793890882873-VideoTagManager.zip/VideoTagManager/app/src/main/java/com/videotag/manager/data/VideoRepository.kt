package com.videotag.manager.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class VideoRepository(private val context: Context) {

    private val dao = AppDatabase.getInstance(context).videoDao()

    fun getAllVideos(): Flow<List<VideoEntity>> = dao.getAllVideos()
    fun getTrashVideos(): Flow<List<VideoEntity>> = dao.getTrashVideos()
    fun getAllTags(): Flow<List<TagEntity>> = dao.getAllTags()
    fun getTagsWithCount(): Flow<List<TagWithCount>> = dao.getTagsWithCount()
    fun getVideosByTag(tagId: Long): Flow<List<VideoEntity>> = dao.getVideosByTag(tagId)
    fun getUntaggedVideos(): Flow<List<VideoEntity>> = dao.getUntaggedVideos()
    fun getUntaggedCount(): Flow<Int> = dao.getUntaggedCount()

    suspend fun scanMediaStore() = withContext(Dispatchers.IO) {
        val collection = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.MIME_TYPE
        )

        val videos = mutableListOf<VideoEntity>()
        context.contentResolver.query(
            collection,
            projection,
            null,
            null,
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
            val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                videos.add(
                    VideoEntity(
                        id = id,
                        path = cursor.getString(dataCol) ?: "",
                        displayName = cursor.getString(nameCol) ?: "Unknown",
                        duration = cursor.getLong(durCol),
                        size = cursor.getLong(sizeCol),
                        dateAdded = cursor.getLong(dateCol),
                        mimeType = cursor.getString(mimeCol) ?: "video/*"
                    )
                )
            }
        }
        if (videos.isNotEmpty()) {
            dao.insertVideos(videos)
        }
    }

    fun getContentUri(videoId: Long): Uri {
        return ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, videoId)
    }

    suspend fun moveToTrash(id: Long) = dao.moveToTrash(id)
    suspend fun moveToTrashMultiple(ids: List<Long>) = dao.moveToTrashMultiple(ids)
    suspend fun restoreFromTrash(id: Long) = dao.restoreFromTrash(id)
    suspend fun permanentlyDelete(id: Long) = dao.permanentlyDelete(id)
    suspend fun emptyTrash() = dao.emptyTrash()

    suspend fun createTag(name: String, color: Int = 0xFF00C853.toInt()): Long {
        return dao.insertTag(TagEntity(name = name.trim(), color = color))
    }

    suspend fun deleteTag(id: Long) = dao.deleteTag(id)

    suspend fun addTagToVideo(videoId: Long, tagId: Long) {
        dao.addTagToVideo(VideoTagCrossRef(videoId, tagId))
    }

    suspend fun removeTagFromVideo(videoId: Long, tagId: Long) {
        dao.removeTagFromVideo(videoId, tagId)
    }

    suspend fun getTagIdsForVideo(videoId: Long): List<Long> = dao.getTagIdsForVideo(videoId)

    suspend fun toggleTagOnVideo(videoId: Long, tagId: Long) {
        val existing = dao.getTagIdsForVideo(videoId)
        if (existing.contains(tagId)) {
            dao.removeTagFromVideo(videoId, tagId)
        } else {
            dao.addTagToVideo(VideoTagCrossRef(videoId, tagId))
        }
    }
}
