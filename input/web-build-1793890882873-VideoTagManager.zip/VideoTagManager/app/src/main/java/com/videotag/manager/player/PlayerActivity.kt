package com.videotag.manager.player

import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GestureDetectorCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.google.android.material.chip.Chip
import com.videotag.manager.R
import com.videotag.manager.VideoTagApp
import com.videotag.manager.databinding.ActivityPlayerBinding
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.math.abs

class PlayerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_VIDEO_ID = "video_id"
        const val EXTRA_VIDEO_PATH = "video_path"
        const val EXTRA_VIDEO_NAME = "video_name"
    }

    private lateinit var binding: ActivityPlayerBinding
    private var player: ExoPlayer? = null
    private var videoId: Long = -1
    private var currentIndex = 0
    private var videoList: List<Long> = emptyList() // ids for next/prev

    private lateinit var gestureDetector: GestureDetectorCompat

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        videoId = intent.getLongExtra(EXTRA_VIDEO_ID, -1)
        val path = intent.getStringExtra(EXTRA_VIDEO_PATH) ?: return finish()
        val name = intent.getStringExtra(EXTRA_VIDEO_NAME) ?: "Video"

        setupPlayer(path)
        setupGestures()
        setupButtons()
        loadTags()
        loadPlaylist()
    }

    private fun setupPlayer(path: String) {
        player = ExoPlayer.Builder(this).build().also { exo ->
            binding.playerView.player = exo
            val item = MediaItem.fromUri(path)
            exo.setMediaItem(item)
            exo.prepare()
            exo.playWhenReady = true
            exo.repeatMode = Player.REPEAT_MODE_OFF
        }
    }

    private fun setupGestures() {
        gestureDetector = GestureDetectorCompat(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (e1 == null) return false
                val diffX = e2.x - e1.x
                if (abs(diffX) > 100 && abs(velocityX) > 100) {
                    if (diffX < 0) {
                        // right to left → next
                        playNext()
                    } else {
                        // left to right → previous
                        playPrev()
                    }
                    return true
                }
                return false
            }
        })
        binding.playerView.setOnTouchListener { _, event ->
            gestureDetector.onTouchEvent(event)
            false
        }
    }

    private fun setupButtons() {
        binding.btnClose.setOnClickListener { finish() }
        binding.btnDelete.setOnClickListener {
            // No confirmation as requested
            lifecycleScope.launch {
                (application as VideoTagApp).repository.moveToTrash(videoId)
                Toast.makeText(this@PlayerActivity, "Moved to trash", Toast.LENGTH_SHORT).show()
                playNextOrFinish()
            }
        }
    }

    private fun loadTags() {
        lifecycleScope.launch {
            val repo = (application as VideoTagApp).repository
            val allTags = repo.getAllTags().first()
            val currentTagIds = repo.getTagIdsForVideo(videoId)

            binding.chipGroupTags.removeAllViews()
            allTags.forEach { tag ->
                val chip = Chip(this@PlayerActivity).apply {
                    text = tag.name
                    isCheckable = true
                    isChecked = currentTagIds.contains(tag.id)
                    setOnClickListener {
                        lifecycleScope.launch {
                            repo.toggleTagOnVideo(videoId, tag.id)
                            isChecked = !isChecked
                        }
                    }
                }
                binding.chipGroupTags.addView(chip)
            }
            // Add new tag chip
            val addChip = Chip(this@PlayerActivity).apply {
                text = "+ Tag"
                setOnClickListener {
                    // Simple create
                    Toast.makeText(this@PlayerActivity, "Use Tags tab to create new tags", Toast.LENGTH_SHORT).show()
                }
            }
            binding.chipGroupTags.addView(addChip)
        }
    }

    private fun loadPlaylist() {
        lifecycleScope.launch {
            val list = (application as VideoTagApp).repository.getAllVideos().first()
            videoList = list.map { it.id }
            currentIndex = videoList.indexOf(videoId).coerceAtLeast(0)
        }
    }

    private fun playNext() {
        if (currentIndex < videoList.size - 1) {
            currentIndex++
            switchTo(videoList[currentIndex])
        }
    }

    private fun playPrev() {
        if (currentIndex > 0) {
            currentIndex--
            switchTo(videoList[currentIndex])
        }
    }

    private fun playNextOrFinish() {
        if (currentIndex < videoList.size - 1) {
            playNext()
        } else {
            finish()
        }
    }

    private fun switchTo(id: Long) {
        lifecycleScope.launch {
            val video = (application as VideoTagApp).repository.let { repo ->
                // We need path - for simplicity re-scan or store
                // In full app use a map or query
                videoId = id
                // Restart player with new path (simplified - real app should keep list of entities)
                finish() // For demo; better to update media item
            }
        }
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
