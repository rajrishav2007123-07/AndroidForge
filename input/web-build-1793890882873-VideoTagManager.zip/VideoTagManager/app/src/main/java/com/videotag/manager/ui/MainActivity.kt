package com.videotag.manager.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.google.android.material.tabs.TabLayoutMediator
import com.videotag.manager.R
import com.videotag.manager.VideoTagApp
import com.videotag.manager.databinding.ActivityMainBinding
import com.videotag.manager.ui.fragments.SettingsFragment
import com.videotag.manager.ui.fragments.TagsFragment
import com.videotag.manager.ui.fragments.TrashFragment
import com.videotag.manager.ui.fragments.VideosFragment
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var multiSelectMode = false
    private val selectedIds = mutableSetOf<Long>()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.any { it }) {
            scanAndRefresh()
        } else {
            Toast.makeText(this, getString(R.string.storage_permission_required), Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        setupViewPager()
        setupMultiBar()
        checkPermissionAndScan()
    }

    private fun setupViewPager() {
        binding.viewPager.adapter = object : FragmentStateAdapter(this) {
            override fun getItemCount() = 4
            override fun createFragment(position: Int) = when (position) {
                0 -> VideosFragment()
                1 -> TagsFragment()
                2 -> TrashFragment()
                else -> SettingsFragment()
            }
        }
        TabLayoutMediator(binding.tabLayout, binding.viewPager) { tab, pos ->
            tab.text = when (pos) {
                0 -> getString(R.string.videos)
                1 -> getString(R.string.tags)
                2 -> getString(R.string.trash)
                else -> getString(R.string.settings)
            }
        }.attach()
    }

    private fun setupMultiBar() {
        binding.btnMultiTag.setOnClickListener { multiActionTag() }
        binding.btnMultiShare.setOnClickListener { multiActionShare() }
        binding.btnMultiDelete.setOnClickListener { multiActionDelete() }
    }

    private fun checkPermissionAndScan() {
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            scanAndRefresh()
        } else {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun scanAndRefresh() {
        lifecycleScope.launch {
            (application as VideoTagApp).repository.scanMediaStore()
        }
    }

    fun enterMultiSelect(initialId: Long? = null) {
        multiSelectMode = true
        selectedIds.clear()
        initialId?.let { selectedIds.add(it) }
        binding.multiBar.visibility = View.VISIBLE
        invalidateOptionsMenu()
        supportFragmentManager.fragments.forEach {
            if (it is VideosFragment) it.setMultiMode(true)
        }
    }

    fun exitMultiSelect() {
        multiSelectMode = false
        selectedIds.clear()
        binding.multiBar.visibility = View.GONE
        invalidateOptionsMenu()
        supportFragmentManager.fragments.forEach {
            if (it is VideosFragment) it.setMultiMode(false)
        }
    }

    fun toggleSelection(id: Long) {
        if (selectedIds.contains(id)) selectedIds.remove(id) else selectedIds.add(id)
        supportFragmentManager.fragments.forEach {
            if (it is VideosFragment) it.notifySelectionChanged()
        }
    }

    fun isSelected(id: Long) = selectedIds.contains(id)
    fun isMultiMode() = multiSelectMode
    fun getSelectedIds() = selectedIds.toList()

    private fun multiActionDelete() {
        if (selectedIds.isEmpty()) return
        lifecycleScope.launch {
            (application as VideoTagApp).repository.moveToTrashMultiple(selectedIds.toList())
            exitMultiSelect()
            Toast.makeText(this@MainActivity, "Moved to trash", Toast.LENGTH_SHORT).show()
        }
    }

    private fun multiActionShare() {
        if (selectedIds.isEmpty()) return
        val uris = selectedIds.map {
            (application as VideoTagApp).repository.getContentUri(it)
        }
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "video/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Share videos"))
    }

    private fun multiActionTag() {
        if (selectedIds.isEmpty()) return
        // Simple dialog for now - TagsFragment can improve
        lifecycleScope.launch {
            val tags = (application as VideoTagApp).repository.getAllTags()
            // Collect first value for dialog (simplified)
            tags.collect { list ->
                if (list.isEmpty()) {
                    Toast.makeText(this@MainActivity, "No tags created yet", Toast.LENGTH_SHORT).show()
                    return@collect
                }
                val names = list.map { it.name }.toTypedArray()
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Add Tag")
                    .setItems(names) { _, which ->
                        lifecycleScope.launch {
                            selectedIds.forEach { vid ->
                                (application as VideoTagApp).repository.addTagToVideo(vid, list[which].id)
                            }
                            exitMultiSelect()
                            Toast.makeText(this@MainActivity, "Tagged", Toast.LENGTH_SHORT).show()
                        }
                    }
                    .show()
                return@collect
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.findItem(R.id.action_select)?.title =
            if (multiSelectMode) getString(R.string.cancel) else getString(R.string.select)
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_select -> {
                if (multiSelectMode) exitMultiSelect() else enterMultiSelect()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
