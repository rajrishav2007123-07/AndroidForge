package com.videotag.manager.ui.adapters

import android.text.format.DateUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.videotag.manager.data.VideoEntity
import com.videotag.manager.databinding.ItemVideoBinding
import com.videotag.manager.VideoTagApp
import java.util.concurrent.TimeUnit

class VideoAdapter(
    private val onClick: (VideoEntity) -> Unit,
    private val onLongClick: (VideoEntity) -> Unit,
    private val isSelected: (Long) -> Boolean,
    private val isMultiMode: () -> Boolean
) : ListAdapter<VideoEntity, VideoAdapter.VH>(DIFF) {

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<VideoEntity>() {
            override fun areItemsTheSame(a: VideoEntity, b: VideoEntity) = a.id == b.id
            override fun areContentsTheSame(a: VideoEntity, b: VideoEntity) = a == b
        }
    }

    inner class VH(val binding: ItemVideoBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemVideoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val video = getItem(position)
        val b = holder.binding
        b.title.text = video.displayName
        b.duration.text = formatDuration(video.duration)
        b.checkBox.visibility = if (isMultiMode()) View.VISIBLE else View.GONE
        b.checkBox.isChecked = isSelected(video.id)

        val uri = (b.root.context.applicationContext as VideoTagApp).repository.getContentUri(video.id)
        Glide.with(b.thumbnail)
            .load(uri)
            .centerCrop()
            .into(b.thumbnail)

        b.root.setOnClickListener { onClick(video) }
        b.root.setOnLongClickListener {
            onLongClick(video)
            true
        }
    }

    private fun formatDuration(ms: Long): String {
        val hours = TimeUnit.MILLISECONDS.toHours(ms)
        val minutes = TimeUnit.MILLISECONDS.toMinutes(ms) % 60
        val seconds = TimeUnit.MILLISECONDS.toSeconds(ms) % 60
        return if (hours > 0) String.format("%d:%02d:%02d", hours, minutes, seconds)
        else String.format("%02d:%02d", minutes, seconds)
    }
}
