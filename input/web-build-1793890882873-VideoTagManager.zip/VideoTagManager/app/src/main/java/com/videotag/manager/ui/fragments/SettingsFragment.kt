package com.videotag.manager.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.utils.ColorTemplate
import com.videotag.manager.VideoTagApp
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class SettingsFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val root = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        val title = TextView(requireContext()).apply {
            text = "Tag-wise Distribution"
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 0, 0, 16)
        }
        root.addView(title)

        val chart = PieChart(requireContext()).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                600
            )
            description.isEnabled = false
            setUsePercentValues(true)
            setEntryLabelColor(0xFFFFFFFF.toInt())
            legend.textColor = 0xFFCCCCCC.toInt()
            setHoleColor(0xFF1A1A1A.toInt())
        }
        root.addView(chart)

        viewLifecycleOwner.lifecycleScope.launch {
            val repo = (requireActivity().application as VideoTagApp).repository
            repo.getTagsWithCount().collectLatest { tags ->
                val entries = mutableListOf<PieEntry>()
                tags.filter { it.count > 0 }.forEach {
                    entries.add(PieEntry(it.count.toFloat(), it.name))
                }
                // Untagged
                repo.getUntaggedCount().collectLatest { untagged ->
                    if (untagged > 0) entries.add(PieEntry(untagged.toFloat(), "Untagged"))
                    if (entries.isNotEmpty()) {
                        val dataSet = PieDataSet(entries, "").apply {
                            colors = ColorTemplate.MATERIAL_COLORS.toList()
                            valueTextColor = 0xFFFFFFFF.toInt()
                            valueTextSize = 12f
                        }
                        chart.data = PieData(dataSet)
                        chart.invalidate()
                    }
                }
            }
        }

        return root
    }
}
