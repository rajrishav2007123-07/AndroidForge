package com.videotag.manager.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.videotag.manager.R
import com.videotag.manager.VideoTagApp
import com.videotag.manager.data.TagWithCount
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class TagsFragment : Fragment() {

    private lateinit var container: LinearLayout

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val root = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }
        this.container = root

        val createBtn = MaterialButton(requireContext()).apply {
            text = getString(R.string.create_tag)
            setOnClickListener { showCreateTagDialog() }
        }
        root.addView(createBtn)

        // Untagged
        val untaggedView = createTagRow("Untagged", -1, 0) {
            (parentFragmentManager.findFragmentByTag("f0") as? VideosFragment)?.setFilterTag(-1L)
            // Switch to videos tab ideally
        }
        root.addView(untaggedView)

        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val repo = (requireActivity().application as VideoTagApp).repository
        viewLifecycleOwner.lifecycleScope.launch {
            repo.getTagsWithCount().collectLatest { tags ->
                // Clear previous dynamic rows (keep create + untagged)
                while (container.childCount > 2) {
                    container.removeViewAt(2)
                }
                tags.forEach { tag ->
                    container.addView(createTagRow(tag.name, tag.id, tag.count) {
                        // Filter videos by this tag
                        Toast.makeText(requireContext(), "Filter: ${tag.name}", Toast.LENGTH_SHORT).show()
                    })
                }
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            repo.getUntaggedCount().collectLatest { count ->
                // Update untagged count text if needed
            }
        }
    }

    private fun createTagRow(name: String, id: Long, count: Int, onClick: () -> Unit): View {
        return LinearLayout(requireContext()).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 12, 0, 12)
            addView(TextView(requireContext()).apply {
                text = "$name ($count)"
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 16f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(MaterialButton(requireContext(), null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = "View"
                setOnClickListener { onClick() }
            })
            if (id > 0) {
                addView(MaterialButton(requireContext()).apply {
                    text = "✕"
                    setBackgroundColor(0xFFFF1744.toInt())
                    setOnClickListener {
                        lifecycleScope.launch {
                            (requireActivity().application as VideoTagApp).repository.deleteTag(id)
                        }
                    }
                })
            }
        }
    }

    private fun showCreateTagDialog() {
        val input = EditText(requireContext()).apply {
            hint = "Tag name"
            setPadding(40, 40, 40, 40)
        }
        AlertDialog.Builder(requireContext())
            .setTitle(R.string.create_tag)
            .setView(input)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    lifecycleScope.launch {
                        (requireActivity().application as VideoTagApp).repository.createTag(name)
                        Toast.makeText(requireContext(), "Tag created", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
