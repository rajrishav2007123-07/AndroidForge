package com.videotag.manager.ui.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.videotag.manager.VideoTagApp
import com.videotag.manager.databinding.FragmentVideosBinding
import com.videotag.manager.player.PlayerActivity
import com.videotag.manager.ui.MainActivity
import com.videotag.manager.ui.adapters.VideoAdapter
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class VideosFragment : Fragment() {

    private var _binding: FragmentVideosBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: VideoAdapter
    private var filterTagId: Long? = null // null = all, -1 = untagged

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentVideosBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        adapter = VideoAdapter(
            onClick = { video ->
                val main = activity as? MainActivity
                if (main?.isMultiMode() == true) {
                    main.toggleSelection(video.id)
                    adapter.notifyDataSetChanged()
                } else {
                    val intent = Intent(requireContext(), PlayerActivity::class.java).apply {
                        putExtra(PlayerActivity.EXTRA_VIDEO_ID, video.id)
                        putExtra(PlayerActivity.EXTRA_VIDEO_PATH, video.path)
                        putExtra(PlayerActivity.EXTRA_VIDEO_NAME, video.displayName)
                    }
                    startActivity(intent)
                }
            },
            onLongClick = { video ->
                (activity as? MainActivity)?.enterMultiSelect(video.id)
                adapter.notifyDataSetChanged()
            },
            isSelected = { id -> (activity as? MainActivity)?.isSelected(id) == true },
            isMultiMode = { (activity as? MainActivity)?.isMultiMode() == true }
        )
        binding.recyclerView.layoutManager = GridLayoutManager(requireContext(), 2)
        binding.recyclerView.adapter = adapter
        loadVideos()
    }

    private fun loadVideos() {
        val repo = (requireActivity().application as VideoTagApp).repository
        viewLifecycleOwner.lifecycleScope.launch {
            val flow = when {
                filterTagId == -1L -> repo.getUntaggedVideos()
                filterTagId != null -> repo.getVideosByTag(filterTagId!!)
                else -> repo.getAllVideos()
            }
            flow.collectLatest { list ->
                adapter.submitList(list)
                binding.emptyText.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    fun setFilterTag(tagId: Long?) {
        filterTagId = tagId
        loadVideos()
    }

    fun setMultiMode(enabled: Boolean) {
        adapter.notifyDataSetChanged()
    }

    fun notifySelectionChanged() {
        adapter.notifyDataSetChanged()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
