# MediaTag Advanced — Android Studio Project

## Build
1. ZIP extract karein.
2. Android Studio (JDK 17) mein `MediaTagAdvanced` folder open karein.
3. Gradle sync complete hone dein.
4. Android device/emulator par Run karein.
5. APK: `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`).

## Included
- MediaStore video library + Android runtime permission request
- Search, sort, tag filters, Untagged
- Persistent tags and per-video tag assignments (SharedPreferences)
- Media3 ExoPlayer playback, seek controls, speed presets
- Swipe next/previous, PiP entry action
- Bulk select, share, app-managed trash
- Tag-wise counts and storage overview

## Important Android platform constraints
- Android 13+ uses granular media permissions. Android does not provide unrestricted access to every file by asking for a single legacy storage permission.
- Permanent MediaStore deletion on modern Android is gated by OS confirmation (`MediaStore.createDeleteRequest`). This project intentionally uses an app-managed Trash so a delete tap does not silently destroy the user's original file.
- The current library scans videos. Non-video documents/audio/images require a SAF document picker or separate MediaStore queries; they are not silently scanned.
- Thumbnail rendering uses a play placeholder in this starter UI; a production polish pass can add Coil/MediaMetadataRetriever thumbnail extraction.
- Subtitles/audio tracks are handled by Media3 where embedded tracks are available. External subtitle picker and advanced audio selector UI are not wired in this starter.
- Brightness gesture, lock controls, playlist persistence, background playback notification/service, and true permanent deletion request UI are follow-on implementation tasks.

Package: `com.mediatag.advanced`
Min SDK 23 · Target SDK 35 · Gradle 8.10.2 · AGP 8.7.3 · Kotlin 2.0.21
