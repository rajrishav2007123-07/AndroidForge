package com.mediatag.advanced

import android.Manifest
import android.app.PictureInPictureParams
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Rational
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import org.json.JSONArray
import org.json.JSONObject

data class VideoFile(
    val uri: Uri, val name: String, val size: Long, val duration: Long,
    val mime: String, val date: Long
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MediaTagApp(
            onEnterPip = {
                if (Build.VERSION.SDK_INT >= 26) {
                    enterPictureInPictureMode(PictureInPictureParams.Builder()
                        .setAspectRatio(Rational(16, 9)).build())
                }
            }
        ) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediaTagApp(onEnterPip: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("mediatag", Context.MODE_PRIVATE) }
    var videos by remember { mutableStateOf(emptyList<VideoFile>()) }
    var tags by remember { mutableStateOf(loadTags(prefs)) }
    var tagMap by remember { mutableStateOf(loadTagMap(prefs)) }
    var trash by remember { mutableStateOf(loadTrash(prefs)) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var activeTag by remember { mutableStateOf("All") }
    var query by remember { mutableStateOf("") }
    var page by remember { mutableStateOf("Library") }
    var playing by remember { mutableStateOf<VideoFile?>(null) }
    var speed by remember { mutableFloatStateOf(1f) }
    var brightness by remember { mutableFloatStateOf(0.5f) }
    var showTagDialog by remember { mutableStateOf(false) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var newTagName by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf("Name") }
    val player = remember { ExoPlayer.Builder(context).build() }

    fun persist() {
        prefs.edit().putString("tags", JSONArray(tags).toString())
            .putString("tagMap", JSONObject().apply { tagMap.forEach { (k,v) -> put(k, JSONArray(v)) } }.toString())
            .putString("trash", JSONArray(trash).toString()).apply()
    }
    fun refresh() { videos = queryVideos(context) }
    val permissionList = remember {
        when {
            Build.VERSION.SDK_INT >= 34 -> arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
            Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_VIDEO)
            else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (it.values.any { granted -> granted }) refresh()
        else Toast.makeText(context, "Video access is required to scan your library. You can also pick files using Android's file picker.", Toast.LENGTH_LONG).show()
    }
    LaunchedEffect(Unit) {
        if (permissionList.all { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }) refresh()
        else permissionLauncher.launch(permissionList)
    }
    DisposableEffect(Unit) { onDispose { player.release() } }

    val visible = videos.filter { v ->
        val key = v.uri.toString()
        key !in trash &&
        (activeTag == "All" || (activeTag == "Untagged" && tagMap[key].isNullOrEmpty()) ||
            tagMap[key]?.contains(activeTag) == true) &&
        (v.name.contains(query, true) || (tagMap[key]?.any { it.contains(query, true) } == true))
    }.let { list ->
        when(sort) { "Newest" -> list.sortedByDescending { it.date }; "Largest" -> list.sortedByDescending { it.size }; "Duration" -> list.sortedByDescending { it.duration }; else -> list.sortedBy { it.name.lowercase() } }
    }

    fun play(video: VideoFile) {
        playing = video
        player.setMediaItem(MediaItem.fromUri(video.uri))
        player.prepare()
        player.playWhenReady = true
        page = "Player"
    }
    fun moveToTrash(video: VideoFile) {
        // App-managed trash: no OS delete dialog. Original MediaStore file remains untouched.
        trash = (trash + video.uri.toString()).distinct()
        persist()
        if (playing?.uri == video.uri) { player.stop(); playing = null; page = "Library" }
        Toast.makeText(context, "Moved to MediaTag Trash", Toast.LENGTH_SHORT).show()
    }
    fun share(items: List<VideoFile>) {
        if (items.isEmpty()) return
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "video/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(items.map { it.uri }))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share videos"))
    }
    fun addTagTo(items: List<VideoFile>, tag: String) {
        items.forEach { v ->
            val key = v.uri.toString()
            tagMap = tagMap.toMutableMap().apply { put(key, (get(key).orEmpty() + tag).distinct()) }
        }
        persist()
    }

    BackHandler(page == "Player") { player.pause(); page = "Library" }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFF91A9FF),
        background = androidx.compose.ui.graphics.Color(0xFF0B1020),
        surface = androidx.compose.ui.graphics.Color(0xFF151D32)
    )) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(if (page == "Player") playing?.name ?: "Player" else "MediaTag") },
                    navigationIcon = { if (page == "Player") IconButton(onClick = { player.pause(); page = "Library" }) { Icon(Icons.Default.ArrowBack, null) } },
                    actions = {
                        if (page != "Player") {
                            IconButton(onClick = { refresh() }) { Icon(Icons.Default.Refresh, "Refresh") }
                            IconButton(onClick = { page = "Settings" }) { Icon(Icons.Default.Settings, "Settings") }
                        } else {
                            IconButton(onClick = onEnterPip) { Icon(Icons.Default.PictureInPicture, "Picture in picture") }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            bottomBar = {
                if (page != "Player") NavigationBar {
                    listOf("Library" to Icons.Default.VideoLibrary, "Tags" to Icons.Default.Label,
                        "Trash" to Icons.Default.Delete, "Settings" to Icons.Default.Settings).forEach { (name, icon) ->
                        NavigationBarItem(selected = page == name, onClick = { page = name },
                            icon = { Icon(icon, null) }, label = { Text(name) })
                    }
                }
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { padding ->
            when (page) {
                "Library" -> Column(Modifier.padding(padding).fillMaxSize().padding(12.dp)) {
                    OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(),
                        placeholder = { Text("Search videos or tags") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        listOf("All", "Untagged").plus(tags).forEach { t ->
                            FilterChip(selected = activeTag == t, onClick = { activeTag = t }, label = { Text(t) })
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${visible.size} videos", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                        var expanded by remember { mutableStateOf(false) }
                        Box {
                            TextButton(onClick = { expanded = true }) { Text("Sort: $sort"); Icon(Icons.Default.ArrowDropDown, null) }
                            DropdownMenu(expanded, { expanded = false }) {
                                listOf("Name","Newest","Largest","Duration").forEach { s -> DropdownMenuItem(text={Text(s)},onClick={sort=s;expanded=false}) }
                            }
                        }
                        TextButton(onClick = { selected = if (selected.size == visible.size) emptySet() else visible.map { it.uri.toString() }.toSet() }) { Text("Select") }
                    }
                    if (selected.isNotEmpty()) {
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("${selected.size} selected", Modifier.weight(1f))
                            TextButton(onClick = { showTagDialog = true }) { Text("Tag") }
                            TextButton(onClick = { share(visible.filter { it.uri.toString() in selected }) }) { Text("Share") }
                            TextButton(onClick = { visible.filter { it.uri.toString() in selected }.forEach { moveToTrash(it) }; selected = emptySet() }) { Text("Trash") }
                        }
                    }
                    if (visible.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.VideoLibrary, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
                            Text("No videos found", style = MaterialTheme.typography.titleMedium)
                            Text("Grant video permission or use file picker.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Button(onClick = { refresh() }) { Text("Scan again") }
                        }
                    } else LazyVerticalGrid(columns = GridCells.Adaptive(150.dp), contentPadding = PaddingValues(bottom = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        gridItems(visible, key = { it.uri.toString() }) { video ->
                            VideoCard(video, tagMap[video.uri.toString()].orEmpty(), video.uri.toString() in selected,
                                onSelect = { selected = if (it) selected + video.uri.toString() else selected - video.uri.toString() },
                                onClick = { play(video) })
                        }
                    }
                }
                "Player" -> playing?.let { v ->
                    Column(Modifier.padding(padding).fillMaxSize().padding(12.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            tags.forEach { tag ->
                                FilterChip(selected = tag in tagMap[v.uri.toString()].orEmpty(),
                                    onClick = { addTagTo(listOf(v), tag) }, label = { Text(tag) })
                            }
                            IconButton(onClick = { showCreateDialog = true }) { Icon(Icons.Default.Add, "New tag") }
                        }
                        var drag by remember { mutableFloatStateOf(0f) }
                        AndroidView(factory = { ctx -> PlayerView(ctx).apply {
                            player = player
                            useController = true
                            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                        } }, update = { it.player = player },
                            modifier = Modifier.fillMaxWidth().weight(1f).pointerInput(v.uri) {
                                detectHorizontalDragGestures(onHorizontalDrag = { _, amount -> drag += amount },
                                    onDragEnd = {
                                        if (drag < -60) { val i = videos.indexOfFirst { it.uri == v.uri }; videos.getOrNull(i+1)?.let { play(it) } }
                                        if (drag > 60) { val i = videos.indexOfFirst { it.uri == v.uri }; videos.getOrNull(i-1)?.let { play(it) } }
                                        drag = 0f
                                    })
                            })
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Speed", Modifier.width(55.dp))
                            listOf(.5f,.75f,1f,1.25f,1.5f,2f).forEach { s ->
                                TextButton(onClick = { speed=s; player.setPlaybackSpeed(s) }, contentPadding=PaddingValues(horizontal=5.dp)) {
                                    Text("${s}x", color=if(speed==s) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                                }
                            }
                        }
                        Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
                            IconButton(onClick = { player.seekTo((player.currentPosition-10_000).coerceAtLeast(0)) }) { Icon(Icons.Default.Replay10, "Back 10 sec") }
                            IconButton(onClick = { player.seekTo(player.duration.coerceAtLeast(0)-1) }) { Icon(Icons.Default.Forward10, "Forward") }
                            IconButton(onClick = { share(listOf(v)) }) { Icon(Icons.Default.Share, "Share") }
                            IconButton(onClick = { moveToTrash(v) }) { Icon(Icons.Default.Delete, "Move to app trash", tint=MaterialTheme.colorScheme.error) }
                        }
                        Text("Swipe left/right for next/previous · Player supports available audio/subtitle tracks via controller",
                            color=MaterialTheme.colorScheme.onSurfaceVariant, style=MaterialTheme.typography.bodySmall)
                    }
                }
                "Tags" -> Column(Modifier.padding(padding).padding(16.dp)) {
                    Button(onClick = { showCreateDialog = true }) { Icon(Icons.Default.Add, null); Text("Create tag") }
                    LazyColumn {
                        items(tags) { tag ->
                            ListItem(headlineContent={Text(tag)}, supportingContent={Text("${videos.count { tag in tagMap[it.uri.toString()].orEmpty() }} tagged videos")},
                                trailingContent={ IconButton(onClick={
                                    tags=tags-tag
                                    tagMap=tagMap.mapValues { it.value-tag }
                                    persist()
                                }) { Icon(Icons.Default.Delete, "Delete tag") } })
                        }
                    }
                }
                "Trash" -> Column(Modifier.padding(padding).padding(16.dp)) {
                    Text("MediaTag Trash", style=MaterialTheme.typography.titleLarge)
                    Text("Files are hidden from the library; original media is not deleted.")
                    trash.forEach { key ->
                        val v=videos.find { it.uri.toString()==key }
                        if (v!=null) ListItem(headlineContent={Text(v.name)}, trailingContent={
                            Row { TextButton(onClick={trash=trash-key;persist()}){Text("Restore")}
                                TextButton(onClick={trash=trash-key;persist(); Toast.makeText(context,"Removed from app trash list",Toast.LENGTH_SHORT).show()}){Text("Remove")} }
                        })
                    }
                    TextButton(onClick={trash=emptyList();persist()}) { Text("Empty app trash") }
                }
                "Settings" -> Column(Modifier.padding(padding).padding(16.dp)) {
                    Text("Storage & statistics", style=MaterialTheme.typography.titleLarge)
                    val counts = tags.associateWith { t -> videos.count { it.uri.toString() !in trash && t in tagMap[it.uri.toString()].orEmpty() } } +
                        ("Untagged" to videos.count { it.uri.toString() !in trash && tagMap[it.uri.toString()].isNullOrEmpty() })
                    Text("Total videos: ${videos.count { it.uri.toString() !in trash }}")
                    Text("Total size: ${formatSize(videos.filter { it.uri.toString() !in trash }.sumOf { it.size })}")
                    Spacer(Modifier.height(12.dp))
                    counts.forEach { (tag,count) ->
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Text(tag, Modifier.weight(1f)); Text("$count")
                        }
                        LinearProgressIndicator(progress={ if(videos.isEmpty()) 0f else count.toFloat()/videos.size }, Modifier.fillMaxWidth().padding(vertical=4.dp))
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Access: Android scoped media permission. Other file types can be added in a future SAF file browser. Android requires system confirmation for permanent MediaStore deletion; app trash is used here to avoid unexpected deletion.")
                }
            }
        }
    }

    if (showCreateDialog) AlertDialog(onDismissRequest={showCreateDialog=false}, title={Text("Create tag")},
        text={ OutlinedTextField(newTagName,{newTagName=it},label={Text("Tag name")}) },
        confirmButton={TextButton(onClick={
            val t=newTagName.trim()
            if(t.isNotEmpty() && t !in tags) { tags=tags+t; playing?.let { addTagTo(listOf(it),t) }; persist() }
            newTagName="";showCreateDialog=false
        }){Text("Create")} }, dismissButton={TextButton(onClick={showCreateDialog=false}){Text("Cancel")}})
    if (showTagDialog) AlertDialog(onDismissRequest={showTagDialog=false}, title={Text("Apply tag to selected")},
        text={Column { tags.forEach { t -> TextButton(onClick={
            addTagTo(videos.filter { it.uri.toString() in selected },t); showTagDialog=false; selected=emptySet()
        }) { Text(t) } } }}, confirmButton={TextButton(onClick={showTagDialog=false}){Text("Close")}})
}

@Composable
fun VideoCard(v: VideoFile, tags: List<String>, checked: Boolean, onSelect:(Boolean)->Unit, onClick:()->Unit) {
    Card(shape=RoundedCornerShape(14.dp), modifier=Modifier.fillMaxWidth().clickable(onClick=onClick)) {
        Column {
            Box(Modifier.fillMaxWidth().height(105.dp).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment=Alignment.Center) {
                Icon(Icons.Default.PlayCircle, null, Modifier.size(42.dp), tint=MaterialTheme.colorScheme.primary)
                Checkbox(checked, onSelect, Modifier.align(Alignment.TopEnd))
                Text(formatDuration(v.duration), Modifier.align(Alignment.BottomEnd).padding(5.dp), color=MaterialTheme.colorScheme.onSurface)
            }
            Column(Modifier.padding(9.dp)) {
                Text(v.name, maxLines=1, overflow=TextOverflow.Ellipsis, style=MaterialTheme.typography.titleSmall)
                Text("${formatSize(v.size)} · ${tags.joinToString().ifBlank { "Untagged" }}", maxLines=1,
                    overflow=TextOverflow.Ellipsis, style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

fun queryVideos(context: Context): List<VideoFile> {
    val result= mutableListOf<VideoFile>()
    val collection=MediaStore.Video.Media.EXTERNAL_CONTENT_URI
    val projection=arrayOf(MediaStore.Video.Media._ID,MediaStore.Video.Media.DISPLAY_NAME,
        MediaStore.Video.Media.SIZE,MediaStore.Video.Media.DURATION,MediaStore.Video.Media.MIME_TYPE,MediaStore.Video.Media.DATE_ADDED)
    try {
        context.contentResolver.query(collection,projection,null,null,"${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c ->
            val id=c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val name=c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val size=c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            val dur=c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val mime=c.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
            val date=c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
            while(c.moveToNext()) {
                val uri=ContentUris.withAppendedId(collection,c.getLong(id))
                result.add(VideoFile(uri,c.getString(name)?: "Video",c.getLong(size),c.getLong(dur),c.getString(mime)?:"video/*",c.getLong(date)))
            }
        }
    } catch (_: SecurityException) { }
    return result
}
fun loadTags(p: android.content.SharedPreferences)=try { val a=JSONArray(p.getString("tags","[]")); (0 until a.length()).map { a.getString(it) } } catch (_:Exception){ emptyList() }
fun loadTagMap(p: android.content.SharedPreferences)=try {
    val o=JSONObject(p.getString("tagMap","{}")); buildMap { o.keys().forEach { k -> val a=o.getJSONArray(k); put(k,(0 until a.length()).map { a.getString(it) }) } }
} catch (_:Exception){ emptyMap() }
fun loadTrash(p: android.content.SharedPreferences)=try { val a=JSONArray(p.getString("trash","[]")); (0 until a.length()).map { a.getString(it) } } catch (_:Exception){ emptyList() }
fun formatSize(n:Long):String = when { n<1024 -> "$n B"; n<1048576 -> "${n/1024} KB"; else -> String.format("%.1f MB",n/1048576f) }
fun formatDuration(ms:Long):String { val s=ms/1000; return "%d:%02d".format(s/60,s%60) }
