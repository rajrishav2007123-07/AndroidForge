# Library Management SaaS – Android MVP Frontend

Follows the **Library Management SaaS Architecture & Development Blueprint** (confirmed product decisions).

## Confirmed product model implemented in UI

| Decision | Implementation |
|----------|----------------|
| One common app listing | Single APK, role-based screens after login |
| Student onboarding | Discover nearby libraries → select → join |
| Owner access | Mobile only (OwnerMainActivity) |
| WhatsApp | Owner connects own Business number (mock + TODO) |
| Trial | 7-day trial banner + Subscription screen |
| Students free | No student payment UI |
| Custom features | Placeholder notes for one-time charge + flag activation |

## What is frontend-ready (demoable)

- Auth screen (phone + OTP mock)
- Student: Discover list → Library detail → Join / Book seat
- Seat grid with occupied/available states
- Owner: Dashboard (occupancy, pending joins, trial days)
- Owner: Seats setup entry, WhatsApp connect, Subscription plans
- All screens contain clear **Backend TODO** comments pointing to Firestore paths / Cloud Functions / security rules from the blueprint

## Backend work still required (vacant spaces)

Look for `TODO BACKEND` comments in:

- `data/repository/LibraryRepository.kt` – every method
- `ui/auth/AuthActivity.kt` – Firebase Phone Auth + role claims
- `ui/student/BookingActivity.kt` – transactional seat lock
- `ui/owner/*` – subscription webhooks, Secret Manager for WhatsApp tokens

Recommended stack (from blueprint, still open): **Flutter or native + Firebase Auth / Firestore / Cloud Functions / Secret Manager / App Check**.

This project is **native Kotlin** so you can open it directly in Android Studio and produce an APK today while the backend is built.

## How to build APK

1. Unzip
2. Open folder in **Android Studio** (Hedgehog+)
3. Let Gradle sync
4. Run on device/emulator **or** Build → Build Bundle(s)/APK(s) → Build APK(s)

```
./gradlew assembleDebug
```

APK will be at `app/build/outputs/apk/debug/app-debug.apk`

## Package

`com.librarysaas.app`

## Next steps for production

1. Add Firebase BOM + Auth + Firestore + Functions
2. Implement security rules (tenant isolation is mandatory)
3. Replace every mock in `LibraryRepository`
4. Add real location permission flow for discovery
5. Decide payment provider & plan prices (still open in blueprint)
6. Super Admin web console (separate, not in this mobile app)
