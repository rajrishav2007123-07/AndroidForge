# Keep models for future serialization
-keep class com.librarysaas.app.data.model.** { *; }
