package com.librarysaas.app

import android.app.Application
import com.librarysaas.app.data.repository.LibraryRepository

class LibrarySaaSApp : Application() {
    // Simple singleton for MVP. Replace with Hilt/Koin + real Firebase instances later.
    val repository by lazy { LibraryRepository() }

    // TODO BACKEND: Initialize FirebaseApp, App Check, Crashlytics, Analytics here
    // FirebaseApp.initializeApp(this)
    // FirebaseAppCheck.getInstance().installAppCheckProviderFactory(...)
}
