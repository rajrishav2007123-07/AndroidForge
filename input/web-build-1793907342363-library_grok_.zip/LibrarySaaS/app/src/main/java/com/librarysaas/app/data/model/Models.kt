package com.librarysaas.app.data.model

/**
 * Domain models matching the multi-tenant SaaS blueprint.
 * Backend (Firestore) mapping is indicated in comments.
 */

enum class UserRole { STUDENT, OWNER, STAFF, PLATFORM_ADMIN }

data class UserProfile(
    val uid: String,
    val name: String,
    val phone: String,
    val role: UserRole,
    val selectedLibraryId: String? = null, // for student current membership
    // TODO Backend: users/{uid} document in Firestore
)

data class Library(
    val id: String,
    val name: String,
    val address: String,
    val city: String,
    val lat: Double = 0.0,
    val lng: Double = 0.0,
    val openingHours: String = "08:00 - 22:00",
    val facilities: List<String> = emptyList(),
    val isPublic: Boolean = true,
    val ownerId: String = "",
    val trialEndsAt: Long = 0L,          // epoch millis
    val subscriptionStatus: String = "trial", // trial | active | past_due | cancelled
    val planId: String? = null,
    // TODO Backend: libraries/{libraryId}
    // Security: only public fields readable by unauthenticated / students; private fields owner-scoped
)

data class Seat(
    val id: String,
    val libraryId: String,
    val label: String,           // e.g. "A-12"
    val isOccupied: Boolean = false,
    val currentStudentId: String? = null,
    // TODO Backend: libraries/{libraryId}/seats/{seatId}
)

data class TimeSlot(
    val id: String,
    val libraryId: String,
    val startTime: String,       // "09:00"
    val endTime: String,         // "12:00"
    val maxSeats: Int = 0,
    // TODO Backend: libraries/{libraryId}/slots/{slotId}
)

data class Booking(
    val id: String,
    val libraryId: String,
    val studentId: String,
    val seatId: String?,
    val slotId: String?,
    val date: String,            // yyyy-MM-dd
    val status: String = "confirmed", // pending | confirmed | cancelled | completed
    val createdAt: Long = System.currentTimeMillis(),
    // TODO Backend: libraries/{libraryId}/bookings/{bookingId}
    // Critical: use Firestore transaction + deterministic lock to prevent double booking
)

data class Invoice(
    val id: String,
    val libraryId: String,
    val studentId: String,
    val amount: Double,
    val currency: String = "INR",
    val dueDate: String,
    val status: String = "pending", // pending | paid | overdue | cancelled
    val description: String = "",
    // TODO Backend: libraries/{libraryId}/invoices/{invoiceId}
)

data class Membership(
    val id: String,
    val libraryId: String,
    val studentId: String,
    val status: String = "pending", // pending | active | suspended | left
    val joinedAt: Long = 0L,
    // TODO Backend: libraries/{libraryId}/members/{memberId}  or  users/{uid}/memberships
)
