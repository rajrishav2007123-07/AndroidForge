package com.librarysaas.app.data.repository

import com.librarysaas.app.data.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * FRONTEND MOCK REPOSITORY
 *
 * All methods return local mock data so the UI is fully demo-able.
 * Replace each method body with real Firebase / Cloud Function calls
 * when backend is ready. Comments indicate the exact backend work.
 */
class LibraryRepository {

    // ------------------------------------------------------------------
    // AUTH
    // ------------------------------------------------------------------
    suspend fun signInWithPhone(phone: String, otp: String): UserProfile {
        // TODO BACKEND:
        // 1. Firebase Auth: PhoneAuthProvider.verifyPhoneNumber → signInWithCredential
        // 2. After auth, fetch users/{uid} from Firestore
        // 3. If document missing → create with role selection flow
        // 4. Never trust client-supplied role; server sets / validates role
        delay(800)
        return UserProfile(
            uid = "mock_uid_${phone.takeLast(4)}",
            name = "Demo User",
            phone = phone,
            role = UserRole.STUDENT, // change to OWNER for owner demo
            selectedLibraryId = null
        )
    }

    // ------------------------------------------------------------------
    // PUBLIC LIBRARY DIRECTORY (Student discovery)
    // ------------------------------------------------------------------
    fun getNearbyLibraries(lat: Double, lng: Double): Flow<List<Library>> = flow {
        // TODO BACKEND:
        // Firestore query: libraries where isPublic == true
        // Optional: GeoFirestore or Cloud Function with distance filter
        // Only return public fields (name, address, hours, facilities, lat/lng)
        delay(600)
        emit(listOf(
            Library("lib_001", "Patna Central Library", "Boring Road, Patna", "Patna", 25.61, 85.14,
                facilities = listOf("AC", "WiFi", "Power"), trialEndsAt = System.currentTimeMillis() + 5 * 86400000),
            Library("lib_002", "GEC Study Hub", "Madhubani", "Madhubani", 26.35, 86.07,
                facilities = listOf("WiFi", "Parking"), trialEndsAt = System.currentTimeMillis() + 2 * 86400000),
            Library("lib_003", "Focus Reading Room", "Rajendra Nagar, Patna", "Patna", 25.60, 85.15,
                facilities = listOf("AC", "Silent Zone"))
        ))
    }

    suspend fun getLibraryDetail(libraryId: String): Library? {
        // TODO BACKEND: libraries/{libraryId}  (public snapshot)
        delay(400)
        return Library(libraryId, "Patna Central Library", "Boring Road, Patna", "Patna",
            facilities = listOf("AC", "WiFi", "Power", "CCTV"))
    }

    // ------------------------------------------------------------------
    // MEMBERSHIP / JOIN
    // ------------------------------------------------------------------
    suspend fun requestMembership(libraryId: String, studentId: String): Membership {
        // TODO BACKEND:
        // Cloud Function or transaction:
        // - Verify student is authenticated
        // - Create memberships doc with status=pending (or auto-approve per library setting)
        // - Notify owner
        delay(700)
        return Membership("mem_${System.currentTimeMillis()}", libraryId, studentId, "pending")
    }

    // ------------------------------------------------------------------
    // SEATS & BOOKING (critical path)
    // ------------------------------------------------------------------
    fun getSeats(libraryId: String): Flow<List<Seat>> = flow {
        // TODO BACKEND: libraries/{libraryId}/seats
        delay(300)
        emit((1..24).map {
            Seat("seat_$it", libraryId, "A-$it", isOccupied = it % 5 == 0)
        })
    }

    suspend fun createBooking(libraryId: String, studentId: String, seatId: String?, date: String): Booking {
        // TODO BACKEND (VERY IMPORTANT):
        // Use Firestore transaction + deterministic document lock
        // (e.g. seats/{seatId}/locks/{date} or a bookings lock collection)
        // Check subscription status of library before allowing
        // Reject if seat already taken for that slot/date
        delay(900)
        return Booking("book_${System.currentTimeMillis()}", libraryId, studentId, seatId, null, date)
    }

    // ------------------------------------------------------------------
    // OWNER SIDE
    // ------------------------------------------------------------------
    suspend fun createLibrary(ownerId: String, name: String, address: String, city: String): Library {
        // TODO BACKEND:
        // Cloud Function:
        // - Create libraries/{newId}
        // - Set ownerId, trialEndsAt = now + 7 days, subscriptionStatus = "trial"
        // - Create owner membership / claims
        // - Return libraryId
        delay(1000)
        return Library("lib_new_${System.currentTimeMillis()}", name, address, city,
            ownerId = ownerId, trialEndsAt = System.currentTimeMillis() + 7 * 86400000L,
            subscriptionStatus = "trial")
    }

    fun getOwnerDashboard(libraryId: String): Flow<Map<String, Any>> = flow {
        // TODO BACKEND: aggregate queries or Cloud Function for occupancy, pending joins, overdue invoices
        delay(500)
        emit(mapOf(
            "totalSeats" to 40,
            "occupied" to 18,
            "pendingJoins" to 3,
            "overdueInvoices" to 2,
            "trialDaysLeft" to 5
        ))
    }

    // ------------------------------------------------------------------
    // SUBSCRIPTION / TRIAL
    // ------------------------------------------------------------------
    suspend fun getSubscriptionStatus(libraryId: String): String {
        // TODO BACKEND: libraries/{libraryId}.subscriptionStatus + trialEndsAt
        // Also check Stripe / Razorpay / Play Billing webhook state
        delay(300)
        return "trial"
    }

    // ------------------------------------------------------------------
    // WHATSAPP (owner connects own number)
    // ------------------------------------------------------------------
    suspend fun connectWhatsApp(libraryId: String, businessNumber: String): Boolean {
        // TODO BACKEND:
        // 1. Store Meta permanent token in Secret Manager (never in client)
        // 2. libraries/{libraryId}/whatsapp = { number, status, connectedAt }
        // 3. Cloud Function verifies number via Meta API
        delay(1200)
        return true
    }

    // ------------------------------------------------------------------
    // INVOICES / FEES
    // ------------------------------------------------------------------
    fun getStudentInvoices(libraryId: String, studentId: String): Flow<List<Invoice>> = flow {
        // TODO BACKEND: libraries/{libraryId}/invoices where studentId == ...
        delay(400)
        emit(listOf(
            Invoice("inv_1", libraryId, studentId, 1500.0, dueDate = "2026-11-15", status = "pending", description = "Monthly seat fee"),
            Invoice("inv_2", libraryId, studentId, 1500.0, dueDate = "2026-10-15", status = "paid", description = "Monthly seat fee")
        ))
    }
}
