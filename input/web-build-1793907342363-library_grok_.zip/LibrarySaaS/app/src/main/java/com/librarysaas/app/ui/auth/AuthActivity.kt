package com.librarysaas.app.ui.auth

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.librarysaas.app.LibrarySaaSApp
import com.librarysaas.app.data.model.UserRole
import com.librarysaas.app.databinding.ActivityAuthBinding
import com.librarysaas.app.ui.owner.OwnerMainActivity
import com.librarysaas.app.ui.student.StudentMainActivity
import kotlinx.coroutines.launch

/**
 * Entry point. One common app → role resolved after auth.
 *
 * BACKEND WORK (later):
 * - Replace mock with FirebaseAuth phone verification
 * - After successful auth, read users/{uid} 
 * - If no profile → show role selection (Student / Create Library as Owner)
 * - Persist selectedLibraryId for students
 */
class AuthActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAuthBinding
    // Demo toggle: set true to open Owner flow
    private val forceOwnerDemo = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAuthBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnContinue.setOnClickListener {
            val phone = binding.etPhone.text?.toString()?.trim().orEmpty()
            val otp = binding.etOtp.text?.toString()?.trim().orEmpty()
            if (phone.length < 8 || otp.length < 4) {
                Toast.makeText(this, "Enter valid phone + OTP (demo)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            doLogin(phone, otp)
        }
    }

    private fun doLogin(phone: String, otp: String) {
        binding.progress.visibility = View.VISIBLE
        binding.btnContinue.isEnabled = false
        lifecycleScope.launch {
            try {
                val repo = (application as LibrarySaaSApp).repository
                val profile = repo.signInWithPhone(phone, otp)
                // In real app: profile.role comes from server
                val role = if (forceOwnerDemo) UserRole.OWNER else profile.role
                when (role) {
                    UserRole.OWNER, UserRole.STAFF -> {
                        startActivity(Intent(this@AuthActivity, OwnerMainActivity::class.java))
                    }
                    else -> {
                        startActivity(Intent(this@AuthActivity, StudentMainActivity::class.java))
                    }
                }
                finish()
            } catch (e: Exception) {
                Toast.makeText(this@AuthActivity, "Login failed: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                binding.progress.visibility = View.GONE
                binding.btnContinue.isEnabled = true
            }
        }
    }
}
