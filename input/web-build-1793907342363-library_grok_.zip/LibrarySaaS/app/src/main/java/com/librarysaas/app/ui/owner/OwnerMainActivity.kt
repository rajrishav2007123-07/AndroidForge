package com.librarysaas.app.ui.owner

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.librarysaas.app.LibrarySaaSApp
import com.librarysaas.app.R
import com.librarysaas.app.databinding.ActivityOwnerMainBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Owner mobile experience (confirmed: mobile only).
 *
 * BACKEND:
 * - On first owner login → createLibrary Cloud Function sets trialEndsAt = now+7d
 * - All owner writes must verify uid owns the libraryId
 * - Subscription gate on paid features after trial
 */
class OwnerMainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOwnerMainBinding
    // Demo library id – real app gets from user claims / profile
    private val demoLibraryId = "lib_001"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOwnerMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        lifecycleScope.launch {
            (application as LibrarySaaSApp).repository.getOwnerDashboard(demoLibraryId)
                .collectLatest { data ->
                    binding.tvOccupancy.text = "${data["occupied"]} / ${data["totalSeats"]} seats occupied"
                    binding.tvPending.text = "${data["pendingJoins"]} pending join requests"
                    binding.tvTrial.text = "Trial Active – ${data["trialDaysLeft"]} days left"
                }
        }

        binding.btnUpgrade.setOnClickListener {
            startActivity(Intent(this, SubscriptionActivity::class.java))
        }
        binding.btnSeats.setOnClickListener {
            startActivity(Intent(this, SeatSetupActivity::class.java).apply {
                putExtra("libraryId", demoLibraryId)
            })
        }
        binding.btnWhatsApp.setOnClickListener {
            lifecycleScope.launch {
                val ok = (application as LibrarySaaSApp).repository.connectWhatsApp(demoLibraryId, "+919999999999")
                Toast.makeText(this@OwnerMainActivity,
                    if (ok) "WhatsApp connected (mock). Real: store token in Secret Manager only."
                    else "Failed", Toast.LENGTH_LONG).show()
            }
        }

        binding.bottomNav.setOnItemSelectedListener {
            when (it.itemId) {
                R.id.nav_sub -> startActivity(Intent(this, SubscriptionActivity::class.java))
                R.id.nav_students -> Toast.makeText(this, "Students list – backend: members collection", Toast.LENGTH_SHORT).show()
                R.id.nav_fees -> Toast.makeText(this, "Fees & invoices – backend: invoices + payment webhooks", Toast.LENGTH_SHORT).show()
            }
            true
        }
    }
}
