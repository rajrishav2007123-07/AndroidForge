package com.librarysaas.app.ui.owner

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar

class SeatSetupActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val toolbar = MaterialToolbar(this).apply {
            title = "Seats & Time Slots"
            setNavigationOnClickListener { finish() }
        }
        val info = TextView(this).apply {
            text = """
                FRONTEND: Grid of seats + add/edit slot UI goes here.
                
                BACKEND TODO:
                • libraries/{libraryId}/seats/{seatId}
                • libraries/{libraryId}/slots/{slotId}
                • Only owner / permitted staff can write
                • Validate maxSeats vs physical seats
            """.trimIndent()
            setPadding(32, 32, 32, 32)
            textSize = 14f
        }
        val root = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            addView(toolbar)
            addView(info)
        }
        setContentView(root)
    }
}
