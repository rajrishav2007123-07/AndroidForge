package com.librarysaas.app.ui.owner

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton

/**
 * Trial → Paid plan selection.
 *
 * BACKEND / OPEN DECISIONS (from blueprint):
 * - Payment provider (Razorpay / Stripe / Play Billing)
 * - Exact plan prices & quotas
 * - Grace period length
 * - Webhook → update libraries/{id}.subscriptionStatus
 * - Custom feature one-time payment then catalogue activation
 */
class SubscriptionActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val toolbar = MaterialToolbar(this).apply {
            title = "Subscription"
            setNavigationOnClickListener { finish() }
        }
        val info = TextView(this).apply {
            text = """
                Current: 7-day Trial
                
                Plans (placeholder – prices still open decision):
                • Starter
                • Growth
                • Pro
                
                BACKEND TODO:
                1. Create plan documents in Firestore
                2. Checkout session via chosen provider
                3. Signed webhook → set subscriptionStatus = active
                4. Entitlement check on every owner write after trial
                5. Custom feature: one-time charge → feature catalogue → per-tenant flag
            """.trimIndent()
            setPadding(32, 24, 32, 16)
            textSize = 14f
        }
        val btn = MaterialButton(this).apply {
            text = "Start Checkout (mock)"
            setOnClickListener {
                android.widget.Toast.makeText(this@SubscriptionActivity,
                    "Payment provider still open decision – see blueprint", android.widget.Toast.LENGTH_LONG).show()
            }
        }
        val root = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(16, 0, 16, 16)
            addView(toolbar)
            addView(info)
            addView(btn)
        }
        setContentView(root)
    }
}
