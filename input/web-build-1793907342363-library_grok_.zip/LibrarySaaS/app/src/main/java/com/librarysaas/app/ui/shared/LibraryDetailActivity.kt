package com.librarysaas.app.ui.shared

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.librarysaas.app.LibrarySaaSApp
import com.librarysaas.app.databinding.ActivityLibraryDetailBinding
import com.librarysaas.app.ui.student.BookingActivity
import kotlinx.coroutines.launch

class LibraryDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLibraryDetailBinding
    private var libraryId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLibraryDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        libraryId = intent.getStringExtra("libraryId") ?: return finish()
        binding.tvName.text = intent.getStringExtra("libraryName") ?: "Library"

        lifecycleScope.launch {
            val lib = (application as LibrarySaaSApp).repository.getLibraryDetail(libraryId)
            lib?.let {
                binding.tvName.text = it.name
                binding.tvAddress.text = it.address
                binding.tvHours.text = "Hours: ${it.openingHours}"
                binding.tvFacilities.text = "Facilities: ${it.facilities.joinToString()}"
            }
        }

        binding.btnJoin.setOnClickListener {
            lifecycleScope.launch {
                // TODO: real studentId from FirebaseAuth.currentUser.uid
                (application as LibrarySaaSApp).repository.requestMembership(libraryId, "mock_student")
                Toast.makeText(this@LibraryDetailActivity, "Join request sent (mock)", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnBook.setOnClickListener {
            startActivity(Intent(this, BookingActivity::class.java).apply {
                putExtra("libraryId", libraryId)
            })
        }
    }
}
