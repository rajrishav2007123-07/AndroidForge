package com.librarysaas.app.ui.student

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.librarysaas.app.LibrarySaaSApp
import com.librarysaas.app.data.model.Seat
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Seat booking screen.
 *
 * BACKEND CRITICAL PATH:
 * createBooking must run inside a Firestore transaction that locks the seat/date
 * and verifies the library's subscription is active or in trial.
 */
class BookingActivity : AppCompatActivity() {

    private var libraryId = ""
    private val seats = mutableListOf<Seat>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        libraryId = intent.getStringExtra("libraryId") ?: return finish()

        val toolbar = MaterialToolbar(this).apply {
            title = "Select Seat"
            setNavigationOnClickListener { finish() }
        }
        val recycler = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@BookingActivity, 4)
            setPadding(16, 16, 16, 16)
        }

        val root = androidx.constraintlayout.widget.ConstraintLayout(this)
        root.addView(toolbar)
        root.addView(recycler)
        setContentView(root)

        val adapter = object : RecyclerView.Adapter<VH>() {
            override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): VH {
                val tv = android.widget.TextView(parent.context).apply {
                    setPadding(24, 32, 24, 32)
                    textSize = 14f
                    gravity = android.view.Gravity.CENTER
                }
                return VH(tv)
            }
            override fun getItemCount() = seats.size
            override fun onBindViewHolder(holder: VH, position: Int) {
                val s = seats[position]
                holder.tv.text = s.label
                holder.tv.setBackgroundColor(if (s.isOccupied) 0xFFFFCDD2.toInt() else 0xFFC8E6C9.toInt())
                holder.itemView.setOnClickListener {
                    if (s.isOccupied) {
                        Toast.makeText(this@BookingActivity, "Occupied", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    lifecycleScope.launch {
                        val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                        (application as LibrarySaaSApp).repository.createBooking(
                            libraryId, "mock_student", s.id, date
                        )
                        Toast.makeText(this@BookingActivity, "Booked ${s.label} (mock)", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                }
            }
        }
        recycler.adapter = adapter

        lifecycleScope.launch {
            (application as LibrarySaaSApp).repository.getSeats(libraryId).collectLatest {
                seats.clear()
                seats.addAll(it)
                adapter.notifyDataSetChanged()
            }
        }
    }

    class VH(val tv: android.widget.TextView) : RecyclerView.ViewHolder(tv)
}
