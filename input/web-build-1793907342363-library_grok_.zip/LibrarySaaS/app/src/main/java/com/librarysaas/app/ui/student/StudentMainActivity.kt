package com.librarysaas.app.ui.student

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView
import com.librarysaas.app.LibrarySaaSApp
import com.librarysaas.app.R
import com.librarysaas.app.data.model.Library
import com.librarysaas.app.databinding.ActivityStudentMainBinding
import com.librarysaas.app.ui.shared.LibraryDetailActivity
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Student experience – Discover nearby libraries, then join / book / invoices.
 *
 * BACKEND:
 * - Location optional (ACCESS_FINE_LOCATION)
 * - Query public libraries (isPublic == true)
 * - Membership check before allowing booking
 */
class StudentMainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStudentMainBinding
    private val libraries = mutableListOf<Library>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStudentMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Simple: show Discover list in container
        showDiscover()

        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_discover -> showDiscover()
                R.id.nav_bookings -> showPlaceholder("My Bookings\n\nBackend: query libraries/{id}/bookings where studentId == currentUid")
                R.id.nav_invoices -> showPlaceholder("Invoices\n\nBackend: libraries/{id}/invoices filtered by student")
                R.id.nav_profile -> showPlaceholder("Profile & Notification controls\n\nBackend: users/{uid}")
            }
            true
        }
    }

    private fun showDiscover() {
        val recycler = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@StudentMainActivity)
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setPadding(16, 16, 16, 16)
            clipToPadding = false
        }
        binding.fragmentContainer.removeAllViews()
        binding.fragmentContainer.addView(recycler)

        val adapter = object : RecyclerView.Adapter<LibVH>() {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LibVH {
                val card = LayoutInflater.from(parent.context)
                    .inflate(android.R.layout.simple_list_item_2, parent, false)
                return LibVH(card)
            }
            override fun getItemCount() = libraries.size
            override fun onBindViewHolder(holder: LibVH, position: Int) {
                val lib = libraries[position]
                holder.title.text = lib.name
                holder.subtitle.text = "${lib.address} • ${lib.facilities.joinToString()}"
                holder.itemView.setOnClickListener {
                    startActivity(Intent(this@StudentMainActivity, LibraryDetailActivity::class.java).apply {
                        putExtra("libraryId", lib.id)
                        putExtra("libraryName", lib.name)
                    })
                }
            }
        }
        recycler.adapter = adapter

        lifecycleScope.launch {
            (application as LibrarySaaSApp).repository.getNearbyLibraries(25.6, 85.1)
                .collectLatest { list ->
                    libraries.clear()
                    libraries.addAll(list)
                    adapter.notifyDataSetChanged()
                }
        }
    }

    private fun showPlaceholder(msg: String) {
        binding.fragmentContainer.removeAllViews()
        binding.fragmentContainer.addView(TextView(this).apply {
            text = msg
            setPadding(48, 48, 48, 48)
            textSize = 16f
        })
    }

    class LibVH(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(android.R.id.text1)
        val subtitle: TextView = view.findViewById(android.R.id.text2)
    }
}
