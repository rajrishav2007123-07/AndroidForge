# BACKEND IMPLEMENTATION SPACE — DO NOT PUT SECRETS IN THE APP

This project intentionally ships with a complete **demo frontend** and backend integration placeholders.
The blueprint recommends Flutter + Firebase/Google Cloud, but notes that this stack is a recommendation,
not a formally confirmed choice. Confirm it before production.

## 1. Suggested project structure
Create backend separately (recommended: Firebase Authentication + Firestore + Cloud Functions 2nd gen/Cloud Run,
Cloud Storage, App Check, Secret Manager, Cloud Scheduler and Cloud Tasks).

```
backend/
  functions/src/
    auth/                 # OTP, role resolution, account lifecycle
    tenants/              # create/claim library, approve/publish, membership
    discovery/            # public directory, geohash search
    seats/                # seat/slot CRUD
    bookings/             # transaction-backed reservation locks
    invoices/             # invoice lifecycle, integer paise
    payments/             # payment orders, signed webhooks, reconciliation
    subscriptions/        # 7-day trial, plan entitlements, renewal
    whatsapp/             # Meta onboarding, webhooks, consent, outbox worker
    features/             # custom request, quotes, catalogue, tenant activation
    staff/                # invites, granular permissions
    reports/              # aggregates and exports
    notifications/        # in-app + push/outbox
    support/              # support tickets
    shared/               # authz, tenant checks, validation, audit, idempotency
  firestore.rules
  firestore.indexes.json
  storage.rules
```

## 2. Firestore data map from the blueprint
Global collections:
- `users/{uid}`
- `publicLibraries/{libraryId}` — curated public projection only
- `subscriptions/{libraryId}`
- `platformAdmins/{uid}`
- `platformFeatures/{featureId}`
- `featureRequests/{requestId}`
- `subscriptionEvents/{eventId}`
- `customDevelopmentPayments/{paymentId}`

Tenant collections:
- `libraries/{libraryId}/members/{uid}`
- `students`, `seats`, `timeSlots`, `reservations`, `reservationLocks`
- `feeInvoices`, `payments`, `staff`, `settings`, `whatsapp`
- `messageOutbox`, `messageLogs`, `auditLogs`

## 3. Integration points in this frontend
Search `BACKEND TODO` or `Demo UI only` in `lib/main.dart`.
Replace each demo callback with a typed repository/controller method.
Recommended interfaces:
- `AuthRepository`: signInWithPhoneOtp, signOut, currentUser, resolveRole
- `LibraryRepository`: createLibrary, getMyLibraries, getPublicLibraries, requestJoin, switchTenant
- `SeatRepository`: listSeats, createSeat, updateSeat, listSlots
- `BookingRepository`: createBooking, cancelBooking, listBookings
- `StudentRepository`: listStudents, addStudent, updateMembership
- `InvoiceRepository`: createInvoice, listInvoices, issueInvoice
- `PaymentRepository`: createPaymentOrder, listPayments (never mark paid from client)
- `SubscriptionRepository`: getSubscription, createCheckoutSession
- `WhatsAppRepository`: beginEmbeddedSignup, disconnect, getConnection, updateConsent
- `FeatureRepository`: submitRequest, listCatalogue, setTenantActivation
- `StaffRepository`: inviteStaff, updatePermissions, revokeStaff
- `ReportsRepository`: getDashboardSummary, getOccupancy, exportReport
- `NotificationRepository`: listNotifications, updatePreferences
- `SupportRepository`: createTicket, listTickets

## 4. Mandatory security rules
- Firebase UID is identity; never use email as authorization key.
- Every private read/write is tenant-scoped by immutable `libraryId`.
- Backend resolves membership from trusted UID; never trust client `libraryId` alone.
- Default-deny Firestore and Storage Rules. Rules are not query filters.
- Admin SDK bypasses Firestore Rules; repeat authorization in every privileged endpoint.
- Owner, staff and student permissions are distinct; staff permissions are granular.
- Payment status, subscription status, booking locks and trial timestamps are server-owned.
- WhatsApp tokens, payment secrets and webhook secrets live in Secret Manager only.
- Record audit actor, tenant, action, target, result and correlation ID.
- Test cross-tenant isolation: Library A must never read/write Library B private data.

## 5. Workflows that must be server-authoritative
### Booking
Client -> callable function -> auth + membership + entitlement -> Firestore transaction on deterministic
`seatId + bookingDate + slotId` lock -> reservation result. Availability shown in UI is advisory only.

### Payments
Backend creates order. Provider sends signed webhook. Verify signature, amount, currency, tenant, invoice,
deduplicate provider event, then update payment/invoice. Never trust client success callback.

### WhatsApp reminders
Scheduler -> bounded query -> outbox -> Cloud Tasks worker -> check invoice + recorded consent + tenant
connection + rate limits -> Meta API -> status webhook. Use retry/backoff and idempotency key.

### Custom feature
Owner request -> admin review -> quote + scope -> owner acceptance -> verified one-time payment ->
development behind feature flag -> regression/security review -> catalogue -> per-library activation record.

## 6. Open decisions from blueprint — do not hard-code
- Flutter/Firebase stack approval
- Android-only vs Android+iOS
- payment provider and Play Billing approach
- subscription plan prices and quotas
- grace-period length (3 days was only a proposal)
- WhatsApp cost pass-through/allowance
- data retention, support SLA, custom-feature maintenance/IP terms

## 7. Production acceptance checklist
- OTP abuse controls, MFA for Super Admin, App Check
- tenant isolation and rules emulator tests
- booking concurrency + idempotency tests
- payment webhook signature/replay/refund tests
- WhatsApp consent/opt-out and delivery retry tests
- backup restore, monitoring, budgets and rollback
- privacy policy, DPDP/legal review, deletion/export workflow
- low-network, small-screen, Hindi/English, accessibility and device tests

## Demo data warning
All names, counts, library details, seats, invoices and money values in this app are illustrative local UI data.
No Firebase project, payment gateway, Meta connection, production auth or persistent database is configured.
