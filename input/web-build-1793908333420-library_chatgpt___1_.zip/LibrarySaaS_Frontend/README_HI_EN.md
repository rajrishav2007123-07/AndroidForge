# LibraryOS — Android Flutter Frontend Starter

## What is included
- Single common mobile app with role preview: Owner, Student and Super Admin.
- Owner workspace: dashboard, students, seats/slots, bookings, fees/invoices, payments, staff, WhatsApp, reports,
  subscription, custom features, library profile, notifications, settings and support.
- Student workspace: nearby library discovery, selected library, seat map, bookings, own invoices/payments,
  notifications, profile and help.
- Super Admin preview: platform overview, library tenant list, subscriptions, feature catalogue/requests,
  WhatsApp health, support and audit log screens.
- Responsive Material 3 UI, demo data, dialogs, status chips and empty integration callouts.
- Backend TODO document with exact suggested services, Firestore paths, repository interfaces and security checklist.

## Important: frontend starter, not production backend
Buttons currently show demo messages/placeholders. The app does not authenticate real users, persist data remotely,
process payments, reserve seats transactionally or send WhatsApp messages. Connect the backend before using real data.
The attached architecture blueprint says Flutter/Firebase is recommended but not yet formally confirmed. It also leaves
payment provider, plan prices, grace period and platform billing approach open.

## Open in Android Studio
1. Install Flutter SDK and Android Studio (Flutter + Dart plugins).
2. Extract this ZIP.
3. Android Studio -> Open -> select the extracted `LibrarySaaS_Frontend` folder.
4. Set Flutter SDK path in Android Studio (Settings -> Languages & Frameworks -> Flutter).
5. In terminal at project root run:
   ```
   flutter pub get
   flutter doctor
   ```
6. Run on emulator/device with the green Run button or:
   ```
   flutter run
   ```
7. Build APK:
   ```
   flutter build apk --release
   ```
   APK output: `build/app/outputs/flutter-apk/app-release.apk`

Flutter generates `android/local.properties` and the Gradle wrapper JAR on first toolchain setup.
Do not copy credentials into source control.

## Demo role switch
Use the role selector in the left navigation (or navigation drawer on narrow screens) to preview Owner,
Student and Super Admin screens. This is only a UI preview. Real roles must be resolved from Firebase UID and
trusted membership/admin records; hiding navigation is not authorization.

## Package structure
- `lib/main.dart` — demo frontend screens and navigation.
- `BACKEND_TODO.md` — backend integration blueprint and placeholders.
- `android/` — Android Gradle/Flutter host configuration.
- `pubspec.yaml` — Flutter package manifest.

## Based on uploaded blueprint
The app follows the one-common-app model, mobile-only library owner experience, separate student/owner navigation,
seven-day trial display, free student experience, per-library WhatsApp connection concept, and one-time custom feature
request lifecycle. The private Super Admin UI is a preview only; the blueprint recommends a separate private web console.
