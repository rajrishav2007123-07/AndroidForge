Flutter Android host. Open the project root in Android Studio with Flutter and Dart plugins installed.
Flutter SDK generates local.properties and the Gradle wrapper bootstrap during `flutter pub get` / first build.
