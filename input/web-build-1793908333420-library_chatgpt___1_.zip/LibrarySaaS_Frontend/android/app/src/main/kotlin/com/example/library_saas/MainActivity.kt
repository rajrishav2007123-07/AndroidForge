package com.example.library_saas
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
