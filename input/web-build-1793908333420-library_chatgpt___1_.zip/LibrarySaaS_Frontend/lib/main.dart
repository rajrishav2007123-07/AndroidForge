
import 'package:flutter/material.dart';

void main() => runApp(const LibrarySaasApp());

class LibrarySaasApp extends StatelessWidget {
  const LibrarySaasApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Library SaaS',
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF3457D5), brightness: Brightness.light),
      scaffoldBackgroundColor: const Color(0xFFF5F7FB),
            inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: const Color(0xFFF4F6FA),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide.none),
      ),
    ),
    home: const AppShell(),
  );
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  String role = 'Owner';
  String page = 'Dashboard';
  String library = 'Apex Study Library';
  final List<Map<String, String>> students = [
    {'name':'Aarav Kumar','phone':'+91 98765 43210','status':'Active','seat':'A-12'},
    {'name':'Ananya Singh','phone':'+91 91234 56780','status':'Active','seat':'B-04'},
    {'name':'Rohan Das','phone':'+91 99887 76655','status':'Pending','seat':'—'},
    {'name':'Priya Sharma','phone':'+91 90000 11223','status':'Active','seat':'C-08'},
  ];
  final List<Map<String, String>> libraries = [
    {'name':'Apex Study Library','area':'Boring Road, Patna','distance':'1.2 km','seats':'42 seats available'},
    {'name':'Knowledge Hub','area':'Kankarbagh, Patna','distance':'2.8 km','seats':'18 seats available'},
    {'name':'Focus Reading Zone','area':'Rajendra Nagar, Patna','distance':'3.4 km','seats':'9 seats available'},
  ];
  int selectedTab = 0;
  final ownerPages = ['Dashboard','Students','Seats & Slots','Bookings','Fees & Invoices','Payments','Staff','WhatsApp','Reports','Subscription','Custom Features','Library Profile','Notifications','Settings','Support'];
  final studentPages = ['Discover Libraries','My Library','Seat Map','My Bookings','My Invoices','Payments','Notifications','Profile','Help & Support'];
  final adminPages = ['Platform Overview','Libraries','Subscriptions','Feature Catalogue','Feature Requests','WhatsApp Health','Support Tickets','Audit Logs'];

  List<String> get pages => role == 'Owner' ? ownerPages : role == 'Student' ? studentPages : adminPages;

  void go(String p) => setState(() { page = p; selectedTab = 0; });
  void toast(String msg) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));

  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.sizeOf(context).width < 760;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white, surfaceTintColor: Colors.white,
        titleSpacing: 18,
        title: Row(children: [
          Container(width: 36,height: 36,decoration: BoxDecoration(color: const Color(0xFFE9EDFF),borderRadius: BorderRadius.circular(11)),child: const Icon(Icons.local_library_rounded,color: Color(0xFF3457D5))),
          const SizedBox(width: 10),
          const Text('LibraryOS',style: TextStyle(fontWeight: FontWeight.w800,letterSpacing:-.4)),
        ]),
        actions: [
          if (!isMobile) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: DropdownButton<String>(
            value: role, underline: const SizedBox(), items: ['Owner','Student','Super Admin'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),
            onChanged:(v)=>setState(() { role=v!; page=pages.first; }),
          )),
          IconButton(onPressed:()=>go('Notifications'),icon: const Icon(Icons.notifications_none_rounded)),
          const SizedBox(width: 6),
          const Padding(padding: EdgeInsets.only(right: 16),child: CircleAvatar(radius:17,backgroundColor:Color(0xFFE8ECFF),child:Text('AK',style:TextStyle(color:Color(0xFF3457D5),fontWeight:FontWeight.bold)))),
        ],
      ),
      drawer: isMobile ? Drawer(child: _navigation()) : null,
      body: Row(children: [
        if (!isMobile) SizedBox(width: 248, child: _navigation()),
        Expanded(child: Column(children: [
          if (role == 'Owner') _tenantBar(),
          Expanded(child: _content()),
        ])),
      ]),
      bottomNavigationBar: isMobile ? NavigationBar(
        selectedIndex: selectedTab.clamp(0,2),
        onDestinationSelected:(i)=>setState(() { selectedTab=i; page=(role=='Student'?['Discover Libraries','My Bookings','Profile']:role=='Owner'?['Dashboard','Students','Bookings']:['Platform Overview','Libraries','Feature Requests'])[i]; }),
        destinations: const [
          NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),
          NavigationDestination(icon:Icon(Icons.people_outline),selectedIcon:Icon(Icons.people),label:'People'),
          NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'Account'),
        ],
      ):null,
    );
  }

  Widget _tenantBar() => Container(
    color: Colors.white,
    padding: const EdgeInsets.fromLTRB(20,0,20,12),
    child: Row(children: [
      const Icon(Icons.apartment_rounded,size:18,color:Color(0xFF64748B)),
      const SizedBox(width:8),
      Expanded(child: Text(library,style:const TextStyle(fontWeight:FontWeight.w600))),
      Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:6),decoration:BoxDecoration(color:const Color(0xFFEAF7EF),borderRadius:BorderRadius.circular(20)),child:const Text('7-day trial',style:TextStyle(color:Color(0xFF16834A),fontSize:12,fontWeight:FontWeight.w700))),
      const SizedBox(width:8),
      IconButton(onPressed:()=>_dialog('Switch library','Choose a library workspace.',['Apex Study Library','Knowledge Hub']),icon:const Icon(Icons.swap_horiz_rounded)),
    ]),
  );

  Widget _navigation() => Container(
    color: Colors.white,
    child: Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Padding(padding:const EdgeInsets.fromLTRB(18,18,18,8),child:DropdownButtonFormField<String>(
        value:role,decoration:const InputDecoration(labelText:'Preview role',contentPadding:EdgeInsets.symmetric(horizontal:12,vertical:8)),
        items:['Owner','Student','Super Admin'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),
        onChanged:(v)=>setState(() { role=v!; page=pages.first; }),
      )),
      Padding(padding:const EdgeInsets.fromLTRB(20,18,20,8),child:Text(role.toUpperCase()+' WORKSPACE',style:const TextStyle(fontSize:10,letterSpacing:1.3,fontWeight:FontWeight.w800,color:Color(0xFF94A3B8)))),
      Expanded(child:ListView(padding:const EdgeInsets.symmetric(horizontal:10),children:pages.map((p){
        final active=page==p;
        final icon=_iconFor(p);
        return Padding(padding:const EdgeInsets.symmetric(vertical:2),child:ListTile(
          dense:true,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(12)),
          selected:active,selectedTileColor:const Color(0xFFEEF1FF),
          leading:Icon(icon,color:active?const Color(0xFF3457D5):const Color(0xFF64748B),size:20),
          title:Text(p,style:TextStyle(fontSize:13,fontWeight:active?FontWeight.w700:FontWeight.w500,color:active?const Color(0xFF2946B5):const Color(0xFF475569))),
          onTap:(){go(p);if(MediaQuery.sizeOf(context).width<760)Navigator.pop(context);},
        ));
      }).toList())),
      const Divider(height:1),
      Padding(padding:const EdgeInsets.all(16),child:Row(children:[const CircleAvatar(radius:18,child:Text('AK')),const SizedBox(width:10),const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Aman Kumar',style:TextStyle(fontWeight:FontWeight.w700,fontSize:13)),Text('Workspace account',style:TextStyle(fontSize:11,color:Colors.grey))])),IconButton(onPressed:()=>go('Settings'),icon:const Icon(Icons.settings_outlined,size:19))])),
    ]),
  );

  IconData _iconFor(String p) {
    if(p.contains('Dashboard')||p.contains('Overview'))return Icons.grid_view_rounded;
    if(p.contains('Student')||p=='People')return Icons.people_alt_outlined;
    if(p.contains('Seat'))return Icons.event_seat_outlined;
    if(p.contains('Booking'))return Icons.calendar_month_outlined;
    if(p.contains('Fee')||p.contains('Invoice'))return Icons.receipt_long_outlined;
    if(p.contains('Payment')||p.contains('Subscription'))return Icons.account_balance_wallet_outlined;
    if(p.contains('WhatsApp'))return Icons.chat_bubble_outline;
    if(p.contains('Report'))return Icons.bar_chart_rounded;
    if(p.contains('Staff'))return Icons.badge_outlined;
    if(p.contains('Library')||p.contains('Discover'))return Icons.local_library_outlined;
    if(p.contains('Feature'))return Icons.extension_outlined;
    if(p.contains('Notification'))return Icons.notifications_none;
    if(p.contains('Audit'))return Icons.fact_check_outlined;
    if(p.contains('Support')||p.contains('Help'))return Icons.support_agent;
    return Icons.tune_rounded;
  }

  Widget _content() {
    switch(page){
      case 'Dashboard': return _ownerDashboard();
      case 'Discover Libraries': return _discover();
      case 'Platform Overview': return _adminDashboard();
      case 'Students': return _students();
      case 'Libraries': return _listPage('Libraries','Manage tenant onboarding, status and directory publishing.',['Apex Study Library · Active','Knowledge Hub · Pending approval','Focus Reading Zone · Trial']);
      case 'Seats & Slots': case 'Seat Map': return _seats();
      case 'Bookings': case 'My Bookings': return _bookings();
      case 'Fees & Invoices': case 'My Invoices': return _invoices();
      case 'Payments': return _payments();
      case 'Staff': return _staff();
      case 'WhatsApp': case 'WhatsApp Health': return _whatsapp();
      case 'Reports': return _reports();
      case 'Subscription': case 'Subscriptions': return _subscription();
      case 'Custom Features': case 'Feature Requests': case 'Feature Catalogue': return _features();
      case 'Library Profile': return _profile();
      case 'Notifications': return _notifications();
      case 'Settings': case 'Profile': return _settings();
      case 'Support': case 'Help & Support': case 'Support Tickets': return _support();
      case 'Audit Logs': return _listPage('Audit Logs','Privileged activity history · backend integration pending',['Owner updated seat configuration','Staff invitation created','Library profile edited']);
      case 'My Library': return _myLibrary();
      default: return _ownerDashboard();
    }
  }

  Widget _pageHeader(String title,String subtitle,{Widget? action}) => Padding(
    padding:const EdgeInsets.fromLTRB(22,22,22,14),
    child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(title,style:const TextStyle(fontSize:25,fontWeight:FontWeight.w800,letterSpacing:-.6)),
        const SizedBox(height:5),Text(subtitle,style:const TextStyle(color:Color(0xFF64748B),fontSize:13)),
      ])),
      if(action!=null) action!,
    ]),
  );

  Widget _ownerDashboard()=>ListView(children:[
    _pageHeader('Good morning, Aman 👋','Here is what is happening at your library today.',action:FilledButton.icon(onPressed:()=>_dialog('Quick action','Choose an action',['Add student','Add seat','Create invoice']),icon:const Icon(Icons.add,size:18),label:const Text('Quick action'))),
    Padding(padding:const EdgeInsets.symmetric(horizontal:20),child:Wrap(spacing:12,runSpacing:12,children:[
      _metric('Total students','248','+12 this month',Icons.people_alt_outlined,const Color(0xFFEAF0FF)),
      _metric('Seats occupied','86 / 120','71.6% occupancy',Icons.event_seat_outlined,const Color(0xFFE8F7F0)),
      _metric('Fees due','₹42,800','31 invoices pending',Icons.receipt_long_outlined,const Color(0xFFFFF4E5)),
      _metric('Collected this month','₹1,28,400','+8.4% vs last month',Icons.currency_rupee,const Color(0xFFF2ECFF)),
    ])),
    Padding(padding:const EdgeInsets.fromLTRB(22,24,22,10),child:Row(children:[const Expanded(child:Text('Today at a glance',style:TextStyle(fontSize:17,fontWeight:FontWeight.w800))),TextButton(onPressed:()=>go('Reports'),child:const Text('View reports'))])),
    Padding(padding:const EdgeInsets.symmetric(horizontal:20),child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Expanded(flex:3,child:_panel('Seat occupancy',Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Row(children:[const Text('71.6%',style:TextStyle(fontSize:30,fontWeight:FontWeight.w800)),const Spacer(),_pill('Healthy',Colors.green)]),
        const SizedBox(height:12),ClipRRect(borderRadius:BorderRadius.circular(10),child:const LinearProgressIndicator(value:.716,minHeight:12,backgroundColor:Color(0xFFE9EDF4),color:Color(0xFF3457D5))),
        const SizedBox(height:10),const Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text('86 occupied',style:TextStyle(color:Colors.grey,fontSize:12)),Text('34 available',style:TextStyle(color:Colors.grey,fontSize:12))]),
      ]))),
      const SizedBox(width:12),
      Expanded(flex:2,child:_panel('Upcoming bookings',Column(children:[
        _miniRow('09:00 AM','A-12 · Aarav'),const Divider(height:18),_miniRow('10:30 AM','B-04 · Ananya'),const Divider(height:18),_miniRow('12:00 PM','C-08 · Priya'),
      ]))),
    ])),
    Padding(padding:const EdgeInsets.fromLTRB(22,22,22,10),child:const Text('Needs your attention',style:TextStyle(fontSize:17,fontWeight:FontWeight.w800))),
    Padding(padding:const EdgeInsets.fromLTRB(20,0,20,24),child:Column(children:[
      _notice(Icons.pending_actions,'8 student join requests','Review pending membership requests.',()=>go('Students')),
      _notice(Icons.receipt_long,'31 invoices are overdue','Send reminders after checking consent.',()=>go('Fees & Invoices')),
      _notice(Icons.chat_bubble_outline,'WhatsApp is not connected','Connect this library’s own business number.',()=>go('WhatsApp')),
    ])),
  ]);

  Widget _metric(String label,String value,String note,IconData icon,Color bg)=>SizedBox(width:MediaQuery.sizeOf(context).width<760? (MediaQuery.sizeOf(context).width-52)/2:230,child:Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Row(children:[Container(width:38,height:38,decoration:BoxDecoration(color:bg,borderRadius:BorderRadius.circular(12)),child:Icon(icon,color:const Color(0xFF3457D5))),const Spacer(),const Icon(Icons.more_horiz,color:Colors.grey)]),
    const SizedBox(height:16),Text(value,style:const TextStyle(fontSize:24,fontWeight:FontWeight.w800)),const SizedBox(height:4),Text(label,style:const TextStyle(fontWeight:FontWeight.w600,fontSize:12)),const SizedBox(height:5),Text(note,style:const TextStyle(color:Color(0xFF16834A),fontSize:11)),
  ]))));

  Widget _panel(String title,Widget child)=>Card(child:Padding(padding:const EdgeInsets.all(17),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:14)),const SizedBox(height:16),child])));
  Widget _miniRow(String t,String s)=>Row(children:[Text(t,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:12)),const Spacer(),Text(s,style:const TextStyle(fontSize:11,color:Colors.grey))]);
  Widget _notice(IconData i,String t,String s,VoidCallback f)=>Card(child:ListTile(leading:CircleAvatar(backgroundColor:const Color(0xFFF0F3FF),child:Icon(i,color:const Color(0xFF3457D5))),title:Text(t,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:13)),subtitle:Text(s,style:const TextStyle(fontSize:11)),trailing:const Icon(Icons.chevron_right),onTap:f));

  Widget _students()=>ListView(children:[
    _pageHeader('Students','Manage memberships, student profiles and access.',action:FilledButton.icon(onPressed:()=>_addStudent(),icon:const Icon(Icons.person_add_alt_1,size:18),label:const Text('Add student'))),
    Padding(padding:const EdgeInsets.symmetric(horizontal:20),child:TextField(decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Search by name, phone or membership ID'))),
    Padding(padding:const EdgeInsets.all(20),child:_panel('Student directory',Column(children:students.map((s)=>ListTile(contentPadding:EdgeInsets.zero,leading:CircleAvatar(child:Text(s['name']![0])),title:Text(s['name']!,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:13)),subtitle:Text('${s['phone']}  ·  Seat ${s['seat']}',style:const TextStyle(fontSize:11)),trailing:_pill(s['status']!,s['status']=='Active'?Colors.green:Colors.orange),onTap:()=>_dialog(s['name']!,'Student profile · Backend student document will be loaded here.',['View profile','View invoices','Booking history']))).toList()))),
  ]);

  Widget _seats()=>ListView(children:[
    _pageHeader('Seats & time slots','Configure capacity, zones and bookable time slots.',action:FilledButton.icon(onPressed:()=>_dialog('Add seat','Seat form placeholder',['Save seat']),icon:const Icon(Icons.add),label:const Text('Add seat'))),
    Padding(padding:const EdgeInsets.symmetric(horizontal:20),child:Wrap(spacing:10,children:[_pill('86 occupied',Colors.blue),_pill('34 available',Colors.green),_pill('120 total',Colors.grey)])),
    Padding(padding:const EdgeInsets.all(20),child:_panel('Floor 1 · Reading hall',Wrap(spacing:10,runSpacing:10,children:List.generate(30,(i){final busy=[0,1,2,4,5,7,8,9,12,13,15,18,20,22,24,25,27].contains(i);return InkWell(onTap:()=>_dialog('Seat ${i+1}','Seat status and booking controls will connect to the seat repository.',['Edit seat','View bookings','Deactivate']),child:Container(width:62,height:58,decoration:BoxDecoration(color:busy?const Color(0xFFFFE9E7):const Color(0xFFE7F7EF),borderRadius:BorderRadius.circular(12),border:Border.all(color:busy?Colors.red.shade100:Colors.green.shade100)),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(Icons.event_seat,color:busy?Colors.red:Colors.green,size:18),Text('S-${i+1}',style:const TextStyle(fontSize:10,fontWeight:FontWeight.w700))])));}))),
    Padding(padding:const EdgeInsets.symmetric(horizontal:20),child:_panel('Configured time slots',Column(children:[_miniRow('Morning','06:00 AM – 12:00 PM'),const Divider(),_miniRow('Afternoon','12:00 PM – 06:00 PM'),const Divider(),_miniRow('Evening','06:00 PM – 10:00 PM')]))),
  ]);

  Widget _bookings()=>ListView(children:[
    _pageHeader(role=='Student'?'My bookings':'Booking management','View reservations, status and seat allocation.',action:FilledButton.icon(onPressed:()=>_dialog('New booking','Select student, seat, date and slot. Final availability must be checked by backend.',['Continue']),icon:const Icon(Icons.add),label:const Text('New booking'))),
    Padding(padding:const EdgeInsets.all(20),child:_panel('Upcoming reservations',Column(children:[
      _bookingRow('Aarav Kumar','Seat A-12','Today · 09:00 AM','Confirmed'),
      _bookingRow('Ananya Singh','Seat B-04','Today · 10:30 AM','Confirmed'),
      _bookingRow('Priya Sharma','Seat C-08','Tomorrow · 08:00 AM','Pending'),
      _bookingRow('Rohan Das','Seat A-09','Tomorrow · 11:00 AM','Cancelled'),
    ]))),
  ]);
  Widget _bookingRow(String name,String seat,String when,String status)=>ListTile(contentPadding:EdgeInsets.zero,leading:const CircleAvatar(child:Icon(Icons.event_seat)),title:Text(name,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:13)),subtitle:Text('$seat · $when',style:const TextStyle(fontSize:11)),trailing:_pill(status,status=='Confirmed'?Colors.green:status=='Pending'?Colors.orange:Colors.grey));

  Widget _invoices()=>ListView(children:[
    _pageHeader('Fees & invoices','Create fee invoices, record adjustments and track dues.',action:FilledButton.icon(onPressed:()=>_dialog('Create invoice','Choose student, fee period, line items and due date. Backend will create invoice number.',['Create draft']),icon:const Icon(Icons.add),label:const Text('Create invoice'))),
    Padding(padding:const EdgeInsets.symmetric(horizontal:20),child:Wrap(spacing:10,children:[_metricSmall('Outstanding','₹42,800'),_metricSmall('Collected','₹1,28,400'),_metricSmall('Overdue','31') ])),
    Padding(padding:const EdgeInsets.all(20),child:_panel('Recent invoices',Column(children:[
      _invoiceRow('INV-2026-1042','Aarav Kumar','₹2,000','Overdue'),
      _invoiceRow('INV-2026-1041','Ananya Singh','₹1,800','Paid'),
      _invoiceRow('INV-2026-1040','Priya Sharma','₹2,000','Partially paid'),
      _invoiceRow('INV-2026-1039','Rohan Das','₹1,500','Issued'),
    ]))),
  ]);
  Widget _metricSmall(String a,String b)=>Container(margin:const EdgeInsets.only(right:5),padding:const EdgeInsets.all(13),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(13)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a,style:const TextStyle(color:Colors.grey,fontSize:11)),Text(b,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:17))]));
  Widget _invoiceRow(String id,String name,String amount,String status)=>ListTile(contentPadding:EdgeInsets.zero,leading:const Icon(Icons.description_outlined),title:Text(id,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:12)),subtitle:Text(name,style:const TextStyle(fontSize:11)),trailing:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.end,children:[Text(amount,style:const TextStyle(fontWeight:FontWeight.w800)),_pill(status,status=='Paid'?Colors.green:status=='Overdue'?Colors.red:Colors.orange)]));

  Widget _payments()=>ListView(children:[
    _pageHeader('Payments','Student-to-library payment records. SaaS subscription billing is separate.'),
    Padding(padding:const EdgeInsets.all(20),child:_panel('Payment ledger',Column(children:[
      _invoiceRow('PAY-77821','Aarav Kumar','₹2,000','Success'),
      _invoiceRow('PAY-77820','Ananya Singh','₹1,800','Success'),
      _invoiceRow('PAY-77819','Priya Sharma','₹1,000','Pending'),
      _invoiceRow('PAY-77818','Rohan Das','₹1,500','Refunded'),
    ]))),
  ]);

  Widget _staff()=>ListView(children:[
    _pageHeader('Staff & permissions','Invite staff and grant only the permissions they need.',action:FilledButton.icon(onPressed:()=>_dialog('Invite staff','Enter verified phone/email and assign permission keys. Invite expires.',['Send invite']),icon:const Icon(Icons.person_add),label:const Text('Invite staff'))),
    Padding(padding:const EdgeInsets.all(20),child:_panel('Team members',Column(children:[
      _staffRow('Neha Verma','Front desk','students.read · bookings.manage'),
      _staffRow('Vikash Raj','Fee operator','fees.read · payments.read'),
      _staffRow('Sana Khan','Library assistant','checkin.manage'),
    ]))),
  ]);
  Widget _staffRow(String n,String r,String perms)=>ListTile(contentPadding:EdgeInsets.zero,leading:const CircleAvatar(child:Icon(Icons.badge_outlined)),title:Text(n,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:13)),subtitle:Text('$r\n$perms',style:const TextStyle(fontSize:10)),isThreeLine:true,trailing:IconButton(onPressed:()=>_dialog('Staff permissions',perms,['Edit permissions','Suspend access']),icon:const Icon(Icons.more_vert)));

  Widget _whatsapp()=>ListView(children:[
    _pageHeader('WhatsApp connection','Connect this library’s own WhatsApp Business number.'),
    Padding(padding:const EdgeInsets.all(20),child:_panel('Connection status',Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[const CircleAvatar(backgroundColor:Color(0xFFE7F7EF),child:Icon(Icons.chat,color:Color(0xFF16834A))),const SizedBox(width:12),const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Not connected',style:TextStyle(fontWeight:FontWeight.w800)),Text('Connect using Meta Embedded Signup',style:TextStyle(color:Colors.grey,fontSize:11))])),_pill('Action needed',Colors.orange)]),
      const SizedBox(height:16),const Text('Backend placeholder: Meta OAuth / Embedded Signup, webhook verification and Secret Manager token storage are not configured.',style:TextStyle(fontSize:12)),
      const SizedBox(height:14),FilledButton.icon(onPressed:()=>toast('Backend TODO: launch Meta Embedded Signup from a secure backend session.'),icon:const Icon(Icons.link),label:const Text('Connect WhatsApp Business')),
    ]))),
    Padding(padding:const EdgeInsets.symmetric(horizontal:20),child:_panel('Consent & reminders',Column(children:[
      SwitchListTile(contentPadding:EdgeInsets.zero,value:false,onChanged:(v)=>toast('Connect backend consent preferences first.'),title:const Text('Enable fee reminders'),subtitle:const Text('Only message students with recorded consent.',style:TextStyle(fontSize:11))),
      const Divider(),_miniRow('Approved templates','0'),const SizedBox(height:12),_miniRow('Messages this month','0 / plan allowance'),
    ]))),
  ]);

  Widget _reports()=>ListView(children:[
    _pageHeader('Reports & analytics','Occupancy, utilization, collections and communication metrics.'),
    Padding(padding:const EdgeInsets.all(20),child:_panel('Monthly collection',Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('₹1,28,400',style:TextStyle(fontSize:30,fontWeight:FontWeight.w800)),const Text('Illustrative demo data · replace with server aggregates',style:TextStyle(fontSize:10,color:Colors.grey)),const SizedBox(height:18),
      Row(crossAxisAlignment:CrossAxisAlignment.end,children:List.generate(12,(i)=>Expanded(child:Container(margin:const EdgeInsets.symmetric(horizontal:3),height:30.0+(i%5)*17,decoration:BoxDecoration(color:const Color(0xFF9BAEF4),borderRadius:BorderRadius.circular(5)))))),
      const SizedBox(height:8),const Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text('Jan',style:TextStyle(fontSize:10)),Text('Jun',style:TextStyle(fontSize:10)),Text('Dec',style:TextStyle(fontSize:10))]),
    ]))),
    Padding(padding:const EdgeInsets.symmetric(horizontal:20),child:_panel('Report exports',Column(children:[_miniRow('Occupancy report','CSV / PDF'),const Divider(),_miniRow('Fee collection report','CSV / PDF'),const Divider(),_miniRow('WhatsApp delivery summary','CSV / PDF')]))),
  ]);

  Widget _subscription()=>ListView(children:[
    _pageHeader('Subscription & plans','Owner subscription for LibraryOS. Separate from student fee collection.'),
    Padding(padding:const EdgeInsets.all(20),child:_panel('Your trial',Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[const Expanded(child:Text('7-day free trial',style:TextStyle(fontWeight:FontWeight.w800,fontSize:18))),_pill('Trial active',Colors.green)]),
      const SizedBox(height:8),const Text('Trial starts after verified library onboarding. Exact expiry is calculated by the backend.',style:TextStyle(fontSize:12,color:Colors.grey)),
      const SizedBox(height:18),const LinearProgressIndicator(value:.42,minHeight:8),const SizedBox(height:8),const Text('Illustrative progress only · connect subscription service for live status.',style:TextStyle(fontSize:10,color:Colors.grey)),
    ]))),
    Padding(padding:const EdgeInsets.symmetric(horizontal:20),child:Wrap(spacing:12,runSpacing:12,children:[
      _planCard('Basic','Up to 100 seats','Plan price to be configured'),
      _planCard('Professional','Up to 250 seats','Plan price to be configured'),
      _planCard('Enterprise','Up to 500 seats','Plan price to be configured'),
    ])),
  ]);
  Widget _planCard(String n,String d,String price)=>SizedBox(width:MediaQuery.sizeOf(context).width<760?MediaQuery.sizeOf(context).width-50:220,child:Card(child:Padding(padding:const EdgeInsets.all(17),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(n,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:17)),const SizedBox(height:8),Text(d),const SizedBox(height:12),Text(price,style:const TextStyle(color:Colors.grey,fontSize:11)),const SizedBox(height:12),OutlinedButton(onPressed:()=>toast('Backend TODO: create subscription checkout order.'),child:const Text('Choose plan'))]))));

  Widget _features()=>ListView(children:[
    _pageHeader('Custom features','Request one-time custom development. Released features can be enabled per library.',action:FilledButton.icon(onPressed:()=>_dialog('Request a feature','Describe the use case, expected outcome and priority. A quote and acceptance criteria must be approved before development.',['Submit request']),icon:const Icon(Icons.add),label:const Text('New request'))),
    Padding(padding:const EdgeInsets.all(20),child:_panel('Request lifecycle',Column(children:[
      _lifecycle('Submitted','Request received'),_lifecycle('Under review','Feasibility and scope assessment'),_lifecycle('Quoted','One-time development fee and timeline'),_lifecycle('Awaiting payment','Owner accepts scope and payment'),_lifecycle('In development','Build behind feature flag'),_lifecycle('Internal testing / Pilot','Regression and security checks'),_lifecycle('Available','Catalogue entry; each library activates individually'),
    ]))),
    Padding(padding:const EdgeInsets.symmetric(horizontal:20),child:_panel('Available feature catalogue',Column(children:[
      _featureRow('Automated attendance reports','Available','Not enabled'),
      _featureRow('Advanced seat analytics','Available','Enabled'),
      _featureRow('Parent notification module','Under review','Request submitted'),
    ]))),
  ]);
  Widget _lifecycle(String a,String b)=>ListTile(dense:true,contentPadding:EdgeInsets.zero,leading:const Icon(Icons.check_circle_outline,color:Color(0xFF3457D5)),title:Text(a,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:12)),subtitle:Text(b,style:const TextStyle(fontSize:11)));
  Widget _featureRow(String a,String b,String c)=>ListTile(contentPadding:EdgeInsets.zero,title:Text(a,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:12)),subtitle:Text('$b · $c',style:const TextStyle(fontSize:11)),trailing:Switch(value:c=='Enabled',onChanged:(v)=>toast('Backend TODO: update feature activation for this library.')));

  Widget _discover()=>ListView(children:[
    _pageHeader('Find your library','Discover public libraries nearby or search by locality.'),
    Padding(padding:const EdgeInsets.symmetric(horizontal:20),child:TextField(decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Search library name, city or area'))),
    Padding(padding:const EdgeInsets.fromLTRB(20,14,20,0),child:Row(children:[const Icon(Icons.location_on_outlined,color:Color(0xFF3457D5)),const SizedBox(width:6),const Expanded(child:Text('Showing libraries near Patna · Demo location',style:TextStyle(fontSize:12))),TextButton(onPressed:()=>toast('Backend TODO: geolocation and geohash query.'),child:const Text('Change'))])),
    Padding(padding:const EdgeInsets.all(20),child:Column(children:libraries.map((l)=>Card(child:Padding(padding:const EdgeInsets.all(15),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[Container(width:54,height:54,decoration:BoxDecoration(color:const Color(0xFFE9EDFF),borderRadius:BorderRadius.circular(13)),child:const Icon(Icons.local_library,color:Color(0xFF3457D5),size:28)),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(l['name']!,style:const TextStyle(fontWeight:FontWeight.w800)),Text(l['area']!,style:const TextStyle(fontSize:11,color:Colors.grey)),Text(l['distance']!,style:const TextStyle(fontSize:10,color:Colors.grey))]))]),
      const SizedBox(height:12),Row(children:[_pill(l['seats']!,Colors.green),const Spacer(),FilledButton(onPressed:()=>_dialog(l['name']!,'Library details, public facilities and membership policy.',['View details','Request to join']),child:const Text('Explore'))]),
    ])))).toList())),
  ]);
  Widget _myLibrary()=>ListView(children:[_pageHeader('My library','Your selected library workspace.'),Padding(padding:const EdgeInsets.all(20),child:_panel('Apex Study Library',Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Boring Road, Patna',style:TextStyle(color:Colors.grey)),const SizedBox(height:12),_miniRow('Membership status','Active'),const Divider(),_miniRow('Seat','A-12'),const Divider(),_miniRow('Opening hours','06:00 AM – 10:00 PM'),const SizedBox(height:12),FilledButton(onPressed:()=>go('Seat Map'),child:const Text('View seat availability'))])))]);

  Widget _profile()=>ListView(children:[
    _pageHeader('Library profile','Manage public information and onboarding details.',action:FilledButton(onPressed:()=>toast('Profile changes will save through backend repository.'),child:const Text('Save changes'))),
    Padding(padding:const EdgeInsets.all(20),child:_panel('Public library information',Column(children:[
      _field('Library name','Apex Study Library'),_field('Address','Boring Road, Patna, Bihar'),_field('Contact number','+91 98765 43210'),_field('Opening hours','06:00 AM – 10:00 PM'),_field('Total capacity','120'),_field('Facilities','Wi-Fi, AC, CCTV, drinking water'),
    ]))),
  ]);
  Widget _field(String label,String value)=>Padding(padding:const EdgeInsets.only(bottom:12),child:TextFormField(initialValue:value,decoration:InputDecoration(labelText:label)));
  Widget _notifications()=>ListView(children:[
    _pageHeader('Notifications','Booking, invoice, payment, trial and staff updates.'),
    Padding(padding:const EdgeInsets.all(20),child:_panel('Recent activity',Column(children:[
      _notice(Icons.event_available,'Booking confirmed','Aarav Kumar · Seat A-12 · Today',()=>go('Bookings')),
      _notice(Icons.receipt_long,'Invoice issued','INV-2026-1042 · ₹2,000',()=>go('Fees & Invoices')),
      _notice(Icons.person_add,'New join request','Rohan Das requested membership',()=>go('Students')),
    ]))),
  ]);
  Widget _settings()=>ListView(children:[
    _pageHeader('Profile & settings','Account details, language, privacy and preferences.'),
    Padding(padding:const EdgeInsets.all(20),child:_panel('Preferences',Column(children:[
      ListTile(contentPadding:EdgeInsets.zero,title:const Text('Language'),subtitle:const Text('English · Hindi labels planned'),trailing:const Icon(Icons.chevron_right),onTap:()=>_dialog('Language','Select display language',['English','हिन्दी'])),
      const Divider(),ListTile(contentPadding:EdgeInsets.zero,title:const Text('Privacy & consent'),subtitle:const Text('Notification permissions and data requests'),trailing:const Icon(Icons.chevron_right),onTap:()=>toast('Backend TODO: consent and data-rights endpoints.')),
      const Divider(),ListTile(contentPadding:EdgeInsets.zero,title:const Text('Sign out'),trailing:const Icon(Icons.logout),onTap:()=>toast('Connect Firebase Auth sign-out.')),
    ]))),
  ]);
  Widget _support()=>ListView(children:[
    _pageHeader('Help & support','Get help with bookings, fees, account access or integrations.'),
    Padding(padding:const EdgeInsets.all(20),child:_panel('Create support ticket',Column(children:[
      _field('Subject',''),_field('Describe the issue',''),const SizedBox(height:10),FilledButton(onPressed:()=>toast('Backend TODO: create support ticket and upload attachments.'),child:const Text('Submit ticket')),
    ]))),
  ]);
  Widget _adminDashboard()=>ListView(children:[
    _pageHeader('Platform overview','Private Super Admin workspace · restricted access.'),
    Padding(padding:const EdgeInsets.symmetric(horizontal:20),child:Wrap(spacing:12,runSpacing:12,children:[
      _metric('Total libraries','128','12 pending approval',Icons.apartment,const Color(0xFFEAF0FF)),
      _metric('Active subscriptions','96','75% of tenants',Icons.verified_outlined,const Color(0xFFE8F7F0)),
      _metric('Trial tenants','18','7-day trial cohort',Icons.hourglass_top,const Color(0xFFFFF4E5)),
      _metric('Open requests','14','Custom feature queue',Icons.extension_outlined,const Color(0xFFF2ECFF)),
    ])),
    Padding(padding:const EdgeInsets.all(20),child:_panel('Platform operations',Column(children:[
      _miniRow('Library approvals','12 pending'),const Divider(),_miniRow('Subscription events','7 require review'),const Divider(),_miniRow('WhatsApp connections','23 attention'),const Divider(),_miniRow('Feature requests','14 open'),
    ]))),
  ]);
  Widget _listPage(String title,String subtitle,List<String> rows)=>ListView(children:[_pageHeader(title,subtitle),Padding(padding:const EdgeInsets.all(20),child:_panel(title,Column(children:rows.map((r)=>ListTile(contentPadding:EdgeInsets.zero,title:Text(r,style:const TextStyle(fontSize:13,fontWeight:FontWeight.w600)),trailing:const Icon(Icons.chevron_right),onTap:()=>_dialog(title,r,['Open details','Update status']))).toList())))]);

  Widget _pill(String t,Color c)=>Container(padding:const EdgeInsets.symmetric(horizontal:9,vertical:5),decoration:BoxDecoration(color:c.withOpacity(.10),borderRadius:BorderRadius.circular(30)),child:Text(t,style:TextStyle(color:c,fontSize:10,fontWeight:FontWeight.w700)));
  void _addStudent()=>_dialog('Add student','Student profile form · save to libraries/{libraryId}/students/{studentId}.',['Save student']);
  void _dialog(String title,String desc,List<String> actions){
    showDialog(context:context,builder:(ctx)=>AlertDialog(title:Text(title),content:Text(desc),actions:[
      TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Close')),
      ...actions.map((a)=>TextButton(onPressed:(){Navigator.pop(ctx);toast('$a · Demo UI only; connect the backend endpoint.');},child:Text(a))),
    ]));
  }
}
