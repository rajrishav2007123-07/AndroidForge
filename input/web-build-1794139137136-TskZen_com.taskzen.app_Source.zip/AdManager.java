package com.taskzen.app;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback;

import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * AdMob integration for Study Tracker.
 * App-open ads are intentionally NOT used.
 *
 * Unit IDs (names kept for clarity):
 *   BANNER               ca-app-pub-8477940154609095/1328583983
 *   REWARDED_INTERSTITIAL ca-app-pub-8477940154609095/2120377747
 *   NATIVE_ADVANCED      ca-app-pub-8477940154609095/2300341144
 *   REWARDED             ca-app-pub-8477940154609095/3613422813
 *   INTERSTITIAL         ca-app-pub-8477940154609095/7702420641
 *   APP_OPEN (unused)    ca-app-pub-8477940154609095/9987259477
 */
public final class AdManager {

    private static final String TAG = "AdManager";
    private static final String PREFS = "ad_prefs";

    // ---- Named Ad Unit IDs (do not use APP_OPEN) ----
    public static final String AD_UNIT_BANNER = "ca-app-pub-8477940154609095/1328583983"; // Banner
    public static final String AD_UNIT_REWARDED_INTERSTITIAL = "ca-app-pub-8477940154609095/2120377747"; // Rewarded interstitial
    public static final String AD_UNIT_NATIVE = "ca-app-pub-8477940154609095/2300341144"; // Native advanced
    public static final String AD_UNIT_REWARDED = "ca-app-pub-8477940154609095/3613422813"; // Rewarded
    public static final String AD_UNIT_INTERSTITIAL = "ca-app-pub-8477940154609095/7702420641"; // Interstitial
    // public static final String AD_UNIT_APP_OPEN = "ca-app-pub-8477940154609095/9987259477"; // intentionally unused

    private static AdManager instance;
    private WeakReference<Activity> activityRef;
    private final SharedPreferences prefs;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final AtomicBoolean sdkReady = new AtomicBoolean(false);

    private AdView topBanner;
    private AdView bottomBanner;
    private InterstitialAd interstitialAd;
    private RewardedAd rewardedAd;
    private RewardedInterstitialAd rewardedInterstitialAd;
    private NativeAd nativeAd;

    private int interstitialActionsSinceShow = 0;
    private boolean loadingInterstitial;
    private boolean loadingRewarded;
    private boolean loadingRewardedInterstitial;

    public interface SimpleCallback {
        void onDone(boolean shownOrEarned);
    }

    private AdManager(Activity activity) {
        this.activityRef = new WeakReference<>(activity);
        this.prefs = activity.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        // Defaults: ads on, interstitial every 1 action (user can change remotely later via bridge)
        if (!prefs.contains("ads_enabled")) prefs.edit().putBoolean("ads_enabled", true).apply();
        if (!prefs.contains("interstitial_every_n")) prefs.edit().putInt("interstitial_every_n", 1).apply();
        if (!prefs.contains("rewarded_enabled")) prefs.edit().putBoolean("rewarded_enabled", true).apply();
        if (!prefs.contains("native_enabled")) prefs.edit().putBoolean("native_enabled", true).apply();
        if (!prefs.contains("banners_enabled")) prefs.edit().putBoolean("banners_enabled", true).apply();
    }

    public static synchronized AdManager get(Activity activity) {
        if (instance == null) {
            instance = new AdManager(activity);
        } else {
            instance.activityRef = new WeakReference<>(activity);
        }
        return instance;
    }

    public void initialize(@Nullable Runnable onReady) {
        final Activity act = activityRef.get();
        if (act == null) return;
        MobileAds.initialize(act, initializationStatus -> {
            sdkReady.set(true);
            Log.i(TAG, "MobileAds initialized");
            mainHandler.post(() -> {
                loadInterstitial();
                loadRewarded();
                loadRewardedInterstitial();
                if (onReady != null) onReady.run();
            });
        });
    }

    public boolean isAdsEnabled() {
        return prefs.getBoolean("ads_enabled", true);
    }

    public void setAdsEnabled(boolean enabled) {
        prefs.edit().putBoolean("ads_enabled", enabled).apply();
        Activity act = activityRef.get();
        if (act == null) return;
        act.runOnUiThread(() -> {
            if (topBanner != null) topBanner.setVisibility(View.GONE); // top always hidden
            if (bottomBanner != null) {
                bottomBanner.setVisibility(enabled && prefs.getBoolean("banners_enabled", true)
                        ? View.VISIBLE : View.GONE);
            }
        });
    }

    /** Interstitial frequency: show once every N gated actions (default 1). */
    public void setInterstitialEveryN(int n) {
        if (n < 1) n = 1;
        prefs.edit().putInt("interstitial_every_n", n).apply();
    }

    public int getInterstitialEveryN() {
        return Math.max(1, prefs.getInt("interstitial_every_n", 1));
    }

    public void setRewardedEnabled(boolean v) {
        prefs.edit().putBoolean("rewarded_enabled", v).apply();
    }

    public void setNativeEnabled(boolean v) {
        prefs.edit().putBoolean("native_enabled", v).apply();
    }

    public void setBannersEnabled(boolean v) {
        prefs.edit().putBoolean("banners_enabled", v).apply();
        Activity act = activityRef.get();
        if (act == null) return;
        act.runOnUiThread(() -> {
            if (topBanner != null) topBanner.setVisibility(View.GONE); // top always hidden
            if (bottomBanner != null) {
                bottomBanner.setVisibility((v && isAdsEnabled()) ? View.VISIBLE : View.GONE);
            }
        });
    }

    // ---- Banners (top + bottom) ----

    public void attachBanners(LinearLayout topContainer, LinearLayout bottomContainer) {
        Activity act = activityRef.get();
        if (act == null || bottomContainer == null) return;
        act.runOnUiThread(() -> {
            // Only small bottom banner (reference layout) — hide top to keep UI clean
            if (topContainer != null) {
                topContainer.removeAllViews();
                topContainer.setVisibility(View.GONE);
            }
            bottomContainer.removeAllViews();

            if (topBanner != null) {
                topBanner.destroy();
                topBanner = null;
            }

            bottomBanner = new AdView(act);
            bottomBanner.setAdUnitId(AD_UNIT_BANNER);
            bottomBanner.setAdSize(AdSize.BANNER); // 320x50 small banner
            bottomBanner.setAdListener(simpleBannerListener("bottom"));
            bottomContainer.addView(bottomBanner, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            boolean show = isAdsEnabled() && prefs.getBoolean("banners_enabled", true);
            bottomBanner.setVisibility(show ? View.VISIBLE : View.GONE);

            if (show) {
                AdRequest req = new AdRequest.Builder().build();
                bottomBanner.loadAd(req);
            }
        });
    }

    private AdListener simpleBannerListener(final String label) {
        return new AdListener() {
            @Override public void onAdLoaded() { Log.i(TAG, label + " banner loaded"); }
            @Override public void onAdFailedToLoad(@NonNull LoadAdError error) {
                Log.w(TAG, label + " banner failed: " + error.getMessage());
            }
        };
    }

    public void resume() {
        if (topBanner != null) topBanner.resume();
        if (bottomBanner != null) bottomBanner.resume();
    }

    public void pause() {
        if (topBanner != null) topBanner.pause();
        if (bottomBanner != null) bottomBanner.pause();
    }

    public void destroy() {
        if (topBanner != null) { topBanner.destroy(); topBanner = null; }
        if (bottomBanner != null) { bottomBanner.destroy(); bottomBanner = null; }
        if (nativeAd != null) { nativeAd.destroy(); nativeAd = null; }
    }

    // ---- Interstitial ----

    private void loadInterstitial() {
        Activity act = activityRef.get();
        if (act == null || loadingInterstitial) return;
        loadingInterstitial = true;
        InterstitialAd.load(act, AD_UNIT_INTERSTITIAL, // Interstitial
                new AdRequest.Builder().build(),
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd ad) {
                        interstitialAd = ad;
                        loadingInterstitial = false;
                        Log.i(TAG, "Interstitial loaded");
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        interstitialAd = null;
                        loadingInterstitial = false;
                        Log.w(TAG, "Interstitial failed: " + loadAdError.getMessage());
                        mainHandler.postDelayed(() -> loadInterstitial(), 30000);
                    }
                });
    }

    /**
     * Gate an action (mode / theme). Respects interstitial_every_n.
     * Always invokes callback so UX is never blocked if ad fails.
     */
    public void maybeShowInterstitialForAction(@Nullable final SimpleCallback cb) {
        if (!isAdsEnabled()) {
            if (cb != null) cb.onDone(false);
            return;
        }
        interstitialActionsSinceShow++;
        int every = getInterstitialEveryN();
        if (interstitialActionsSinceShow < every) {
            if (cb != null) cb.onDone(false);
            return;
        }
        interstitialActionsSinceShow = 0;
        showInterstitialNow(cb);
    }

    public void showInterstitialNow(@Nullable final SimpleCallback cb) {
        final Activity act = activityRef.get();
        if (act == null || !isAdsEnabled()) {
            if (cb != null) cb.onDone(false);
            return;
        }
        act.runOnUiThread(() -> {
            if (interstitialAd == null) {
                loadInterstitial();
                if (cb != null) cb.onDone(false);
                return;
            }
            interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override public void onAdDismissedFullScreenContent() {
                    interstitialAd = null;
                    loadInterstitial();
                    if (cb != null) cb.onDone(true);
                }
                @Override public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                    interstitialAd = null;
                    loadInterstitial();
                    if (cb != null) cb.onDone(false);
                }
                @Override public void onAdShowedFullScreenContent() {
                    Log.i(TAG, "Interstitial shown");
                }
            });
            interstitialAd.show(act);
        });
    }

    // ---- Rewarded ----

    private void loadRewarded() {
        Activity act = activityRef.get();
        if (act == null || loadingRewarded) return;
        loadingRewarded = true;
        RewardedAd.load(act, AD_UNIT_REWARDED, // Rewarded
                new AdRequest.Builder().build(),
                new RewardedAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull RewardedAd ad) {
                        rewardedAd = ad;
                        loadingRewarded = false;
                        Log.i(TAG, "Rewarded loaded");
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        rewardedAd = null;
                        loadingRewarded = false;
                        Log.w(TAG, "Rewarded failed: " + loadAdError.getMessage());
                        mainHandler.postDelayed(() -> loadRewarded(), 30000);
                    }
                });
    }

    public void showRewarded(@Nullable final SimpleCallback cb) {
        final Activity act = activityRef.get();
        if (act == null || !isAdsEnabled() || !prefs.getBoolean("rewarded_enabled", true)) {
            if (cb != null) cb.onDone(false);
            return;
        }
        act.runOnUiThread(() -> {
            if (rewardedAd == null) {
                loadRewarded();
                if (cb != null) cb.onDone(false);
                return;
            }
            final boolean[] earned = {false};
            rewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override public void onAdDismissedFullScreenContent() {
                    rewardedAd = null;
                    loadRewarded();
                    if (cb != null) cb.onDone(earned[0]);
                }
                @Override public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                    rewardedAd = null;
                    loadRewarded();
                    if (cb != null) cb.onDone(false);
                }
            });
            rewardedAd.show(act, rewardItem -> {
                earned[0] = true;
                Log.i(TAG, "User earned reward: " + rewardItem.getAmount() + " " + rewardItem.getType());
            });
        });
    }

    // ---- Rewarded Interstitial ----

    private void loadRewardedInterstitial() {
        Activity act = activityRef.get();
        if (act == null || loadingRewardedInterstitial) return;
        loadingRewardedInterstitial = true;
        RewardedInterstitialAd.load(act, AD_UNIT_REWARDED_INTERSTITIAL, // Rewarded interstitial
                new AdRequest.Builder().build(),
                new RewardedInterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull RewardedInterstitialAd ad) {
                        rewardedInterstitialAd = ad;
                        loadingRewardedInterstitial = false;
                        Log.i(TAG, "Rewarded interstitial loaded");
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        rewardedInterstitialAd = null;
                        loadingRewardedInterstitial = false;
                        Log.w(TAG, "Rewarded interstitial failed: " + loadAdError.getMessage());
                    }
                });
    }

    public void showRewardedInterstitial(@Nullable final SimpleCallback cb) {
        final Activity act = activityRef.get();
        if (act == null || !isAdsEnabled() || !prefs.getBoolean("rewarded_enabled", true)) {
            if (cb != null) cb.onDone(false);
            return;
        }
        act.runOnUiThread(() -> {
            if (rewardedInterstitialAd == null) {
                loadRewardedInterstitial();
                if (cb != null) cb.onDone(false);
                return;
            }
            final boolean[] earned = {false};
            rewardedInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override public void onAdDismissedFullScreenContent() {
                    rewardedInterstitialAd = null;
                    loadRewardedInterstitial();
                    if (cb != null) cb.onDone(earned[0]);
                }
                @Override public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                    rewardedInterstitialAd = null;
                    loadRewardedInterstitial();
                    if (cb != null) cb.onDone(false);
                }
            });
            rewardedInterstitialAd.show(act, rewardItem -> earned[0] = true);
        });
    }

    // ---- Native (optional strip) ----

    public void loadNativeInto(final FrameLayout container) {
        Activity act = activityRef.get();
        if (act == null || container == null) return;
        if (!isAdsEnabled() || !prefs.getBoolean("native_enabled", true)) {
            act.runOnUiThread(() -> container.setVisibility(View.GONE));
            return;
        }
        AdLoader loader = new AdLoader.Builder(act, AD_UNIT_NATIVE) // Native advanced
                .forNativeAd(ad -> {
                    if (nativeAd != null) nativeAd.destroy();
                    nativeAd = ad;
                    act.runOnUiThread(() -> {
                        container.removeAllViews();
                        // Simple text fallback container – full native templates need XML layouts.
                        // Keep container visible so mediation still records; detailed UI can be expanded later.
                        container.setVisibility(View.VISIBLE);
                        Log.i(TAG, "Native ad loaded");
                    });
                })
                .withAdListener(new AdListener() {
                    @Override public void onAdFailedToLoad(@NonNull LoadAdError error) {
                        Log.w(TAG, "Native failed: " + error.getMessage());
                        act.runOnUiThread(() -> container.setVisibility(View.GONE));
                    }
                })
                .withNativeAdOptions(new NativeAdOptions.Builder().build())
                .build();
        loader.loadAd(new AdRequest.Builder().build());
    }
}
