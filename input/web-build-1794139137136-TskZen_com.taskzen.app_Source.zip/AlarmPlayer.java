package com.taskzen.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Build;
import android.os.Looper;

/**
 * Plays custom MP3 or system alarm sound.
 * In Library mode → no sound (notification + vibration still happen).
 */
public class AlarmPlayer {

    private static MediaPlayer mediaPlayer;
    private static Ringtone activeRingtone;
    private static final long AUTO_STOP_MS = 30000; // 30s safety

    public static synchronized void play(Context context) {
        stop();

        // Library mode = mute sound only
        SharedPreferences prefs = context.getSharedPreferences("jee_prefs", Context.MODE_PRIVATE);
        if (prefs.getBoolean("library_mode", false)) {
            return; // silent – NotificationHelper already shows status-bar + vibration
        }

        boolean useCustom = prefs.getBoolean("use_custom_alarm", false);
        String customPath = prefs.getString("custom_alarm_path", null);

        try {
            if (useCustom && customPath != null) {
                java.io.File f = new java.io.File(customPath);
                if (f.exists()) {
                    mediaPlayer = new MediaPlayer();
                    mediaPlayer.setDataSource(customPath);
                    mediaPlayer.setAudioAttributes(
                            new AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_ALARM)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                    .build()
                    );
                    mediaPlayer.setLooping(true); // keep ringing until stopped
                    mediaPlayer.prepare();
                    mediaPlayer.start();
                    new Handler(Looper.getMainLooper()).postDelayed(AlarmPlayer::stop, AUTO_STOP_MS);
                    return;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Fallback → system default alarm
        try {
            Uri alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (alarmUri == null) {
                alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            }
            activeRingtone = RingtoneManager.getRingtone(context.getApplicationContext(), alarmUri);
            if (activeRingtone != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    activeRingtone.setLooping(true);
                }
                activeRingtone.play();
                new Handler(Looper.getMainLooper()).postDelayed(AlarmPlayer::stop, AUTO_STOP_MS);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static synchronized void stop() {
        try {
            if (mediaPlayer != null) {
                if (mediaPlayer.isPlaying()) mediaPlayer.stop();
                mediaPlayer.release();
            }
        } catch (Exception ignored) {}
        mediaPlayer = null;

        try {
            if (activeRingtone != null && activeRingtone.isPlaying()) {
                activeRingtone.stop();
            }
        } catch (Exception ignored) {}
        activeRingtone = null;
        // vibration stop is handled by NotificationHelper.cancelAlarmNotification
    }
}
