package com.taskzen.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;

/** Reads only the foreground package identifier from window-state events; no view text/content is requested. */
public class AppBlockAccessibilityService extends AccessibilityService {
    private long lastRedirect;
    @Override public void onAccessibilityEvent(AccessibilityEvent event){
        if(event==null||event.getEventType()!=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED)return;
        if(!AppBlockStore.isFocusActive(this)||AppBlockStore.emergencyActive(this))return;
        CharSequence name=event.getPackageName();if(name==null)return;String pkg=name.toString();
        if(AppBlockStore.isAlwaysAllowed(this,pkg)||!AppBlockPolicy.selectedForBlocking(pkg,getPackageName(),AppBlockStore.selected(this)))return;
        long now=System.currentTimeMillis();if(now-lastRedirect<1200)return;lastRedirect=now;
        performGlobalAction(GLOBAL_ACTION_HOME);
        Intent show=new Intent(this,AppBlockActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("blocked_package",pkg);startActivity(show);
    }
    @Override public void onInterrupt(){}
}
