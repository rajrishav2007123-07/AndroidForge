package com.taskzen.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.content.res.Configuration;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Simple native blocked-app landing page with a user-controlled emergency exit. */
public class AppBlockActivity extends Activity {
    private TextView timer;
    private final android.os.Handler handler=new android.os.Handler();
    private final Runnable tick=()->{if(timer!=null){long ms=AppBlockStore.remainingMillis(this);timer.setText(ms<0?"Focus session active":(ms/60000)+" min remaining");handler.postDelayed(this.tick,1000);}};
    @Override protected void onCreate(Bundle b){super.onCreate(b);
        boolean dark=(getResources().getConfiguration().uiMode&Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;
        try{org.json.JSONObject state=new org.json.JSONObject(getSharedPreferences("jee_prefs",MODE_PRIVATE).getString("task_state","{}"));String choice=state.optString("focusTheme","system");if("dark".equals(choice))dark=true;else if("light".equals(choice))dark=false;}catch(Exception ignored){}
        int bg=dark?Color.rgb(16,22,42):Color.rgb(246,248,255),fg=dark?Color.WHITE:Color.rgb(22,30,55),muted=dark?0xFFCBD5E1:0xFF4C5873,accent=dark?0xFFB9A7FF:0xFF6546D8;
        getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER);box.setPadding(28,32,28,32);box.setBackgroundColor(bg);
        TextView title=new TextView(this);title.setText("Stay with your focus");title.setTextColor(fg);title.setTextSize(25);title.setGravity(Gravity.CENTER);box.addView(title);
        TextView body=new TextView(this);body.setText("This app is paused while your TskZen Focus session is active. App blocking depends on Android Accessibility access and can be turned off at any time.");body.setTextColor(muted);body.setTextSize(16);body.setGravity(Gravity.CENTER);body.setPadding(0,18,0,14);box.addView(body);
        timer=new TextView(this);timer.setTextColor(accent);timer.setTextSize(19);timer.setGravity(Gravity.CENTER);box.addView(timer);handler.post(tick);
        Button exit=new Button(this);exit.setText("Emergency exit · pause blocking for 30 min");box.addView(exit);exit.setOnClickListener(v->{AppBlockStore.emergencyExit(this);finish();});
        Button open=new Button(this);open.setText("Open TskZen Focus controls");box.addView(open);open.setOnClickListener(v->{Intent i=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);startActivity(i);finish();});
        setContentView(box);
    }
    @Override protected void onDestroy(){handler.removeCallbacks(tick);super.onDestroy();}
}
