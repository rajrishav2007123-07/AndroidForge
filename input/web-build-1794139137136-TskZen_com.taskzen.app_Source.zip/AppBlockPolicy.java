package com.taskzen.app;

import java.util.Set;

/** Small deterministic selection predicate; safety-critical package exclusions remain in AppBlockStore. */
public final class AppBlockPolicy {
    private AppBlockPolicy() {}
    public static boolean selectedForBlocking(String packageName, String ownPackage, Set<String> selected) {
        return packageName != null && !packageName.isEmpty() && !packageName.equals(ownPackage)
                && selected != null && selected.contains(packageName);
    }
}
