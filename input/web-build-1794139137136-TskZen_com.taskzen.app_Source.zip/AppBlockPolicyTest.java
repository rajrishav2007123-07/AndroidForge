package com.taskzen.app;

import static org.junit.Assert.*;
import org.junit.Test;
import java.util.Arrays;
import java.util.HashSet;

public class AppBlockPolicyTest {
    @Test public void onlySelectedOtherPackagesAreEligible(){
        HashSet<String> selected=new HashSet<>(Arrays.asList("com.example.social"));
        assertTrue(AppBlockPolicy.selectedForBlocking("com.example.social","com.taskzen.app",selected));
        assertFalse(AppBlockPolicy.selectedForBlocking("com.example.reader","com.taskzen.app",selected));
        assertFalse(AppBlockPolicy.selectedForBlocking("com.taskzen.app","com.taskzen.app",selected));
        assertFalse(AppBlockPolicy.selectedForBlocking("android", "com.taskzen.app",selected));
    }
}
