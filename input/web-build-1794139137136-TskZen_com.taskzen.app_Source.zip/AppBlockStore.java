package com.taskzen.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import java.util.Set;

public final class AppBlockStore {
    private static final String PREF="app_block_rules",KEY="packages";
    private AppBlockStore(){}
    public static Set<String> selected(Context c){Set<String> out=new HashSet<>();try{JSONArray a=new JSONArray(c.getSharedPreferences(PREF,0).getString(KEY,"[]"));for(int i=0;i<a.length();i++){String p=a.optString(i);if(!p.isEmpty())out.add(p);}}catch(Exception ignored){}return out;}
    public static void save(Context c,Set<String> packages){JSONArray a=new JSONArray();for(String p:packages)if(!isAlwaysAllowed(c,p))a.put(p);c.getSharedPreferences(PREF,0).edit().putString(KEY,a.toString()).apply();}
    public static boolean isAlwaysAllowed(Context c,String p){
        if(p==null||p.isEmpty()||p.equals(c.getPackageName())||p.startsWith("com.android.settings")||p.startsWith("com.android.systemui")||p.startsWith("com.android.phone")||p.startsWith("com.android.server.telecom")||p.startsWith("com.android.emergency")||p.startsWith("com.google.android.dialer")||p.startsWith("com.android.permissioncontroller")||p.startsWith("com.google.android.permissioncontroller")||p.startsWith("com.android.packageinstaller")||p.startsWith("com.google.android.packageinstaller")||p.startsWith("com.android.launcher"))return true;
        try{android.content.pm.ApplicationInfo app=c.getPackageManager().getApplicationInfo(p,0);if((app.flags&(android.content.pm.ApplicationInfo.FLAG_SYSTEM|android.content.pm.ApplicationInfo.FLAG_UPDATED_SYSTEM_APP))!=0)return true;}catch(Exception ignored){}
        try{android.telecom.TelecomManager telecom=(android.telecom.TelecomManager)c.getSystemService(Context.TELECOM_SERVICE);String dialer=telecom==null?null:telecom.getDefaultDialerPackage();if(p.equals(dialer))return true;}catch(Exception ignored){}
        try{android.content.Intent home=new android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(android.content.Intent.CATEGORY_HOME);for(android.content.pm.ResolveInfo ri:c.getPackageManager().queryIntentActivities(home,0)){if(ri.activityInfo!=null&&p.equals(ri.activityInfo.packageName))return true;}}catch(Exception ignored){}
        try{for(android.accessibilityservice.AccessibilityServiceInfo info:((android.view.accessibility.AccessibilityManager)c.getSystemService(Context.ACCESSIBILITY_SERVICE)).getEnabledAccessibilityServiceList(-1)){if(info.getResolveInfo()!=null&&info.getResolveInfo().serviceInfo!=null&&p.equals(info.getResolveInfo().serviceInfo.packageName))return true;}}catch(Exception ignored){}
        return false;
    }
    public static boolean isFocusActive(Context c){try{org.json.JSONObject state=new org.json.JSONObject(c.getSharedPreferences("jee_prefs",0).getString("task_state","{}"));org.json.JSONArray a=state.optJSONArray("focusSessions");if(a==null)return false;for(int i=a.length()-1;i>=0;i--){org.json.JSONObject s=a.optJSONObject(i);if(s!=null&&"active".equals(s.optString("status"))){long plan=s.optLong("plannedDurationMs",0),elapsed=s.optLong("focusDurationMs",0)+Math.max(0,System.currentTimeMillis()-s.optLong("activeSince",System.currentTimeMillis()));return plan<=0||elapsed<plan;}}}catch(Exception ignored){}return false;}
    public static long remainingMillis(Context c){try{org.json.JSONObject state=new org.json.JSONObject(c.getSharedPreferences("jee_prefs",0).getString("task_state","{}"));org.json.JSONArray a=state.optJSONArray("focusSessions");if(a!=null)for(int i=a.length()-1;i>=0;i--){org.json.JSONObject s=a.optJSONObject(i);if(s!=null&&"active".equals(s.optString("status"))){long plan=s.optLong("plannedDurationMs",0),elapsed=s.optLong("focusDurationMs",0)+Math.max(0,System.currentTimeMillis()-s.optLong("activeSince",System.currentTimeMillis()));return plan>0?Math.max(0,plan-elapsed):-1;}}}catch(Exception ignored){}return 0;}
    public static boolean emergencyExit(Context c){SharedPreferences p=c.getSharedPreferences(PREF,0);if(!isFocusActive(c))return false;p.edit().putLong("emergency_until",System.currentTimeMillis()+30*60*1000L).apply();return true;}
    public static boolean emergencyActive(Context c){return c.getSharedPreferences(PREF,0).getLong("emergency_until",0)>System.currentTimeMillis();}
}
