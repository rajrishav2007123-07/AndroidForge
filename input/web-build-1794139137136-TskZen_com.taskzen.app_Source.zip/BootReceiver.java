package com.taskzen.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * After phone reboot, re-schedules all pending task alarms
 * so reminders still work without opening the app again.
 */
public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        try { HourlyMotivationReceiver.ensureScheduled(context); } catch (Exception ignored) {}
        if (intent == null || intent.getAction() == null) return;
        String action = intent.getAction();
        if (action == null) return;
        boolean boot = Intent.ACTION_BOOT_COMPLETED.equals(action) || "android.intent.action.QUICKBOOT_POWERON".equals(action);
        boolean clockChange = Intent.ACTION_TIME_CHANGED.equals(action) || Intent.ACTION_TIMEZONE_CHANGED.equals(action) || Intent.ACTION_DATE_CHANGED.equals(action);
        if (boot || clockChange) { try { FocusScheduleManager.syncAll(context); } catch (Exception ignored) {} }
        if (!boot) return;

        SharedPreferences prefs = context.getSharedPreferences("jee_prefs", Context.MODE_PRIVATE);
        boolean enabled = prefs.getBoolean("reminders_enabled", true);
        if (!enabled) return;

        String json = prefs.getString("task_state", "");
        if (json == null || json.isEmpty()) return;

        try {
            JSONObject state = new JSONObject(json);
            JSONArray tasks = state.optJSONArray("tasks");
            if (tasks == null) return;

            for (int i = 0; i < tasks.length(); i++) {
                JSONObject task = tasks.getJSONObject(i);
                boolean completed = task.optBoolean("completed", false);
                String startTime = task.optString("startTime", "");
                String date = task.optString("date", "");
                long taskId = task.optLong("id", 0);
                String title = task.optString("title", "Task");

                if (!completed && !startTime.isEmpty() && !date.isEmpty() && taskId != 0) {
                    TaskAlarmHelper.scheduleReminders(context, taskId, title, date, startTime);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Refresh home-screen widget after reboot
        try {
            StudyWidgetProvider.requestUpdate(context);
            CountdownWidgetProvider.requestUpdate(context);
        } catch (Exception ignored) {}
        try {
            PersonalAlarmHelper.scheduleAll(context);
        } catch (Exception ignored) {}
    }
}
