package com.taskzen.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;
import java.util.Locale;

public class CountdownWidgetProvider extends AppWidgetProvider {
 public static final String ACTION_REFRESH="com.taskzen.app.COUNTDOWN_WIDGET_REFRESH";
 @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){if(ids!=null)for(int id:ids)updateWidget(c,m,id);}
 @Override public void onDeleted(Context c,int[] ids){super.onDeleted(c,ids);SharedPreferences.Editor e=c.getSharedPreferences("jee_prefs",Context.MODE_PRIVATE).edit();if(ids!=null)for(int id:ids)e.remove("countdown_widget_slot_"+id);e.apply();}
 @Override public void onReceive(Context c,Intent i){super.onReceive(c,i);if(i!=null&&(ACTION_REFRESH.equals(i.getAction())||AppWidgetManager.ACTION_APPWIDGET_UPDATE.equals(i.getAction()))){AppWidgetManager m=AppWidgetManager.getInstance(c);onUpdate(c,m,m.getAppWidgetIds(new ComponentName(c,CountdownWidgetProvider.class)));}}
 public static void requestUpdate(Context c){try{Context a=c.getApplicationContext();AppWidgetManager m=AppWidgetManager.getInstance(a);int[] ids=m.getAppWidgetIds(new ComponentName(a,CountdownWidgetProvider.class));if(ids!=null&&ids.length>0){Intent i=new Intent(a,CountdownWidgetProvider.class).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS,ids);a.sendBroadcast(i);}}catch(Exception e){e.printStackTrace();}}
 private static int bg(String color){if(color==null)color="purple";switch(color.toLowerCase(Locale.US)){case"red":return R.drawable.widget_countdown_bg_red;case"blue":return R.drawable.widget_countdown_bg_blue;case"green":return R.drawable.widget_countdown_bg_green;case"orange":case"sunlight":return R.drawable.widget_countdown_bg_orange;case"teal":return R.drawable.widget_countdown_bg_teal;default:return R.drawable.widget_countdown_bg_purple;}}
 private static JSONObject slot(Context c,int n){try{String raw=c.getSharedPreferences("jee_prefs",Context.MODE_PRIVATE).getString("task_state","");if(raw.isEmpty())return null;JSONObject st=new JSONObject(raw);JSONArray a=st.optJSONArray("countdowns");if(a!=null&&n<a.length())return a.optJSONObject(n);JSONObject e=st.optJSONObject("exam");return n==0?e:null;}catch(Exception e){return null;}}
 private static long daysLeft(String date){try{Calendar target=Calendar.getInstance();String[] p=date.split("-");target.set(Integer.parseInt(p[0]),Integer.parseInt(p[1])-1,Integer.parseInt(p[2]),23,59,59);target.set(Calendar.MILLISECOND,0);return Math.max(0,(long)Math.ceil((target.getTimeInMillis()-System.currentTimeMillis())/86400000.0));}catch(Exception e){return 0;}}
 static void updateWidget(Context c,AppWidgetManager m,int id){RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget_countdown);SharedPreferences p=c.getSharedPreferences("jee_prefs",Context.MODE_PRIVATE);int slotIndex=p.getInt("countdown_widget_slot_"+id,0);JSONObject ex=slot(c,slotIndex);String color=p.getString("countdown_slot_"+slotIndex+"_color",null);if(color==null&&ex!=null)color=ex.optString("color",p.getString("countdown_widget_color","purple"));if(color==null)color="purple";String days="—",name="Set exam date",dateLabel="Countdown "+(slotIndex+1);if(ex!=null){String d=ex.optString("date","");if(!d.isEmpty()){long daysN=daysLeft(d);days=String.valueOf(daysN);name=ex.optString("name","Exam");dateLabel=d+(daysN==0?" · Today!":"");}}v.setInt(R.id.countdown_circle,"setBackgroundResource",bg(color));v.setTextViewText(R.id.cd_days,days);v.setTextViewText(R.id.cd_exam,name);v.setTextViewText(R.id.cd_label,"DAYS LEFT · #"+(slotIndex+1));try{Intent open=new Intent(c,MainActivity.class);open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);PendingIntent pi=PendingIntent.getActivity(c,id+100,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);v.setOnClickPendingIntent(R.id.countdown_root,pi);}catch(Exception ignored){}m.updateAppWidget(id,v);}
}
