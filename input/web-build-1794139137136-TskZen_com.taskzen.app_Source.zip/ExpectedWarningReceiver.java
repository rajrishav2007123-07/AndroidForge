package com.taskzen.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ExpectedWarningReceiver extends BroadcastReceiver {
    public static final String ACTION="com.taskzen.app.EXPECTED_WARNING";
    public static final int NOTIFICATION_ID=9003;
    @Override public void onReceive(Context context, Intent intent){
        if(intent==null || !ACTION.equals(intent.getAction())) return;
        long taskId=intent.getLongExtra("taskId",0);
        String title=intent.getStringExtra("title");
        int minutes=intent.getIntExtra("minutes",5);
        if(title==null) title="Task";
        android.content.SharedPreferences prefs=context.getSharedPreferences("jee_prefs",Context.MODE_PRIVATE);
        if(!prefs.getBoolean("late_warn_enabled",true) || !prefs.getBoolean("late_warn_vibration",true)) return;
        NotificationHelper.showExpectedWarning(context,title,minutes);
    }
}
