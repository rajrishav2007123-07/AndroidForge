package com.taskzen.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.ZoneId;

public final class FocusScheduleManager {
    static final String ACTION_START="com.taskzen.app.FOCUS_SCHEDULE_START";
    static final String ACTION_END="com.taskzen.app.FOCUS_SCHEDULE_END";
    private FocusScheduleManager() {}
    public static void syncAll(Context c){
        JSONArray a=FocusScheduleStore.all(c); long now=System.currentTimeMillis();
        for(int i=0;i<a.length();i++){JSONObject s=a.optJSONObject(i);if(s==null)continue;String id=s.optString("id","");
            if(s.optBoolean("enabled",true)&&!s.optBoolean("paused",false)){
                long latest=FocusScheduleRules.latestStartMillis(s,now,ZoneId.systemDefault());
                if(latest>0&&latest!=s.optLong("lastProcessedOccurrence",0L)){
                    long end=FocusScheduleRules.endMillis(s,latest,ZoneId.systemDefault());
                    try{s.put("lastProcessedOccurrence",latest);s.put("occurrenceAt",latest);s.put("status",now<end?"awaiting_confirmation":"missed");FocusScheduleStore.put(c,s);}catch(Exception ignored){}
                    if(now<end)FocusScheduleReceiver.notifyOccurrence(c,s,latest);
                    else FocusScheduleReceiver.notifyMissed(c,s);
                }
            }
            if(!s.optBoolean("enabled",true)||s.optBoolean("paused",false)){cancel(c,id,ACTION_START);cancel(c,id,ACTION_END);continue;}
            long next=FocusScheduleRules.nextStartMillis(s,now,ZoneId.systemDefault());
            if(next>0){schedule(c,id,ACTION_START,next);schedule(c,id,ACTION_END,FocusScheduleRules.endMillis(s,next,ZoneId.systemDefault()));}
            else{cancel(c,id,ACTION_START);cancel(c,id,ACTION_END);}
        }
    }
    static void schedule(Context c,String id,String action,long at){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am==null)return;
        Intent alarmIntent=new Intent(c,FocusScheduleReceiver.class).setAction(action).setData(android.net.Uri.parse("tskzen-focus://schedule/"+android.net.Uri.encode(id)+"/"+action.substring(action.lastIndexOf('_')+1))).putExtra("schedule_id",id).putExtra("alarm_at",at);
        PendingIntent pi=PendingIntent.getBroadcast(c,0,alarmIntent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        try {if(Build.VERSION.SDK_INT>=31&&!am.canScheduleExactAlarms())am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);else if(Build.VERSION.SDK_INT>=23)am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);else am.setExact(AlarmManager.RTC_WAKEUP,at,pi);}catch(SecurityException e){am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);}
    }
    static void cancel(Context c,String id,String action){AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am!=null){PendingIntent p=pending(c,id,action,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);if(p!=null){am.cancel(p);p.cancel();}}}
    static PendingIntent pending(Context c,String id,String action,int flags){Intent i=new Intent(c,FocusScheduleReceiver.class).setAction(action).setData(android.net.Uri.parse("tskzen-focus://schedule/"+android.net.Uri.encode(id)+"/"+action.substring(action.lastIndexOf('_')+1)));i.putExtra("schedule_id",id);return PendingIntent.getBroadcast(c,0,i,flags);}
}
