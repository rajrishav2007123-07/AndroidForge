package com.taskzen.app;

import android.Manifest;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import org.json.JSONObject;

public class FocusScheduleReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent){
        if(intent==null)return; String id=intent.getStringExtra("schedule_id"); if(id==null)return;
        JSONObject s=FocusScheduleStore.find(context,id); if(s==null||!s.optBoolean("enabled",true)||s.optBoolean("paused",false))return;
        String action=intent.getAction();
        if(FocusScheduleManager.ACTION_START.equals(action)){
            s=copy(s);try{long occurrence=intent.getLongExtra("alarm_at",System.currentTimeMillis());s.put("status","awaiting_confirmation");s.put("occurrenceAt",occurrence);s.put("lastProcessedOccurrence",occurrence);FocusScheduleStore.put(context,s);}catch(Exception ignored){}
            notifyOccurrence(context,s,s.optLong("occurrenceAt"));
            FocusScheduleManager.syncAll(context);
        } else if(FocusScheduleManager.ACTION_END.equals(action)){
            s=copy(s);try{if("awaiting_confirmation".equals(s.optString("status"))){s.put("status","missed");FocusScheduleStore.put(context,s);notifyMissed(context,s);}else if("started".equals(s.optString("status"))){s.put("status","completed");FocusScheduleStore.put(context,s);}}catch(Exception ignored){}
        }
    }
    static void notifyOccurrence(Context context,JSONObject s,long at){
        String id=s.optString("id","");Intent open=new Intent(context,MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("focus_schedule_start",true).putExtra("schedule_id",id).putExtra("duration_minutes",s.optInt("durationMinutes",25)).putExtra("linked_task_id",s.optString("taskId",""));
        PendingIntent start=PendingIntent.getActivity(context,stableId(id),open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);post(context,stableId(id),"Focus schedule is ready",s.optString("title","Scheduled focus"),start,"Start now");
    }
    static void notifyMissed(Context context,JSONObject s){post(context,stableId(s.optString("id",""))+50000,"Focus schedule missed",s.optString("title","Your scheduled focus")+" was not started.",null,null);}
    private static JSONObject copy(JSONObject x){try{return new JSONObject(x.toString());}catch(Exception e){return new JSONObject();}}
    private static int stableId(String id){return Math.abs(id.hashCode()%40000)+12000;}
    private static void post(Context c,int id,String title,String body,PendingIntent action,String actionTitle){
        if(Build.VERSION.SDK_INT>=33&&c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        NotificationHelper.createChannel(c);NotificationCompat.Builder b=new NotificationCompat.Builder(c,"focus_schedules").setSmallIcon(R.drawable.ic_notification).setContentTitle(title).setContentText(body).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_DEFAULT);
        if(action!=null){b.setContentIntent(action).addAction(0,actionTitle,action);}try{NotificationManagerCompat.from(c).notify(id,b.build());}catch(SecurityException ignored){}
    }
}
