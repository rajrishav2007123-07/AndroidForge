package com.taskzen.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.zone.ZoneOffsetTransition;
import java.time.zone.ZoneRules;
import java.util.List;

/** Pure date/recurrence helpers. Local wall-clock schedules are recalculated in the current zone. */
public final class FocusScheduleRules {
    private FocusScheduleRules() {}

    public static long nextStartMillis(JSONObject schedule, long afterMillis, ZoneId zone) {
        String repeat = schedule.optString("repeat", "once");
        LocalTime time;
        try { time = LocalTime.parse(schedule.optString("startTime")); }
        catch (Exception e) { return -1L; }
        LocalDate from = ZonedDateTime.ofInstant(java.time.Instant.ofEpochMilli(afterMillis), zone).toLocalDate();
        String dateText = schedule.optString("startDate", "");
        LocalDate first;
        try { first = dateText.isEmpty() ? from : LocalDate.parse(dateText); }
        catch (Exception e) { return -1L; }
        if ("once".equals(repeat)) {
            if (first.isBefore(from)) return -1L;
            long candidate = resolve(LocalDateTime.of(first, time), zone).toInstant().toEpochMilli();
            return candidate > afterMillis ? candidate : -1L;
        }
        JSONArray days = schedule.optJSONArray("weekdays");
        for (int offset = 0; offset < 370; offset++) {
            LocalDate date = from.plusDays(offset);
            if (date.isBefore(first) || !matches(repeat, days, date.getDayOfWeek())) continue;
            long candidate = resolve(LocalDateTime.of(date, time), zone).toInstant().toEpochMilli();
            if (candidate > afterMillis) return candidate;
        }
        return -1L;
    }

    public static long endMillis(JSONObject schedule,long startMillis,ZoneId zone){
        try{LocalTime end=LocalTime.parse(schedule.optString("endTime"));LocalDate date=ZonedDateTime.ofInstant(java.time.Instant.ofEpochMilli(startMillis),zone).toLocalDate();ZonedDateTime at=resolve(LocalDateTime.of(date,end),zone);return at.toInstant().toEpochMilli();}catch(Exception e){return startMillis+Math.max(1,schedule.optLong("durationMinutes",25))*60000L;}
    }

    public static long latestStartMillis(JSONObject schedule,long nowMillis,ZoneId zone){
        long cursor=nowMillis-370L*24*60*60*1000,latest=-1;
        for(int i=0;i<400;i++){long next=nextStartMillis(schedule,cursor,zone);if(next<=0||next>nowMillis)break;latest=next;cursor=next;}
        return latest;
    }

    static boolean matches(String repeat, JSONArray days, DayOfWeek day) {
        if ("daily".equals(repeat)) return true;
        if ("weekdays".equals(repeat)) return day != DayOfWeek.SATURDAY && day != DayOfWeek.SUNDAY;
        if ("weekends".equals(repeat)) return day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY;
        if ("custom".equals(repeat) && days != null) {
            for (int i=0;i<days.length();i++) if (days.optInt(i,0)==day.getValue()) return true;
        }
        return false;
    }

    public static boolean conflicts(JSONObject a, JSONObject b) {
        try {
            LocalTime as=LocalTime.parse(a.optString("startTime")), ae=LocalTime.parse(a.optString("endTime"));
            LocalTime bs=LocalTime.parse(b.optString("startTime")), be=LocalTime.parse(b.optString("endTime"));
            if(!as.isBefore(be)||!bs.isBefore(ae))return false;
            String ar=a.optString("repeat","once"),br=b.optString("repeat","once");
            if("once".equals(ar)&&"once".equals(br))return a.optString("startDate").equals(b.optString("startDate"));
            if("once".equals(ar))return occursOn(b,LocalDate.parse(a.optString("startDate")).getDayOfWeek());
            if("once".equals(br))return occursOn(a,LocalDate.parse(b.optString("startDate")).getDayOfWeek());
            for(DayOfWeek day:DayOfWeek.values())if(occursOn(a,day)&&occursOn(b,day))return true;
        }catch(Exception ignored){}
        return false;
    }
    private static boolean occursOn(JSONObject s,DayOfWeek day){return matches(s.optString("repeat","once"),s.optJSONArray("weekdays"),day);}

    /** DST gaps shift to the first valid instant; overlaps choose the earlier offset deterministically. */
    static ZonedDateTime resolve(LocalDateTime local, ZoneId zone) {
        ZoneRules rules=zone.getRules();
        List<java.time.ZoneOffset> offsets=rules.getValidOffsets(local);
        if(offsets.size()==1)return ZonedDateTime.ofLocal(local,zone,offsets.get(0));
        if(offsets.size()>1)return ZonedDateTime.ofLocal(local,zone,offsets.get(0));
        ZoneOffsetTransition transition=rules.getTransition(local);
        return transition.getDateTimeAfter().atZone(zone);
    }
}
