package com.taskzen.app;

import static org.junit.Assert.*;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class FocusScheduleRulesTest {
    private JSONObject schedule(String repeat,String date,String time,String end,String days)throws Exception{
        JSONObject x=new JSONObject();x.put("repeat",repeat);x.put("startDate",date);x.put("startTime",time);x.put("endTime",end);x.put("durationMinutes",25);if(days!=null)x.put("weekdays",new JSONArray(days));return x;
    }
    @Test public void oneTimeScheduleOnlyReturnsFutureOccurrence()throws Exception{
        ZoneId zone=ZoneId.of("Asia/Kolkata");long base=ZonedDateTime.of(2026,11,8,8,0,0,0,zone).toInstant().toEpochMilli();
        JSONObject s=schedule("once","2026-11-08","09:00","10:00",null);
        assertEquals(ZonedDateTime.of(2026,11,8,9,0,0,0,zone).toInstant().toEpochMilli(),FocusScheduleRules.nextStartMillis(s,base,zone));
        assertEquals(-1,FocusScheduleRules.nextStartMillis(s,ZonedDateTime.of(2026,11,8,9,0,0,0,zone).toInstant().toEpochMilli(),zone));
    }
    @Test public void dailyAndWeekdayRecurrenceAdvanceCorrectly()throws Exception{
        ZoneId z=ZoneId.of("UTC");long base=Instant.parse("2026-11-08T10:00:00Z").toEpochMilli();
        assertEquals(Instant.parse("2026-11-09T08:00:00Z").toEpochMilli(),FocusScheduleRules.nextStartMillis(schedule("daily","2026-11-01","08:00","09:00",null),base,z));
        assertEquals(Instant.parse("2026-11-09T08:00:00Z").toEpochMilli(),FocusScheduleRules.nextStartMillis(schedule("weekdays","2026-11-01","08:00","09:00",null),base,z));
    }
    @Test public void customDaysOnlyMatchChosenWeekday()throws Exception{
        ZoneId z=ZoneId.of("UTC");long base=Instant.parse("2026-11-08T00:00:00Z").toEpochMilli();
        assertEquals(Instant.parse("2026-11-11T08:00:00Z").toEpochMilli(),FocusScheduleRules.nextStartMillis(schedule("custom","2026-11-08","08:00","09:00","[3]"),base,z));
    }
    @Test public void daylightSavingGapMovesToFirstValidLocalTime()throws Exception{
        ZoneId z=ZoneId.of("America/New_York");long base=Instant.parse("2026-03-08T05:00:00Z").toEpochMilli();
        assertEquals(Instant.parse("2026-03-08T07:00:00Z").toEpochMilli(),FocusScheduleRules.nextStartMillis(schedule("once","2026-03-08","02:30","04:00",null),base,z));
    }
    @Test public void daylightSavingOverlapUsesEarlierOffset()throws Exception{
        ZoneId z=ZoneId.of("America/New_York");long base=Instant.parse("2026-11-01T04:00:00Z").toEpochMilli();
        assertEquals(Instant.parse("2026-11-01T05:30:00Z").toEpochMilli(),FocusScheduleRules.nextStartMillis(schedule("once","2026-11-01","01:30","02:30",null),base,z));
    }
    @Test public void latestPastOccurrenceCanBeReportedMissedAfterRestart()throws Exception{
        ZoneId z=ZoneId.of("UTC");long now=Instant.parse("2026-11-08T10:00:00Z").toEpochMilli();
        assertEquals(Instant.parse("2026-11-08T08:00:00Z").toEpochMilli(),FocusScheduleRules.latestStartMillis(schedule("daily","2026-11-01","08:00","09:00",null),now,z));
    }
    @Test public void localScheduleTimeRecalculatesForCurrentTimezone()throws Exception{
        JSONObject s=schedule("daily","2026-11-08","08:00","09:00",null);
        long before=Instant.parse("2026-11-08T00:00:00Z").toEpochMilli();
        assertEquals(Instant.parse("2026-11-08T02:30:00Z").toEpochMilli(),FocusScheduleRules.nextStartMillis(s,before,ZoneId.of("Asia/Kolkata")));
    }
    @Test public void overlapConflictsOnlyWhenTimesAndRepeatDaysOverlap()throws Exception{
        JSONObject a=schedule("custom","2026-11-09","09:00","10:00","[1,3]");
        JSONObject b=schedule("weekdays","2026-11-09","09:30","10:30",null);
        JSONObject c=schedule("weekends","2026-11-09","09:30","10:30",null);
        assertTrue(FocusScheduleRules.conflicts(a,b));assertFalse(FocusScheduleRules.conflicts(a,c));
    }
}
