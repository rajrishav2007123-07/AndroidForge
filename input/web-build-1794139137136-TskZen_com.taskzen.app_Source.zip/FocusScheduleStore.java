package com.taskzen.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

/** Schedule data is isolated from task_state and remains available to receivers during reboot. */
public final class FocusScheduleStore {
    private static final String PREFS="focus_schedule_store", KEY="schedules_v1";
    private FocusScheduleStore() {}
    public static JSONArray all(Context c){try{return new JSONArray(c.getSharedPreferences(PREFS,0).getString(KEY,"[]"));}catch(Exception e){return new JSONArray();}}
    public static synchronized void put(Context c, JSONObject item){
        JSONArray old=all(c), next=new JSONArray(); String id=item.optString("id",""); boolean found=false;
        for(int i=0;i<old.length();i++){JSONObject x=old.optJSONObject(i);if(x==null)continue;if(id.equals(x.optString("id"))){next.put(item);found=true;}else next.put(x);}
        if(!found)next.put(item);save(c,next);
    }
    public static synchronized void remove(Context c,String id){JSONArray old=all(c),next=new JSONArray();for(int i=0;i<old.length();i++){JSONObject x=old.optJSONObject(i);if(x!=null&&!id.equals(x.optString("id")))next.put(x);}save(c,next);}
    public static synchronized void save(Context c,JSONArray a){c.getSharedPreferences(PREFS,0).edit().putString(KEY,a.toString()).apply();}
    public static JSONObject find(Context c,String id){JSONArray a=all(c);for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&id.equals(x.optString("id")))return x;}return null;}
}
