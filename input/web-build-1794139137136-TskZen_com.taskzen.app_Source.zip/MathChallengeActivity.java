package com.taskzen.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

/**
 * Full-screen activity: user must solve 2 easy random add/sub questions
 * to stop the alarm. Prevents accidental dismiss.
 */
public class MathChallengeActivity extends Activity {

    private TextView q1View, q2View, statusView;
    private EditText a1Input, a2Input;
    private int ans1, ans2;
    private int attempts = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Keep screen on and show over lock screen if possible
        getWindow().addFlags(
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                        | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                        | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                        | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        );

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(48, 80, 48, 48);
        root.setBackgroundColor(0xFF1A0A2E);

        TextView title = new TextView(this);
        title.setText("🧠 Solve to stop alarm");
        title.setTextSize(24);
        title.setTextColor(0xFFFFFFFF);
        title.setPadding(0, 0, 0, 24);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Answer both easy questions correctly");
        sub.setTextSize(14);
        sub.setTextColor(0xFFB8A0D0);
        sub.setPadding(0, 0, 0, 32);
        root.addView(sub);

        q1View = new TextView(this);
        q1View.setTextSize(22);
        q1View.setTextColor(0xFFFFD700);
        q1View.setPadding(0, 16, 0, 8);
        root.addView(q1View);

        a1Input = new EditText(this);
        a1Input.setHint("Answer 1");
        a1Input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER
                | android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);
        a1Input.setTextColor(0xFFFFFFFF);
        a1Input.setHintTextColor(0xFF888888);
        a1Input.setBackgroundColor(0xFF2A1A40);
        a1Input.setPadding(24, 20, 24, 20);
        root.addView(a1Input);

        q2View = new TextView(this);
        q2View.setTextSize(22);
        q2View.setTextColor(0xFFFFD700);
        q2View.setPadding(0, 32, 0, 8);
        root.addView(q2View);

        a2Input = new EditText(this);
        a2Input.setHint("Answer 2");
        a2Input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER
                | android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);
        a2Input.setTextColor(0xFFFFFFFF);
        a2Input.setHintTextColor(0xFF888888);
        a2Input.setBackgroundColor(0xFF2A1A40);
        a2Input.setPadding(24, 20, 24, 20);
        root.addView(a2Input);

        statusView = new TextView(this);
        statusView.setTextSize(14);
        statusView.setTextColor(0xFFFF6B9D);
        statusView.setPadding(0, 24, 0, 16);
        root.addView(statusView);

        Button submit = new Button(this);
        submit.setText("✓ Submit & Stop Alarm");
        submit.setTextSize(16);
        submit.setBackgroundColor(0xFF6C4CFF);
        submit.setTextColor(0xFFFFFFFF);
        submit.setOnClickListener(v -> checkAnswers());
        root.addView(submit);

        setContentView(root);
        generateQuestions();
    }

    private void generateQuestions() {
        Random r = new Random();
        // Easy: numbers 1–20, add or subtract (result non-negative for sub)
        int a = 1 + r.nextInt(20);
        int b = 1 + r.nextInt(20);
        if (r.nextBoolean()) {
            q1View.setText("Q1:  " + a + "  +  " + b + "  = ?");
            ans1 = a + b;
        } else {
            if (a < b) { int t = a; a = b; b = t; }
            q1View.setText("Q1:  " + a + "  −  " + b + "  = ?");
            ans1 = a - b;
        }

        a = 1 + r.nextInt(20);
        b = 1 + r.nextInt(20);
        if (r.nextBoolean()) {
            q2View.setText("Q2:  " + a + "  +  " + b + "  = ?");
            ans2 = a + b;
        } else {
            if (a < b) { int t = a; a = b; b = t; }
            q2View.setText("Q2:  " + a + "  −  " + b + "  = ?");
            ans2 = a - b;
        }
        a1Input.setText("");
        a2Input.setText("");
        statusView.setText("");
    }

    private void checkAnswers() {
        attempts++;
        try {
            int u1 = Integer.parseInt(a1Input.getText().toString().trim());
            int u2 = Integer.parseInt(a2Input.getText().toString().trim());
            if (u1 == ans1 && u2 == ans2) {
                AlarmPlayer.stop();
                NotificationHelper.cancelAlarmNotification(this);
                Toast.makeText(this, "✅ Correct! Alarm stopped", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                statusView.setText("❌ Wrong. Try again (attempt " + attempts + ")");
                generateQuestions(); // new questions
            }
        } catch (NumberFormatException e) {
            statusView.setText("Please enter numbers only");
        }
    }

    @Override
    public void onBackPressed() {
        // Prevent dismissing without solving
        Toast.makeText(this, "Solve the questions to stop the alarm", Toast.LENGTH_SHORT).show();
    }
}
