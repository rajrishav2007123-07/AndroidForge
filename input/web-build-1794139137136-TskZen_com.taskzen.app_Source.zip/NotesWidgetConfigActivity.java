package com.taskzen.app;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashSet;
import java.util.Set;

public class NotesWidgetConfigActivity extends Activity {
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        int id=getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,AppWidgetManager.INVALID_APPWIDGET_ID);
        if(id==AppWidgetManager.INVALID_APPWIDGET_ID){setResult(RESULT_CANCELED);finish();return;}
        setResult(RESULT_CANCELED);
        Context c=this;
        android.content.SharedPreferences prefs=getSharedPreferences("jee_prefs",MODE_PRIVATE);
        AppWidgetManager mgr=AppWidgetManager.getInstance(this);
        int[] existing=mgr.getAppWidgetIds(new android.content.ComponentName(this,NotesWidgetProvider.class));
        Set<Integer> used=new HashSet<>();
        boolean alreadyRegistered=false;
        for(int x:existing){ if(x==id) alreadyRegistered=true; else used.add(prefs.getInt("notes_widget_slot_"+x,-1)); }
        if(existing.length>=3 && !alreadyRegistered){
            Toast.makeText(this,"Maximum 3 Notes Widgets allowed.",Toast.LENGTH_LONG).show(); finish(); return;
        }
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(28,28,28,28);
        TextView title=new TextView(this); title.setText("Choose Notes Widget"); title.setTextSize(22); title.setGravity(Gravity.CENTER_VERTICAL); box.addView(title);
        TextView info=new TextView(this); info.setText("Choose one of the 3 note slots. Edit its text and colour inside Menu → Notes Widget."); info.setTextSize(14); info.setPadding(0,12,0,14); box.addView(info);
        String[] labels={"Notes Widget 1","Notes Widget 2","Notes Widget 3"};
        for(int i=0;i<3;i++){
            if(used.contains(i)) continue;
            final int slot=i; Button btn=new Button(this); btn.setText(labels[i]);
            btn.setOnClickListener(v->{
                prefs.edit().putInt("notes_widget_slot_"+id,slot).apply();
                Intent result=new Intent(); result.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id); setResult(RESULT_OK,result);
                NotesWidgetProvider.requestUpdate(c); finish();
            }); box.addView(btn);
        }
        setContentView(box);
    }
}
