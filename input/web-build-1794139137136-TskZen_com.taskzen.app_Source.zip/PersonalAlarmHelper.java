package com.taskzen.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;

/**
 * Schedules up to 5 independent personal alarms (not linked to tasks).
 */
public class PersonalAlarmHelper {

    private static final String PREFS = "jee_prefs";
    private static final String KEY = "personal_alarms_json";

    public static String getAlarmsJson(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY, "[]");
    }

    public static void saveAlarmsJson(Context context, String json) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY, json).apply();
    }

    public static void scheduleAll(Context context) {
        cancelAll(context);
        try {
            JSONArray arr = new JSONArray(getAlarmsJson(context));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject a = arr.getJSONObject(i);
                if (!a.optBoolean("enabled", true)) continue;
                scheduleOne(context, a.optInt("id", i + 1),
                        a.optString("title", "Alarm"),
                        a.optString("time", ""),
                        a.optBoolean("repeatDaily", false));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void scheduleOne(Context context, int id, String title, String timeHHMM, boolean daily) {
        if (timeHHMM == null || !timeHHMM.contains(":")) return;
        try {
            String[] p = timeHHMM.split(":");
            int hour = Integer.parseInt(p[0].trim());
            int minute = Integer.parseInt(p[1].trim());

            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY, hour);
            cal.set(Calendar.MINUTE, minute);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            if (cal.getTimeInMillis() <= System.currentTimeMillis()) {
                cal.add(Calendar.DAY_OF_YEAR, 1);
            }

            Intent intent = new Intent(context, PersonalAlarmReceiver.class);
            intent.setAction("com.taskzen.app.PERSONAL_ALARM");
            intent.putExtra("alarmId", id);
            intent.putExtra("title", title);

            PendingIntent pi = PendingIntent.getBroadcast(
                    context, 2000 + id, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;

            if (daily) {
                am.setRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(),
                        AlarmManager.INTERVAL_DAY, pi);
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
                } else {
                    am.setExact(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void cancelAll(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        for (int id = 1; id <= 5; id++) {
            Intent intent = new Intent(context, PersonalAlarmReceiver.class);
            intent.setAction("com.taskzen.app.PERSONAL_ALARM");
            PendingIntent pi = PendingIntent.getBroadcast(
                    context, 2000 + id, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            am.cancel(pi);
        }
    }

    public static void cancelOne(Context context, int id) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent intent = new Intent(context, PersonalAlarmReceiver.class);
        intent.setAction("com.taskzen.app.PERSONAL_ALARM");
        PendingIntent pi = PendingIntent.getBroadcast(
                context, 2000 + id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.cancel(pi);
    }
}
