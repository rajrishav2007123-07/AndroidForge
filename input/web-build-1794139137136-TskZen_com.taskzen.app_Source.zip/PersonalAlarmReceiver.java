package com.taskzen.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Fires when a user-set personal alarm triggers.
 */
public class PersonalAlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String title = intent.getStringExtra("title");
        if (title == null || title.isEmpty()) title = "Personal Alarm";
        int alarmId = intent.getIntExtra("alarmId", 0);

        NotificationHelper.showPersonal(context, "⏰ " + title, "Personal alarm is ringing");
        AlarmPlayer.play(context);
    }
}
