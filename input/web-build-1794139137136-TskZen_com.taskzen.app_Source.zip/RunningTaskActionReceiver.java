package com.taskzen.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Handles Start / Stop actions from notifications.
 * Start: task alarm notification → start study session in WebView.
 * Stop: running-task notification → stop session.
 */
public class RunningTaskActionReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;
        String action = intent.getAction();
        long taskId = intent.getLongExtra(NotificationHelper.EXTRA_TASK_ID, 0);

        if (NotificationHelper.ACTION_NOTIF_START.equals(action)) {
            // Stop alarm sound / vibration
            try {
                Intent stopAlarm = new Intent(context, StopAlarmReceiver.class);
                stopAlarm.setAction(NotificationHelper.ACTION_STOP_ALARM);
                context.sendBroadcast(stopAlarm);
            } catch (Exception ignored) {}
            try {
                NotificationHelper.cancelTaskStartAlarm(context, taskId);
            } catch (Exception ignored) {}

            Intent i = new Intent(context, MainActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            i.putExtra("notif_action", "start");
            i.putExtra("task_id", taskId);
            context.startActivity(i);
            return;
        }

        if (NotificationHelper.ACTION_NOTIF_STOP.equals(action)) {
            Intent i = new Intent(context, MainActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            i.putExtra("notif_action", "stop");
            i.putExtra("task_id", taskId);
            context.startActivity(i);
            NotificationHelper.cancelRunningTask(context);
        }
    }
}
