package com.taskzen.app;
import android.content.BroadcastReceiver;import android.content.Context;import android.content.Intent;
public class StopExpectedWarningReceiver extends BroadcastReceiver {
 public static final String ACTION_STOP="com.taskzen.app.STOP_EXPECTED_WARNING";
 @Override public void onReceive(Context c,Intent i){if(i!=null&&ACTION_STOP.equals(i.getAction()))NotificationHelper.stopExpectedWarning(c);}
}
