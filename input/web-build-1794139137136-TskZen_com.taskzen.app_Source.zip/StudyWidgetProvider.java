package com.taskzen.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class StudyWidgetProvider extends AppWidgetProvider {

    public static final String ACTION_REFRESH = "com.taskzen.app.WIDGET_REFRESH";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        if (appWidgetIds == null) return;
        for (int appWidgetId : appWidgetIds) {
            try {
                updateAppWidget(context, appWidgetManager, appWidgetId);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {
        super.onDeleted(context, appWidgetIds);
        android.content.SharedPreferences.Editor ed=context.getSharedPreferences("jee_prefs",Context.MODE_PRIVATE).edit();
        if(appWidgetIds!=null) for(int id:appWidgetIds) ed.remove("task_widget_day_offset_"+id);
        ed.apply();
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        try {
            if (intent != null && (ACTION_REFRESH.equals(intent.getAction())
                    || AppWidgetManager.ACTION_APPWIDGET_UPDATE.equals(intent.getAction()))) {
                AppWidgetManager mgr = AppWidgetManager.getInstance(context);
                int[] ids = mgr.getAppWidgetIds(new ComponentName(context, StudyWidgetProvider.class));
                onUpdate(context, mgr, ids);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void requestUpdate(Context context) {
        try {
            Context app = context.getApplicationContext();
            AppWidgetManager mgr = AppWidgetManager.getInstance(app);
            int[] ids = mgr.getAppWidgetIds(new ComponentName(app, StudyWidgetProvider.class));
            if (ids != null && ids.length > 0) {
                Intent intent = new Intent(app, StudyWidgetProvider.class);
                intent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
                intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
                app.sendBroadcast(intent);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_study);
        SharedPreferences widgetPrefs=context.getSharedPreferences("jee_prefs",Context.MODE_PRIVATE);
        int widgetSlot=widgetPrefs.getInt("task_widget_day_offset_"+appWidgetId,0);
        if(widgetSlot<0 || widgetSlot>2) widgetSlot=0;
        Calendar targetCal=Calendar.getInstance();
        String targetDate=widgetPrefs.getString("task_widget_date_"+widgetSlot, "");
        if(targetDate==null || targetDate.isEmpty()){
            targetCal.add(Calendar.DAY_OF_YEAR,widgetSlot);
            targetDate=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(targetCal.getTime());
        } else {
            try { targetCal.setTime(new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(targetDate)); } catch(Exception ignored) {}
        }
        String dayLabel="Widget "+(widgetSlot+1);

        SharedPreferences prefs0 = widgetPrefs;
        // Prefer the date saved in the app state, so import/export and app settings
        // immediately control which exact calendar date this widget displays.
        try {
            String savedState = prefs0.getString("task_state", "");
            if (savedState != null && !savedState.isEmpty()) {
                JSONObject saved = new JSONObject(savedState);
                JSONArray savedDates = saved.optJSONArray("taskWidgetDates");
                if (savedDates != null && widgetSlot < savedDates.length()) {
                    String d = savedDates.optString(widgetSlot, "");
                    if (d != null && !d.isEmpty()) {
                        targetDate = d;
                        try { targetCal.setTime(new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(targetDate)); } catch(Exception ignored) {}
                    }
                }
            }
        } catch (Exception ignored) {}
        String twColor = prefs0.getString("task_widget_color_" + widgetSlot, prefs0.getString("task_widget_color", "purple"));
        String twSize = prefs0.getString("task_widget_text_size", "normal");
        // Prefer the per-slot colours stored in the app state so settings survive import/export
        // and every existing widget instance reflects the same Today/Tomorrow/+2 configuration.
        try {
            String stateJson = prefs0.getString("task_state", "");
            if (stateJson != null && !stateJson.isEmpty()) {
                JSONObject st = new JSONObject(stateJson);
                JSONArray colors = st.optJSONArray("taskWidgetColors");
                if (colors != null && widgetSlot >= 0 && widgetSlot < colors.length()) {
                    String c = colors.optString(widgetSlot, "");
                    if (c != null && !c.isEmpty()) twColor = c;
                }
                twSize = st.optString("taskWidgetTextSize", twSize);
            }
        } catch (Exception ignored) {}
        views.setInt(R.id.widget_root, "setBackgroundResource", taskWidgetBgForColor(twColor));
        int widgetFg = taskWidgetTextColor(twColor);
        views.setTextColor(R.id.widget_title, widgetFg);
        views.setTextColor(R.id.widget_subtitle, widgetFg);
        views.setTextColor(R.id.widget_exam, widgetFg);
        views.setTextColor(R.id.widget_progress, widgetFg);
        views.setTextColor(R.id.widget_all_tasks, widgetFg);
        views.setFloat(R.id.widget_title, "setTextSize", textSizeFor(twSize, 15f));
        views.setFloat(R.id.widget_subtitle, "setTextSize", textSizeFor(twSize, 11f));
        views.setFloat(R.id.widget_exam, "setTextSize", textSizeFor(twSize, 12f));
        views.setFloat(R.id.widget_progress, "setTextSize", textSizeFor(twSize, 12f));
        views.setFloat(R.id.widget_all_tasks, "setTextSize", textSizeFor(twSize, 13f));


        try {
            Intent openIntent = new Intent(context, MainActivity.class);
            openIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent openPi = PendingIntent.getActivity(
                    context, appWidgetId, openIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            views.setOnClickPendingIntent(R.id.widget_root, openPi);
        } catch (Exception e) {
            e.printStackTrace();
        }

        String prettyToday = "Today";
        String today = "";
        try {
            today = targetDate;
            prettyToday = new SimpleDateFormat("EEE, dd MMM", Locale.getDefault()).format(targetCal.getTime());
        } catch (Exception ignored) {}

        views.setTextViewText(R.id.widget_title, "JEE Study Tracker");
        views.setTextViewText(R.id.widget_subtitle, dayLabel + " · " + prettyToday);
        views.setTextViewText(R.id.widget_progress, "Open app and add tasks");
        views.setTextViewText(R.id.widget_exam, "");
        views.setTextViewText(R.id.widget_all_tasks, "");

        try {
            SharedPreferences prefs = context.getSharedPreferences("jee_prefs", Context.MODE_PRIVATE);
            boolean widgetEnabled = prefs.getBoolean("widget_enabled", true);

            if (!widgetEnabled) {
                views.setTextViewText(R.id.widget_progress, "Widget disabled in settings");
                appWidgetManager.updateAppWidget(appWidgetId, views);
                return;
            }

            String json = prefs.getString("task_state", "");
            int total = 0;
            int done = 0;
            long takenSec = 0;
            long expectedSec = 0;
            ArrayList<String> pendingTitles = new ArrayList<>();

            if (json != null && !json.isEmpty()) {
                JSONObject state = new JSONObject(json);

                try {
                    JSONObject exam = state.optJSONObject("exam");
                    if (exam != null) {
                        String examDate = exam.optString("date", "");
                        String examName = exam.optString("name", "Exam");
                        if (!examDate.isEmpty()) {
                            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
                            Date target = sdf.parse(examDate);
                            if (target != null) {
                                Calendar cal = Calendar.getInstance();
                                cal.setTime(target);
                                cal.set(Calendar.HOUR_OF_DAY, 23);
                                cal.set(Calendar.MINUTE, 59);
                                long diff = cal.getTimeInMillis() - System.currentTimeMillis();
                                // Match the app's home-screen "days left" calc (Math.ceil), so this
                                // widget's number never drifts from what's shown inside the app.
                                long days = Math.max(0, (long) Math.ceil(diff / 86400000.0));
                                views.setTextViewText(R.id.widget_exam,
                                        days + " days left · " + examName);
                            }
                        }
                    }
                } catch (Exception ignored) {}

                if (!today.isEmpty()) {
                    JSONArray tasks = state.optJSONArray("tasks");
                    if (tasks != null) {
                        for (int i = 0; i < tasks.length(); i++) {
                            JSONObject t = tasks.optJSONObject(i);
                            if (t == null) continue;
                            String date = t.optString("date", "");
                            if (!today.equals(date)) continue;

                            total++;
                            boolean completed = t.optBoolean("completed", false);
                            long runningAt = t.optLong("runningAt", 0);
                            boolean isRunning = runningAt > 0;
                            double taken = t.optDouble("taken", 0);
                            if (isRunning) {
                                taken += (System.currentTimeMillis() - runningAt) / 1000.0;
                            }
                            takenSec += (long) taken;
                            expectedSec += t.optInt("expected", 0) * 60L;

                            if (completed) {
                                done++;
                            } else {
                                String title = t.optString("title", "Task");
                                String subject = t.optString("subject", "");
                                String prefix = isRunning ? "▶ " : "• ";
                                pendingTitles.add(prefix + title
                                        + (subject.isEmpty() ? "" : " | " + subject));
                            }
                        }
                    }
                }
            }

            int pct = expectedSec > 0
                    ? (int) Math.min(100, Math.round((takenSec * 100.0) / expectedSec))
                    : 0;
            String progressText = done + "/" + total + " done | "
                    + fmtShort(takenSec) + " / " + fmtShort(expectedSec)
                    + " | " + pct + "%";
            views.setTextViewText(R.id.widget_progress, progressText);

            if (pendingTitles.isEmpty()) {
                if (total == 0) {
                    views.setTextViewText(R.id.widget_all_tasks, "No tasks for " + dayLabel.toLowerCase(Locale.getDefault()));
                } else {
                    views.setTextViewText(R.id.widget_all_tasks, "All done for today ✓");
                }
            } else {
                // Show ALL pending tasks — expand widget to see more
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < pendingTitles.size(); i++) {
                    if (i > 0) sb.append("\n");
                    sb.append(pendingTitles.get(i));
                }
                views.setTextViewText(R.id.widget_all_tasks, sb.toString());
            }

        } catch (Exception e) {
            e.printStackTrace();
            views.setTextViewText(R.id.widget_progress, "Tap to open app");
            views.setTextViewText(R.id.widget_all_tasks, "Add a task to see it here");
        }

        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    private static String fmtShort(long sec) {
        sec = Math.max(0, sec);
        long h = sec / 3600;
        long m = (sec % 3600) / 60;
        if (h > 0) return h + "h " + m + "m";
        return m + "m";
    }

    private static int taskWidgetBgForColor(String color) {
        if (color == null) color = "purple";
        switch (color.toLowerCase()) {
            case "white": return R.drawable.widget_bg_white;
            case "black": return R.drawable.widget_bg_black;
            case "red": return R.drawable.widget_bg_red;
            case "orange": return R.drawable.widget_bg_orange;
            case "yellow": return R.drawable.widget_bg_yellow;
            case "green": return R.drawable.widget_bg_green;
            case "lime": return R.drawable.widget_bg_lime;
            case "skyblue": return R.drawable.widget_bg_skyblue;
            case "blue": return R.drawable.widget_bg_blue;
            case "purple": default: return R.drawable.widget_bg_purple;
        }
    }

    private static int taskWidgetTextColor(String color) {
        if (color == null) return android.graphics.Color.WHITE;
        switch (color.toLowerCase()) {
            case "white": case "yellow": case "lime": case "skyblue":
                return android.graphics.Color.BLACK;
            default: return android.graphics.Color.WHITE;
        }
    }

    private static float textSizeFor(String size, float base) {
        if (size == null) size = "normal";
        switch (size.toLowerCase()) {
            case "small": return base * 0.85f;
            case "large": return base * 1.2f;
            case "xlarge": return base * 1.4f;
            default: return base;
        }
    }
}
