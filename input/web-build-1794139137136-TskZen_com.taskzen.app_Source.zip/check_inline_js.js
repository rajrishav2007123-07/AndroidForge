const fs = require('fs');
const source = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const scripts = [...source.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/gi)];
scripts.forEach((match) => new Function(match[1]));
console.log(`Parsed ${scripts.length} inline scripts successfully.`);
