# App Blocking test checklist

Run these checks on a physical Android phone after installing the debug build and enabling TaskZen App Blocking in Android Settings → Accessibility.

1. Create two named lists and select different launchable apps in each.
2. Assign List A to Task A and List B to Task B; confirm each task uses only its assigned task-start list.
3. Enable task-start blocking, start a task, open a selected app, and confirm the full-screen notice shows the app icon/name, list name, task title, custom message and quote.
4. Return to TaskZen, enable a task break, and confirm task-based blocking pauses; turn the break off and confirm it resumes.
5. Stop or complete the task and confirm task-based blocking stops.
6. Enable a daily schedule and confirm it blocks independently of task state. Stop a task during the schedule and confirm the scheduled block remains until the schedule end.
7. Test a schedule crossing midnight (for example 22:00–06:00).
8. Set an app to 10 minutes per rolling hour and 5 minutes continuous; confirm the app is blocked at the continuous cap and the remaining hourly allowance can be used after reopening.
9. Confirm background time is not counted, and usage from only selected apps is tracked.
10. Confirm list creation/edit/delete/duplicate and task-list assignment are unavailable while a task or schedule is actively blocking.
11. Reboot the phone and reopen a selected app while a task/schedule is still active; confirm the enabled Accessibility service resumes evaluation.
12. Disable the Accessibility service in Android Settings and confirm TaskZen no longer intercepts selected apps.
13. Export JSON and inspect it: selected app package names and app-usage/attempt analytics must not appear. Import an older JSON backup and confirm tasks still load.
14. Test under battery saver and the phone manufacturer's background restrictions.

Android/Play note: Accessibility-based detection is device- and OS-dependent and is not a tamper-proof lock. Complete the Play Console Accessibility API declaration and review the public privacy policy/Data safety answers before production rollout.
