# TaskZen Study

**Version 2.0.0** · targetSdk 36 · minSdk 26 · Java 17

A focused study productivity app for JEE / NEET / Engineering / Business cohorts.  

---

## Features

- **Task timers** with break tracking, single-running-task rule, expected-time warnings
- **Cohorts**: JEE, NEET, B.Tech/Engineering, Startup/Business/Corporate
- **Home-screen widgets**: daily task progress + circular exam countdown
- **Alarms & reminders**: exact alarms, continuous vibration (foreground service), personal alarms, math-challenge stop
- **Library / continuous mode** for long study sessions
- **Export / import** JSON + auto safety backup to Downloads
- **AdMob** banners, interstitial, rewarded, native (no app-open ads)
- **Themes, reports, hourly motivation**

All workflows above are preserved from the production 1.6.x line.

---

## Project structure

```
app/
  src/main/
    assets/index.html          # Full study UI + business logic
    java/com/jeetracker/app/   # Native bridge, widgets, alarms, ads
    res/                       # Layouts, drawables, widgets, themes
  build.gradle
  proguard-rules.pro
```

Native responsibilities:
| Class | Role |
|-------|------|
| `MainActivity` | WebView host, permissions, file chooser |
| `AndroidBridge` | `@JavascriptInterface` surface for the Web UI |
| `AdManager` | AdMob banners / interstitial / rewarded / native |
| `VibrationService` | Foreground continuous vibration (Doze-safe) |
| `*WidgetProvider` | Home-screen widgets |
| `*Alarm*` / `*Receiver` | Exact alarms, boot restore, notifications |
| `NotificationHelper` | Channels and notification actions |

---

## Build

```bash
cp local.properties.example local.properties
# edit sdk.dir=...

./gradlew clean bundleRelease
# AAB → app/build/outputs/bundle/release/app-release.aab
```

Debug:
```bash
./gradlew assembleDebug
```

---

## Google Play (API 36 / 2026) checklist

| Requirement | Status in this project |
|-------------|------------------------|
| targetSdk / compileSdk 36 | ✅ |
| 16 KB page size | ✅ (pure Java + WebView) |
| SCHEDULE_EXACT_ALARM only (no USE_EXACT_ALARM) | ✅ |
| WebView debugging only in debug builds | ✅ |
| Cleartext traffic disabled | ✅ |
| R8 minify + shrink for release | ✅ |
| Foreground service `specialUse` declared | ✅ (still declare in Play Console) |
| AAB packaging | Use `bundleRelease` |

**You must still complete in Play Console:**
2. Privacy policy URL
3. Account deletion path (if using Auth)
4. Special-use FGS declaration
5. Ads / Advertising ID declaration

Replace `privacy_policy_url` in `res/values/strings.xml` with your real policy.

---

## Configuration

- **AdMob App ID** – `AndroidManifest.xml` meta-data  
- **Ad unit IDs** – `AdManager.java` constants  

Never embed service-account keys or admin passwords in the APK.

---

## License / notes

Production-ready structure for Play Store submission.  
Business logic lives in `index.html` by design so the proven study workflows remain stable.


## v2.0.4 Language Selector
Added a top-right language selector with 10 languages (English first): English, Hindi, Bengali, Telugu, Marathi, Tamil, Gujarati, Kannada, Malayalam and Punjabi. Selection is persisted locally.

## App Blocking (v2.0.14 / versionCode 53)

- Open **Menu → App Blocking** to create multiple named blocking lists.
- A list can block selected launchable apps when an assigned task starts and/or during a daily time schedule. Both enabled rules are evaluated together.
- Assign a list separately to each task in the Add/Edit Task dialog.
- Configure a maximum foreground-use allowance per selected app: minutes per rolling 60-minute window and maximum continuous foreground minutes. Set both values to `0` for strict blocking.
- Task-based blocking pauses during a global or task break and resumes when the break ends. A scheduled rule remains active independently, including after a task is stopped or completed.
- The blocking notice shows the attempted app icon/name, list, current task (when applicable), custom message and a motivational line. The user can return to TaskZen to stop the task or turn on a break.
- App Blocking requires the user to explicitly enable **TaskZen App Blocking** under Android Settings → Accessibility. The service requests only foreground-window change events and does not retrieve window content.
- Selected app package names, foreground-use counters and blocking-attempt history are stored locally in app preferences/local storage. They are deliberately excluded from normal JSON exports and automatic JSON backups. Task records retain only the selected blocking-list ID.

### Android / Play testing notes

Accessibility-based foreground detection is subject to Android version and device-manufacturer background/service restrictions; it is not a tamper-proof device lock and must not be advertised as guaranteed 100% blocking. Before Play publication, complete the Play Console Accessibility API declaration, provide the in-app prominent disclosure/consent, and ensure the public privacy policy and Data safety answers describe this optional feature accurately. Test on physical devices, including reboot, app restart, battery saver, task stop/complete, both break controls, schedule crossing midnight, and usage allowance rollover.
