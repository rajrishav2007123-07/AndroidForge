# Study Tracker – R8 / ProGuard rules (release)

-keepattributes *Annotation*,SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# WebView JavaScript bridge – method names must match index.html calls
-keepclassmembers class com.jeetracker.app.AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Firebase

# AdMob
-keep class com.google.android.gms.ads.** { *; }
-dontwarn com.google.android.gms.**

# Application components
-keep class com.jeetracker.app.StudyTrackerApp { *; }
-keep class * extends android.content.BroadcastReceiver
-keep class * extends android.app.Service
-keep class * extends android.appwidget.AppWidgetProvider
-keep class * extends android.app.Activity

-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}
