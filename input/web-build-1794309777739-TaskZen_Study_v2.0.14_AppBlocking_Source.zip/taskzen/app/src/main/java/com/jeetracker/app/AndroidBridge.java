package com.jeetracker.app;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.core.content.FileProvider;


import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

/**
 * JavaScript ↔ Java bridge.
 * HTML calls these methods via window.AndroidBridge.xxx()
 * Also keeps native AppWidget in sync.
 * Auth + cloud sync added in v1.6.15 – fully optional; app works offline without login.
 */
public class AndroidBridge {

    private final Context context;
    private final SharedPreferences prefs;
    private final WeakReference<Activity> activityRef;
    private final WeakReference<WebView> webViewRef;
    private ConnectivityManager.NetworkCallback networkCallback;

    public AndroidBridge(Activity activity, WebView webView) {
        this.context = activity.getApplicationContext();
        this.prefs = this.context.getSharedPreferences("jee_prefs", Context.MODE_PRIVATE);
        this.activityRef = new WeakReference<>(activity);
        this.webViewRef = new WeakReference<>(webView);
        registerAutoSyncNetworkCallback();
    }

    /** Backward-compatible constructor (no JS callbacks). */
    public AndroidBridge(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = this.context.getSharedPreferences("jee_prefs", Context.MODE_PRIVATE);
        this.activityRef = new WeakReference<>(null);
        this.webViewRef = new WeakReference<>(null);
        registerAutoSyncNetworkCallback();
    }

    private void runJs(final String script) {
        final WebView wv = webViewRef.get();
        final Activity act = activityRef.get();
        if (wv == null || act == null) return;
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    wv.evaluateJavascript(script, null);
                } catch (Exception ignored) {}
            }
        });
    }

    private void notifyAuth(String event, String jsonPayload) {
        String safe = (jsonPayload == null ? "{}" : jsonPayload)
                .replace("\\", "\\\\")
                .replace("'", "\\'");
        runJs("window.__onAuthEvent && window.__onAuthEvent('" + event + "', '" + safe + "');");
    }

    @JavascriptInterface
    public void saveTaskState(String json) {
        SharedPreferences.Editor ed = prefs.edit().putString("task_state", json);
        try {
            JSONObject state = new JSONObject(json == null ? "{}" : json);
            JSONObject blocking = state.optJSONObject("appBlocking");
            if (blocking != null) AppBlockingController.setConfig(context, blocking.toString());
            JSONArray dates = state.optJSONArray("taskWidgetDates");
            if (dates != null) {
                for (int i = 0; i < 3 && i < dates.length(); i++) {
                    String d = dates.optString(i, "");
                    if (d != null && !d.isEmpty()) ed.putString("task_widget_date_" + i, d);
                }
            }
        } catch (Exception ignored) {}
        ed.putBoolean("auto_sync_dirty", true).apply();
        StudyWidgetProvider.requestUpdate(context);
        CountdownWidgetProvider.requestUpdate(context);
        NotesWidgetProvider.requestUpdate(context);
        maybeAutoBackup(json);
    }

    @JavascriptInterface
    public void refreshNotesWidgets() {
        NotesWidgetProvider.requestUpdate(context);
    }

    @JavascriptInterface
    public String getTaskState() {
        return prefs.getString("task_state", "");
    }

    @JavascriptInterface
    public String getAppBlockingConfig() { return AppBlockingController.getConfig(context); }

    @JavascriptInterface
    public String getAppBlockingStats() { return AppBlockingController.getAttemptStats(context); }

    @JavascriptInterface
    public void setAppBlockingConfig(String json) { AppBlockingController.setConfig(context, json); }

    @JavascriptInterface
    public boolean isAppBlockingAccessibilityEnabled() { return AppBlockingController.isAccessibilityEnabled(context); }

    @JavascriptInterface
    public void openAppBlockingAccessibilitySettings() { AppBlockingController.openAccessibilitySettings(context); }

    @JavascriptInterface
    public String getLaunchableApps() {
        JSONArray out = new JSONArray();
        try {
            android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_MAIN, null);
            intent.addCategory(android.content.Intent.CATEGORY_LAUNCHER);
            java.util.List<android.content.pm.ResolveInfo> apps = context.getPackageManager().queryIntentActivities(intent, 0);
            java.util.Collections.sort(apps, (a,b) -> String.CASE_INSENSITIVE_ORDER.compare(String.valueOf(a.loadLabel(context.getPackageManager())), String.valueOf(b.loadLabel(context.getPackageManager()))));
            for (android.content.pm.ResolveInfo ri : apps) {
                String pkg = ri.activityInfo == null ? "" : ri.activityInfo.packageName;
                if (pkg.isEmpty() || pkg.equals(context.getPackageName()) || pkg.equals("com.android.settings") || pkg.equals("com.android.phone") || pkg.equals("com.android.server.telecom") || pkg.equals("com.android.incallui") || pkg.equals("com.google.android.dialer") || pkg.equals("com.android.permissioncontroller") || pkg.equals("com.google.android.permissioncontroller") || pkg.equals("com.android.packageinstaller") || pkg.equals("com.google.android.packageinstaller")) continue;
                JSONObject item = new JSONObject(); item.put("packageName", pkg); item.put("label", String.valueOf(ri.loadLabel(context.getPackageManager())));
                try { item.put("icon", ""); } catch (Exception ignored) {}
                out.put(item);
            }
        } catch (Exception ignored) {}
        return out.toString();
    }

    @JavascriptInterface
    public void scheduleTaskReminders(String taskJson) {
        try {
            JSONObject task = new JSONObject(taskJson);
            long taskId = task.optLong("id", 0);
            String title = task.optString("title", "Task");
            String date = task.optString("date", "");
            String startTime = task.optString("startTime", "");
            boolean completed = task.optBoolean("completed", false);

            if (completed || startTime.isEmpty() || date.isEmpty()) {
                TaskAlarmHelper.cancelReminders(context, taskId);
                return;
            }

            boolean enabled = prefs.getBoolean("reminders_enabled", true);
            if (!enabled) {
                TaskAlarmHelper.cancelReminders(context, taskId);
                return;
            }

            TaskAlarmHelper.scheduleReminders(context, taskId, title, date, startTime);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @JavascriptInterface
    public void cancelTaskReminders(long taskId) {
        TaskAlarmHelper.cancelReminders(context, taskId);
    }

    @JavascriptInterface
    public void setHourlyMotivationEnabled(boolean enabled) {
        prefs.edit().putBoolean("hourly_motivation_enabled", enabled).apply();
        if (enabled) {
            try { HourlyMotivationReceiver.ensureScheduled(context); } catch (Exception ignored) {}
        }
    }

    @JavascriptInterface
    public boolean isHourlyMotivationEnabled() {
        return prefs.getBoolean("hourly_motivation_enabled", true);
    }

    @JavascriptInterface
    public void setRemindersEnabled(boolean enabled) {
        prefs.edit().putBoolean("reminders_enabled", enabled).apply();
        if (!enabled) {
            cancelAllFromState();
        } else {
            rescheduleAllFromState();
        }
    }

    private void cancelAllFromState() {
        String json = prefs.getString("task_state", "");
        if (json == null || json.isEmpty()) return;
        try {
            JSONObject state = new JSONObject(json);
            JSONArray tasks = state.optJSONArray("tasks");
            if (tasks == null) return;
            for (int i = 0; i < tasks.length(); i++) {
                JSONObject t = tasks.getJSONObject(i);
                long id = t.optLong("id", 0);
                if (id != 0) TaskAlarmHelper.cancelReminders(context, id);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void rescheduleAllFromState() {
        String json = prefs.getString("task_state", "");
        if (json == null || json.isEmpty()) return;
        try {
            JSONObject state = new JSONObject(json);
            JSONArray tasks = state.optJSONArray("tasks");
            if (tasks == null) return;
            for (int i = 0; i < tasks.length(); i++) {
                JSONObject t = tasks.getJSONObject(i);
                boolean completed = t.optBoolean("completed", false);
                String startTime = t.optString("startTime", "");
                String date = t.optString("date", "");
                long taskId = t.optLong("id", 0);
                String title = t.optString("title", "Task");
                if (!completed && !startTime.isEmpty() && !date.isEmpty() && taskId != 0) {
                    TaskAlarmHelper.scheduleReminders(context, taskId, title, date, startTime);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @JavascriptInterface
    public void setCustomAlarmBase64(String base64Data) {
        try {
            if (base64Data == null || base64Data.isEmpty()) {
                clearCustomAlarm();
                return;
            }
            if (base64Data.contains(",")) {
                base64Data = base64Data.substring(base64Data.indexOf(",") + 1);
            }
            byte[] data = Base64.decode(base64Data, Base64.DEFAULT);
            File dir = new File(context.getFilesDir(), "alarms");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, "custom_alarm.mp3");
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(data);
            fos.close();
            prefs.edit()
                    .putString("custom_alarm_path", file.getAbsolutePath())
                    .putBoolean("use_custom_alarm", true)
                    .apply();
            android.os.Handler mainHandler = new android.os.Handler(context.getMainLooper());
            mainHandler.post(() ->
                    Toast.makeText(context, "Custom alarm saved ✓", Toast.LENGTH_SHORT).show());
        } catch (Exception e) {
            e.printStackTrace();
            android.os.Handler mainHandler = new android.os.Handler(context.getMainLooper());
            mainHandler.post(() ->
                    Toast.makeText(context, "Failed to save alarm sound", Toast.LENGTH_SHORT).show());
        }
    }

    @JavascriptInterface
    public void clearCustomAlarm() {
        prefs.edit()
                .remove("custom_alarm_path")
                .putBoolean("use_custom_alarm", false)
                .apply();
        try {
            File file = new File(context.getFilesDir(), "alarms/custom_alarm.mp3");
            if (file.exists()) file.delete();
        } catch (Exception ignored) {}
    }

    @JavascriptInterface
    public void testAlarm() {
        AlarmPlayer.play(context);
    }

    @JavascriptInterface
    public boolean isWidgetEnabled() {
        return prefs.getBoolean("widget_enabled", true);
    }

    @JavascriptInterface
    public void setWidgetEnabled(boolean enabled) {
        prefs.edit().putBoolean("widget_enabled", enabled).apply();
        StudyWidgetProvider.requestUpdate(context);
    }

    @JavascriptInterface
    public boolean isNative() {
        return true;
    }

    @JavascriptInterface
    public void updateWidget() {
        StudyWidgetProvider.requestUpdate(context);
        CountdownWidgetProvider.requestUpdate(context);
        NotesWidgetProvider.requestUpdate(context);
    }

    /** Countdown widget color: purple|red|blue|green|orange|teal */
    @JavascriptInterface
    public void setCountdownWidgetColor(String color) {
        if (color == null || color.isEmpty()) color = "purple";
        prefs.edit().putString("countdown_widget_color", color.toLowerCase()).apply();
        CountdownWidgetProvider.requestUpdate(context);
    }

    @JavascriptInterface
    public String getCountdownWidgetColor() {
        return prefs.getString("countdown_widget_color", "purple");
    }

    /**
     * Silent, throttled safety-net backup written to Downloads every ~24h whenever
     * data changes. This exists because Android does not let any app detect or
     * intercept the system "Uninstall" button in Settings — so instead of relying on
     * that (impossible) hook, we make sure a recent backup already sits in Downloads
     * before the user ever gets there. Same filename is reused/replaced each time so
     * Downloads doesn't fill up with dozens of dated copies.
     */
    private void maybeAutoBackup(String json) {
        try {
            if (json == null || json.isEmpty()) return;
            long last = prefs.getLong("last_auto_backup_at", 0);
            long now = System.currentTimeMillis();
            if (now - last < 24L * 60 * 60 * 1000) return; // once a day is enough
            String result = writeToDownloadsInternal(
                    "StudyTracker_autobackup.json", json, "application/json", false, true);
            if (result != null && !result.startsWith("error")) {
                prefs.edit().putLong("last_auto_backup_at", now).apply();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Opens the system "Uninstall app" confirmation screen for this app.
     * NOTE: this only works when the user taps an in-app "Uninstall" action — Android
     * gives apps no way to detect or hook the Uninstall button inside phone Settings
     * itself, so that path always relies on the silent auto-backup above instead.
     */
    @JavascriptInterface
    public void requestUninstall() {
        try {
            Intent intent = new Intent(Intent.ACTION_DELETE);
            intent.setData(Uri.parse("package:" + context.getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
            android.os.Handler mainHandler = new android.os.Handler(context.getMainLooper());
            mainHandler.post(() ->
                    Toast.makeText(context, "Could not open uninstall screen", Toast.LENGTH_SHORT).show());
        }
    }

    @JavascriptInterface
    public long getLastAutoBackupAt() {
        return prefs.getLong("last_auto_backup_at", 0);
    }


    @JavascriptInterface
    public void shareReportHtml(String html, String filename) {
        try {
            if (filename == null || filename.isEmpty()) filename = "JEE_Study_Report.html";
            if (!filename.endsWith(".html")) filename = filename + ".html";

            File dir = new File(context.getCacheDir(), "reports");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, filename);
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(html.getBytes("UTF-8"));
            fos.close();

            Uri uri = FileProvider.getUriForFile(
                    context,
                    context.getPackageName() + ".fileprovider",
                    file
            );

            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/html");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.putExtra(Intent.EXTRA_SUBJECT, "JEE Study Tracker Report");
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            share.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            Intent chooser = Intent.createChooser(share, "Save / Share report");
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(chooser);
        } catch (Exception e) {
            e.printStackTrace();
            android.os.Handler mainHandler = new android.os.Handler(context.getMainLooper());
            mainHandler.post(() ->
                    Toast.makeText(context, "Could not share report", Toast.LENGTH_SHORT).show());
        }
    }

    @JavascriptInterface
    public void setLibraryMode(boolean enabled) {
        prefs.edit().putBoolean("library_mode", enabled).apply();
    }

    @JavascriptInterface
    public boolean getLibraryMode() {
        return prefs.getBoolean("library_mode", false);
    }

    @JavascriptInterface
    public void setMathChallengeEnabled(boolean enabled) {
        prefs.edit().putBoolean("math_challenge_enabled", enabled).apply();
    }

    @JavascriptInterface
    public boolean getMathChallengeEnabled() {
        return prefs.getBoolean("math_challenge_enabled", false);
    }

    /** Task widget text size: small | normal | large | xlarge */
    @JavascriptInterface
    public void setTaskWidgetTextSize(String size) {
        if (size == null || size.isEmpty()) size = "normal";
        prefs.edit().putString("task_widget_text_size", size.toLowerCase()).apply();
        StudyWidgetProvider.requestUpdate(context);
    }

    @JavascriptInterface
    public String getTaskWidgetTextSize() {
        return prefs.getString("task_widget_text_size", "normal");
    }

    /** Task widget color: purple|red|blue|green|orange|teal|black|sunlight */
    @JavascriptInterface
    public void setTaskWidgetColor(String color) {
        if (color == null || color.isEmpty()) color = "purple";
        prefs.edit().putString("task_widget_color", color.toLowerCase()).apply();
        StudyWidgetProvider.requestUpdate(context);
    }

    /** Per-day task widget colour: slot 0=today, 1=tomorrow, 2=day-after-tomorrow. */
    @JavascriptInterface
    public void setTaskWidgetSlotColor(int slot, String color) {
        if (slot < 0 || slot > 2) return;
        if (color == null || color.isEmpty()) color = "purple";
        prefs.edit().putString("task_widget_color_" + slot, color.toLowerCase()).apply();
        StudyWidgetProvider.requestUpdate(context);
    }

    @JavascriptInterface
    public String getTaskWidgetSlotColor(int slot) {
        if (slot < 0 || slot > 2) return "purple";
        return prefs.getString("task_widget_color_" + slot, prefs.getString("task_widget_color", "purple"));
    }

    /** Exact calendar date shown by task widget slot 0/1/2. */
    @JavascriptInterface
    public void setTaskWidgetSlotDate(int slot, String date) {
        if (slot < 0 || slot > 2 || date == null || date.isEmpty()) return;
        prefs.edit().putString("task_widget_date_" + slot, date).apply();
        StudyWidgetProvider.requestUpdate(context);
    }

    @JavascriptInterface
    public String getTaskWidgetSlotDate(int slot) {
        if (slot < 0 || slot > 2) return "";
        return prefs.getString("task_widget_date_" + slot, "");
    }

    @JavascriptInterface
    public String getTaskWidgetColor() {
        return prefs.getString("task_widget_color", "purple");
    }


    @JavascriptInterface
    public void setPersonalAlarmsJson(String json) {
        if (json == null) json = "[]";
        PersonalAlarmHelper.saveAlarmsJson(context, json);
        PersonalAlarmHelper.scheduleAll(context);
    }

    @JavascriptInterface
    public String getPersonalAlarmsJson() {
        return PersonalAlarmHelper.getAlarmsJson(context);
    }

    @JavascriptInterface
    public void setContinuousVibration(boolean enabled) {
        prefs.edit().putBoolean("continuous_vibration", enabled).apply();
        if (!enabled) NotificationHelper.stopContinuousVibration(context);
    }

    @JavascriptInterface
    public void setLateWarnVibration(boolean enabled) {
        prefs.edit().putBoolean("late_warn_vibration", enabled).apply();
    }

    @JavascriptInterface
    public void scheduleExpectedWarnings(String taskJson) {
        try {
            JSONObject t=new JSONObject(taskJson);
            if(t.optBoolean("completed",false) || t.optLong("runningAt",0)<=0) return;
            boolean enabled=prefs.getBoolean("late_warn_enabled",true);
            if(!enabled){ TaskAlarmHelper.cancelExpectedWarnings(context,t.optLong("id",0)); return; }
            TaskAlarmHelper.scheduleExpectedWarnings(context,t.optLong("id",0),t.optString("title","Task"),t.optInt("expected",60),t.optLong("runningAt",0));
        }catch(Exception e){e.printStackTrace();}
    }

    @JavascriptInterface
    public void cancelExpectedWarnings(long taskId) { TaskAlarmHelper.cancelExpectedWarnings(context,taskId); }

    @JavascriptInterface
    public void setLateWarnEnabled(boolean enabled) {
        prefs.edit().putBoolean("late_warn_enabled", enabled).apply();
    }

    @JavascriptInterface
    public void setCountdownWidgetSlotColor(int slot, String color) {
        if(slot<0 || slot>2) return;
        if(color==null || color.isEmpty()) color="purple";
        prefs.edit().putString("countdown_slot_"+slot+"_color",color.toLowerCase()).apply();
        CountdownWidgetProvider.requestUpdate(context);
    }

    @JavascriptInterface
    public boolean getContinuousVibration() {
        return prefs.getBoolean("continuous_vibration", true);
    }

    /**
     * Save text/binary content into public Downloads folder.
     * @param filename e.g. backup.json or report.html
     * @param content  plain text or base64 if isBase64=true
     * @param mime     e.g. application/json or text/html
     * @param isBase64 false for JSON/HTML text
     * @return absolute path or "ok" / error message
     */
    @JavascriptInterface
    public String saveToDownloads(String filename, String content, String mime, boolean isBase64) {
        return writeToDownloadsInternal(filename, content, mime, isBase64, false);
    }

    /**
     * Shared implementation behind saveToDownloads() and the silent auto-backup.
     * @param replaceExisting when true, an existing file with the same name in
     *        Downloads is removed first so the backup is overwritten in place
     *        instead of piling up as "name (1).json", "name (2).json", etc.
     */
    private String writeToDownloadsInternal(String filename, String content, String mime,
                                              boolean isBase64, boolean replaceExisting) {
        try {
            if (filename == null || filename.isEmpty()) filename = "download.txt";
            if (mime == null || mime.isEmpty()) mime = "text/plain";
            byte[] data;
            if (isBase64) {
                String b64 = content;
                if (b64 != null && b64.contains(",")) b64 = b64.substring(b64.indexOf(",") + 1);
                data = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
            } else {
                data = (content != null ? content : "").getBytes("UTF-8");
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentResolver resolver = context.getContentResolver();
                if (replaceExisting) {
                    deleteExistingDownload(resolver, filename);
                }
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
                values.put(MediaStore.Downloads.MIME_TYPE, mime);
                values.put(MediaStore.Downloads.IS_PENDING, 1);
                android.net.Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) return "error: insert failed";
                java.io.OutputStream os = resolver.openOutputStream(uri);
                if (os == null) return "error: stream null";
                os.write(data);
                os.close();
                values.clear();
                values.put(MediaStore.Downloads.IS_PENDING, 0);
                resolver.update(uri, values, null, null);
                return "Downloads/" + filename;
            } else {
                java.io.File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists()) dir.mkdirs();
                java.io.File file = new java.io.File(dir, filename);
                java.io.FileOutputStream fos = new java.io.FileOutputStream(file);
                fos.write(data);
                fos.close();
                // notify media scanner
                Intent scan = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                scan.setData(android.net.Uri.fromFile(file));
                context.sendBroadcast(scan);
                return file.getAbsolutePath();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "error: " + e.getMessage();
        }
    }

    /** Best-effort delete of a prior Downloads entry with the same display name (API 29+). */
    private void deleteExistingDownload(ContentResolver resolver, String filename) {
        try {
            android.database.Cursor cursor = resolver.query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    new String[]{MediaStore.Downloads._ID},
                    MediaStore.Downloads.DISPLAY_NAME + "=?",
                    new String[]{filename},
                    null);
            if (cursor == null) return;
            while (cursor.moveToNext()) {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Downloads._ID));
                Uri itemUri = android.content.ContentUris.withAppendedId(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI, id);
                try {
                    resolver.delete(itemUri, null, null);
                } catch (Exception ignored) {}
            }
            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Firebase login/cloud sync was intentionally removed. Local-only compatibility stubs.
    @JavascriptInterface public String getCurrentUser() { return ""; }
    @JavascriptInterface public boolean isLoggedIn() { return false; }
    @JavascriptInterface public void signIn(String email, String password) { notifyAuth("error", "{\"message\":\"Account login has been removed. Your data is stored locally.\"}"); }
    @JavascriptInterface public void signUp(String email, String password) { notifyAuth("error", "{\"message\":\"Account registration has been removed. Your data is stored locally.\"}"); }
    @JavascriptInterface public void signOut() {}
    @JavascriptInterface public void sendPasswordReset(String email) {}
    @JavascriptInterface public void uploadStateToCloud(String json) {}
    @JavascriptInterface public void downloadStateFromCloud() {}
    @JavascriptInterface public void deleteAccount(String password) {}
    @JavascriptInterface public void updateUsername(String username) {}
    @JavascriptInterface public void submitRanking(long coins, String username) {}
    @JavascriptInterface public void loadLeaderboard() { runJs("window.__onLeaderboard && window.__onLeaderboard('[]');"); }

    // ========== AdMob bridge (names match AdManager unit constants) ==========
    @JavascriptInterface
    public void showInterstitialAd() {
        final Activity act = activityRef.get();
        if (act == null) return;
        act.runOnUiThread(() -> {
            try {
                AdManager.get(act).showInterstitialNow(shown ->
                    runJs("window.__onInterstitialClosed && window.__onInterstitialClosed(" + (shown ? "true" : "false") + ")")
                );
            } catch (Exception e) {
                runJs("window.__onInterstitialClosed && window.__onInterstitialClosed(false)");
            }
        });
    }

    @JavascriptInterface
    public void showInterstitialForAction() {
        final Activity act = activityRef.get();
        if (act == null) {
            runJs("window.__onInterstitialClosed && window.__onInterstitialClosed(false)");
            return;
        }
        act.runOnUiThread(() -> {
            try {
                AdManager.get(act).maybeShowInterstitialForAction(shown ->
                    runJs("window.__onInterstitialClosed && window.__onInterstitialClosed(" + (shown ? "true" : "false") + ")")
                );
            } catch (Exception e) {
                runJs("window.__onInterstitialClosed && window.__onInterstitialClosed(false)");
            }
        });
    }

    @JavascriptInterface
    public void showRewardedAd() {
        final Activity act = activityRef.get();
        if (act == null) return;
        act.runOnUiThread(() -> {
            try {
                AdManager.get(act).showRewarded(earned ->
                    runJs("window.__onRewardedClosed && window.__onRewardedClosed(" + (earned ? "true" : "false") + ")")
                );
            } catch (Exception e) {
                runJs("window.__onRewardedClosed && window.__onRewardedClosed(false)");
            }
        });
    }

    @JavascriptInterface
    public void showRewardedInterstitialAd() {
        final Activity act = activityRef.get();
        if (act == null) return;
        act.runOnUiThread(() -> {
            try {
                AdManager.get(act).showRewardedInterstitial(earned ->
                    runJs("window.__onRewardedClosed && window.__onRewardedClosed(" + (earned ? "true" : "false") + ")")
                );
            } catch (Exception e) {
                runJs("window.__onRewardedClosed && window.__onRewardedClosed(false)");
            }
        });
    }

    @JavascriptInterface
    public void setAdsEnabled(boolean enabled) {
        final Activity act = activityRef.get();
        if (act == null) return;
        act.runOnUiThread(() -> AdManager.get(act).setAdsEnabled(enabled));
    }

    @JavascriptInterface
    public void setInterstitialEveryN(int n) {
        final Activity act = activityRef.get();
        if (act == null) return;
        act.runOnUiThread(() -> AdManager.get(act).setInterstitialEveryN(n));
    }

    @JavascriptInterface
    public void setBannersEnabled(boolean enabled) {
        final Activity act = activityRef.get();
        if (act == null) return;
        act.runOnUiThread(() -> AdManager.get(act).setBannersEnabled(enabled));
    }

    @JavascriptInterface
    public void setRewardedEnabled(boolean enabled) {
        final Activity act = activityRef.get();
        if (act == null) return;
        act.runOnUiThread(() -> AdManager.get(act).setRewardedEnabled(enabled));
    }

    @JavascriptInterface
    public void setNativeEnabled(boolean enabled) {
        final Activity act = activityRef.get();
        if (act == null) return;
        act.runOnUiThread(() -> AdManager.get(act).setNativeEnabled(enabled));
    }

    @JavascriptInterface
    public boolean isAdsEnabled() {
        final Activity act = activityRef.get();
        if (act == null) return false;
        try {
            return AdManager.get(act).isAdsEnabled();
        } catch (Exception e) {
            return false;
        }
    }

}
