package com.jeetracker.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;
import android.os.Handler;
import android.os.Looper;
import android.content.SharedPreferences;
import org.json.JSONObject;

/** User-enabled accessibility service used only to detect foreground apps for the user's selected blocking lists. */
public class AppBlockingAccessibilityService extends AccessibilityService {
    private final Handler handler=new Handler(Looper.getMainLooper());
    private String foreground=""; private long enteredAt=0; private long lastPersistedAt=0; private boolean launching=false;
    private static final String USAGE="blocking_usage_v1";
    private final Runnable checker=new Runnable(){@Override public void run(){
        try{ long now=System.currentTimeMillis(); if(!foreground.isEmpty()){ if(lastPersistedAt>0&&now-lastPersistedAt>=15000L){recordUsage(foreground,lastPersistedAt,now);lastPersistedAt=now;} evaluate(foreground,now); } }catch(Exception ignored){}
        handler.postDelayed(this,1500L);
    }};
    @Override public void onServiceConnected(){super.onServiceConnected();handler.post(checker);}
    @Override public void onAccessibilityEvent(AccessibilityEvent event){
        if(event==null||event.getPackageName()==null)return;
        int type=event.getEventType();
        if(type!=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED&&type!=AccessibilityEvent.TYPE_WINDOWS_CHANGED)return;
        String pkg=String.valueOf(event.getPackageName()); long now=System.currentTimeMillis();
        if(!pkg.equals(foreground)){ if(!foreground.isEmpty())recordUsage(foreground,lastPersistedAt>0?lastPersistedAt:enteredAt,now); foreground=pkg; enteredAt=now; lastPersistedAt=now; }
        evaluate(pkg,now);
    }
    private void evaluate(String pkg,long now){
        if(launching)return;
        JSONObject decision=AppBlockingController.getBlockingDecision(this,pkg,now);
        if(decision==null){launching=false;return;}
        int hourly=decision.optInt("maxHourlyMinutes",0), continuous=decision.optInt("maxContinuousMinutes",0);
        long hourlyUsed=getRollingUsage(pkg,now); long continuousUsed=Math.max(0,now-enteredAt);
        boolean overHourly=hourly>0&&hourlyUsed>=hourly*60000L;
        boolean overContinuous=continuous>0&&continuousUsed>=continuous*60000L;
        boolean strict=decision.optBoolean("strict",true);
        if((strict&&hourly==0&&continuous==0)||overHourly||overContinuous){
            launching=true;
            AppBlockingController.recordAttempt(this,pkg,now);
            try{
                Intent i=new Intent(this,AppBlockingActivity.class); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
                i.putExtra("blocked_package",pkg); i.putExtra("list_name",decision.optString("listName","Focus"));
                i.putExtra("message",decision.optString("message","First complete your task.")); i.putExtra("task_title",decision.optString("taskTitle",""));
                startActivity(i);
            }catch(Exception e){launching=false;}
        }
    }
    private void recordUsage(String pkg,long start,long end){ if(start<=0||end<=start||!AppBlockingController.isPackageSelected(this,pkg))return; try{
        SharedPreferences p=getSharedPreferences("jee_prefs",MODE_PRIVATE); JSONObject all=new JSONObject(p.getString(USAGE,"{}"));
        org.json.JSONArray a=all.optJSONArray(pkg);if(a==null)a=new org.json.JSONArray();
        JSONObject seg=new JSONObject();seg.put("start",start);seg.put("end",end);a.put(seg);
        org.json.JSONArray recent=new org.json.JSONArray();long cutoff=end-7200000L;for(int i=0;i<a.length();i++){JSONObject old=a.optJSONObject(i);if(old!=null&&old.optLong("end",0)>=cutoff)recent.put(old);}all.put(pkg,recent);p.edit().putString(USAGE,all.toString()).apply();
    }catch(Exception ignored){} }
    private long getRollingUsage(String pkg,long now){
        try{JSONObject all=new JSONObject(getSharedPreferences("jee_prefs",MODE_PRIVATE).getString(USAGE,"{}"));org.json.JSONArray a=all.optJSONArray(pkg);long total=0,cut=now-3600000L;
            if(a!=null)for(int i=0;i<a.length();i++){JSONObject s=a.optJSONObject(i);if(s==null)continue;long st=s.optLong("start"),en=s.optLong("end");long from=Math.max(st,cut),to=Math.min(en,now);if(to>from)total+=to-from;}
            if(pkg.equals(foreground)&&lastPersistedAt>0){long from=Math.max(lastPersistedAt,cut);if(now>from)total+=now-from;}
            return total;
        }catch(Exception e){return 0;}
    }
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){handler.removeCallbacks(checker);if(!foreground.isEmpty())recordUsage(foreground,lastPersistedAt>0?lastPersistedAt:enteredAt,System.currentTimeMillis());super.onDestroy();}
}
