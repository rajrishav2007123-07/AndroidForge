package com.jeetracker.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.content.Intent;

/** Clear, dismissible blocking notice. Returning to TaskZen lets the user stop the task or enable a break. */
public class AppBlockingActivity extends Activity {
    private String blockedPackage="";
    @Override protected void onCreate(Bundle b){super.onCreate(b);getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED|WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON|WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_FULLSCREEN);
        blockedPackage=getIntent().getStringExtra("blocked_package");
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER);root.setPadding(28,32,28,32);root.setBackgroundColor(Color.rgb(17,24,39));
        ImageView appIcon=new ImageView(this); try{if(blockedPackage!=null)appIcon.setImageDrawable(getPackageManager().getApplicationIcon(blockedPackage));}catch(Exception ignored){} LinearLayout.LayoutParams iconLp=new LinearLayout.LayoutParams(104,104);iconLp.gravity=Gravity.CENTER;root.addView(appIcon,iconLp);
        TextView icon=label("🔒",20,Color.WHITE,true);root.addView(icon);
        TextView appName=label(getAppLabel(blockedPackage),18,Color.rgb(255,204,128),true);root.addView(appName);
        TextView title=label("App blocked",28,Color.WHITE,true);title.setPadding(0,12,0,8);root.addView(title);
        TextView list=label("Blocking list: "+safe(getIntent().getStringExtra("list_name")),14,Color.LTGRAY,false);list.setPadding(0,0,0,8);root.addView(list);
        TextView task=label("Current task: "+(getIntent().getStringExtra("task_title")==null||getIntent().getStringExtra("task_title").isEmpty()?"Scheduled focus":getIntent().getStringExtra("task_title")),18,Color.rgb(255,204,128),true);task.setPadding(0,8,0,18);root.addView(task);
        TextView message=label(safe(getIntent().getStringExtra("message")),17,Color.WHITE,false);message.setGravity(Gravity.CENTER);message.setPadding(0,0,0,24);root.addView(message);
        TextView quote=label("Stay focused. Small steps create big results.",14,Color.LTGRAY,false);quote.setGravity(Gravity.CENTER);quote.setPadding(0,0,0,28);root.addView(quote);
        TextView back=label("Return to TaskZen Study",16,Color.WHITE,true);back.setGravity(Gravity.CENTER);back.setPadding(22,15,22,15);GradientDrawable bg=new GradientDrawable();bg.setColor(Color.rgb(230,126,34));bg.setCornerRadius(28);back.setBackground(bg);root.addView(back,new LinearLayout.LayoutParams(-1,-2));
        back.setOnClickListener(v->{Intent i=getPackageManager().getLaunchIntentForPackage(getPackageName());if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);startActivity(i);}finish();});
        setContentView(root);
    }
    private String getAppLabel(String pkg){try{return String.valueOf(getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg,0)));}catch(Exception e){return "Selected app";}}
    private TextView label(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s==null?"":s);t.setTextColor(color);t.setTextSize(size);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setGravity(Gravity.CENTER);return t;}
    private String safe(String s){return s==null||s.trim().isEmpty()?"First complete your task.":s;}
    @Override public void onBackPressed(){super.onBackPressed();}
}
