package com.jeetracker.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.Intent;
import android.provider.Settings;
import android.text.TextUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Calendar;

/** Voluntary app-blocking rules. Rules are evaluated locally on-device. */
public final class AppBlockingController {
    private static final String PREFS="jee_prefs";
    private static final String CONFIG="app_blocking_config";
    private AppBlockingController(){}
    static SharedPreferences prefs(Context c){return c.getApplicationContext().getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
    public static String getConfig(Context c){return prefs(c).getString(CONFIG,"{\"lists\":[],\"globalMessage\":\"First complete your task.\"}");}
    public static void setConfig(Context c,String json){
        try { JSONObject o=new JSONObject(json==null?"{}":json); if(o.optJSONArray("lists")==null)o.put("lists",new JSONArray()); prefs(c).edit().putString(CONFIG,o.toString()).apply(); }
        catch(Exception ignored){}
    }
    public static boolean isAccessibilityEnabled(Context c){
        String enabled=android.provider.Settings.Secure.getString(c.getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return enabled!=null && enabled.contains(c.getPackageName()+"/"+AppBlockingAccessibilityService.class.getName());
    }
    public static void openAccessibilitySettings(Context c){
        Intent i=new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i);
    }
    public static void recordAttempt(Context c,String pkg,long at){
        try { SharedPreferences p=prefs(c); JSONArray a=new JSONArray(p.getString("blocking_attempt_history","[]")); JSONObject e=new JSONObject(); e.put("packageName",pkg); e.put("at",at); a.put(e); JSONArray trimmed=new JSONArray(); for(int i=Math.max(0,a.length()-200);i<a.length();i++)trimmed.put(a.get(i)); p.edit().putString("blocking_attempt_history",trimmed.toString()).apply(); } catch(Exception ignored){}
    }
    public static String getAttemptStats(Context c){
        try { JSONArray a=new JSONArray(prefs(c).getString("blocking_attempt_history","[]")); long today=System.currentTimeMillis(); java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyyMMdd",Locale.US); String key=f.format(new Date(today)); int count=0; JSONArray recent=new JSONArray(); for(int i=a.length()-1;i>=0;i--){JSONObject e=a.optJSONObject(i);if(e==null)continue;if(key.equals(f.format(new Date(e.optLong("at",0)))))count++;if(recent.length()<30)recent.put(e);} JSONObject out=new JSONObject();out.put("total",a.length());out.put("today",count);out.put("recent",recent);return out.toString(); }catch(Exception e){return "{\"total\":0,\"today\":0,\"recent\":[]}";}
    }
    static JSONObject activeTask(Context c){
        try {
            JSONObject state=new JSONObject(prefs(c).getString("task_state","{}"));
            JSONArray tasks=state.optJSONArray("tasks"); if(tasks==null)return null;
            for(int i=0;i<tasks.length();i++){ JSONObject t=tasks.optJSONObject(i); if(t!=null && t.optLong("runningAt",0)>0 && !t.optBoolean("completed",false))return t; }
        }catch(Exception ignored){} return null;
    }
    static boolean globalBreak(Context c){
        try { JSONObject s=new JSONObject(prefs(c).getString("task_state","{}")); JSONObject b=s.optJSONObject("globalBreak"); if(b!=null&&b.optBoolean("active",false))return true; JSONObject t=activeTask(c); return t!=null&&t.optLong("breakStartedAt",0)>0; }catch(Exception e){return false;}
    }
    static boolean isScheduleActive(JSONObject list,long now){
        JSONObject r=list.optJSONObject("rules"); if(r==null)return false;
        JSONObject s=r.optJSONObject("schedule"); if(s==null||!s.optBoolean("enabled",false))return false;
        String start=s.optString("start","22:00"), end=s.optString("end","06:00");
        Calendar cal=Calendar.getInstance(); cal.setTimeInMillis(now);
        int dow=cal.get(Calendar.DAY_OF_WEEK); // 1 Sunday .. 7 Saturday
        JSONArray days=s.optJSONArray("days");
        if(days!=null && days.length()>0){ boolean ok=false; for(int i=0;i<days.length();i++)if(days.optInt(i,-1)==dow-1)ok=true; if(!ok)return false; }
        String hm=new SimpleDateFormat("HH:mm",Locale.US).format(new Date(now));
        return start.compareTo(end)<=0 ? hm.compareTo(start)>=0&&hm.compareTo(end)<0 : hm.compareTo(start)>=0||hm.compareTo(end)<0;
    }
    public static boolean isPackageSelected(Context c,String packageName){
        try { JSONArray lists=new JSONObject(getConfig(c)).optJSONArray("lists"); if(lists==null)return false; for(int i=0;i<lists.length();i++){JSONObject l=lists.optJSONObject(i);if(l==null||!l.optBoolean("enabled",true))continue;JSONArray apps=l.optJSONArray("apps");if(apps==null)continue;for(int j=0;j<apps.length();j++){JSONObject a=apps.optJSONObject(j);if(a!=null&&packageName.equals(a.optString("packageName")))return true;}} }catch(Exception ignored){} return false;
    }

    public static JSONObject getBlockingDecision(Context c,String packageName,long now){
        try {
            if(packageName==null||packageName.equals(c.getPackageName())||packageName.startsWith("com.android.systemui")||packageName.equals("com.android.phone")||packageName.equals("com.android.settings")||packageName.equals("com.google.android.permissioncontroller")||packageName.equals("com.android.packageinstaller")||packageName.equals("com.google.android.packageinstaller"))return null;
            JSONObject cfg=new JSONObject(getConfig(c)); JSONArray lists=cfg.optJSONArray("lists"); if(lists==null)return null;
            JSONObject task=activeTask(c); boolean onBreak=globalBreak(c);
            String assigned=task==null?"":task.optString("blockingListId","");
            JSONObject matched=null; boolean taskRule=false,scheduled=false; int hourlyLimit=-1, continuousLimit=-1;
            for(int i=0;i<lists.length();i++){
                JSONObject l=lists.optJSONObject(i); if(l==null||!l.optBoolean("enabled",true))continue;
                JSONArray apps=l.optJSONArray("apps"); JSONObject appMatch=null;
                if(apps!=null)for(int j=0;j<apps.length();j++){JSONObject a=apps.optJSONObject(j);if(a!=null&&packageName.equals(a.optString("packageName"))){appMatch=a;break;}}
                boolean selected=appMatch!=null;
                if(!selected)continue;
                JSONObject rules=l.optJSONObject("rules"); if(rules==null)continue;
                boolean listTask=task!=null&&!onBreak&&assigned.equals(l.optString("id",""))&&rules.optJSONObject("taskStart")!=null&&rules.optJSONObject("taskStart").optBoolean("enabled",false);
                boolean listSchedule=isScheduleActive(l,now);
                if(listTask||listSchedule){ matched=l; taskRule|=listTask; scheduled|=listSchedule; int h=appMatch.optInt("hourlyMinutes",0),ct=appMatch.optInt("continuousMinutes",0);hourlyLimit=hourlyLimit<0?h:Math.min(hourlyLimit,h);continuousLimit=continuousLimit<0?ct:Math.min(continuousLimit,ct); }
            }
            if(matched==null)return null;
            JSONObject result=new JSONObject(); result.put("listName",matched.optString("name","Focus"));
            String custom=matched.optString("message",""); if(custom.trim().isEmpty())custom=cfg.optString("globalMessage","First complete your task."); result.put("message",custom);
            result.put("taskTitle",task==null?"":task.optString("title",""));
            result.put("taskRule",taskRule); result.put("scheduled",scheduled);
            JSONObject rules=matched.optJSONObject("rules"); JSONObject usage=rules==null?null:rules.optJSONObject("usage");
            result.put("maxHourlyMinutes",hourlyLimit<0?0:hourlyLimit);
            result.put("maxContinuousMinutes",continuousLimit<0?0:continuousLimit);
            result.put("strict",hourlyLimit<=0&&continuousLimit<=0);
            return result;
        }catch(Exception e){return null;}
    }
}
