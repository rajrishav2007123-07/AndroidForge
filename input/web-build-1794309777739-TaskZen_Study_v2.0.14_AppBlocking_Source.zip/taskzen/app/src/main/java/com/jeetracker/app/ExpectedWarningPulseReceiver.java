package com.jeetracker.app;
import android.content.BroadcastReceiver;import android.content.Context;import android.content.Intent;
public class ExpectedWarningPulseReceiver extends BroadcastReceiver {
 public static final String ACTION="com.jeetracker.app.EXPECTED_WARNING_PULSE";
 @Override public void onReceive(Context c,Intent i){if(i==null||!ACTION.equals(i.getAction()))return;android.content.SharedPreferences p=c.getSharedPreferences("jee_prefs",Context.MODE_PRIVATE);if(!p.getBoolean("expected_warning_vibration_active",false)||!p.getBoolean("late_warn_vibration",true))return;NotificationHelper.vibrateWarningOnce(c);NotificationHelper.scheduleExpectedWarningPulse(c,3500);}
}
