package com.jeetracker.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.Random;

/**
 * Hourly gentle reminder: task-related message if tasks exist,
 * otherwise "add a task" + short vibration + rotating motivational quote.
 */
public class HourlyMotivationReceiver extends BroadcastReceiver {

    public static final String ACTION = "com.jeetracker.app.HOURLY_MOTIVATION";
    public static final int REQ = 8801;
    public static final int NOTIF_ID = 8802;

    private static final String[] QUOTES = {
            "Small steps every hour build big results.",
            "You don't have to be perfect — just consistent.",
            "One focused block is better than none.",
            "Your future self is watching. Make them proud.",
            "Discipline beats motivation when motivation fades.",
            "Study the hard page first. Momentum follows.",
            "Progress, not perfection.",
            "The best time to start was earlier. The next best is now.",
            "Protect your streak — even 20 minutes counts.",
            "Clarity comes from action, not overthinking.",
            "You are closer than yesterday.",
            "Deep work for one hour can change the week."
    };

    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            showHourly(context);
        } catch (Exception ignored) {}
        // Reschedule next hour
        scheduleNext(context);
    }

    public static void scheduleNext(Context context) {
        try {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            Intent i = new Intent(context, HourlyMotivationReceiver.class).setAction(ACTION);
            PendingIntent pi = PendingIntent.getBroadcast(
                    context, REQ, i,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.HOUR_OF_DAY, 1);
            cal.set(Calendar.MINUTE, 0);
            cal.set(Calendar.SECOND, 5);
            long when = cal.getTimeInMillis();
            if (when <= System.currentTimeMillis()) {
                when = System.currentTimeMillis() + 60 * 60 * 1000L;
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            } else {
                am.set(AlarmManager.RTC_WAKEUP, when, pi);
            }
        } catch (Exception ignored) {}
    }

    public static void ensureScheduled(Context context) {
        scheduleNext(context);
    }

    private void showHourly(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("jee_prefs", Context.MODE_PRIVATE);
        // Dedicated flag (default ON). Do not use task-alarm "reminders_enabled".
        if (!prefs.getBoolean("hourly_motivation_enabled", true)) {
            return;
        }

        String stateJson = prefs.getString("task_state", "");
        String title = "💡 Study tip";
        String body;
        boolean hasPendingToday = false;
        boolean hasUnsetStart = false;
        String taskHint = null;

        try {
            if (stateJson != null && !stateJson.isEmpty()) {
                JSONObject state = new JSONObject(stateJson);
                JSONArray tasks = state.optJSONArray("tasks");
                String today = todayKey();
                if (tasks != null) {
                    for (int i = 0; i < tasks.length(); i++) {
                        JSONObject t = tasks.optJSONObject(i);
                        if (t == null) continue;
                        if (t.optBoolean("completed", false)) continue;
                        String day = t.optString("date", t.optString("day", today));
                        if (!today.equals(day) && t.has("date") && !today.equals(t.optString("date"))) {
                            // also accept tasks without date as today
                            if (t.has("date") && t.optString("date").length() > 0) continue;
                        }
                        hasPendingToday = true;
                        String tTitle = t.optString("title", "Task");
                        // start time fields used in app variants
                        boolean hasStart = t.has("startAt") || t.has("startTime") || t.has("plannedStart")
                                || (t.optString("start", "").length() > 0);
                        String startStr = t.optString("startAt", t.optString("startTime", t.optString("start", "")));
                        if (startStr == null || startStr.isEmpty() || "null".equals(startStr)) {
                            hasUnsetStart = true;
                            if (taskHint == null) taskHint = tTitle + " (set a start time)";
                        } else {
                            if (taskHint == null) taskHint = tTitle;
                        }
                    }
                }
            }
        } catch (Exception ignored) {}

        String quote = QUOTES[new Random().nextInt(QUOTES.length)];
        if (!hasPendingToday) {
            body = "➕ Add a study task for today.\n💡 " + quote;
        } else if (hasUnsetStart) {
            body = "⏰ You have tasks without a start time — set one for alarms, or start when ready.\n📌 " + (taskHint != null ? taskHint : "Pending task") + "\n💡 " + quote;
        } else {
            body = "📌 Pending: " + (taskHint != null ? taskHint : "today's tasks") + "\n💡 " + quote;
        }

        // Quiet notification — NO AlarmPlayer, NO task-alarm channel
        NotificationHelper.showHourlyMotivation(context, title, body);
        softVibrate(context);
    }

    private static String todayKey() {
        Calendar c = Calendar.getInstance();
        return String.format("%04d-%02d-%02d",
                c.get(Calendar.YEAR),
                c.get(Calendar.MONTH) + 1,
                c.get(Calendar.DAY_OF_MONTH));
    }

    private static void softVibrate(Context context) {
        try {
            Vibrator v;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                VibratorManager vm = (VibratorManager) context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
                v = vm != null ? vm.getDefaultVibrator() : null;
            } else {
                v = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
            }
            if (v == null) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                v.vibrate(80);
            }
        } catch (Exception ignored) {}
    }
}
