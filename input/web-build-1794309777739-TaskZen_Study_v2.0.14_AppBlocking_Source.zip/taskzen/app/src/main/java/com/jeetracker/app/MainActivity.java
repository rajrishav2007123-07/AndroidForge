package com.jeetracker.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.app.AlarmManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private AdManager adManager;
    private static final int REQ_NOTIFICATION = 1001;
    private static final int REQ_FILE_CHOOSER = 1002;
    private ValueCallback<Uri[]> filePathCallback;

    private void showLaunchQuoteSplash() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(28, 42, 28, 42);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(239,108,0), Color.rgb(93,47,20)});
        bg.setCornerRadius(0f);
        box.setBackground(bg);

        ImageView logo = new ImageView(this);
        try (java.io.InputStream in = getAssets().open("study_tracker_logo.png")) {
            logo.setImageBitmap(BitmapFactory.decodeStream(in));
        } catch (Exception ignored) {}
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams lpLogo = new LinearLayout.LayoutParams(150,150);
        lpLogo.gravity = Gravity.CENTER_HORIZONTAL;
        box.addView(logo, lpLogo);

        TextView name = new TextView(this);
        name.setText("TaskZen Study");
        name.setTextColor(Color.rgb(255,248,238));
        name.setTextSize(29);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        name.setGravity(Gravity.CENTER);
        name.setLetterSpacing(0.04f);
        box.addView(name, new LinearLayout.LayoutParams(-1, -2));

        TextView quote = new TextView(this);
        quote.setText(getLaunchQuote());
        quote.setTextColor(Color.WHITE);
        quote.setTextSize(20);
        quote.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        quote.setGravity(Gravity.CENTER);
        quote.setLineSpacing(0f, 1.28f);
        LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(-1, -2);
        qp.setMargins(0, 56, 0, 18);
        box.addView(quote, qp);

        TextView author = new TextView(this);
        author.setText(getLaunchAuthor());
        author.setTextColor(Color.rgb(255,218,175));
        author.setTextSize(15);
        author.setTypeface(Typeface.DEFAULT_BOLD);
        author.setGravity(Gravity.CENTER);
        box.addView(author, new LinearLayout.LayoutParams(-1, -2));

        dialog.setContentView(box);
        android.view.Window w=dialog.getWindow();
        if(w!=null){
            w.setBackgroundDrawableResource(android.R.color.transparent);
            w.setDimAmount(0f);
            w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }
        dialog.show();
        if(w!=null) w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        new Handler(getMainLooper()).postDelayed(() -> { try{ if(dialog.isShowing()) dialog.dismiss(); }catch(Exception ignored){} }, 4000L);
    }

    private String getLaunchQuote(){
        String[] q={
                "Arise, awake, and do not stop until the goal is reached.",
                "Dream, dream, dream. Dreams transform into thoughts and thoughts result in action.",
                "The important thing is not to stop questioning.",
                "In a gentle way, you can shake the world.",
                "It always seems impossible until it is done.",
                "Give me blood, and I will give you freedom!",
                "Revolution is an inalienable right of mankind.",
                "All the power is within you; you can do anything and everything.",
                "You must be the change you wish to see in the world.",
                "Where the mind is without fear and the head is held high."
        };
        SharedPreferences p=getSharedPreferences("jee_prefs",MODE_PRIVATE);
        int last=p.getInt("launch_quote_index",-1), idx=new java.util.Random().nextInt(q.length);
        if(q.length>1 && idx==last) idx=(idx+1)%q.length;
        p.edit().putInt("launch_quote_index",idx).apply();
        return q[idx];
    }
    private String getLaunchAuthor(){
        SharedPreferences p=getSharedPreferences("jee_prefs",MODE_PRIVATE);
        int idx=p.getInt("launch_quote_index",0);
        String[] a={"Swami Vivekananda","Dr. A. P. J. Abdul Kalam","Albert Einstein","Mahatma Gandhi","Nelson Mandela","Subhas Chandra Bose","Bhagat Singh","Swami Vivekananda","Mahatma Gandhi","Rabindranath Tagore"};
        return "— "+a[Math.max(0,Math.min(idx,a.length-1))];
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Keep content below status bar and above navigation bar (Image-1 style).
        // On targetSdk 35+ Android defaults to edge-to-edge; we opt out so the
        // WebView UI is not drawn under the system bars.
        WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
        getWindow().setStatusBarColor(0xFF8D4A1F);
        getWindow().setNavigationBarColor(0xFF101018);
        WindowInsetsControllerCompat insetsController =
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (insetsController != null) {
            insetsController.setAppearanceLightStatusBars(false);
            insetsController.setAppearanceLightNavigationBars(false);
        }

        setContentView(R.layout.activity_main);
        showLaunchQuoteSplash();

        adManager = AdManager.get(this);
        adManager.initialize(new Runnable() {
            @Override
            public void run() {
                try {
                    LinearLayout top = findViewById(R.id.topAdContainer);
                    LinearLayout bottom = findViewById(R.id.bottomAdContainer);
                    adManager.attachBanners(top, bottom);
                    adManager.loadNativeInto(findViewById(R.id.nativeAdContainer));
                } catch (Exception ignored) {
                }
            }
        });

        webView = findViewById(R.id.webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        if (Build.VERSION.SDK_INT >= 19) {
            webView.setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null);
        }
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        // Never enable WebView debugging in release builds (Play Store policy / security)
        if (BuildConfig.DEBUG && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;
                try {
                    Intent intent = fileChooserParams.createIntent();
                    String[] acceptTypes = fileChooserParams.getAcceptTypes();
                    boolean wantsJson = false;
                    if (acceptTypes != null) {
                        for (String a : acceptTypes) {
                            if (a != null && (a.toLowerCase().contains("json") || a.toLowerCase().contains(".json"))) {
                                wantsJson = true;
                                break;
                            }
                        }
                    }
                    if (wantsJson) {
                        intent.setType("application/json");
                        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json", "text/plain"});
                    } else {
                        intent.setType("audio/*");
                        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"audio/mpeg", "audio/mp3", "audio/*"});
                    }
                    startActivityForResult(intent, REQ_FILE_CHOOSER);
                } catch (Exception e) {
                    MainActivity.this.filePathCallback = null;
                    Toast.makeText(MainActivity.this, "Cannot open file picker", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        webView.addJavascriptInterface(new AndroidBridge(this, webView), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");

        NotificationHelper.createChannel(this);
        HourlyMotivationReceiver.ensureScheduled(this);
        requestNeededPermissions();
        handleNotifIntent(getIntent());
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            try {
                webView.evaluateJavascript("try{if(document.querySelector('#breakHistoryDialog')?.open){document.querySelector('#breakHistoryDialog').close();true}else if(typeof closeSidebar==='function' && document.querySelector('#sidebar')?.classList.contains('open')){closeSidebar();true}else if(typeof closeSettingsSheet==='function' && document.querySelector('dialog[open]')){closeSettingsSheet();true}else{false}}catch(e){false}", value -> {
                    if (value == null || !"true".equals(value)) MainActivity.super.onBackPressed();
                });
                return;
            } catch (Exception ignored) {}
        }
        super.onBackPressed();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleNotifIntent(intent);
    }

    private void handleNotifIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getStringExtra("notif_action");
        if (action == null) return;
        long taskId = intent.getLongExtra("task_id", 0);

        if ("start".equals(action) && webView != null) {
            final long id = taskId;
            final int[] attempt = {0};
            final Runnable runStart = new Runnable() {
                @Override
                public void run() {
                    try {
                        // Start task by id; if already running, no-op. If another running, JS alerts.
                        String js = "try{"
                                + "if(typeof startTask==='function'){"
                                + "  var id=" + id + ";"
                                + "  var t=(state.tasks||[]).find(function(x){return Math.floor(Number(x.id))===Math.floor(Number(id))&&!x.completed;});"
                                + "  if(t){ startTask(t.id); if(typeof render==='function') render(); }"
                                + "  else if(typeof render==='function'){ render(); }"
                                + "}"
                                + "}catch(e){}";
                        webView.evaluateJavascript(js, null);
                    } catch (Exception ignored) {
                    }
                    attempt[0]++;
                    if (attempt[0] < 6) {
                        webView.postDelayed(this, 400);
                    }
                }
            };
            webView.postDelayed(runStart, 350);
            return;
        }

        if ("stop".equals(action) && webView != null) {
            final long id = taskId;
            final int[] attempt = {0};
            final Runnable runStop = new Runnable() {
                @Override
                public void run() {
                    try {
                        String js = "try{"
                                + "if(typeof stopTask==='function'){"
                                + "  var id=" + id + ";"
                                + "  var t=(state.tasks||[]).find(function(x){return Math.floor(Number(x.id))===Math.floor(Number(id))&&x.runningAt;})"
                                + "    ||(state.tasks||[]).find(function(x){return !x.completed&&x.runningAt;});"
                                + "  if(t) stopTask(t.id);"
                                + "}"
                                + "}catch(e){}";
                        webView.evaluateJavascript(js, null);
                    } catch (Exception ignored) {
                    }
                    attempt[0]++;
                    if (attempt[0] < 5) {
                        webView.postDelayed(this, 400);
                    }
                }
            };
            webView.postDelayed(runStop, 300);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE_CHOOSER) {
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                String dataString = data.getDataString();
                if (dataString != null) {
                    results = new Uri[]{Uri.parse(dataString)};
                } else if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) {
                        results[i] = data.getClipData().getItemAt(i).getUri();
                    }
                }
            }
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
        }
    }

    private void requestNeededPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATION);
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
            if (am != null && !am.canScheduleExactAlarms()) {
                try {
                    Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                    Toast.makeText(this,
                            "Please allow Exact Alarms for reliable task reminders",
                            Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIFICATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Notification permission granted", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (adManager != null) {
            adManager.resume();
        }
        if (webView != null) {
            try { webView.evaluateJavascript("try{if(document.getElementById('sidePanelBlocking')&&document.getElementById('sidePanelBlocking').classList.contains('show')&&typeof renderAppBlockingPanel==='function')renderAppBlockingPanel();}catch(e){}", null); } catch (Exception ignored) {}
        }
    }

    @Override
    protected void onPause() {
        if (adManager != null) {
            adManager.pause();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (adManager != null) {
            adManager.destroy();
        }
        super.onDestroy();
    }

    public AdManager getAdManager() {
        return adManager;
    }
}
