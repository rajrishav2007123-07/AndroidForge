package com.jeetracker.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

public class NotesWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_REFRESH = "com.jeetracker.app.NOTES_WIDGET_REFRESH";

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        if (ids == null) return;
        for (int id : ids) updateAppWidget(context, manager, id);
    }

    @Override public void onDeleted(Context context, int[] ids) {
        super.onDeleted(context, ids);
        SharedPreferences.Editor ed=context.getSharedPreferences("jee_prefs",Context.MODE_PRIVATE).edit();
        if(ids!=null) for(int id:ids) ed.remove("notes_widget_slot_"+id);
        ed.apply();
    }

    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context,intent);
        if(intent!=null && (ACTION_REFRESH.equals(intent.getAction()) || AppWidgetManager.ACTION_APPWIDGET_UPDATE.equals(intent.getAction()))) {
            AppWidgetManager mgr=AppWidgetManager.getInstance(context);
            int[] ids=mgr.getAppWidgetIds(new ComponentName(context,NotesWidgetProvider.class));
            onUpdate(context,mgr,ids);
        }
    }

    public static void requestUpdate(Context context) {
        try {
            Context app=context.getApplicationContext();
            AppWidgetManager mgr=AppWidgetManager.getInstance(app);
            int[] ids=mgr.getAppWidgetIds(new ComponentName(app,NotesWidgetProvider.class));
            if(ids!=null && ids.length>0){
                Intent i=new Intent(app,NotesWidgetProvider.class);
                i.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
                i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS,ids);
                app.sendBroadcast(i);
            }
        } catch(Exception ignored) {}
    }

    static void updateAppWidget(Context context, AppWidgetManager manager, int id) {
        RemoteViews views=new RemoteViews(context.getPackageName(),R.layout.widget_notes);
        SharedPreferences prefs=context.getSharedPreferences("jee_prefs",Context.MODE_PRIVATE);
        int slot=prefs.getInt("notes_widget_slot_"+id,0);
        if(slot<0 || slot>2) slot=0;
        String text="", color="white";
        try{
            String json=prefs.getString("task_state","");
            if(!json.isEmpty()){
                JSONObject state=new JSONObject(json);
                JSONArray arr=state.optJSONArray("notesWidgets");
                if(arr!=null && slot<arr.length()){
                    JSONObject n=arr.optJSONObject(slot);
                    if(n!=null){ text=n.optString("text",""); color=n.optString("color","white"); }
                }
            }
        }catch(Exception ignored){}
        views.setInt(R.id.notes_widget_root,"setBackgroundResource",backgroundForColor(color));
        int fg=textColorFor(color);
        views.setTextColor(R.id.notes_widget_title,fg);
        views.setTextColor(R.id.notes_widget_text,fg);
        views.setTextViewText(R.id.notes_widget_title,"Notes Widget "+(slot+1));
        views.setTextViewText(R.id.notes_widget_text,text.isEmpty()?"Open app → Menu → Notes Widget":""+text);
        try{
            Intent open=new Intent(context,MainActivity.class);
            open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi=PendingIntent.getActivity(context,id,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            views.setOnClickPendingIntent(R.id.notes_widget_root,pi);
        }catch(Exception ignored){}
        manager.updateAppWidget(id,views);
    }

    private static int backgroundForColor(String c){
        if(c==null)c="white";
        switch(c.toLowerCase()){
            case "black": return R.drawable.widget_bg_black;
            case "red": return R.drawable.widget_bg_red;
            case "orange": return R.drawable.widget_bg_orange;
            case "yellow": return R.drawable.widget_bg_yellow;
            case "green": return R.drawable.widget_bg_green;
            case "lime": return R.drawable.widget_bg_lime;
            case "skyblue": return R.drawable.widget_bg_skyblue;
            case "blue": return R.drawable.widget_bg_blue;
            case "purple": return R.drawable.widget_bg_purple;
            default: return R.drawable.widget_bg_white;
        }
    }
    private static int textColorFor(String c){
        if(c==null)return Color.BLACK;
        switch(c.toLowerCase()){
            case "white": case "yellow": case "lime": case "skyblue": return Color.BLACK;
            default:return Color.WHITE;
        }
    }
}
