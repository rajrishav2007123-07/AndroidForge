package com.jeetracker.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

/**
 * Status-bar notifications + optional continuous vibration until stop.
 * Personal alarms can open MathChallenge via full-screen intent / stop action.
 */
public class NotificationHelper {

    public static final String CHANNEL_ID = "jee_task_alarms";
    public static final String CHANNEL_PERSONAL = "jee_personal_alarms";
    public static final String ACTION_STOP_ALARM = "com.jeetracker.app.STOP_ALARM";
    public static final int NOTIFICATION_ID = 9001;
    public static final int PERSONAL_NOTIFICATION_ID = 9002;
    public static final String CHANNEL_RUNNING = "jee_running_task";
    public static final String CHANNEL_HOURLY = "jee_hourly_motivation";
    public static final int HOURLY_NOTIFICATION_ID = 8802;
    public static final int RUNNING_NOTIFICATION_ID = 9010;
    public static final String ACTION_NOTIF_STOP = "com.jeetracker.app.NOTIF_STOP_TASK";
    public static final String ACTION_NOTIF_START = "com.jeetracker.app.NOTIF_START_TASK";
    public static final String EXTRA_TASK_ID = "task_id";

    private static final long[] PULSE = {0, 700, 400, 700, 400, 900};
    private static final Handler vibeHandler = new Handler(Looper.getMainLooper());
    private static Runnable vibeRunnable;
    private static boolean vibrating = false;

    public static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = context.getSystemService(NotificationManager.class);
            if (nm == null) return;

            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "Task Alarms", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Task start reminders");
            ch.enableVibration(true);
            ch.setVibrationPattern(PULSE);
            ch.setSound(null, null);
            ch.setShowBadge(true);
            nm.createNotificationChannel(ch);

            NotificationChannel ch2 = new NotificationChannel(
                    CHANNEL_PERSONAL, "Personal Alarms", NotificationManager.IMPORTANCE_HIGH);
            ch2.setDescription("Personal work alarms");
            ch2.enableVibration(true);
            ch2.setVibrationPattern(PULSE);
            ch2.setSound(null, null);
            ch2.setShowBadge(true);
            // Allow full-screen intents for math challenge
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ch2.setBypassDnd(true);
            }
            NotificationChannel chRun = new NotificationChannel(
                    CHANNEL_RUNNING, "Running Study Session", NotificationManager.IMPORTANCE_LOW);
            chRun.setDescription("Shows the currently running task with Start/Stop");
            chRun.setShowBadge(false);
            chRun.setSound(null, null);
            nm.createNotificationChannel(chRun);

            NotificationChannel chHourly = new NotificationChannel(
                    CHANNEL_HOURLY, "Hourly study tips", NotificationManager.IMPORTANCE_DEFAULT);
            chHourly.setDescription("Gentle motivational quotes and task reminders — no alarm sound");
            chHourly.enableVibration(true);
            chHourly.setVibrationPattern(new long[]{0, 60, 40, 60});
            chHourly.setSound(null, null);
            chHourly.setShowBadge(false);
            nm.createNotificationChannel(chHourly);


            nm.createNotificationChannel(ch2);
        }
    }


    /**
     * Hourly tip: quote + task reminder. NO alarm sound — short vibration only.
     * Uses dedicated quiet channel (not Task Alarms channel).
     */
    public static void showHourlyMotivation(Context context, String title, String body) {
        try {
            createChannel(context);
            Intent open = new Intent(context, MainActivity.class);
            open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            PendingIntent contentPi = PendingIntent.getActivity(
                    context, 8803, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            NotificationCompat.Builder b = new NotificationCompat.Builder(context, CHANNEL_HOURLY)
                    .setSmallIcon(R.drawable.ic_notification)
                    .setContentTitle(title != null ? title : "Study Tracker")
                    .setContentText(body)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .setCategory(NotificationCompat.CATEGORY_REMINDER)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    .setAutoCancel(true)
                    .setOngoing(false)
                    .setSilent(true)
                    .setOnlyAlertOnce(true)
                    .setContentIntent(contentPi);

            NotificationManagerCompat.from(context).notify(HOURLY_NOTIFICATION_ID, b.build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void show(Context context, String title, String body) {
        showInternal(context, title, body, CHANNEL_ID, NOTIFICATION_ID, false);
    }

    public static void showPersonal(Context context, String title, String body) {
        showInternal(context, title, body, CHANNEL_PERSONAL, PERSONAL_NOTIFICATION_ID, true);
    }

    public static void showExpectedWarning(Context context, String taskTitle, int minutes) {
        createChannel(context);
        Intent openApp=new Intent(context,MainActivity.class); openApp.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content=PendingIntent.getActivity(context,91,openApp,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent stop=new Intent(context,StopExpectedWarningReceiver.class).setAction(StopExpectedWarningReceiver.ACTION_STOP);
        PendingIntent stopPi=PendingIntent.getBroadcast(context,92,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b=new NotificationCompat.Builder(context,CHANNEL_ID)
          .setSmallIcon(R.drawable.ic_notification).setContentTitle("⚠️ Expected time warning")
          .setContentText("\\\""+taskTitle+"\\\" — "+minutes+" min left")
          .setPriority(NotificationCompat.PRIORITY_HIGH).setCategory(NotificationCompat.CATEGORY_REMINDER)
          .setOngoing(true).setAutoCancel(false).setOnlyAlertOnce(true).setSilent(true)
          .setContentIntent(content).addAction(0,"⏹ Stop vibration",stopPi);
        try{NotificationManagerCompat.from(context).notify(ExpectedWarningReceiver.NOTIFICATION_ID,b.build());}catch(Exception ignored){}
        if(isLateWarnVibrationEnabled(context)) startExpectedWarningVibration(context);
    }
    private static boolean isLateWarnVibrationEnabled(Context context){return context.getSharedPreferences("jee_prefs",Context.MODE_PRIVATE).getBoolean("late_warn_vibration",true);}
    private static final long[] WARNING_PULSE={0,300,150,300};
    static void startExpectedWarningVibration(Context context){
        context.getSharedPreferences("jee_prefs",Context.MODE_PRIVATE).edit().putBoolean("expected_warning_vibration_active",true).apply();
        vibrateWarningOnce(context); scheduleExpectedWarningPulse(context,3500);
    }
    static void stopExpectedWarning(Context context){
        context.getSharedPreferences("jee_prefs",Context.MODE_PRIVATE).edit().putBoolean("expected_warning_vibration_active",false).apply();
        cancelExpectedWarningPulse(context);
        try{NotificationManagerCompat.from(context).cancel(ExpectedWarningReceiver.NOTIFICATION_ID);}catch(Exception ignored){}
        try{
            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.S){VibratorManager vm=(VibratorManager)context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE);if(vm!=null)vm.getDefaultVibrator().cancel();}
            else{Vibrator v=(Vibrator)context.getSystemService(Context.VIBRATOR_SERVICE);if(v!=null)v.cancel();}
        }catch(Exception ignored){}
    }
    static void vibrateWarningOnce(Context context){
        try{
            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.S){VibratorManager vm=(VibratorManager)context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE);if(vm!=null)vm.getDefaultVibrator().vibrate(VibrationEffect.createWaveform(WARNING_PULSE,-1));}
            else{Vibrator v=(Vibrator)context.getSystemService(Context.VIBRATOR_SERVICE);if(v!=null){if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)v.vibrate(VibrationEffect.createWaveform(WARNING_PULSE,-1));else v.vibrate(WARNING_PULSE,-1);}}
        }catch(Exception ignored){}
    }
    static void scheduleExpectedWarningPulse(Context context,long delayMs){
        try{android.app.AlarmManager am=(android.app.AlarmManager)context.getSystemService(Context.ALARM_SERVICE);if(am==null)return;Intent i=new Intent(context,ExpectedWarningPulseReceiver.class).setAction(ExpectedWarningPulseReceiver.ACTION);android.app.PendingIntent pi=android.app.PendingIntent.getBroadcast(context,7799,i,android.app.PendingIntent.FLAG_UPDATE_CURRENT|android.app.PendingIntent.FLAG_IMMUTABLE);long at=System.currentTimeMillis()+Math.max(0,delayMs);if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M)am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP,at,pi);else am.setExact(android.app.AlarmManager.RTC_WAKEUP,at,pi);}catch(Exception ignored){}
    }
    static void cancelExpectedWarningPulse(Context context){
        try{android.app.AlarmManager am=(android.app.AlarmManager)context.getSystemService(Context.ALARM_SERVICE);if(am==null)return;Intent i=new Intent(context,ExpectedWarningPulseReceiver.class).setAction(ExpectedWarningPulseReceiver.ACTION);android.app.PendingIntent pi=android.app.PendingIntent.getBroadcast(context,7799,i,android.app.PendingIntent.FLAG_UPDATE_CURRENT|android.app.PendingIntent.FLAG_IMMUTABLE);am.cancel(pi);pi.cancel();}catch(Exception ignored){}
    }

    private static void showInternal(Context context, String title, String body,
                                     String channelId, int notifId, boolean isPersonal) {
        createChannel(context);

        Intent openApp = new Intent(context, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
                context, isPersonal ? 11 : 10, openApp,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stopIntent = new Intent(context, StopAlarmReceiver.class);
        stopIntent.setAction(ACTION_STOP_ALARM);
        stopIntent.putExtra("is_personal", isPersonal);
        PendingIntent stopPi = PendingIntent.getBroadcast(
                context, isPersonal ? 22 : 21, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setAutoCancel(false)
                .setOngoing(true)
                .setContentIntent(contentIntent)
                .setOnlyAlertOnce(false)
                .addAction(0, "⏹ Stop Alarm", stopPi);

        // Personal + math ON → full-screen intent so MathChallenge always opens
        if (isPersonal && isMathChallengeEnabled(context)) {
            Intent challenge = new Intent(context, MathChallengeActivity.class);
            challenge.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_NO_USER_ACTION);
            PendingIntent fullScreen = PendingIntent.getActivity(
                    context, 33, challenge,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            builder.setFullScreenIntent(fullScreen, true);
            builder.setContentIntent(fullScreen);
        }

        try {
            NotificationManagerCompat.from(context).notify(notifId, builder.build());
        } catch (SecurityException e) {
            e.printStackTrace();
        }

        if (isContinuousVibrationEnabled(context)) {
            startContinuousVibration(context);
        } else {
            // one short pulse still helpful
            vibrateOnce(context);
        }
    }

    public static boolean isContinuousVibrationEnabled(Context context) {
        return context.getSharedPreferences("jee_prefs", Context.MODE_PRIVATE)
                .getBoolean("continuous_vibration", true);
    }

    public static synchronized void startContinuousVibration(Context context) {
        stopContinuousVibration(context);
        if (!isContinuousVibrationEnabled(context)) {
            return;
        }
        context.getSharedPreferences("jee_prefs", Context.MODE_PRIVATE)
                .edit().putBoolean("alarm_vibration_active", true).apply();
        try {
            Intent service = new Intent(context, VibrationService.class)
                    .setAction(VibrationService.ACTION_START);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(service);
            } else {
                context.startService(service);
            }
        } catch (Exception e) {
            // Fallback for devices that reject foreground-service startup.
            scheduleVibrationPulse(context, 0);
        }
    }

    public static synchronized void stopContinuousVibration(Context context) {
        context.getSharedPreferences("jee_prefs", Context.MODE_PRIVATE)
                .edit().putBoolean("alarm_vibration_active", false).apply();
        cancelVibrationPulse(context);
        try {
            Intent service = new Intent(context, VibrationService.class)
                    .setAction(VibrationService.ACTION_STOP);
            context.startService(service);
        } catch (Exception ignored) {}
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                VibratorManager vm = (VibratorManager) context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
                if (vm != null) vm.getDefaultVibrator().cancel();
            } else {
                Vibrator v = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null) v.cancel();
            }
        } catch (Exception ignored) {}
    }

    static void scheduleVibrationPulse(Context context, long delayMs) {
        try {
            android.app.AlarmManager am=(android.app.AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
            if(am==null)return;
            Intent i=new Intent(context,VibrationPulseReceiver.class).setAction(VibrationPulseReceiver.ACTION_ALARM);
            android.app.PendingIntent pi=android.app.PendingIntent.getBroadcast(context, 7711, i, android.app.PendingIntent.FLAG_UPDATE_CURRENT|android.app.PendingIntent.FLAG_IMMUTABLE);
            long at=System.currentTimeMillis()+Math.max(0,delayMs);
            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M) am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP,at,pi); else am.setExact(android.app.AlarmManager.RTC_WAKEUP,at,pi);
        }catch(Exception ignored){}
    }

    static void cancelVibrationPulse(Context context) {
        try {
            android.app.AlarmManager am=(android.app.AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
            if(am==null)return;
            Intent i=new Intent(context,VibrationPulseReceiver.class).setAction(VibrationPulseReceiver.ACTION_ALARM);
            android.app.PendingIntent pi=android.app.PendingIntent.getBroadcast(context,7711,i,android.app.PendingIntent.FLAG_UPDATE_CURRENT|android.app.PendingIntent.FLAG_IMMUTABLE);
            am.cancel(pi); pi.cancel();
        }catch(Exception ignored){}
    }

    static void vibrateOnce(Context context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                VibratorManager vm = (VibratorManager) context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
                if (vm != null) {
                    vm.getDefaultVibrator().vibrate(VibrationEffect.createWaveform(PULSE, -1));
                }
            } else {
                Vibrator v = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v.vibrate(VibrationEffect.createWaveform(PULSE, -1));
                    } else {
                        v.vibrate(PULSE, -1);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void cancelAlarmNotification(Context context) {
        try {
            NotificationManagerCompat.from(context).cancel(NOTIFICATION_ID);
            NotificationManagerCompat.from(context).cancel(PERSONAL_NOTIFICATION_ID);
            NotificationManagerCompat.from(context).cancel(ExpectedWarningReceiver.NOTIFICATION_ID);
        } catch (Exception ignored) {}
        context.getSharedPreferences("jee_prefs", Context.MODE_PRIVATE).edit().putBoolean("expected_warning_active",false).apply();
        stopContinuousVibration(context);
    }

    public static boolean isLibraryMode(Context context) {
        return context.getSharedPreferences("jee_prefs", Context.MODE_PRIVATE)
                .getBoolean("library_mode", false);
    }

    public static boolean isMathChallengeEnabled(Context context) {
        return context.getSharedPreferences("jee_prefs", Context.MODE_PRIVATE)
                .getBoolean("math_challenge_enabled", false);
    }


    /**
     * Task start reminder with ▶ Start Task button on the notification itself.
     * User can start the study task without opening the full UI first.
     */
    public static void showTaskStartAlarm(Context context, String title, String body, long taskId) {
        try {
            createChannel(context);
            int notifId = NOTIFICATION_ID + (int) (Math.abs(taskId) % 1000);

            Intent open = new Intent(context, MainActivity.class);
            open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            open.putExtra("notif_action", "open");
            open.putExtra(EXTRA_TASK_ID, taskId);
            PendingIntent contentPi = PendingIntent.getActivity(
                    context, (int) (20 + taskId % 1000), open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            // ▶ Start Task — handled by RunningTaskActionReceiver → MainActivity startTask
            Intent start = new Intent(context, RunningTaskActionReceiver.class);
            start.setAction(ACTION_NOTIF_START);
            start.putExtra(EXTRA_TASK_ID, taskId);
            start.putExtra("task_title", title != null ? title : "Task");
            PendingIntent startPi = PendingIntent.getBroadcast(
                    context, (int) (30 + taskId % 1000), start,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            // Dismiss / stop sound
            Intent stop = new Intent(context, StopAlarmReceiver.class);
            stop.setAction(ACTION_STOP_ALARM);
            PendingIntent stopPi = PendingIntent.getBroadcast(
                    context, (int) (40 + taskId % 1000), stop,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            String head = "⏰ Task starting soon!";
            String text = body != null ? body : (title != null ? title : "Your task is about to start");

            NotificationCompat.Builder b = new NotificationCompat.Builder(context, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_notification)
                    .setContentTitle(head)
                    .setContentText(text)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                    .setPriority(NotificationCompat.PRIORITY_MAX)
                    .setCategory(NotificationCompat.CATEGORY_ALARM)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    .setAutoCancel(true)
                    .setOngoing(false)
                    .setContentIntent(contentPi)
                    .setOnlyAlertOnce(false)
                    .addAction(0, "▶ Start Task", startPi)
                    .addAction(0, "Dismiss", stopPi);

            NotificationManagerCompat.from(context).notify(notifId, b.build());
        } catch (Exception e) {
            e.printStackTrace();
            // fallback
            show(context, "⏰ Task starting soon!", body != null ? body : title);
        }
    }

    public static void cancelTaskStartAlarm(Context context, long taskId) {
        try {
            int notifId = NOTIFICATION_ID + (int) (Math.abs(taskId) % 1000);
            NotificationManagerCompat.from(context).cancel(notifId);
        } catch (Exception ignored) {}
    }

    /** Ongoing notification for currently running task / break. Actions: Stop. */
    public static void showRunningTask(Context context, long taskId, String title, String subject,
                                       long elapsedSec, boolean isBreak) {
        try {
            createChannel(context);
            Intent open = new Intent(context, MainActivity.class);
            open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent contentPi = PendingIntent.getActivity(
                    context, 0, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Intent stop = new Intent(context, RunningTaskActionReceiver.class);
            stop.setAction(ACTION_NOTIF_STOP);
            stop.putExtra(EXTRA_TASK_ID, taskId);
            PendingIntent stopPi = PendingIntent.getBroadcast(
                    context, 11, stop,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            String timeStr = formatElapsed(elapsedSec);
            String head = isBreak ? "☕ Break" : "▶ Studying";
            String body = isBreak
                    ? ("Break · " + timeStr)
                    : ((subject != null && !subject.isEmpty() ? subject + " · " : "") + (title != null ? title : "Task") + " · " + timeStr);

            NotificationCompat.Builder b = new NotificationCompat.Builder(context, CHANNEL_RUNNING)
                    .setSmallIcon(R.drawable.ic_notification)
                    .setContentTitle(head)
                    .setContentText(body)
                    .setSubText(timeStr)
                    .setOngoing(true)
                    .setOnlyAlertOnce(true)
                    .setSilent(true)
                    .setPriority(NotificationCompat.PRIORITY_LOW)
                    .setCategory(NotificationCompat.CATEGORY_PROGRESS)
                    .setContentIntent(contentPi)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC);

            if (!isBreak && taskId > 0) {
                b.addAction(0, "⏹ Stop", stopPi);
            }

            NotificationManagerCompat.from(context).notify(RUNNING_NOTIFICATION_ID, b.build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void cancelRunningTask(Context context) {
        try {
            NotificationManagerCompat.from(context).cancel(RUNNING_NOTIFICATION_ID);
        } catch (Exception ignored) {}
    }

    private static String formatElapsed(long sec) {
        if (sec < 0) sec = 0;
        long h = sec / 3600;
        long m = (sec % 3600) / 60;
        long s = sec % 60;
        if (h > 0) return h + "h " + m + "m";
        if (m > 0) return m + "m " + s + "s";
        return s + "s";
    }

}
