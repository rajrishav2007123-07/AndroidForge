package com.jeetracker.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;

/**
 * Stop button from notification.
 * Math challenge only for PERSONAL alarms.
 */
public class StopAlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        if (!NotificationHelper.ACTION_STOP_ALARM.equals(intent.getAction())) return;

        boolean isPersonal = intent.getBooleanExtra("is_personal", false);

        if (isPersonal && NotificationHelper.isMathChallengeEnabled(context)) {
            // Keep receiver alive briefly while starting activity
            final PendingResult pr = goAsync();
            try {
                Intent challenge = new Intent(context, MathChallengeActivity.class);
                challenge.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_CLEAR_TOP
                        | Intent.FLAG_ACTIVITY_SINGLE_TOP
                        | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                context.startActivity(challenge);
            } catch (Exception e) {
                e.printStackTrace();
                // Fallback: stop without math if activity cannot start
                AlarmPlayer.stop();
                NotificationHelper.cancelAlarmNotification(context);
            }
            new Handler(Looper.getMainLooper()).postDelayed(pr::finish, 2000);
        } else {
            AlarmPlayer.stop();
            NotificationHelper.cancelAlarmNotification(context);
        }
    }
}
