package com.jeetracker.app;

import android.app.Application;

/** TaskZen Study application entry point. All study data is stored locally on-device. */
public class StudyTrackerApp extends Application { @Override public void onCreate() { super.onCreate(); } }
