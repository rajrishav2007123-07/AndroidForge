package com.jeetracker.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.Calendar;

/**
 * Schedules exact alarms for 10, 5 and 1 minute before task start time.
 * Works even when app is closed / killed (using setExactAndAllowWhileIdle).
 */
public class TaskAlarmHelper {

    // 10 min, 5 min, 1 min before start
    private static final int[] OFFSETS = {10, 5, 1};

    public static void scheduleReminders(Context context, long taskId, String title,
                                         String date, String startTime) {
        // Always cancel old ones first
        cancelReminders(context, taskId);

        if (startTime == null || startTime.isEmpty() || date == null || date.isEmpty()) return;

        try {
            String[] timeParts = startTime.split(":");
            int hour = Integer.parseInt(timeParts[0].trim());
            int minute = Integer.parseInt(timeParts[1].trim());

            String[] dateParts = date.split("-");
            int year = Integer.parseInt(dateParts[0].trim());
            int month = Integer.parseInt(dateParts[1].trim()) - 1; // Calendar is 0-based
            int day = Integer.parseInt(dateParts[2].trim());

            Calendar startCal = Calendar.getInstance();
            startCal.set(Calendar.YEAR, year);
            startCal.set(Calendar.MONTH, month);
            startCal.set(Calendar.DAY_OF_MONTH, day);
            startCal.set(Calendar.HOUR_OF_DAY, hour);
            startCal.set(Calendar.MINUTE, minute);
            startCal.set(Calendar.SECOND, 0);
            startCal.set(Calendar.MILLISECOND, 0);

            long startMillis = startCal.getTimeInMillis();
            long now = System.currentTimeMillis();

            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;

            for (int offset : OFFSETS) {
                long fireAt = startMillis - (offset * 60_000L);
                if (fireAt <= now) continue; // already past

                Intent intent = new Intent(context, TaskAlarmReceiver.class);
                intent.setAction("com.jeetracker.app.TASK_ALARM");
                intent.putExtra("taskId", taskId);
                intent.putExtra("title", title);
                intent.putExtra("minutesLeft", offset);

                // Unique request code per task + offset
                int requestCode = generateRequestCode(taskId, offset);

                PendingIntent pi = PendingIntent.getBroadcast(
                        context,
                        requestCode,
                        intent,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                );

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fireAt, pi);
                } else {
                    am.setExact(AlarmManager.RTC_WAKEUP, fireAt, pi);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void cancelReminders(Context context, long taskId) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        for (int offset : OFFSETS) {
            Intent intent = new Intent(context, TaskAlarmReceiver.class);
            intent.setAction("com.jeetracker.app.TASK_ALARM");

            int requestCode = generateRequestCode(taskId, offset);

            PendingIntent pi = PendingIntent.getBroadcast(
                    context,
                    requestCode,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
            am.cancel(pi);
            pi.cancel();
        }
    }

    private static int generateRequestCode(long taskId, int offset) {
        // Keep it within int range and unique
        return (int) ((taskId % 100000) * 10 + offset);
    }
    private static final int[] EXPECTED_OFFSETS = {10, 5};

    public static void scheduleExpectedWarnings(Context context, long taskId, String title, int expectedMinutes, long runningAt) {
        cancelExpectedWarnings(context, taskId);
        if (taskId == 0 || runningAt <= 0 || expectedMinutes <= 0) return;
        AlarmManager am=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        if(am==null)return;
        long endAt=runningAt + expectedMinutes*60_000L;
        for(int offset:EXPECTED_OFFSETS){
            long fireAt=endAt-offset*60_000L;
            if(fireAt<=System.currentTimeMillis()) continue;
            Intent in=new Intent(context,ExpectedWarningReceiver.class).setAction(ExpectedWarningReceiver.ACTION);
            in.putExtra("taskId",taskId); in.putExtra("title",title); in.putExtra("minutes",offset);
            int code=expectedRequestCode(taskId,offset);
            PendingIntent pi=PendingIntent.getBroadcast(context,code,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,fireAt,pi); else am.setExact(AlarmManager.RTC_WAKEUP,fireAt,pi);
        }
    }
    public static void cancelExpectedWarnings(Context context,long taskId){
        NotificationHelper.stopExpectedWarning(context);
        AlarmManager am=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE); if(am==null)return;
        for(int offset:EXPECTED_OFFSETS){
            Intent in=new Intent(context,ExpectedWarningReceiver.class).setAction(ExpectedWarningReceiver.ACTION);
            PendingIntent pi=PendingIntent.getBroadcast(context,expectedRequestCode(taskId,offset),in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            am.cancel(pi); pi.cancel();
        }
    }
    private static int expectedRequestCode(long taskId,int offset){return (int)((taskId%100000)*10+offset+500000);}

}
