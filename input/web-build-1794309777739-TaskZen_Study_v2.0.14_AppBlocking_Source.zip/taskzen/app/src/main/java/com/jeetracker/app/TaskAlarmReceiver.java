package com.jeetracker.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Receives the task start alarm even when the app is closed.
 * Shows a status-bar notification with ▶ Start Task action + plays alarm sound.
 */
public class TaskAlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;

        String title = intent.getStringExtra("title");
        int minutesLeft = intent.getIntExtra("minutesLeft", 0);
        long taskId = intent.getLongExtra("taskId", 0);
        // also accept task_id key used elsewhere
        if (taskId == 0) {
            taskId = intent.getLongExtra(NotificationHelper.EXTRA_TASK_ID, 0);
        }

        if (title == null || title.isEmpty()) title = "Task";

        String body;
        if (minutesLeft <= 0) {
            body = "\"" + title + "\" is ready — tap Start Task to begin studying.";
        } else {
            body = "\"" + title + "\" starts in " + minutesLeft
                    + " minute" + (minutesLeft > 1 ? "s" : "")
                    + ". Tap Start Task when ready.";
        }

        // Notification with ▶ Start Task button
        NotificationHelper.showTaskStartAlarm(context, title, body, taskId);

        // Play alarm sound (library mode stays silent)
        AlarmPlayer.play(context);
    }
}
