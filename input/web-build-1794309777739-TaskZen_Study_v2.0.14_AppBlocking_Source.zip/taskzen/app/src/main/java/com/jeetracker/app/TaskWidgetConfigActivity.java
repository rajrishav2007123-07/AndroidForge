package com.jeetracker.app;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Configuration screen shown when a Task Widget is added. The widget chooses one
 * of the three user-configurable date slots; the actual dates are edited inside
 * the app's Task Widget settings. */
public class TaskWidgetConfigActivity extends Activity {
 @Override public void onCreate(Bundle b){
  super.onCreate(b);
  int id=getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,AppWidgetManager.INVALID_APPWIDGET_ID);
  if(id==AppWidgetManager.INVALID_APPWIDGET_ID){setResult(RESULT_CANCELED);finish();return;}
  LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(28,28,28,28);
  TextView title=new TextView(this); title.setText("Choose Task Widget Slot"); title.setTextSize(22); title.setGravity(Gravity.CENTER_VERTICAL); box.addView(title);
  TextView info=new TextView(this); info.setText("Each slot has its own date in Settings → Task Widget settings. The selected slot's date determines which tasks appear."); info.setTextSize(14); info.setPadding(0,12,0,14); box.addView(info);
  String[] labels={"Task Widget 1","Task Widget 2","Task Widget 3"};
  for(int i=0;i<3;i++){ final int slot=i; Button btn=new Button(this); btn.setText(labels[i]); btn.setOnClickListener(v->{
      getSharedPreferences("jee_prefs",Context.MODE_PRIVATE).edit().putInt("task_widget_day_offset_"+id,slot).apply();
      AppWidgetManager.getInstance(this).updateAppWidget(id,null);
      Intent result=new Intent();result.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id);setResult(RESULT_OK,result);
      StudyWidgetProvider.requestUpdate(this); finish();
  }); box.addView(btn); }
  Button settings=new Button(this); settings.setText("Open app to choose dates"); settings.setOnClickListener(v->{
      Intent open=new Intent(this,MainActivity.class); open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP); startActivity(open);
      Toast.makeText(this,"Choose dates in Settings → Task Widget settings, then add/refresh the widget.",Toast.LENGTH_LONG).show();
  }); box.addView(settings);
  setContentView(box);
 }
}
