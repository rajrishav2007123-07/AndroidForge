package com.jeetracker.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class VibrationPulseReceiver extends BroadcastReceiver {
    public static final String ACTION_ALARM="com.jeetracker.app.VIBRATION_PULSE";
    @Override public void onReceive(Context context, Intent intent){
        if(intent==null || !ACTION_ALARM.equals(intent.getAction())) return;
        android.content.SharedPreferences p=context.getSharedPreferences("jee_prefs",Context.MODE_PRIVATE);
        if(!p.getBoolean("alarm_vibration_active",false) || !p.getBoolean("continuous_vibration",true)) return;
        NotificationHelper.vibrateOnce(context);
        NotificationHelper.scheduleVibrationPulse(context,3500);
    }
}
