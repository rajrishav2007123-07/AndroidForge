package com.jeetracker.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;

import androidx.core.app.NotificationCompat;

/**
 * Keeps the alarm vibration alive until the user presses Stop Alarm in the
 * status-bar notification. A repeating Vibrator waveform is used instead of
 * repeatedly scheduling 3.5-second AlarmManager pulses, which Android may
 * throttle while the device is idle.
 */
public class VibrationService extends Service {
    public static final String ACTION_START = "com.jeetracker.app.START_VIBRATION_SERVICE";
    public static final String ACTION_STOP = "com.jeetracker.app.STOP_VIBRATION_SERVICE";
    private static final long[] HARDCORE_PATTERN = {0, 700, 350, 700, 350, 900};
    private static final int SERVICE_NOTIFICATION_ID = NotificationHelper.NOTIFICATION_ID;

    @Override public void onCreate() {
        super.onCreate();
        NotificationHelper.createChannel(this);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopVibrationAndSelf();
            return START_NOT_STICKY;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForeground(SERVICE_NOTIFICATION_ID, buildNotification());
        } else {
            startForeground(SERVICE_NOTIFICATION_ID, buildNotification());
        }
        startRepeatingVibration();
        return START_STICKY;
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(this, 101, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, StopAlarmReceiver.class)
                .setAction(NotificationHelper.ACTION_STOP_ALARM)
                .putExtra("is_personal", false);
        PendingIntent stopPi = PendingIntent.getBroadcast(this, 102, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, NotificationHelper.CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("📚 Library mode alarm")
                .setContentText("Vibration is active — tap Stop Alarm to stop it")
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setOngoing(true)
                .setAutoCancel(false)
                .setOnlyAlertOnce(true)
                .setContentIntent(content)
                .addAction(0, "⏹ Stop Alarm", stopPi)
                .build();
    }

    private void startRepeatingVibration() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                VibratorManager vm = (VibratorManager) getSystemService(VIBRATOR_MANAGER_SERVICE);
                if (vm != null) vm.getDefaultVibrator().vibrate(
                        VibrationEffect.createWaveform(HARDCORE_PATTERN, 0));
            } else {
                Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                if (v != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v.vibrate(VibrationEffect.createWaveform(HARDCORE_PATTERN, 0));
                    } else {
                        v.vibrate(HARDCORE_PATTERN, 0);
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    private void stopVibrationAndSelf() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                VibratorManager vm = (VibratorManager) getSystemService(VIBRATOR_MANAGER_SERVICE);
                if (vm != null) vm.getDefaultVibrator().cancel();
            } else {
                Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                if (v != null) v.cancel();
            }
        } catch (Exception ignored) {}
        stopForeground(true);
        stopSelf();
    }

    @Override public void onDestroy() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                VibratorManager vm = (VibratorManager) getSystemService(VIBRATOR_MANAGER_SERVICE);
                if (vm != null) vm.getDefaultVibrator().cancel();
            } else {
                Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                if (v != null) v.cancel();
            }
        } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
