# Android Build Environment and Gradle Wrapper

Project: TaskZen Study v2.0.14  
Application ID: `com.jeetracker.app`

## Gradle configuration

- Gradle Wrapper distribution: **Gradle 8.13**
- Android Gradle Plugin: **8.13.2**
- Java compatibility: **17**
- Compile SDK: **36**
- Target SDK: **36**
- Minimum SDK: **26**

The Android Gradle Plugin 8.13.2 configuration is paired with Gradle 8.13. Use JDK 17 or a compatible newer JDK (such as JDK 21).

## Included wrapper files

- `gradlew` (Linux/macOS wrapper launcher; executable bit set)
- `gradlew.bat` (Windows wrapper launcher)
- `gradle/wrapper/gradle-wrapper.jar`
- `gradle/wrapper/gradle-wrapper.properties`

All Gradle project configuration files are located in the project root. The Android module is in `app/`.

## Build commands

Linux:

```bash
chmod +x ./gradlew   # normally already executable in this ZIP
./gradlew --version
./gradlew assembleDebug
./gradlew bundleRelease
```

Windows CMD:

```bat
gradlew.bat --version
gradlew.bat assembleDebug
gradlew.bat bundleRelease
```

## Android SDK prerequisites

Install Android SDK Platform 36 and the Android SDK Build-Tools version required by the Android Gradle Plugin. Set `ANDROID_HOME` (or `ANDROID_SDK_ROOT`) to the SDK directory, and accept the SDK licences. `local.properties` is machine-specific and is intentionally not bundled; create it locally if Android Studio needs an explicit `sdk.dir`.

## Verification disclosure

The ZIP structure, required wrapper files, wrapper JAR archive integrity, Linux executable permission, Gradle/AGP version pairing, and Android module build configuration were inspected. A full Gradle build was **not** completed in the packaging environment: it had no installed Android SDK, and the Gradle distribution download was blocked by unavailable network/DNS access (`services.gradle.org`). Therefore this package is configured for a Linux Android build environment, but a successful APK/AAB build has not been claimed or verified here.
