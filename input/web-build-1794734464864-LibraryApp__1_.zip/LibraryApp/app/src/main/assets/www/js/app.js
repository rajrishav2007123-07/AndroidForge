(function () {
  var $ = U.$;

  function loginError(msg) { $('login-error').textContent = msg; U.show($('login-error'), !!msg); }
  function busy(on) {
    $('login-btn').disabled = on;
    U.show($('login-btn').querySelector('.spinner'), on);
    $('login-btn').querySelector('.btn-label').textContent = on ? 'Login ho raha hai…' : 'Login';
  }

  function enterHome() { Screens.show('home'); Screens.loadHome(); }

  $('toggle-pass').addEventListener('click', function () {
    var p = $('password'), show = p.type === 'password';
    p.type = show ? 'text' : 'password';
    this.textContent = show ? 'Hide' : 'Show';
  });

  $('login-form').addEventListener('submit', function (ev) {
    ev.preventDefault();
    loginError('');
    var email = $('email').value.trim(), pass = $('password').value;
    if (!/^\S+@\S+\.\S+$/.test(email)) return loginError('Sahi email likhein.');
    if (pass.length < 6) return loginError('Password kam se kam 6 akshar ka hota hai.');
    if (!U.configured()) return loginError('App setup adhura hai: js/config.js me Supabase URL aur anon key daalein.');
    busy(true);
    Auth.login(email, pass).then(function () {
      $('password').value = ''; busy(false); Screens.ctx.libId = null; enterHome();
    }, function (e) { busy(false); loginError(e.message); });
  });

  $('logout-btn').addEventListener('click', function () {
    Auth.logout().then(function () { Screens.ctx.libId = null; Screens.show('login'); U.toast('Logout ho gaye'); });
  });
  $('refresh-btn').addEventListener('click', function () { Screens.loadHome(); });

  // Android back button: nothing to close yet -> let the app exit.
  window.__onNativeBack = function () { return 'exit'; };

  // Start
  if (!U.configured()) { Screens.show('login'); return; }
  Auth.restore().then(function (s) { if (s) enterHome(); else Screens.show('login'); });
})();
