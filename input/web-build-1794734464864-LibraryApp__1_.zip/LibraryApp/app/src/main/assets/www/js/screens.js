(function () {
  var $ = U.$;
  var ctx = { libId: null, libName: '', role: '' };

  function setLoading(on) {
    ['home'].forEach(function () {
      document.getElementById('screen-home').classList.toggle('skeleton', on);
    });
  }

  function fill(d) {
    $('s-active').textContent = U.num(d.active_students);
    $('s-free').textContent = U.num(d.seats_completely_free);
    $('s-free-sub').textContent = 'kul seats: ' + U.num(d.seats_total);
    $('e0').textContent = U.num(d.expiring_today);
    $('e3').textContent = U.num(d.expiring_in_3_days);
    $('e7').textContent = U.num(d.expiring_in_7_days);
    $('e15').textContent = U.num(d.expiring_in_15_days);
    $('s-held').textContent = U.num(d.expired_seat_held);
    $('s-lapsed').textContent = U.num(d.lapsed_seat_released);
    var hasMoney = d.total_balance !== null && d.total_balance !== undefined;
    U.show($('money-block'), hasMoney);
    if (hasMoney) {
      $('m-today').textContent = U.money(d.today_collection);
      $('m-today-sub').textContent = U.num(d.today_payments_count) + ' payments';
      $('m-month').textContent = U.money(d.month_collection);
      $('m-due').textContent = U.money(d.total_balance);
      $('m-due-sub').textContent = U.num(d.students_with_balance) + ' students ka bakaya';
    }
    $('as-on').textContent = d.as_on ? 'Data as on ' + d.as_on : '';
  }

  window.Screens = {
    ctx: ctx,
    show: function (name) {
      ['login', 'home'].forEach(function (n) { U.show($('screen-' + n), n === name); });
      window.scrollTo(0, 0);
    },
    loadHome: function () {
      U.show($('home-error'), false);
      setLoading(true);
      return Auth.token().then(function (tok) {
        var pick = ctx.libId ? Promise.resolve(null) :
          Api.myMemberships(tok, Auth.current().user.id).then(function (rows) {
            if (!rows || !rows.length) throw new Api.ApiError('Is account ko kisi library se nahi jodaa gaya hai.', 403);
            ctx.libId = rows[0].library_id; ctx.role = rows[0].role;
            ctx.libName = (rows[0].libraries && rows[0].libraries.name) || 'My Library';
          });
        return pick.then(function () {
          $('lib-name').textContent = ctx.libName;
          $('hello').textContent = ctx.role === 'owner' ? 'Owner' : 'Staff';
          return Api.rpc(tok, 'dashboard', { p_lib: ctx.libId });
        });
      }).then(function (d) { fill(d); setLoading(false); })
        .catch(function (e) {
          setLoading(false);
          if (e.status === 401) { Auth.forget(); Screens.show('login'); return; }
          $('home-error').textContent = e.message; U.show($('home-error'), true);
        });
    }
  };
})();
