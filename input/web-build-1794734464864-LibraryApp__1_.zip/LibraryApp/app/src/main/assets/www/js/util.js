(function () {
  var U = {};
  U.$ = function (id) { return document.getElementById(id); };
  U.show = function (el, on) { el.classList.toggle('hidden', !on); };
  U.money = function (n) {
    if (n === null || n === undefined) return '—';
    return '₹' + Number(n).toLocaleString('en-IN');
  };
  U.num = function (n) { return (n === null || n === undefined) ? '–' : String(n); };
  var t;
  U.toast = function (msg) {
    var el = U.$('toast'); el.textContent = msg; el.classList.add('show');
    clearTimeout(t); t = setTimeout(function () { el.classList.remove('show'); }, 2600);
  };
  U.configured = function () {
    var c = window.APP_CONFIG || {};
    return /^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(c.SUPABASE_URL || '') && (c.SUPABASE_ANON_KEY || '').length > 40;
  };
  window.U = U;
})();
