LIBRARY MANAGER - Android project (Java + WebView)
==================================================

APK KAISE BANAYEIN (Android Studio)
1. Config already bhara hua hai (js/config.js). Badalna ho to app/src/main/assets/www/js/config.js
   - SUPABASE_URL      = Supabase > Project Settings > API > "Project URL"
   - SUPABASE_ANON_KEY = wahi page, "anon public" key
   *** service_role key KABHI mat daalna. ***
2. Android Studio > File > Open > yeh LibraryApp folder chunein.
3. Pehli baar Gradle sync me kuch minute lagenge (internet chahiye).
   Android Studio khud SDK/JDK ke liye poochega - "OK/Install" dabayein.
   (JDK 17 ya naya chahiye; Android Studio ke saath aata hai.)
4. Build > Build Bundle(s) / APK(s) > Build APK(s)
   APK milega: app/build/outputs/apk/debug/app-debug.apk
   Command line se:  ./gradlew assembleDebug   (Windows: gradlew.bat assembleDebug)
5. APK ko phone me daal kar install karein (Unknown sources allow karna padega).

Login: Supabase me jo owner email/password banaya hai, wahi use hoga.

APP KE SCREENS (v1.1)
  Owner / Staff (bottom tabs):
    Home      dashboard, quick actions, expiry chips (tap -> filtered student list), paise/bakaya
    Students  search (naam/phone/seat/father), expiry filters, shift filter, bakaya filter,
              date-range (future date bhi), student detail, + naya student
    Seats     seat map (khali/partial/bhari/band) + shift-wise vacancy, seat par tap -> kaun baitha hai
    Bakaya    pending dues list, search, "is date tak" (future date) ka bakaya
    Aur       collection report, library info, seats ki sankhya (owner), permissions, logout
  Student detail se: Call, Payment add/cancel, Renew, Edit, Expiry/fee badalna, Remove
    (sirf wahi buttons dikhte hain jinki us user ko permission hai)
  Student role (jiska students.user_id login se juda ho): Home (membership, seat, shift, bakaya),
    Payments history, Profile + library ki jaankari.
  NOTE: student ka login abhi database me apne aap nahi banta; students.user_id me us student ka
  Supabase user jodna padega (agle step me iska function bana sakte hain).

ARCHITECTURE
  app/src/main/java/in/librarymanagement/app/
    MainActivity.java        WebView, WebViewAssetLoader, back button, external links browser me
    bridge/NativeBridge.java sirf 3 kaam: saveSession / getSession / clearSession
    security/SecureStore.java login session Android Keystore (AES-GCM) se encrypted
  app/src/main/assets/www/
    index.html               login + dashboard screens, CSP (sirf *.supabase.co se baat)
    css/app.css              styling (light + dark)
    js/config.js             Supabase URL + anon key (aap edit karte hain)
    js/util.js store.js      helpers, session storage wrapper
    js/api.js                Supabase REST: login, refresh, RPC
    js/auth.js               login/restore/auto-refresh/logout
    js/core.js nav.js        role/permissions, navigation (tabs, pages, bottom sheets)
    js/forms.js              register / payment / renew / edit / remove forms
    js/v_*.js                screens: home, students, seats+dues, student role
    js/app.js                events + start

SECURITY RULES (roadmap ke hisaab se)
  - Sirf anon key app me; secrets/service_role nahi.
  - Asli suraksha Supabase RLS + functions me hai (jo aapne already test ki hai).
  - WebView: file access band, sirf apni assets domain, bahar ke links browser me.

AGLE STEPS: student form (register_student), search, seat map, bakaya list, payment entry.
