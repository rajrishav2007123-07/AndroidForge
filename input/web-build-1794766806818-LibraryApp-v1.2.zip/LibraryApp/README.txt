LIBRARY MANAGER - Android project (Java + WebView)
==================================================

APK KAISE BANAYEIN (Android Studio)
1. Config already bhara hua hai (js/config.js). Badalna ho to app/src/main/assets/www/js/config.js
   - SUPABASE_URL      = Supabase > Project Settings > API > "Project URL"
   - SUPABASE_ANON_KEY = wahi page, "anon public" key
   *** service_role key KABHI mat daalna. ***
2. Android Studio > File > Open > yeh LibraryApp folder chunein.
3. Pehli baar Gradle sync me kuch minute lagenge (internet chahiye).
   Android Studio khud SDK/JDK ke liye poochega - "OK/Install" dabayein.
   (JDK 17 ya naya chahiye; Android Studio ke saath aata hai.)
4. Build > Build Bundle(s) / APK(s) > Build APK(s)
   APK milega: app/build/outputs/apk/debug/app-debug.apk
   Command line se:  ./gradlew assembleDebug   (Windows: gradlew.bat assembleDebug)
5. APK ko phone me daal kar install karein (Unknown sources allow karna padega).

Login: Supabase me jo owner email/password banaya hai, wahi use hoga.

APP KE SCREENS (v1.1)
  Owner / Staff (bottom tabs):
    Home      dashboard, quick actions, expiry chips (tap -> filtered student list), paise/bakaya
    Students  search (naam/phone/seat/father), expiry filters, shift filter, bakaya filter,
              date-range (future date bhi), student detail, + naya student
    Seats     seat map (khali/partial/bhari/band) + shift-wise vacancy, seat par tap -> kaun baitha hai
    Bakaya    pending dues list, search, "is date tak" (future date) ka bakaya
    Aur       collection report, library info, seats ki sankhya (owner), permissions, logout
  Student detail se: Call, Payment add/cancel, Renew, Edit, Expiry/fee badalna, Remove
    (sirf wahi buttons dikhte hain jinki us user ko permission hai)
  Student role (jiska students.user_id login se juda ho): Home (membership, seat, shift, bakaya),
    Payments history, Profile + library ki jaankari.
  NOTE: student ka login abhi database me apne aap nahi banta; students.user_id me us student ka
  Supabase user jodna padega (agle step me iska function bana sakte hain).

ARCHITECTURE
  app/src/main/java/in/librarymanagement/app/
    MainActivity.java        WebView, WebViewAssetLoader, back button, external links browser me
    bridge/NativeBridge.java sirf 3 kaam: saveSession / getSession / clearSession
    security/SecureStore.java login session Android Keystore (AES-GCM) se encrypted
  app/src/main/assets/www/
    index.html               login + dashboard screens, CSP (sirf *.supabase.co se baat)
    css/app.css              styling (light + dark)
    js/config.js             Supabase URL + anon key (aap edit karte hain)
    js/util.js store.js      helpers, session storage wrapper
    js/api.js                Supabase REST: login, refresh, RPC
    js/auth.js               login/restore/auto-refresh/logout
    js/core.js nav.js        role/permissions, navigation (tabs, pages, bottom sheets)
    js/forms.js              register / payment / renew / edit / remove forms
    js/v_*.js                screens: home, students, seats+dues, student role
    js/app.js                events + start

SECURITY RULES (roadmap ke hisaab se)
  - Sirf anon key app me; secrets/service_role nahi.
  - Asli suraksha Supabase RLS + functions me hai (jo aapne already test ki hai).
  - WebView: file access band, sirf apni assets domain, bahar ke links browser me.

AGLE STEPS: student form (register_student), search, seat map, bakaya list, payment entry.


v1.2 CHANGES
  - WhatsApp icon (call icon ke left): Students list aur Dues list me tap karte hi WhatsApp khulta hai
    default message ke saath (dues ho to fees reminder, expiry paas ho to renewal reminder, warna namaste).
    Student detail page me "WhatsApp" button: Fees reminder / Renewal reminder / Seedha message chun sakte hain.
    Message ka text badalna ho: app/src/main/assets/www/js/util.js  ->  U.msg
  - Naam badle: Bakaya -> Dues, Jama -> Received, Kul bakaya -> Total dues.
  - Themes: System, Light, Dark, AMOLED Black, Midnight Blue, Violet Night, Ocean, Forest, Sunset, Rose, Sepia.
    Home ke upar 🎨 button ya Aur > Theme se badlein. Choice phone me save rehti hai.
  - Collection report me "Fees due" card (report ki end date tak ke dues + students ki ginti).


NAYA IN v1.2
  1. WhatsApp button (call icon ke left me): Students list, Dues list aur Student detail me.
     Tap karte hi WhatsApp khulta hai number + ready message ke saath.
       - Dues list: fees reminder (dues amount ke saath)
       - Students list: dues ho to fees reminder, 7 din me expiry ho to renewal reminder
       - Student detail: WhatsApp button -> Fees reminder / Renewal reminder / Seedha message chunein
     Message ka wording badalna ho to js/util.js me U.msg ke andar edit karein.
  2. Labels: Bakaya -> Dues, Jama -> Received, Kul bakaya -> Total dues.
  3. Themes: System (auto), Light, Dark, AMOLED Black, Midnight, Violet, Ocean, Forest, Sunset, Rose, Sepia.
     Home ke upar 🎨 button ya Aur tab -> Theme. Choice yaad rehti hai; status bar bhi theme ke rang ka ho jata hai.
  4. Collection report me "Fees due" card (report ki end date tak ke dues). Tap karne par Dues tab khulta hai.
