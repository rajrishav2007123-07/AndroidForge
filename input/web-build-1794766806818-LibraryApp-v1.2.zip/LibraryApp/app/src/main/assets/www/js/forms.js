// Forms: register student, add payment, renew, edit student, edit membership, remove, cancel payment
(function () {
  var $ = U.$, esc = U.esc;
  var MODES = [['cash', 'Cash'], ['upi', 'UPI'], ['other', 'Other']];

  function errTo(id, msg) { $(id).innerHTML = msg ? U.errBox(msg) : ''; }
  function guard(btn, fn) { // prevents double tap on submit
    btn.addEventListener('click', function () {
      if (btn.disabled) return;
      btn.disabled = true; var t = btn.textContent; btn.textContent = 'Ruko…';
      fn(function () { btn.disabled = false; btn.textContent = t; });
    });
  }
  function num(id) { var s = U.val(id); return s === '' ? NaN : Number(s); }

  // ---------------- Register ----------------
  function register(v) {
    var c = v.el, t = U.today();
    var selSlots = {}, feeTouched = false;
    c.innerHTML = '<div class="card">' + U.field('Naam', 'n-name', 'text', { req: 1, maxlength: 120, autocomplete: 'off' }) +
      U.field('Father ka naam', 'n-father', 'text', { maxlength: 120 }) +
      U.field('Phone (10 digit)', 'n-phone', 'tel', { req: 1, inputmode: 'numeric', maxlength: 15 }) +
      U.field('Email (optional)', 'n-email', 'email', { inputmode: 'email' }) +
      U.field('Address', 'n-addr', 'textarea', { maxlength: 500 }) + '</div>' +
      '<h3 class="sec">Shift aur seat</h3><div class="card"><div class="muted small">Shift chunein (ek se zyada bhi ho sakte hain)</div>' +
      '<div class="chips wrap" id="n-slots">' + U.skeleton(1) + '</div>' +
      '<div class="seatrow">' + U.field('Seat no.', 'n-seat', 'number', { inputmode: 'numeric', min: 1, max: 150, placeholder: 'optional' }) +
      '<button class="ghost-btn" data-act="free">Khali seats dekhein</button></div></div>' +
      '<h3 class="sec">Tareekh aur fee</h3><div class="card"><div class="two">' + U.field('Shuru', 'n-start', 'date', { value: t }) +
      U.field('Expiry', 'n-end', 'date', { value: U.addMonths(t, 1) }) + '</div>' +
      '<div class="presets"><button class="pill" data-act="m" data-v="1">1 mahina</button><button class="pill" data-act="m" data-v="3">3 mahine</button>' +
      '<button class="pill" data-act="m" data-v="6">6 mahine</button><button class="pill" data-act="m" data-v="12">1 saal</button></div>' +
      '<div class="two">' + U.field('Kul fee (₹)', 'n-fee', 'number', { req: 1, inputmode: 'decimal', min: 0 }) +
      U.field('Abhi received (₹)', 'n-paid', 'number', { inputmode: 'decimal', min: 0, value: '0' }) + '</div>' +
      '<div class="balline" id="n-bal"></div>' +
      '<div class="two">' + U.field('Mode', 'n-mode', 'select', { options: MODES, value: 'cash' }) + U.field('Reference/UPI id', 'n-ref', 'text', { maxlength: 60 }) + '</div>' +
      U.field('Notes', 'n-notes', 'textarea', { maxlength: 1000 }) + '</div>' +
      '<div id="n-err"></div><button class="primary" id="n-go">Student register karein</button>';

    function bal() {
      var f = num('n-fee'), p = num('n-paid');
      $('n-bal').innerHTML = !isNaN(f) ? 'Dues: <b class="' + ((f - (p || 0)) > 0 ? 'neg' : 'pos') + '">' + U.money(f - (p || 0)) + '</b>' : '';
    }
    ['n-fee', 'n-paid'].forEach(function (i) { $(i).addEventListener('input', bal); });
    $('n-fee').addEventListener('input', function () { feeTouched = true; });

    App.slots().then(function (sl) {
      sl = sl.filter(function (s) { return s.is_active; });
      $('n-slots').innerHTML = sl.length ? sl.map(function (s) {
        return '<button class="pill" data-act="slot" data-id="' + esc(s.id) + '">' + esc(App.slotLabel(s)) + '</button>'; }).join('')
        : '<span class="muted small">Pehle owner shift banaye.</span>';
      v.slotList = sl;
    }, function (e) { $('n-slots').innerHTML = U.errBox(e.message); });

    v.on('slot', function (el) {
      var id = el.getAttribute('data-id');
      if (selSlots[id]) delete selSlots[id]; else selSlots[id] = 1;
      el.classList.toggle('on', !!selSlots[id]);
      if (!feeTouched) {
        var sum = 0, any = false;
        (v.slotList || []).forEach(function (s) { if (selSlots[s.id] && s.default_price !== null && s.default_price !== undefined) { sum += Number(s.default_price); any = true; } });
        if (any) { $('n-fee').value = sum; bal(); }
      }
    });
    v.on('m', function (el) { $('n-end').value = U.addMonths($('n-start').value || t, parseInt(el.getAttribute('data-v'), 10)); });
    v.on('free', function () {
      var ids = Object.keys(selSlots);
      if (!ids.length) { U.toast('Pehle shift chunein'); return; }
      Nav.sheet('<h3>Khali seats</h3>' + U.skeleton(1));
      Promise.all(ids.map(function (i) { return Api.rpc('vacant_seats', { p_lib: App.libId, p_slot_id: i }); })).then(function (lists) {
        var common = null;
        lists.forEach(function (l) {
          var m = {}; (l || []).forEach(function (r) { m[r.seat_no] = r; });
          if (common === null) common = m; else Object.keys(common).forEach(function (k) { if (!m[k]) delete common[k]; });
        });
        var nos = Object.keys(common || {}).map(Number).sort(function (a, b) { return a - b; });
        Nav.sheet('<h3>Khali seats (' + nos.length + ')</h3><p class="muted small">Chuni hui sabhi shifts me khali. Seat par tap karein.</p>' +
          (nos.length ? '<div class="seatgrid">' + nos.map(function (n) { return '<button class="seat free" data-n="' + n + '">' + n + '</button>'; }).join('') + '</div>' : U.empty('🪑', 'In shifts me koi seat common khali nahi.')));
        Array.prototype.forEach.call(document.querySelectorAll('#sheet-root .seat'), function (b) {
          b.addEventListener('click', function () { $('n-seat').value = b.getAttribute('data-n'); Nav.sheetClose(); });
        });
      }, function (e) { Nav.sheet('<h3>Error</h3>' + U.errBox(e.message)); });
    });

    guard($('n-go'), function (done) {
      var name = U.val('n-name'), phone = U.digits(U.val('n-phone')), fee = num('n-fee'), paid = num('n-paid');
      var start = U.val('n-start'), end = U.val('n-end'), seat = U.val('n-seat'), slots = Object.keys(selSlots);
      var m = null;
      if (name.length < 2) m = 'Naam likhein.';
      else if (!/^[0-9]{10,15}$/.test(phone)) m = 'Phone 10 se 15 digit ka hona chahiye.';
      else if (isNaN(fee) || fee < 0) m = 'Kul fee likhein.';
      else if (isNaN(paid) ? false : paid < 0) m = 'Received amount galat hai.';
      else if (!isNaN(paid) && paid > fee) m = 'Received amount fee se zyada nahi ho sakta.';
      else if (!start || !end || end < start) m = 'Expiry, shuru tareekh ke baad ki honi chahiye.';
      else if (seat && !slots.length) m = 'Seat ke saath shift bhi chunein.';
      if (m) { errTo('n-err', m); done(); return; }
      errTo('n-err', '');
      Api.rpc('register_student', {
        p_lib: App.libId, p_name: name, p_phone: phone, p_fee: fee, p_start: start, p_end: end,
        p_father: U.val('n-father') || null, p_address: U.val('n-addr') || null, p_email: U.val('n-email') || null,
        p_seat_no: seat ? parseInt(seat, 10) : null, p_slot_ids: slots.length ? slots : null,
        p_paid: isNaN(paid) ? 0 : paid, p_mode: U.val('n-mode'), p_reference: U.val('n-ref') || null, p_notes: U.val('n-notes') || null
      }).then(function (r) {
        U.toast('Student register ho gaya');
        Nav.back();
        if (r && r.student_id) Nav.push('Student', window.Views.Detail, { id: r.student_id });
      }, function (e) { done(); errTo('n-err', e.message); });
    });
  }

  // ---------------- Payment sheet ----------------
  function payment(v, m, b) {
    var due = b ? Number(b.balance) : null;
    Nav.sheet('<h3>Payment add karein</h3>' + (due !== null ? '<p class="muted small">Abhi dues: <b class="' + (due > 0 ? 'neg' : 'pos') + '">' + U.money(due) + '</b></p>' : '') +
      '<div class="two">' + U.field('Amount (₹)', 'p-amt', 'number', { req: 1, inputmode: 'decimal', min: 1, value: due > 0 ? due : '' }) +
      U.field('Mode', 'p-mode', 'select', { options: MODES, value: 'cash' }) + '</div>' +
      '<div class="two">' + U.field('Tareekh', 'p-date', 'date', { value: U.today() }) + U.field('Reference', 'p-ref', 'text', { maxlength: 60 }) + '</div>' +
      U.field('Note', 'p-note', 'text', { maxlength: 300 }) + '<div id="p-err"></div><button class="primary" id="p-go">Payment save karein</button>');
    guard($('p-go'), function (done) {
      var a = num('p-amt');
      if (isNaN(a) || a <= 0) { errTo('p-err', 'Amount 0 se zyada likhein.'); done(); return; }
      if (due !== null && a > due) { errTo('p-err', 'Amount dues (' + U.money(due) + ') se zyada hai.'); done(); return; }
      Api.rpc('add_payment', { p_lib: App.libId, p_membership_id: m.id, p_amount: a, p_mode: U.val('p-mode'),
        p_reference: U.val('p-ref') || null, p_received_on: U.val('p-date') || null, p_note: U.val('p-note') || null })
        .then(function () { Nav.sheetClose(); U.toast('Payment add ho gayi'); v.reload(); }, function (e) { done(); errTo('p-err', e.message); });
    });
  }

  function cancelPayment(v, id) {
    Nav.sheet('<h3>Payment cancel karein</h3><p class="muted small">Cancel ke baad dues dobara badh jayega. Kaaran zaroori hai.</p>' +
      U.field('Kaaran', 'c-why', 'text', { req: 1, maxlength: 300 }) + '<div id="c-err"></div><button class="primary danger" id="c-go">Cancel karein</button>');
    guard($('c-go'), function (done) {
      var why = U.val('c-why');
      if (why.length < 3) { errTo('c-err', 'Kaaran kam se kam 3 akshar ka likhein.'); done(); return; }
      Api.rpc('cancel_payment', { p_lib: App.libId, p_payment_id: id, p_reason: why })
        .then(function () { Nav.sheetClose(); U.toast('Payment cancel ho gayi'); v.reload(); }, function (e) { done(); errTo('c-err', e.message); });
    });
  }

  // ---------------- Renew ----------------
  function renew(v, a) {
    var s = a.student, cur = a.cur, c = v.el, t = U.today();
    var base = cur && cur.end_date >= t ? U.addDays(cur.end_date, 1) : t;
    c.innerHTML = '<div class="card"><b>' + esc(s.name) + '</b><div class="muted small">' +
      (cur ? 'Abhi expiry: ' + U.date(cur.end_date) + ' • seat aur shift wahi rahenge' : '') + '</div>' +
      '<p class="muted small">Expiry se pehle renew karne par purani seat/shift purani expiry tak chalu rehti hain.</p>' +
      '<div class="two">' + U.field('Naya shuru', 'r-start', 'date', { value: base }) + U.field('Naya expiry', 'r-end', 'date', { value: U.addMonths(base, 1) }) + '</div>' +
      '<div class="presets"><button class="pill" data-act="m" data-v="1">1 mahina</button><button class="pill" data-act="m" data-v="3">3 mahine</button>' +
      '<button class="pill" data-act="m" data-v="6">6 mahine</button></div>' +
      '<div class="two">' + U.field('Fee (₹)', 'r-fee', 'number', { req: 1, inputmode: 'decimal', min: 0, value: cur ? cur.fee_amount : '' }) +
      U.field('Abhi received (₹)', 'r-paid', 'number', { inputmode: 'decimal', min: 0, value: '0' }) + '</div>' +
      '<div class="two">' + U.field('Mode', 'r-mode', 'select', { options: MODES, value: 'cash' }) + U.field('Reference', 'r-ref', 'text', { maxlength: 60 }) + '</div>' +
      U.field('Notes', 'r-notes', 'text', { maxlength: 1000 }) + '</div><div id="r-err"></div><button class="primary" id="r-go">Renew karein</button>';
    v.on('m', function (el) { $('r-end').value = U.addMonths($('r-start').value || base, parseInt(el.getAttribute('data-v'), 10)); });
    guard($('r-go'), function (done) {
      var fee = num('r-fee'), paid = num('r-paid'), st = U.val('r-start'), en = U.val('r-end'), m = null;
      if (isNaN(fee) || fee < 0) m = 'Fee likhein.';
      else if (!isNaN(paid) && paid > fee) m = 'Received amount fee se zyada nahi ho sakta.';
      else if (!en || (st && en < st)) m = 'Expiry shuru se baad ki honi chahiye.';
      if (m) { errTo('r-err', m); done(); return; }
      Api.rpc('renew_membership', { p_lib: App.libId, p_student_id: s.id, p_end: en, p_fee: fee, p_start: st || null,
        p_paid: isNaN(paid) ? 0 : paid, p_mode: U.val('r-mode'), p_reference: U.val('r-ref') || null, p_notes: U.val('r-notes') || null })
        .then(function () { U.toast('Renew ho gaya'); Nav.back(); }, function (e) { done(); errTo('r-err', e.message); });
    });
  }

  // ---------------- Edit student / membership / remove ----------------
  function editStudent(v, s) {
    Nav.sheet('<h3>Student edit karein</h3>' + U.field('Naam', 'e-name', 'text', { value: s.name, maxlength: 120 }) +
      U.field('Father', 'e-father', 'text', { value: s.father_name || '', maxlength: 120 }) +
      U.field('Phone', 'e-phone', 'tel', { value: s.phone, inputmode: 'numeric', maxlength: 15 }) +
      U.field('Email', 'e-email', 'email', { value: s.email || '' }) + U.field('Address', 'e-addr', 'textarea', { value: s.address || '', maxlength: 500 }) +
      U.field('Notes', 'e-notes', 'textarea', { value: s.notes || '', maxlength: 1000 }) + '<div id="e-err"></div><button class="primary" id="e-go">Save</button>');
    guard($('e-go'), function (done) {
      var ch = {}, name = U.val('e-name'), phone = U.digits(U.val('e-phone'));
      if (name.length < 2) { errTo('e-err', 'Naam likhein.'); done(); return; }
      if (!/^[0-9]{10,15}$/.test(phone)) { errTo('e-err', 'Phone 10 se 15 digit ka hona chahiye.'); done(); return; }
      var map = { name: name, father_name: U.val('e-father'), phone: phone, email: U.val('e-email'), address: U.val('e-addr'), notes: U.val('e-notes') };
      Object.keys(map).forEach(function (k) { if (String(map[k]) !== String(s[k] || '')) ch[k] = map[k] === '' ? null : map[k]; });
      if (!Object.keys(ch).length) { Nav.sheetClose(); return; }
      Api.rpc('edit_student', { p_lib: App.libId, p_student_id: s.id, p_changes: ch })
        .then(function () { Nav.sheetClose(); U.toast('Save ho gaya'); v.reload(); }, function (e) { done(); errTo('e-err', e.message); });
    });
  }

  function editMembership(v, m) {
    Nav.sheet('<h3>Expiry / fee badlein</h3><p class="muted small">Ye badlav history me save hota hai.</p><div class="two">' +
      U.field('Shuru', 'm-start', 'date', { value: m.start_date }) + U.field('Expiry', 'm-end', 'date', { value: m.end_date }) + '</div>' +
      U.field('Fee (₹)', 'm-fee', 'number', { value: m.fee_amount, inputmode: 'decimal', min: 0 }) + '<div id="m-err"></div><button class="primary" id="m-go">Save</button>');
    guard($('m-go'), function (done) {
      var a = { p_lib: App.libId, p_membership_id: m.id }, st = U.val('m-start'), en = U.val('m-end'), fee = num('m-fee');
      if (!st || !en || en < st) { errTo('m-err', 'Expiry, shuru se baad ki honi chahiye.'); done(); return; }
      if (isNaN(fee) || fee < 0) { errTo('m-err', 'Fee sahi likhein.'); done(); return; }
      if (st !== m.start_date) a.p_start = st;
      if (en !== m.end_date) a.p_end = en;
      if (fee !== Number(m.fee_amount)) a.p_fee = fee;
      if (Object.keys(a).length === 2) { Nav.sheetClose(); return; }
      Api.rpc('edit_membership', a).then(function () { Nav.sheetClose(); U.toast('Save ho gaya'); v.reload(); }, function (e) { done(); errTo('m-err', e.message); });
    });
  }

  function remove(v, s) {
    Nav.sheet('<h3>' + esc(s.name) + ' ko remove karein?</h3><p class="muted small">Seat turant khali ho jayegi. Student ka record aur history bachi rahegi.</p>' +
      U.field('Kaaran (optional)', 'x-why', 'text', { maxlength: 300 }) + '<div id="x-err"></div><button class="primary danger" id="x-go">Haan, remove karein</button>');
    guard($('x-go'), function (done) {
      Api.rpc('remove_student', { p_lib: App.libId, p_student_id: s.id, p_reason: U.val('x-why') || null })
        .then(function () { Nav.sheetClose(); U.toast('Student remove ho gaya'); v.reload(); }, function (e) { done(); errTo('x-err', e.message); });
    });
  }

  window.Forms = { register: register, payment: payment, cancelPayment: cancelPayment, renew: renew, editStudent: editStudent, editMembership: editMembership, remove: remove };
})();
