// Theme manager: applies the saved theme before first paint, picker sheet, status-bar sync.
// Choice is saved natively (NativeApp.savePref) because WebView DOM storage is disabled.
(function () {
  var THEMES = [{"id": "system", "name": "System (auto)", "hint": "Phone ke Light/Dark ke hisaab se", "dark": false, "bg": "#F5F6FB"}, {"id": "light", "name": "Light", "hint": "Clean & bright", "dark": false, "bg": "#F5F6FB"}, {"id": "dark", "name": "Dark", "hint": "Easy on the eyes", "dark": true, "bg": "#0F1220"}, {"id": "amoled", "name": "AMOLED Black", "hint": "True black, saves battery", "dark": true, "bg": "#000000"}, {"id": "midnight", "name": "Midnight Blue", "hint": "Deep navy", "dark": true, "bg": "#0A1322"}, {"id": "violet", "name": "Violet Night", "hint": "Purple & pink glow", "dark": true, "bg": "#140F24"}, {"id": "ocean", "name": "Ocean", "hint": "Fresh blue & teal", "dark": false, "bg": "#EDF6FB"}, {"id": "forest", "name": "Forest", "hint": "Calm green", "dark": false, "bg": "#EFF6F1"}, {"id": "sunset", "name": "Sunset", "hint": "Warm orange & pink", "dark": false, "bg": "#FFF5EC"}, {"id": "rose", "name": "Rose", "hint": "Soft pink & berry", "dark": false, "bg": "#FFF0F4"}, {"id": "sepia", "name": "Sepia", "hint": "Warm paper, reading mode", "dark": false, "bg": "#F3EAD3"}];
  var KEY = 'theme', mem = '', current = 'system';
  var native = typeof window.NativeApp !== 'undefined' && window.NativeApp.getPref;
  var mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;

  function find(id) { for (var i = 0; i < THEMES.length; i++) if (THEMES[i].id === id) return THEMES[i]; return null; }
  function stored() {
    try { return (native ? window.NativeApp.getPref(KEY) : mem) || ''; } catch (e) { return ''; }
  }
  function resolve(id) {
    if (id === 'system') return find(mq && mq.matches ? 'dark' : 'light');
    return find(id) || find('light');
  }
  function apply(id) {
    current = find(id) ? id : 'system';
    var t = resolve(current), root = document.documentElement;
    root.setAttribute('data-theme', t.id);
    if (t.dark) root.setAttribute('data-dark', '1'); else root.removeAttribute('data-dark');
    try { if (window.NativeApp && window.NativeApp.setBars) window.NativeApp.setBars(t.bg, !!t.dark); } catch (e) {}
  }
  function save(id) {
    try { if (native) window.NativeApp.savePref(KEY, id); else mem = id; } catch (e) {}
  }

  window.Theme = {
    list: THEMES,
    get: function () { return current; },
    label: function () { var t = find(current); return t ? t.name : 'System (auto)'; },
    set: function (id) { apply(id); save(id); },
    open: function (onChange) {
      var h = '<h3>Theme chunein</h3><p class="muted small">Tap karte hi theme badal jayegi aur yaad rahegi.</p><div class="thmgrid">' +
        THEMES.map(function (t) {
          return '<button class="thm' + (t.id === current ? ' on' : '') + '" data-t="' + t.id + '"><span class="tick">✓</span>' +
            '<div class="sw"><u></u><s></s><i></i></div><b>' + t.name + '</b><small>' + t.hint + '</small></button>';
        }).join('') + '</div>';
      Nav.sheet(h, function (sh) {
        sh.addEventListener('click', function (e) {
          var b = e.target.closest('.thm'); if (!b) return;
          Theme.set(b.getAttribute('data-t'));
          Array.prototype.forEach.call(sh.querySelectorAll('.thm'), function (x) { x.classList.toggle('on', x === b); });
          if (onChange) onChange();
        });
      });
    }
  };

  apply(stored() || 'system');
  if (mq && mq.addEventListener) mq.addEventListener('change', function () { if (current === 'system') apply('system'); });
})();
