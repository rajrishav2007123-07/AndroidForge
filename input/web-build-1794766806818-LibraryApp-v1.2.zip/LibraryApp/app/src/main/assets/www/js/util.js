(function () {
  var U = {};
  // If a screen was already closed when an async reply arrives, writes go to a throwaway element instead of crashing.
  U.$ = function (id) { return document.getElementById(id) || document.createElement('input'); };
  U.show = function (el, on) { el.classList.toggle('hidden', !on); };
  U.esc = function (s) {
    return String(s === null || s === undefined ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  U.money = function (n) {
    if (n === null || n === undefined || n === '') return '—';
    return '₹' + Number(n).toLocaleString('en-IN');
  };
  U.num = function (n) { return (n === null || n === undefined) ? '–' : String(n); };
  var MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  U.date = function (iso) {
    if (!iso) return '—';
    var p = String(iso).slice(0, 10).split('-');
    return parseInt(p[2], 10) + ' ' + MON[parseInt(p[1], 10) - 1] + ' ' + p[0];
  };
  // Today in India (IST) as YYYY-MM-DD, independent of phone timezone.
  U.today = function () { return new Date(Date.now() + 330 * 60000).toISOString().slice(0, 10); };
  U.addDays = function (iso, n) {
    var d = new Date(iso + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10);
  };
  // +n months, expiry = day before same date (1 Jan + 1 month -> 31 Jan)
  U.addMonths = function (iso, n) {
    var p = iso.split('-').map(Number), y = p[0], m = p[1] - 1 + n, d = p[2];
    var last = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
    var dt = new Date(Date.UTC(y, m, Math.min(d, last)));
    dt.setUTCDate(dt.getUTCDate() - 1);
    return dt.toISOString().slice(0, 10);
  };
  U.monthStart = function (iso) { return iso.slice(0, 8) + '01'; };
  U.digits = function (s) { return String(s || '').replace(/\D/g, '').replace(/^91(?=\d{10}$)/, ''); };
  U.debounce = function (fn, ms) {
    var t; return function () { var a = arguments, c = this; clearTimeout(t); t = setTimeout(function () { fn.apply(c, a); }, ms); };
  };
  var tt;
  U.toast = function (msg) {
    var el = U.$('toast'); el.textContent = msg; el.classList.add('show');
    clearTimeout(tt); tt = setTimeout(function () { el.classList.remove('show'); }, 2800);
  };
  U.configured = function () {
    var c = window.APP_CONFIG || {};
    return /^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(c.SUPABASE_URL || '') && (c.SUPABASE_ANON_KEY || '').length > 40;
  };

  // ---- small HTML builders (everything user-supplied goes through esc) ----
  U.badge = function (state) {
    var map = { running: ['Chalu', 'ok'], held: ['Expired • seat hold', 'warn'], expired: ['Expired', 'warn'],
      lapsed: ['Lapsed', 'bad'], left: ['Left', 'bad'], active: ['Active', 'ok'] };
    var m = map[state] || [state || '—', 'mute'];
    return '<span class="badge ' + m[1] + '">' + U.esc(m[0]) + '</span>';
  };
  U.empty = function (icon, text) {
    return '<div class="empty"><div class="ei">' + icon + '</div><p>' + U.esc(text) + '</p></div>';
  };
  U.errBox = function (msg, retry) {
    return '<div class="error">' + U.esc(msg) + (retry ? ' <button class="linkbtn" data-act="retry">Dobara try</button>' : '') + '</div>';
  };
  U.skeleton = function (n) {
    var s = ''; for (var i = 0; i < (n || 4); i++) s += '<div class="sk-card"></div>'; return s;
  };
  U.field = function (label, id, type, opts) {
    opts = opts || {};
    var a = '';
    ['placeholder', 'value', 'inputmode', 'maxlength', 'min', 'max', 'step', 'autocomplete'].forEach(function (k) {
      if (opts[k] !== undefined && opts[k] !== null) a += ' ' + k + '="' + U.esc(opts[k]) + '"';
    });
    var input = type === 'textarea'
      ? '<textarea id="' + id + '" rows="2"' + a + '>' + U.esc(opts.value || '') + '</textarea>'
      : type === 'select'
        ? '<select id="' + id + '">' + opts.options.map(function (o) {
          return '<option value="' + U.esc(o[0]) + '"' + (String(o[0]) === String(opts.value) ? ' selected' : '') + '>' + U.esc(o[1]) + '</option>';
        }).join('') + '</select>'
        : '<input id="' + id + '" type="' + type + '"' + a + '>';
    return '<label class="fl" for="' + id + '">' + U.esc(label) + (opts.req ? ' <i>*</i>' : '') + '</label><div class="field">' + input + '</div>';
  };
  U.val = function (id) { var e = U.$(id) || document.getElementById(id); return e ? e.value.trim() : ''; };

  // ---- WhatsApp: icon + default messages (edit the texts below to change wording) ----
  U.WA_ICON = '<svg class="waic" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>';
  U.waNumber = function (phone) {
    var d = U.digits(phone).replace(/^0+/, '');
    return d.length === 10 ? '91' + d : d;
  };
  U.waLink = function (phone, text) {
    return 'https://wa.me/' + U.waNumber(phone) + '?text=' + encodeURIComponent(text || '');
  };
  // o = { name, lib, due, endDate, daysLeft, seat }
  U.msg = {
    fee: function (o) {
      return 'Namaste ' + o.name + ',\n' + o.lib + ' se message.\n\nAapki library fees ke ' + U.money(o.due) +
        ' dues baaki hain. Kripya jald se jald payment kar dein.\n\nDhanyawad 🙏';
    },
    renew: function (o) {
      var when = o.daysLeft === null || o.daysLeft === undefined || !o.endDate ? 'jald expire ho rahi hai'
        : (o.daysLeft < 0 ? U.date(o.endDate) + ' ko expire ho chuki hai'
          : o.daysLeft === 0 ? 'aaj (' + U.date(o.endDate) + ') expire ho rahi hai'
            : U.date(o.endDate) + ' ko expire ho rahi hai (' + o.daysLeft + ' din baaki)');
      return 'Namaste ' + o.name + ',\n' + o.lib + ' se message.\n\nAapki membership ' + when + '.' + (o.seat ? ' Seat no. ' + o.seat + '.' : '') +
        ' Seat bani rahe iske liye kripya renew karwa lein.\n\nDhanyawad 🙏';
    },
    hello: function (o) { return 'Namaste ' + o.name + ',\n' + o.lib + ' se message.'; },
    // list icon: pick the most useful default
    smart: function (o) {
      if (o.due > 0) return U.msg.fee(o);
      if (o.daysLeft !== null && o.daysLeft !== undefined && o.daysLeft <= 7 && o.endDate) return U.msg.renew(o);
      return U.msg.hello(o);
    }
  };
  U.waBtn = function (phone, text, stop) {
    return '<a class="wabtn" href="' + U.esc(U.waLink(phone, text)) + '"' + (stop ? ' data-stop="1"' : '') + ' aria-label="WhatsApp">' + U.WA_ICON + '</a>';
  };
  window.U = U;
})();
