// SEATS tab (seat map + shift vacancy) and DUES tab (dues list)
(function () {
  var $ = U.$, esc = U.esc;

  function Seats(v) {
    var c = v.el, mode = 'map', data = {};
    c.innerHTML = '<div class="topbar"><div class="lib-name">Seats</div><button class="icon-btn" data-act="refresh" aria-label="Refresh">⟳</button></div>' +
      '<div class="seg"><button class="on" data-act="seg" data-v="map">Seat map</button><button data-act="seg" data-v="shift">Shift ke hisaab se</button></div><div id="sbody">' + U.skeleton(3) + '</div>';
    v.on('refresh', function () { v.reload(); });
    v.on('seg', function (el) {
      mode = el.getAttribute('data-v');
      Array.prototype.forEach.call(c.querySelectorAll('.seg button'), function (b) { b.classList.toggle('on', b === el); });
      paint();
    });

    function legend() {
      return '<div class="legend"><span><i class="seat free"></i>Khali</span><span><i class="seat partial"></i>Kuch time khali</span><span><i class="seat full"></i>Bhari</span><span><i class="seat inactive"></i>Band</span></div>';
    }
    function paint() {
      var b = $('sbody');
      if (mode === 'map') {
        var m = data.map || [];
        if (!m.length) { b.innerHTML = U.empty('🪑', 'Abhi koi seat nahi. Owner "Aur" tab se seats ki sankhya set kare.'); return; }
        var free = m.filter(function (x) { return x.status === 'free'; }).length;
        b.innerHTML = '<div class="sumline">' + m.length + ' seats • ' + free + ' poori khali</div>' + legend() +
          '<div class="seatgrid">' + m.map(function (x) {
            return '<button class="seat ' + esc(x.status) + '" data-act="seat" data-n="' + x.seat_no + '">' + x.seat_no + '</button>'; }).join('') + '</div>';
      } else {
        var s = data.shift || [];
        b.innerHTML = s.length ? s.map(function (x) {
          return '<div class="card shiftcard" data-act="vac" data-id="' + esc(x.slot_id) + '" data-name="' + esc(x.shift) + '"><div class="sc-top"><b>' + esc(x.shift) + '</b><span class="small muted">' +
            App.hhmm(x.start_time) + ' – ' + App.hhmm(x.end_time) + '</span></div><div class="trio"><div><b class="pos">' + x.vacant_seats +
            '</b><small>khali</small></div><div><b class="warnc">' + x.partial_seats + '</b><small>kuch khali</small></div><div><b class="neg">' + x.taken_seats +
            '</b><small>bhari</small></div></div><div class="small muted">Kul ' + x.total_seats + ' seats • list dekhne ke liye tap karein</div></div>'; }).join('')
          : U.empty('⏱', 'Koi shift nahi bani.');
      }
    }
    v.on('seat', function (el) {
      var n = parseInt(el.getAttribute('data-n'), 10), s = (data.map || []).filter(function (x) { return x.seat_no === n; })[0];
      if (!s) return;
      var occ = s.occupants || [];
      Nav.sheet('<h3>Seat ' + n + ' • ' + ({ free: 'Khali', full: 'Bhari', partial: 'Kuch khali', inactive: 'Band' }[s.status] || esc(s.status)) + '</h3>' +
        (s.free_time ? '<p class="muted small">Khali time: <b>' + esc(s.free_time) + '</b></p>' : '') +
        (occ.length ? occ.map(function (o) {
          return '<div class="scard" data-open="' + esc(o.student_id) + '"><div class="sc-main"><div class="sc-top"><b>' + esc(o.name) + '</b>' + U.badge(o.state) + '</div>' +
            '<div class="muted small">' + esc(o.shift) + ' • ' + esc(o.from) + '–' + esc(o.to) + '</div><div class="muted small">Expiry: ' + U.date(o.end_date) + ' • ' + esc(o.phone) + '</div></div></div>'; }).join('')
          : '<p class="muted">Is seat par abhi koi nahi hai.</p>'));
      Array.prototype.forEach.call(document.querySelectorAll('#sheet-root [data-open]'), function (e) {
        e.addEventListener('click', function () { Nav.push('Student', window.Views.Detail, { id: e.getAttribute('data-open') }); });
      });
    });
    v.on('vac', function (el) {
      var id = el.getAttribute('data-id'), nm = el.getAttribute('data-name');
      Nav.sheet('<h3>' + esc(nm) + ' — khali seats</h3>' + U.skeleton(1));
      Api.rpc('vacant_seats', { p_lib: App.libId, p_slot_id: id }).then(function (rows) {
        rows = rows || [];
        Nav.sheet('<h3>' + esc(nm) + ' — khali seats (' + rows.length + ')</h3>' + (rows.length ? rows.map(function (r) {
          return '<div class="row"><span>Seat <b>' + r.seat_no + '</b></span><span class="muted small">' + esc(r.free_time || '') + (r.occupied_by ? ' • ' + esc(r.occupied_by) : '') + '</span></div>'; }).join('')
          : U.empty('🪑', 'Is shift me koi seat khali nahi.')));
      }, function (e) { Nav.sheet('<h3>Error</h3>' + U.errBox(e.message)); });
    });

    Promise.all([Api.rpc('seat_map', { p_lib: App.libId }), Api.rpc('vacancy_summary', { p_lib: App.libId })]).then(function (r) {
      data.map = r[0] || []; data.shift = r[1] || []; paint();
    }, function (e) { $('sbody').innerHTML = U.errBox(e.message, true); });
  }

  // ---------------- DUES ----------------
  function Dues(v) {
    var c = v.el, st = { q: '', status: 'all', asOn: '', offset: 0, rows: [], total: 0, grand: null, busy: false };
    c.innerHTML = '<div class="topbar"><div class="lib-name">Dues</div></div>' +
      '<div class="searchbar"><span>⌕</span><input id="d-q" type="search" placeholder="Naam ya phone se dhundhein" autocomplete="off"></div>' +
      '<div class="filters"><select id="d-status"><option value="all">Sab</option><option value="active">Active</option><option value="left">Left</option></select>' +
      '<div class="field grow"><input id="d-date" type="date" aria-label="Is tareekh tak ke dues"></div><button class="pill" data-act="today">Aaj</button></div>' +
      '<div class="muted small tip">Tareekh chunein to us din tak ke dues dikhega (future bhi).</div>' +
      '<div id="d-sum"></div><div id="d-list"></div><div id="d-more"></div>';

    function load(reset) {
      if (reset) { st.offset = 0; st.rows = []; $('d-list').innerHTML = U.skeleton(4); $('d-more').innerHTML = ''; }
      st.busy = true;
      Api.rpc('pending_dues', { p_lib: App.libId, p_as_on: st.asOn || null, p_q: st.q || null, p_status: st.status, p_limit: 30, p_offset: st.offset }).then(function (rows) {
        st.busy = false; rows = rows || [];
        if (rows.length) { st.total = rows[0].total_count; st.grand = rows[0].grand_total_balance; } else if (reset) { st.total = 0; st.grand = 0; }
        st.rows = st.rows.concat(rows); st.offset = st.rows.length; paint();
      }, function (e) { st.busy = false; $('d-list').innerHTML = U.errBox(e.message, true); });
    }
    function paint() {
      $('d-sum').innerHTML = '<section class="stat due"><div class="k">Total dues' + (st.asOn ? ' (' + U.date(st.asOn) + ' tak)' : '') + '</div><div class="v">' +
        U.money(st.grand) + '</div><div class="sub">' + U.num(st.total) + ' students</div></section>';
      $('d-list').innerHTML = st.rows.length ? st.rows.map(function (r) {
        return '<div class="scard" data-act="open" data-id="' + esc(r.student_id) + '"><div class="avatar sm">' + esc((r.name || '?').charAt(0).toUpperCase()) + '</div>' +
          '<div class="sc-main"><div class="sc-top"><b>' + esc(r.name) + '</b><span class="due-tag">' + U.money(r.balance) + '</span></div>' +
          '<div class="muted small">' + esc(r.phone) + (r.seat_no ? ' • Seat ' + r.seat_no : '') + '</div>' +
          '<div class="sc-foot"><span class="small muted">Fee ' + U.money(r.total_fee) + ' • Received ' + U.money(r.total_paid) + '</span></div>' +
          (r.oldest_due_from ? '<div class="small muted">Oldest dues: ' + U.date(r.oldest_due_from) + '</div>' : '') + '</div>' +
          '<div class="actbtns">' + U.waBtn(r.phone, U.msg.fee({ name: r.name, lib: App.libName, due: Number(r.balance) }), true) +
          '<a class="callbtn" href="tel:' + esc(r.phone) + '" aria-label="Call">☎</a></div></div>'; }).join('')
        : U.empty('🎉', 'Koi dues nahi!');
      $('d-more').innerHTML = st.rows.length < st.total ? '<button class="ghost-btn" data-act="more">Aur dikhayein (' + (st.total - st.rows.length) + ')</button>' : '';
    }
    $('d-q').addEventListener('input', U.debounce(function () { st.q = $('d-q').value.trim(); load(true); }, 350));
    $('d-status').addEventListener('change', function () { st.status = this.value; load(true); });
    $('d-date').addEventListener('change', function () { st.asOn = this.value; load(true); });
    v.on('today', function () { st.asOn = ''; $('d-date').value = ''; load(true); });
    v.on('more', function () { if (!st.busy) load(false); });
    v.on('open', function (el, ev) { if (ev.target.closest('.callbtn, .wabtn')) return; Nav.push('Student', window.Views.Detail, { id: el.getAttribute('data-id') }); });
    load(true);
  }

  window.Views = window.Views || {};
  window.Views.Seats = Seats; window.Views.Dues = Dues;
})();
