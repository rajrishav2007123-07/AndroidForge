// STUDENT role screens: My membership (home), My payments, My profile
(function () {
  var $ = U.$, esc = U.esc;

  function load() {
    var sid = 'eq.' + App.student.id;
    return Promise.all([
      Api.get('students?' + Api.q({ select: '*', id: sid })),
      Api.get('memberships?' + Api.q({ select: '*', student_id: sid, order: 'start_date.desc' })),
      Api.get('membership_balances?' + Api.q({ select: 'membership_id,fee_amount,paid_amount,balance', student_id: sid })).catch(function () { return []; }),
      Api.get('payments?' + Api.q({ select: 'id,amount,mode,reference_no,received_on,status', student_id: sid, order: 'received_on.desc', limit: 100 })).catch(function () { return []; }),
      Api.get('membership_shifts?' + Api.q({ select: 'membership_id,slot_id,is_active,seat_id', student_id: sid })).catch(function () { return []; }),
      App.slots().catch(function () { return []; }),
      App.seats().catch(function () { return []; })
    ]).then(function (r) {
      var s = (r[0] || [])[0] || App.student; App.student = s;
      return { s: s, ms: r[1] || [], bals: r[2] || [], pays: r[3] || [], shifts: r[4] || [], slots: r[5] || [], seats: r[6] || [] };
    });
  }

  function Home(v) {
    var c = v.el;
    c.innerHTML = '<div class="topbar"><div><div class="small muted">Namaste</div><div class="lib-name">' + esc(App.student.name) + '</div></div>' +
      '<button class="icon-btn" data-act="refresh" aria-label="Refresh">⟳</button></div><div id="sb">' + U.skeleton(3) + '</div>';
    v.on('refresh', function () { v.reload(); });
    load().then(function (d) {
      var cur = d.ms.filter(function (m) { return m.status === 'active'; })[0] || d.ms[0];
      if (!cur) { $('sb').innerHTML = U.empty('📭', 'Abhi aapki koi membership nahi hai. Library se sampark karein.'); return; }
      var today = U.today(), left = Math.round((new Date(cur.end_date) - new Date(today)) / 86400000);
      var slotName = {}; d.slots.forEach(function (x) { slotName[x.id] = App.slotLabel(x); });
      var seatNo = {}; d.seats.forEach(function (x) { seatNo[x.id] = x.seat_no; });
      var mine = d.shifts.filter(function (x) { return x.membership_id === cur.id && x.is_active !== false; });
      var b = d.bals.filter(function (x) { return x.membership_id === cur.id; })[0];
      var state = left >= 0 ? 'running' : (cur.hold_until >= today ? 'held' : 'lapsed');
      var tone = left < 0 ? 'bad' : left <= 7 ? 'warnc' : 'okc';
      var h = '<section class="stat accent big mem"><div class="k">Membership ' + U.badge(state) + '</div><div class="v">' +
        (left >= 0 ? left + ' din baaki' : Math.abs(left) + ' din pehle expire') + '</div><div class="sub">Expiry: ' + U.date(cur.end_date) + '</div></section>';
      if (left <= 7 && left >= 0) h += '<div class="notice">⏰ Aapki membership jaldi expire ho rahi hai. Renew ke liye library me sampark karein.</div>';
      if (left < 0) h += '<div class="notice bad">Membership expire ho chuki hai. Seat ' + U.date(cur.hold_until) + ' tak hold hai — us se pehle renew karwayein.</div>';
      h += '<h3 class="sec">Meri seat</h3><section class="card list">' +
        '<div class="row"><span>Seat</span><b>' + (cur.seat_id && seatNo[cur.seat_id] ? seatNo[cur.seat_id] : '—') + '</b></div>' +
        '<div class="row"><span>Shift</span><b class="wrap">' + (mine.length ? mine.map(function (x) { return esc(slotName[x.slot_id] || '?'); }).join('<br>') : '—') + '</b></div>' +
        '<div class="row"><span>Shuru</span><b>' + U.date(cur.start_date) + '</b></div></section>';
      if (b) h += '<h3 class="sec">Fee</h3><section class="grid2">' +
        '<div class="stat"><div class="k">Received</div><div class="v">' + U.money(b.paid_amount) + '</div><div class="sub">kul fee ' + U.money(b.fee_amount) + '</div></div>' +
        '<div class="stat ' + (Number(b.balance) > 0 ? 'due' : '') + '"><div class="k">Dues</div><div class="v ' + (Number(b.balance) > 0 ? 'neg' : 'pos') + '">' + U.money(b.balance) + '</div></div></section>';
      if (App.lib && App.lib.phone) h += '<a class="primary linkprimary" href="tel:' + esc(App.lib.phone) + '">☎ Library ko call karein</a>';
      $('sb').innerHTML = h;
    }, function (e) { $('sb').innerHTML = U.errBox(e.message, true); });
  }

  function Payments(v) {
    var c = v.el;
    c.innerHTML = '<div class="topbar"><div class="lib-name">Meri payments</div></div><div id="sb">' + U.skeleton(3) + '</div>';
    load().then(function (d) {
      var valid = d.pays.filter(function (p) { return p.status === 'valid'; });
      var total = valid.reduce(function (a, p) { return a + Number(p.amount); }, 0);
      var h = '<section class="stat accent big"><div class="k">Ab tak received</div><div class="v">' + U.money(total) + '</div><div class="sub">' + valid.length + ' payments</div></section>';
      h += d.pays.length ? '<h3 class="sec">History</h3><section class="card list">' + d.pays.map(function (p) {
        return '<div class="row pay' + (p.status === 'cancelled' ? ' cancelled' : '') + '"><div><b>' + U.money(p.amount) + '</b> <span class="tag">' + esc(p.mode) + '</span>' +
          '<div class="muted small">' + U.date(p.received_on) + (p.reference_no ? ' • ' + esc(p.reference_no) : '') + (p.status === 'cancelled' ? ' • cancelled' : '') + '</div></div></div>'; }).join('') + '</section>'
        : U.empty('💸', 'Abhi koi payment record nahi.');
      $('sb').innerHTML = h;
    }, function (e) { $('sb').innerHTML = U.errBox(e.message, true); });
  }

  function Profile(v) {
    var s = App.student, u = Auth.current().user, l = App.lib || {};
    v.el.innerHTML = '<div class="topbar"><div class="lib-name">Profile</div></div><section class="card profile"><div class="avatar">' + esc(s.name.charAt(0).toUpperCase()) +
      '</div><div><b>' + esc(s.name) + '</b><div class="muted small">' + esc(u.email || '') + '</div></div></section>' +
      '<section class="card list">' + (s.father_name ? '<div class="row"><span>Father</span><b>' + esc(s.father_name) + '</b></div>' : '') +
      '<div class="row"><span>Phone</span><b>' + esc(s.phone) + '</b></div>' + (s.address ? '<div class="row"><span>Address</span><b class="wrap">' + esc(s.address) + '</b></div>' : '') +
      '<div class="row"><span>Join</span><b>' + U.date(s.joined_on) + '</b></div></section>' +
      '<h3 class="sec">Library</h3><section class="card list"><div class="row"><span>Naam</span><b>' + esc(App.libName) + '</b></div>' +
      (l.address ? '<div class="row"><span>Address</span><b class="wrap">' + esc(l.address) + '</b></div>' : '') +
      (l.phone ? '<div class="row"><span>Phone</span><b><a href="tel:' + esc(l.phone) + '">' + esc(l.phone) + '</a></b></div>' : '') +
      (l.open_time ? '<div class="row"><span>Timing</span><b>' + App.hhmm(l.open_time) + ' – ' + App.hhmm(l.close_time) + '</b></div>' : '') + '</section>' +
      '<section class="card list"><div class="row tap" data-act="theme"><span>🎨 &nbsp;Theme</span><b id="theme-lbl">' + esc(Theme.label()) + ' ›</b></div></section>' +
      '<button class="danger-btn" data-act="logout">Logout</button>';
    v.on('theme', function () { Theme.open(function () { $('theme-lbl').textContent = Theme.label() + ' ›'; }); });
    v.on('logout', function () { window.AppMain.logout(); });
  }

  window.Views = window.Views || {};
  window.Views.StudentHome = Home; window.Views.StudentPayments = Payments; window.Views.StudentProfile = Profile;
})();
