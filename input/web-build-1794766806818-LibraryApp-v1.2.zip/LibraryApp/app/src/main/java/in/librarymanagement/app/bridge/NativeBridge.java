package in.librarymanagement.app.bridge;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Window;
import android.webkit.JavascriptInterface;

import androidx.core.view.WindowInsetsControllerCompat;

import java.util.regex.Pattern;

import in.librarymanagement.app.security.SecureStore;

/**
 * The ONLY door between the web page and the phone.
 * It can do just a few small things:
 *   - save, read and clear the login session (encrypted)
 *   - remember the chosen theme name (one whitelisted key, short text)
 *   - tint the status / navigation bar to match the theme
 * No file access, no shell, no arbitrary calls.
 */
public final class NativeBridge {
    private static final int MAX_LEN = 20000;
    private static final Pattern HEX = Pattern.compile("^#[0-9A-Fa-f]{6}$");
    private static final Pattern PREF_VAL = Pattern.compile("^[a-z0-9_-]{1,32}$");

    private final SecureStore store;
    private final Activity activity;
    private final SharedPreferences prefs;

    public NativeBridge(SecureStore store, Activity activity) {
        this.store = store;
        this.activity = activity;
        this.prefs = activity.getApplicationContext().getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
    }

    @JavascriptInterface
    public void saveSession(String json) {
        if (json == null || json.length() > MAX_LEN) return;
        store.save(json);
    }

    @JavascriptInterface
    public String getSession() {
        String s = store.load();
        return s == null ? "" : s;
    }

    @JavascriptInterface
    public void clearSession() {
        store.clear();
    }

    /** Only the "theme" key is allowed, value must be a short lowercase word. */
    @JavascriptInterface
    public void savePref(String key, String value) {
        if (!"theme".equals(key) || value == null || !PREF_VAL.matcher(value).matches()) return;
        prefs.edit().putString(key, value).apply();
    }

    @JavascriptInterface
    public String getPref(String key) {
        if (!"theme".equals(key)) return "";
        String v = prefs.getString(key, "");
        return v == null ? "" : v;
    }

    /** Colours the status bar + navigation bar. darkBg=true -> light icons. */
    @JavascriptInterface
    public void setBars(String hex, boolean darkBg) {
        if (hex == null || !HEX.matcher(hex).matches()) return;
        final int color = Color.parseColor(hex);
        final boolean dark = darkBg;
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Window w = activity.getWindow();
                    w.setStatusBarColor(color);
                    w.setNavigationBarColor(color);
                    w.setBackgroundDrawable(new ColorDrawable(color));
                    WindowInsetsControllerCompat c = new WindowInsetsControllerCompat(w, w.getDecorView());
                    c.setAppearanceLightStatusBars(!dark);
                    c.setAppearanceLightNavigationBars(!dark);
                } catch (Throwable ignored) {
                    // cosmetic only - never crash the app for this
                }
            }
        });
    }
}
