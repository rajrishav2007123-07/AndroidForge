// Thin Supabase REST client. Uses ONLY the public key + the user's own token.
(function () {
  var cfg = window.APP_CONFIG;

  function ApiError(message, status) { this.message = message; this.status = status; }
  ApiError.prototype = Object.create(Error.prototype);

  function friendly(status, body) {
    var m = (body && (body.error_description || body.msg || body.message || body.error)) || '';
    if (status === 400 && /invalid login/i.test(m)) return 'Email ya password galat hai.';
    if (status === 429) return 'Bahut zyada koshish. Thodi der baad try karein.';
    if (status === 401) return 'Session khatam. Dobara login karein.';
    if (status === 403 && !m) return 'Aapko iski permission nahi hai.';
    if (status === 0) return 'Internet check karein.';
    return m || 'Kuch galat ho gaya (' + status + ').';
  }

  function raw(path, opts) {
    opts = opts || {};
    var headers = { 'apikey': cfg.SUPABASE_ANON_KEY, 'Content-Type': 'application/json' };
    if (opts.token) headers['Authorization'] = 'Bearer ' + opts.token;
    var ctl = new AbortController();
    var timer = setTimeout(function () { ctl.abort(); }, 25000);
    return fetch(cfg.SUPABASE_URL + path, {
      method: opts.method || 'GET', headers: headers, signal: ctl.signal,
      body: opts.body ? JSON.stringify(opts.body) : undefined
    }).then(function (r) {
      clearTimeout(timer);
      return r.text().then(function (t) {
        var j = null; try { j = t ? JSON.parse(t) : null; } catch (e) {}
        if (!r.ok) throw new ApiError(friendly(r.status, j), r.status);
        return j;
      });
    }, function () { clearTimeout(timer); throw new ApiError(friendly(0), 0); });
  }

  function q(o) {
    return Object.keys(o).map(function (k) { return k + '=' + encodeURIComponent(o[k]); }).join('&');
  }

  window.Api = {
    ApiError: ApiError,
    q: q,
    signIn: function (email, password) {
      return raw('/auth/v1/token?grant_type=password', { method: 'POST', body: { email: email, password: password } });
    },
    refresh: function (refreshToken) {
      return raw('/auth/v1/token?grant_type=refresh_token', { method: 'POST', body: { refresh_token: refreshToken } });
    },
    signOut: function (token) {
      return raw('/auth/v1/logout', { method: 'POST', token: token }).catch(function () {});
    },
    // Authenticated calls: always get a fresh token first.
    get: function (path) {
      return Auth.token().then(function (t) { return raw('/rest/v1/' + path, { token: t }); });
    },
    rpc: function (fn, args) {
      return Auth.token().then(function (t) { return raw('/rest/v1/rpc/' + fn, { method: 'POST', token: t, body: args || {} }); });
    }
  };
})();
