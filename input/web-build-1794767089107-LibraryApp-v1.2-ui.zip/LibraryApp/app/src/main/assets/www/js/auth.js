// Session lifecycle: login, restore, auto-refresh, logout.
(function () {
  var session = null; // {access_token, refresh_token, expires_at, user:{id,email}}

  function pack(r) {
    return {
      access_token: r.access_token, refresh_token: r.refresh_token,
      expires_at: Math.floor(Date.now() / 1000) + (r.expires_in || 3600),
      user: { id: r.user && r.user.id, email: r.user && r.user.email }
    };
  }
  function set(s) { session = s; Store.save(s); }

  window.Auth = {
    current: function () { return session; },
    login: function (email, password) {
      return Api.signIn(email, password).then(function (r) { set(pack(r)); return session; });
    },
    restore: function () {
      var s = Store.load();
      if (!s || !s.refresh_token) return Promise.resolve(null);
      session = s;
      return Auth.token().then(function () { return session; }, function () { Auth.forget(); return null; });
    },
    // Returns a valid access token, refreshing a minute before expiry.
    token: function () {
      if (!session) return Promise.reject(new Api.ApiError('Login required', 401));
      if (session.expires_at - 60 > Date.now() / 1000) return Promise.resolve(session.access_token);
      return Api.refresh(session.refresh_token).then(function (r) {
        var p = pack(r); if (!p.user.id) p.user = session.user; set(p); return session.access_token;
      });
    },
    logout: function () {
      var t = session && session.access_token;
      Auth.forget();
      return t ? Api.signOut(t) : Promise.resolve();
    },
    forget: function () { session = null; Store.clear(); }
  };
})();
