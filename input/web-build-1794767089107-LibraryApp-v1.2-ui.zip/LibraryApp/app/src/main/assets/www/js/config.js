// Supabase public settings (publishable/anon key is safe in the app).
// NEVER put the service_role / secret key here.
window.APP_CONFIG = {
  SUPABASE_URL: "https://ytmdftfexmaetdhxxsid.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_TUsaPPU7urxDnFFIUhpDTA_6LhAWazH"
};
