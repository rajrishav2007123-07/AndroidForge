// Navigation: bottom tabs + a stack of full pages on top (with back button).
(function () {
  var stack = [];          // [{title, render, args}]
  var tabs = [];           // [{id,label,icon,render}]
  var current = null;
  var page, tabbar, ptitle, pback, pbar;

  function mount(renderFn, args, isTab) {
    var c = document.createElement('div');
    c.className = 'view';
    page.innerHTML = ''; page.appendChild(c);
    window.scrollTo(0, 0);
    var onAct = {};
    c.addEventListener('click', function (e) {
      var el = e.target.closest('[data-act]');
      if (!el || !c.contains(el)) return;
      var f = onAct[el.getAttribute('data-act')];
      if (f) f(el, e);
    });
    var api = { el: c, on: function (name, fn) { onAct[name] = fn; }, reload: function () { mount(renderFn, args, isTab); } };
    onAct.retry = function () { api.reload(); };
    renderFn(api, args || {});
  }

  window.Nav = {
    init: function (tabList) {
      tabs = tabList;
      page = U.$('page'); tabbar = U.$('tabbar'); ptitle = U.$('ptitle'); pback = U.$('pback'); pbar = U.$('pagebar');
      tabbar.innerHTML = tabs.map(function (t) {
        return '<button data-tab="' + t.id + '"><span class="ti">' + t.icon + '</span><span>' + U.esc(t.label) + '</span></button>';
      }).join('');
      tabbar.addEventListener('click', function (e) {
        var b = e.target.closest('button[data-tab]'); if (b) Nav.tab(b.getAttribute('data-tab'));
      });
      pback.addEventListener('click', function () { Nav.back(); });
    },
    tab: function (id, args) {
      var t = tabs.filter(function (x) { return x.id === id; })[0]; if (!t) return;
      stack = []; current = id; Nav.sheetClose();
      Array.prototype.forEach.call(tabbar.querySelectorAll('button'), function (b) {
        b.classList.toggle('on', b.getAttribute('data-tab') === id);
      });
      U.show(tabbar, true); U.show(pbar, false);
      mount(t.render, args, true);
    },
    push: function (title, renderFn, args) {
      stack.push({ title: title, render: renderFn, args: args });
      Nav.sheetClose();
      U.show(tabbar, false); U.show(pbar, true); ptitle.textContent = title;
      mount(renderFn, args, false);
    },
    back: function () {
      if (!stack.length) return false;
      stack.pop();
      if (!stack.length) { Nav.tab(current); return true; }
      var top = stack[stack.length - 1];
      ptitle.textContent = top.title; mount(top.render, top.args, false);
      return true;
    },
    // Android back button
    onBack: function () {
      if (U.$('sheet-root').firstChild) { Nav.sheetClose(); return 'handled'; }
      if (stack.length) { Nav.back(); return 'handled'; }
      if (current && current !== tabs[0].id) { Nav.tab(tabs[0].id); return 'handled'; }
      return 'exit';
    },
    depth: function () { return stack.length; },
    // Bottom sheet
    sheet: function (html, onMount) {
      var root = U.$('sheet-root');
      root.innerHTML = '<div class="backdrop"></div><div class="sheet"><div class="grab"></div>' + html + '</div>';
      root.querySelector('.backdrop').addEventListener('click', Nav.sheetClose);
      if (onMount) onMount(root.querySelector('.sheet'));
      return root.querySelector('.sheet');
    },
    sheetClose: function () { U.$('sheet-root').innerHTML = ''; }
  };
})();
