// Session storage: Android Keystore via NativeApp bridge; plain memory when
// opened in a desktop browser for testing.
(function () {
  var mem = '';
  var hasNative = typeof window.NativeApp !== 'undefined';
  window.Store = {
    save: function (obj) {
      var s = JSON.stringify(obj);
      if (hasNative) window.NativeApp.saveSession(s); else mem = s;
    },
    load: function () {
      var s = hasNative ? window.NativeApp.getSession() : mem;
      if (!s) return null;
      try { return JSON.parse(s); } catch (e) { return null; }
    },
    clear: function () {
      if (hasNative) window.NativeApp.clearSession(); else mem = '';
    }
  };
})();
