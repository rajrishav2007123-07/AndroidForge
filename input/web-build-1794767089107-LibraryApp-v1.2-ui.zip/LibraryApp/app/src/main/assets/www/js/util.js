(function () {
  var U = {};
  // If a screen was already closed when an async reply arrives, writes go to a throwaway element instead of crashing.
  U.$ = function (id) { return document.getElementById(id) || document.createElement('input'); };
  U.show = function (el, on) { el.classList.toggle('hidden', !on); };
  U.esc = function (s) {
    return String(s === null || s === undefined ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  U.money = function (n) {
    if (n === null || n === undefined || n === '') return '—';
    return '₹' + Number(n).toLocaleString('en-IN');
  };
  U.num = function (n) { return (n === null || n === undefined) ? '–' : String(n); };
  var MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  U.date = function (iso) {
    if (!iso) return '—';
    var p = String(iso).slice(0, 10).split('-');
    return parseInt(p[2], 10) + ' ' + MON[parseInt(p[1], 10) - 1] + ' ' + p[0];
  };
  // Today in India (IST) as YYYY-MM-DD, independent of phone timezone.
  U.today = function () { return new Date(Date.now() + 330 * 60000).toISOString().slice(0, 10); };
  U.addDays = function (iso, n) {
    var d = new Date(iso + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10);
  };
  // +n months, expiry = day before same date (1 Jan + 1 month -> 31 Jan)
  U.addMonths = function (iso, n) {
    var p = iso.split('-').map(Number), y = p[0], m = p[1] - 1 + n, d = p[2];
    var last = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
    var dt = new Date(Date.UTC(y, m, Math.min(d, last)));
    dt.setUTCDate(dt.getUTCDate() - 1);
    return dt.toISOString().slice(0, 10);
  };
  U.monthStart = function (iso) { return iso.slice(0, 8) + '01'; };
  U.digits = function (s) { return String(s || '').replace(/\D/g, '').replace(/^91(?=\d{10}$)/, ''); };
  U.debounce = function (fn, ms) {
    var t; return function () { var a = arguments, c = this; clearTimeout(t); t = setTimeout(function () { fn.apply(c, a); }, ms); };
  };
  var tt;
  U.toast = function (msg) {
    var el = U.$('toast'); el.textContent = msg; el.classList.add('show');
    clearTimeout(tt); tt = setTimeout(function () { el.classList.remove('show'); }, 3200);
  };
  U.configured = function () {
    var c = window.APP_CONFIG || {};
    return /^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(c.SUPABASE_URL || '') && (c.SUPABASE_ANON_KEY || '').length > 40;
  };

  // ---- small HTML builders (everything user-supplied goes through esc) ----
  U.badge = function (state) {
    var map = { running: ['Chalu', 'ok'], held: ['Expired • seat hold', 'warn'], expired: ['Expired', 'warn'],
      lapsed: ['Lapsed', 'bad'], left: ['Left', 'bad'], active: ['Active', 'ok'] };
    var m = map[state] || [state || '—', 'mute'];
    return '<span class="badge ' + m[1] + '">' + U.esc(m[0]) + '</span>';
  };
  U.empty = function (icon, text, sub) {
    return '<div class="empty"><div class="ei">' + icon + '</div><p>' + U.esc(text) + '</p>' +
      (sub ? '<p class="small muted" style="margin-top:6px">' + U.esc(sub) + '</p>' : '') + '</div>';
  };
  U.errBox = function (msg, retry) {
    return '<div class="error">' + U.esc(msg) + (retry ? ' <button class="linkbtn" data-act="retry">Dobara try</button>' : '') + '</div>';
  };
  U.skeleton = function (n) {
    var s = ''; for (var i = 0; i < (n || 4); i++) s += '<div class="sk-card"></div>'; return s;
  };
  U.field = function (label, id, type, opts) {
    opts = opts || {};
    var a = '';
    ['placeholder', 'value', 'inputmode', 'maxlength', 'min', 'max', 'step', 'autocomplete'].forEach(function (k) {
      if (opts[k] !== undefined && opts[k] !== null) a += ' ' + k + '="' + U.esc(opts[k]) + '"';
    });
    var input = type === 'textarea'
      ? '<textarea id="' + id + '" rows="2"' + a + '>' + U.esc(opts.value || '') + '</textarea>'
      : type === 'select'
        ? '<select id="' + id + '">' + opts.options.map(function (o) {
          return '<option value="' + U.esc(o[0]) + '"' + (String(o[0]) === String(opts.value) ? ' selected' : '') + '>' + U.esc(o[1]) + '</option>';
        }).join('') + '</select>'
        : '<input id="' + id + '" type="' + type + '"' + a + '>';
    return '<label class="fl" for="' + id + '">' + U.esc(label) + (opts.req ? ' <i>*</i>' : '') + '</label><div class="field">' + input + '</div>';
  };
  U.val = function (id) { var e = U.$(id) || document.getElementById(id); return e ? e.value.trim() : ''; };
  window.U = U;
})();
