// HOME tab (owner / staff) + MORE tab + COLLECTION REPORT page
(function () {
  var $ = U.$, esc = U.esc;

  function statCard(k, v, sub, cls, act, val) {
    return '<div class="stat ' + (cls || '') + '"' + (act ? ' data-act="' + act + '" data-v="' + val + '"' : '') + '><div class="k">' + k +
      '</div><div class="v">' + v + '</div>' + (sub ? '<div class="sub">' + sub + '</div>' : '') + '</div>';
  }

  function Home(v) {
    var c = v.el;
    c.innerHTML = '<div class="topbar"><div><div class="small muted">' + (App.role === 'owner' ? 'Owner' : 'Staff') +
      '</div><div class="lib-name">' + esc(App.libName) + '</div></div><button class="icon-btn" data-act="refresh" aria-label="Refresh">⟳</button></div>' +
      '<div id="home-body">' + U.skeleton(4) + '</div>';
    v.on('refresh', function () { v.reload(); });
    v.on('go', function (el) { Nav.tab(el.getAttribute('data-v')); });
    v.on('new', function () { Nav.push('Naya student', window.Forms.register); });
    v.on('exp', function (el) { Nav.tab('students', { expiry: el.getAttribute('data-v') }); });
    v.on('report', function () { Nav.push('Collection report', Report); });
    v.on('dues', function () { Nav.tab('dues'); });

    Api.rpc('dashboard', { p_lib: App.libId }).then(function (d) {
      var qa = '';
      if (App.can('can_register_students')) qa += '<button class="qa" data-act="new"><span>＋</span>Naya student</button>';
      qa += '<button class="qa" data-act="go" data-v="students"><span>⌕</span>Search</button>';
      qa += '<button class="qa" data-act="dues"><span>₹</span>Bakaya</button>';
      if (App.can('can_view_reports')) qa += '<button class="qa" data-act="report"><span>▤</span>Report</button>';
      var money = d.total_balance !== null && d.total_balance !== undefined;
      var h = '<div class="qa-row">' + qa + '</div>' +
        '<section class="grid2">' + statCard('Active students', U.num(d.active_students), 'Chalu: ' + U.num(d.running_memberships), 'accent', 'exp', 'running') +
        statCard('Poori khali seats', U.num(d.seats_completely_free), 'kul seats: ' + U.num(d.seats_total), '', 'go', 'seats') + '</section>' +
        '<h3 class="sec">Expiry (tap karke list dekhein)</h3><section class="grid4">' +
        '<div class="chip warn" data-act="exp" data-v="today"><div class="v">' + U.num(d.expiring_today) + '</div><div class="k">Aaj</div></div>' +
        '<div class="chip" data-act="exp" data-v="next3"><div class="v">' + U.num(d.expiring_in_3_days) + '</div><div class="k">3 din</div></div>' +
        '<div class="chip" data-act="exp" data-v="next7"><div class="v">' + U.num(d.expiring_in_7_days) + '</div><div class="k">7 din</div></div>' +
        '<div class="chip" data-act="exp" data-v="next15"><div class="v">' + U.num(d.expiring_in_15_days) + '</div><div class="k">15 din</div></div></section>' +
        '<section class="card list">' +
        '<div class="row tap" data-act="exp" data-v="held"><span>Expired, seat hold par</span><b>' + U.num(d.expired_seat_held) + '</b></div>' +
        '<div class="row tap" data-act="exp" data-v="lapsed"><span>Seat release ho chuki (lapsed)</span><b>' + U.num(d.lapsed_seat_released) + '</b></div></section>';
      if (money) {
        var modes = d.today_by_mode || {};
        var ml = Object.keys(modes).map(function (k) { return esc(k) + ' ' + U.money(modes[k]); }).join(' • ');
        h += '<h3 class="sec">Paise</h3><section class="grid2">' +
          statCard('Aaj ka collection', U.money(d.today_collection), U.num(d.today_payments_count) + ' payments' + (ml ? '<br>' + ml : '')) +
          statCard('Is mahine', U.money(d.month_collection)) + '</section>' +
          '<section class="stat due tap" data-act="dues"><div class="k">Total bakaya</div><div class="v">' + U.money(d.total_balance) +
          '</div><div class="sub">' + U.num(d.students_with_balance) + ' students ka bakaya • list dekhein ›</div></section>';
        if (d.today_cancelled_count) h += '<p class="foot">Aaj ' + d.today_cancelled_count + ' payment cancel hui</p>';
      }
      h += '<p class="foot">Data as on ' + U.date(d.as_on) + '</p>';
      $('home-body').innerHTML = h;
    }, function (e) {
      if (e.status === 401) { window.AppMain.logout(true); return; }
      $('home-body').innerHTML = U.errBox(e.message, true);
    });
  }

  // ---------------- Collection report ----------------
  function Report(v) {
    var c = v.el, t = U.today();
    var st = { from: U.monthStart(t), to: t };
    c.innerHTML = '<div class="presets"><button class="pill" data-act="p" data-v="today">Aaj</button><button class="pill" data-act="p" data-v="7">7 din</button>' +
      '<button class="pill on" data-act="p" data-v="month">Is mahine</button><button class="pill" data-act="p" data-v="30">30 din</button></div>' +
      '<div class="card"><div class="two">' + U.field('Se', 'r-from', 'date', { value: st.from }) + U.field('Tak', 'r-to', 'date', { value: st.to }) +
      '</div><button class="primary sm" data-act="go">Report dekhein</button></div><div id="rep-body"></div>';
    v.on('p', function (el) {
      var k = el.getAttribute('data-v');
      st.to = t; st.from = k === 'today' ? t : k === 'month' ? U.monthStart(t) : U.addDays(t, -(parseInt(k, 10) - 1));
      $('r-from').value = st.from; $('r-to').value = st.to;
      Array.prototype.forEach.call(c.querySelectorAll('.pill'), function (b) { b.classList.toggle('on', b === el); });
      run();
    });
    v.on('go', function () { st.from = $('r-from').value; st.to = $('r-to').value; run(); });
    function run() {
      if (!st.from || !st.to || st.from > st.to) { $('rep-body').innerHTML = U.errBox('Tareekh sahi chunein (Se ≤ Tak).'); return; }
      $('rep-body').innerHTML = U.skeleton(3);
      Api.rpc('collection_report', { p_lib: App.libId, p_from: st.from, p_to: st.to }).then(function (r) {
        var modes = r.by_mode || {}, days = r.by_day || [];
        var mh = Array.isArray(modes) ? modes.map(function (m) { return [m.mode, m.amount]; }) : Object.keys(modes).map(function (k) { return [k, modes[k]]; });
        var h = '<section class="stat accent big"><div class="k">Kul collection</div><div class="v">' + U.money(r.received_total) +
          '</div><div class="sub">' + U.num(r.received_count) + ' payments • ' + U.date(r.from) + ' – ' + U.date(r.to) + '</div></section>';
        h += '<section class="grid2 mt">' + statCard('Naye students', U.num(r.new_students)) +
          statCard('Cancel payments', U.num(r.cancelled_count), U.money(r.cancelled_amount)) + '</section>';
        if (mh.length) h += '<h3 class="sec">Mode ke hisaab se</h3><section class="card list">' + mh.map(function (m) {
          return '<div class="row"><span class="cap">' + esc(m[0]) + '</span><b>' + U.money(m[1]) + '</b></div>'; }).join('') + '</section>';
        if (r.expected_renewals) h += '<h3 class="sec">Aane wale renewals</h3><section class="stat"><div class="v">' + U.num(r.expected_renewals.memberships) +
          '</div><div class="sub">expected fee: ' + U.money(r.expected_renewals.fee_total) + '</div></section>';
        if (days.length) h += '<h3 class="sec">Din ke hisaab se</h3><section class="card list">' + days.slice().reverse().map(function (d) {
          return '<div class="row"><span>' + U.date(d.date) + ' <small class="muted">(' + d.count + ')</small></span><b>' + U.money(d.amount) + '</b></div>'; }).join('') + '</section>';
        $('rep-body').innerHTML = h;
      }, function (e) { $('rep-body').innerHTML = U.errBox(e.message); });
    }
    run();
  }

  // ---------------- MORE tab ----------------
  function More(v) {
    var c = v.el, u = Auth.current().user;
    var h = '<div class="topbar"><div class="lib-name">Aur</div></div>' +
      '<section class="card profile"><div class="avatar">' + esc((u.email || '?').charAt(0).toUpperCase()) + '</div><div><b>' + esc(u.email) +
      '</b><div class="muted small">' + (App.role === 'owner' ? 'Library owner' : 'Staff') + ' • ' + esc(App.libName) + '</div></div></section>' +
      '<section class="card list">';
    if (App.can('can_view_reports')) h += '<div class="row tap" data-act="report"><span>▤ &nbsp;Collection report</span><b>›</b></div>';
    h += '<div class="row tap" data-act="lib"><span>🏛 &nbsp;Library ki jaankari</span><b>›</b></div>';
    if (App.role === 'owner') h += '<div class="row tap" data-act="seatcount"><span>▦ &nbsp;Seats ki sankhya badlein</span><b>›</b></div>';
    h += '<div class="row tap" data-act="perm"><span>🔑 &nbsp;Meri permissions</span><b>›</b></div></section>' +
      '<button class="danger-btn" data-act="logout">Logout</button><p class="foot soft">Library Manager • v1.1</p>';
    c.innerHTML = h;
    v.on('report', function () { Nav.push('Collection report', Report); });
    v.on('logout', function () { window.AppMain.logout(); });
    v.on('perm', function () {
      var names = { can_register_students: 'Student register/edit', can_add_payments: 'Payment entry/cancel', can_edit_expiry: 'Expiry/fee badalna',
        can_remove_students: 'Student remove', can_view_reports: 'Reports aur paise dekhna' };
      Nav.sheet('<h3>Meri permissions</h3>' + Object.keys(names).map(function (k) {
        return '<div class="row"><span>' + names[k] + '</span><b>' + (App.can(k) ? '✅' : '—') + '</b></div>'; }).join(''));
    });
    v.on('lib', function () {
      Nav.sheet('<h3>Library ki jaankari</h3><p class="muted">Loading…</p>');
      Api.get('libraries?' + Api.q({ select: 'name,address,phone,open_time,close_time,seat_capacity,grace_days', id: 'eq.' + App.libId })).then(function (r) {
        var l = r[0] || {};
        Nav.sheet('<h3>' + esc(l.name) + '</h3><div class="row"><span>Address</span><b>' + esc(l.address || '—') + '</b></div>' +
          '<div class="row"><span>Phone</span><b>' + esc(l.phone || '—') + '</b></div>' +
          '<div class="row"><span>Timing</span><b>' + (l.open_time ? App.hhmm(l.open_time) + '–' + App.hhmm(l.close_time) : '—') + '</b></div>' +
          '<div class="row"><span>Seats</span><b>' + U.num(l.seat_capacity) + '</b></div>' +
          '<div class="row"><span>Expiry ke baad seat hold</span><b>' + U.num(l.grace_days) + ' din</b></div>');
      }, function (e) { Nav.sheet('<h3>Error</h3>' + U.errBox(e.message)); });
    });
    v.on('seatcount', function () {
      Nav.sheet('<h3>Seats ki sankhya</h3><p class="muted small">0 se 150. Jin seats par abhi student hai wo band nahi hongi.</p>' +
        U.field('Kul seats', 'sc-n', 'number', { inputmode: 'numeric', min: 0, max: 150, placeholder: 'jaise 60' }) +
        '<div id="sc-err"></div><button class="primary" id="sc-go">Save</button>');
      $('sc-go').addEventListener('click', function () {
        var n = parseInt($('sc-n').value, 10);
        if (isNaN(n) || n < 0 || n > 150) { $('sc-err').innerHTML = U.errBox('0 se 150 ke beech likhein.'); return; }
        this.disabled = true;
        Api.rpc('set_seat_count', { p_lib: App.libId, p_count: n }).then(function () {
          App.clearCaches(); Nav.sheetClose(); U.toast('Seats update ho gayi'); }, function (e) {
          $('sc-go').disabled = false; $('sc-err').innerHTML = U.errBox(e.message); });
      });
    });
  }

  window.Views = window.Views || {};
  window.Views.Home = Home; window.Views.More = More; window.Views.Report = Report;
})();
