// Shared app state: who is logged in, which library, what they may do.
(function () {
  var slotsCache = null, seatsCache = null;
  window.App = {
    libId: null, libName: '', role: null, perms: {}, mode: null, seatStyle: 'number', // mode: 'staff' | 'student'
    student: null,
    reset: function () { App.libId = null; App.libName = ''; App.role = null; App.perms = {}; App.mode = null; App.student = null; App.seatStyle = 'number'; slotsCache = null; seatsCache = null; },
    can: function (k) { return App.role === 'owner' || App.perms[k] === true; },
    slots: function () {
      if (slotsCache) return Promise.resolve(slotsCache);
      return Api.get('time_slots?' + Api.q({ library_id: 'eq.' + App.libId, select: 'id,name,start_time,end_time,default_price,is_active', order: 'sort_order,start_time' }))
        .then(function (r) { slotsCache = r || []; return slotsCache; });
    },
    seats: function () {
      if (seatsCache) return Promise.resolve(seatsCache);
      return Api.get('seats?' + Api.q({ library_id: 'eq.' + App.libId, select: 'id,seat_no', order: 'seat_no', limit: 200 }))
        .then(function (r) { seatsCache = r || []; return seatsCache; });
    },
    clearCaches: function () { slotsCache = null; seatsCache = null; },
    hhmm: function (t) { return t ? String(t).slice(0, 5) : ''; },
    slotLabel: function (s) { return s.name + ' (' + App.hhmm(s.start_time) + '–' + App.hhmm(s.end_time) + ')'; },
    // Work out role after login: library_members first, then own student record.
    bootstrap: function () {
      return Api.get('library_members?' + Api.q({
        select: 'role,permissions,library_id,libraries(name)', is_active: 'eq.true', user_id: 'eq.' + Auth.current().user.id
      })).then(function (rows) {
        if (rows && rows.length) {
          var r = rows[0];
          App.mode = 'staff'; App.libId = r.library_id; App.role = r.role; App.perms = r.permissions || {};
          App.libName = (r.libraries && r.libraries.name) || 'My Library';
          return Api.get('libraries?' + Api.q({ select: 'seat_style', id: 'eq.' + App.libId })).then(function (l) {
            if (l && l[0] && l[0].seat_style) App.seatStyle = l[0].seat_style;
            return 'staff';
          }, function () { return 'staff'; });
        }
        return Api.get('students?' + Api.q({ select: '*', user_id: 'eq.' + Auth.current().user.id, limit: 1 })).then(function (st) {
          if (st && st.length) {
            App.mode = 'student'; App.student = st[0]; App.libId = st[0].library_id; App.role = 'student';
            return Api.get('libraries?' + Api.q({ select: 'name,address,phone,open_time,close_time', id: 'eq.' + App.libId })).then(function (l) {
              if (l && l[0]) { App.libName = l[0].name; App.lib = l[0]; }
              return 'student';
            }, function () { return 'student'; });
          }
          throw new Api.ApiError('Is account ko kisi library se nahi jodaa gaya hai. Owner se sampark karein.', 403);
        });
      });
    }
  };
})();
