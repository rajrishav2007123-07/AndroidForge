// Seat icons (inline SVG, colour follows the seat state via currentColor)
(function () {
  var open = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">';
  var P = {
    chair: open + '<path d="M7 3h10v8H7z"/><path d="M5 11h14v4H5z"/><path d="M7 15v6M17 15v6"/></svg>',
    desk: open + '<rect x="3" y="9" width="18" height="3" rx="1"/><path d="M5 12v8M19 12v8"/><path d="M8 9V5h6v4"/></svg>',
    cabin: open + '<path d="M4 21V5a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v16"/><path d="M3 21h18"/><path d="M8 21v-6h8v6"/><path d="M9 9h6"/></svg>',
    number: ''
  };
  window.Icons = {
    styles: [['chair', 'Chair'], ['desk', 'Study desk'], ['cabin', 'Cabin'], ['number', 'Sirf number']],
    seat: function (style) { return P[style] !== undefined ? P[style] : P.chair; }
  };
})();
