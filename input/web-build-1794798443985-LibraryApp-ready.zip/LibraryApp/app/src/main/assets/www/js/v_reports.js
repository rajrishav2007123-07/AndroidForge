// DATE REPORT (future date tak) and PERIOD REPORT (mahina / date range) with tappable lists
(function () {
  var $ = U.$, esc = U.esc;

  function sqlMissing(m) {
    return /schema cache|Could not find|does not exist|function public\./i.test(m)
      ? 'Naya SQL (A2_reports.sql) abhi database me nahi chala hai. Pehle use chalayein.' : m;
  }
  function stat(k, v, sub, act, data, cls) {
    var d = ''; Object.keys(data || {}).forEach(function (x) { d += ' data-' + x + '="' + esc(data[x]) + '"'; });
    return '<div class="stat ' + (cls || '') + '"' + (act ? ' data-act="' + act + '"' + d : '') + '><div class="k">' + k + '</div><div class="v">' + v + '</div>' +
      (sub ? '<div class="sub">' + sub + '</div>' : '') + '</div>';
  }
  function openList(title, args) {
    args.page = true; args.title = title;
    Nav.push(title, window.Views.Students, args);
  }

  // ---------------- DATE REPORT ----------------
  function DateReport(v) {
    var c = v.el, t = U.today(), st = { to: U.addDays(t, 7) };
    c.innerHTML = '<div class="presets"><button class="pill" data-act="p" data-v="1">Kal</button><button class="pill on" data-act="p" data-v="7">7 din</button>' +
      '<button class="pill" data-act="p" data-v="15">15 din</button><button class="pill" data-act="p" data-v="30">30 din</button>' +
      '<button class="pill" data-act="p" data-v="eom">Mahine ke end tak</button></div>' +
      '<div class="card">' + U.field('Is date tak ka hisaab dekhein', 'dr-to', 'date', { value: st.to, min: t }) +
      '<button class="primary sm" data-act="go">Report dekhein</button></div><div id="dr-body"></div>';
    v.on('p', function (el) {
      var k = el.getAttribute('data-v');
      st.to = k === 'eom' ? new Date(Date.UTC(+t.slice(0, 4), +t.slice(5, 7), 0)).toISOString().slice(0, 10) : U.addDays(t, parseInt(k, 10));
      $('dr-to').value = st.to;
      Array.prototype.forEach.call(c.querySelectorAll('.pill'), function (b) { b.classList.toggle('on', b === el); });
      run();
    });
    v.on('go', function () { st.to = $('dr-to').value; run(); });
    v.on('list', function (el) {
      var k = el.getAttribute('data-k'), d = st.to;
      if (k === 'exp') openList('Expire hone wale (' + U.date(t) + ' – ' + U.date(d) + ')', { expiry: 'running', from: t, to: d });
      else if (k === 'held') openList('Expired, seat hold par', { expiry: 'held' });
      else if (k === 'lapsed') openList('Lapsed (seat release)', { expiry: 'lapsed' });
      else if (k === 'day') openList(U.date(el.getAttribute('data-d')) + ' ko expire', { expiry: 'running', from: el.getAttribute('data-d'), to: el.getAttribute('data-d') });
      else openList(el.getAttribute('data-title'), { fee: k });
    });
    function run() {
      if (!st.to || st.to < t) { $('dr-body').innerHTML = U.errBox('Aaj ya aage ki date chunein.'); return; }
      $('dr-body').innerHTML = U.skeleton(4);
      Api.rpc('date_report', { p_lib: App.libId, p_to: st.to }).then(function (r) {
        var h = '<section class="stat accent big" data-act="list" data-k="exp"><div class="k">' + U.date(t) + ' se ' + U.date(r.to) + ' tak expire hone wale</div><div class="v">' +
          U.num(r.expiring_count) + ' students</div><div class="sub">Inki kul fee: ' + U.money(r.expiring_fee) + ' • list dekhein ›</div></section>';
        h += '<section class="grid2 mt">' + stat('Expired, seat hold par', U.num(r.expired_held), 'tap karein ›', 'list', { k: 'held' }) +
          stat('Lapsed (seat release)', U.num(r.expired_lapsed), 'tap karein ›', 'list', { k: 'lapsed' }) + '</section>';
        h += '<h3 class="sec">Pending bakaya (aaj tak)</h3><section class="stat due" data-act="list" data-k="due" data-title="Bakaya wale students"><div class="k">Kul bakaya</div><div class="v">' + U.money(r.total_balance) +
          '</div><div class="sub">' + U.num(r.students_with_balance) + ' students • list dekhein ›</div></section>';
        h += '<section class="grid3 mt">' +
          stat('Full paid', U.num(r.full_count), '', 'list', { k: 'full', title: 'Full payment wale' }, 'mini') +
          stat('Partial', U.num(r.partial_count), U.money(r.partial_due) + ' baaki', 'list', { k: 'partial', title: 'Partial payment wale' }, 'mini') +
          stat('Kuch nahi diya', U.num(r.unpaid_count), U.money(r.unpaid_due) + ' baaki', 'list', { k: 'unpaid', title: 'Jinhone kuch nahi diya' }, 'mini') + '</section>';
        var tl = r.timeline || [];
        if (tl.length) h += '<h3 class="sec">Din ke hisaab se expiry</h3><section class="card list">' + tl.map(function (x) {
          return '<div class="row tap" data-act="list" data-k="day" data-d="' + esc(x.date) + '"><span>' + U.date(x.date) + '</span><b>' + x.count + ' ›</b></div>'; }).join('') + '</section>';
        else h += '<p class="foot">Is period me koi membership expire nahi hogi.</p>';
        $('dr-body').innerHTML = h;
      }, function (e) { $('dr-body').innerHTML = U.errBox(sqlMissing(e.message)); });
    }
    run();
  }

  // ---------------- PERIOD / COLLECTION REPORT ----------------
  function monthRange(t, back) {
    var y = +t.slice(0, 4), m = +t.slice(5, 7) - 1 - back;
    var f = new Date(Date.UTC(y, m, 1)), l = new Date(Date.UTC(y, m + 1, 0));
    return [f.toISOString().slice(0, 10), l.toISOString().slice(0, 10)];
  }

  function Report(v) {
    var c = v.el, t = U.today();
    var st = { from: U.monthStart(t), to: t };
    c.innerHTML = '<div class="presets"><button class="pill" data-act="p" data-v="today">Aaj</button><button class="pill" data-act="p" data-v="7">7 din</button>' +
      '<button class="pill on" data-act="p" data-v="month">Is mahine</button><button class="pill" data-act="p" data-v="prev">Pichhla mahina</button><button class="pill" data-act="p" data-v="30">30 din</button></div>' +
      '<div class="card"><div class="two">' + U.field('Se', 'r-from', 'date', { value: st.from }) + U.field('Tak', 'r-to', 'date', { value: st.to }) +
      '</div><button class="primary sm" data-act="go">Report dekhein</button></div><div id="rep-body"></div>';
    v.on('p', function (el) {
      var k = el.getAttribute('data-v');
      if (k === 'prev') { var r = monthRange(t, 1); st.from = r[0]; st.to = r[1]; }
      else { st.to = t; st.from = k === 'today' ? t : k === 'month' ? U.monthStart(t) : U.addDays(t, -(parseInt(k, 10) - 1)); }
      $('r-from').value = st.from; $('r-to').value = st.to;
      Array.prototype.forEach.call(c.querySelectorAll('.pill'), function (b) { b.classList.toggle('on', b === el); });
      run();
    });
    v.on('go', function () { st.from = $('r-from').value; st.to = $('r-to').value; run(); });
    v.on('list', function (el) {
      var k = el.getAttribute('data-k'), per = U.date(st.from) + ' – ' + U.date(st.to);
      if (k === 'new') openList('Naye registration (' + per + ')', { status: 'all', joinedFrom: st.from, joinedTo: st.to });
      else if (k === 'pdue') openList('Is period ka bakaya (' + per + ')', { pdFrom: st.from, pdTo: st.to, status: 'all' });
      else if (k === 'all') openList('Kul bakaya wale students', { fee: 'due' });
    });

    function run() {
      if (!st.from || !st.to || st.from > st.to) { $('rep-body').innerHTML = U.errBox('Tareekh sahi chunein (Se ≤ Tak).'); return; }
      $('rep-body').innerHTML = U.skeleton(3);
      var a = { p_lib: App.libId, p_from: st.from, p_to: st.to };
      Promise.all([Api.rpc('collection_report', a), Api.rpc('period_report', a).catch(function (e) { return { _err: e.message }; })]).then(function (res) {
        var r = res[0], p = res[1] || {};
        var modes = r.by_mode || {}, days = r.by_day || [];
        var mh = Array.isArray(modes) ? modes.map(function (m) { return [m.mode, m.amount]; }) : Object.keys(modes).map(function (k) { return [k, modes[k]]; });
        var h = '<section class="stat accent big"><div class="k">Kul collection</div><div class="v">' + U.money(r.received_total) +
          '</div><div class="sub">' + U.num(r.received_count) + ' payments • ' + U.date(r.from) + ' – ' + U.date(r.to) + '</div></section>';
        h += '<section class="grid2 mt">' + stat('Naye registration', U.num(r.new_students), 'list dekhein ›', 'list', { k: 'new' }) +
          stat('Cancel payments', U.num(r.cancelled_count), U.money(r.cancelled_amount)) + '</section>';
        if (p._err) {
          h += '<div class="notice">Fee ka detail dikhane ke liye ' + esc(sqlMissing(p._err)) + '</div>';
        } else {
          h += '<h3 class="sec">Is period ki fees</h3><section class="card list">' +
            '<div class="row"><span>Kitni memberships shuru hui</span><b>' + U.num(p.period_memberships) + '</b></div>' +
            '<div class="row"><span>Kul fee</span><b>' + U.money(p.period_fee) + '</b></div>' +
            '<div class="row"><span>Ab tak jama</span><b>' + U.money(p.period_paid) + '</b></div>' +
            '<div class="row"><span>Bakaya</span><b class="neg">' + U.money(p.period_due) + '</b></div></section>';
          h += '<section class="stat due tap mt" data-act="list" data-k="pdue"><div class="k">Is period ke bakaya wale</div><div class="v">' + U.num(p.period_due_students) +
            ' students</div><div class="sub">list dekhein ›</div></section>';
          h += '<section class="grid3 mt">' + stat('Full paid', U.num(p.full_count), '', '', {}, 'mini') + stat('Partial', U.num(p.partial_count), '', '', {}, 'mini') +
            stat('Kuch nahi diya', U.num(p.unpaid_count), '', '', {}, 'mini') + '</section>';
          h += '<section class="stat tap mt" data-act="list" data-k="all"><div class="k">Kul purana bakaya (sab membership)</div><div class="v">' + U.money(p.overall_due) +
            '</div><div class="sub">' + U.num(p.overall_due_students) + ' students • list dekhein ›</div></section>';
        }
        if (mh.length) h += '<h3 class="sec">Mode ke hisaab se</h3><section class="card list">' + mh.map(function (m) {
          return '<div class="row"><span class="cap">' + esc(m[0]) + '</span><b>' + U.money(m[1]) + '</b></div>'; }).join('') + '</section>';
        if (r.expected_renewals) h += '<h3 class="sec">Aane wale renewals</h3><section class="stat"><div class="v">' + U.num(r.expected_renewals.memberships) +
          '</div><div class="sub">expected fee: ' + U.money(r.expected_renewals.fee_total) + '</div></section>';
        if (days.length) h += '<h3 class="sec">Din ke hisaab se</h3><section class="card list">' + days.slice().reverse().map(function (d) {
          return '<div class="row"><span>' + U.date(d.date) + ' <small class="muted">(' + d.count + ')</small></span><b>' + U.money(d.amount) + '</b></div>'; }).join('') + '</section>';
        $('rep-body').innerHTML = h;
      }, function (e) { $('rep-body').innerHTML = U.errBox(e.message); });
    }
    run();
  }

  window.Views = window.Views || {};
  window.Views.DateReport = DateReport; window.Views.Report = Report;
})();
