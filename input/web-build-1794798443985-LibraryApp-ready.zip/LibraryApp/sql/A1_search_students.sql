-- =====================================================================
-- A1: search_students ko upgrade karna (fee type, joined date, period-due filter)
-- Pehle wali sabhi cheezein waise hi chalengi. Bas 5 naye (optional) filter jude hain:
--   p_fee_type   : 'full' | 'partial' | 'unpaid' | 'due'
--   p_joined_from / p_joined_to : registration date range
--   p_pd_from / p_pd_to : "is period me shuru hui membership jiska bakaya baaki hai"
-- Ye poora ek hi baar me chalayein (Run). Neeche "Expected output" dekhein.
-- =====================================================================

drop function if exists public.search_students(uuid,text,text,text,date,date,uuid,boolean,int,int);

create or replace function public.search_students(
  p_lib         uuid,
  p_q           text    default null,
  p_status      text    default 'active',
  p_expiry      text    default null,
  p_from        date    default null,
  p_to          date    default null,
  p_slot_id     uuid    default null,
  p_has_balance boolean default null,
  p_limit       int     default 50,
  p_offset      int     default 0,
  p_fee_type    text    default null,
  p_joined_from date    default null,
  p_joined_to   date    default null,
  p_pd_from     date    default null,
  p_pd_to       date    default null
)
returns table (
  student_id     uuid,
  membership_id  uuid,
  name           text,
  father_name    text,
  phone          text,
  student_status text,
  seat_no        int,
  shifts         text,
  start_date     date,
  end_date       date,
  days_left      int,
  state          text,
  fee            numeric,
  paid           numeric,
  balance        numeric,
  total_balance  numeric,
  total_count    bigint
)
language plpgsql
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_today  date := public.today_ist();
  v_q      text := nullif(trim(coalesce(p_q, '')), '');
  v_clean  text;
  v_digits boolean := false;
  v_seat   int;
  v_like   text;
  v_dlike  text;
  v_money  boolean;
  v_limit  int := least(greatest(coalesce(p_limit, 50), 1), 100);
  v_offset int := greatest(coalesce(p_offset, 0), 0);
begin
  perform public.require_member(p_lib);
  v_money := public.lib_can_see_money(p_lib);

  if coalesce(p_status, '') not in ('active', 'left', 'all') then
    raise exception 'Status active, left ya all hi ho sakta hai' using errcode = '22023';
  end if;
  if p_expiry is not null
     and p_expiry not in ('today','next3','next7','next15','running','expired','held','lapsed') then
    raise exception 'Expiry filter galat hai (today, next3, next7, next15, running, expired, held, lapsed)'
      using errcode = '22023';
  end if;
  if p_fee_type is not null and p_fee_type not in ('full','partial','unpaid','due') then
    raise exception 'Fee type galat hai (full, partial, unpaid, due)' using errcode = '22023';
  end if;
  if p_from is not null and p_to is not null and p_to < p_from then
    raise exception 'To date From date se pehle nahi ho sakti' using errcode = '22023';
  end if;
  if (p_has_balance is not null or p_fee_type is not null or p_pd_from is not null or p_pd_to is not null)
     and not v_money then
    raise exception 'Bakaya/fee filter ke liye payment ya report ki permission chahiye' using errcode = '42501';
  end if;
  if p_slot_id is not null and not exists
     (select 1 from public.time_slots t where t.id = p_slot_id and t.library_id = p_lib) then
    raise exception 'Shift nahi mila' using errcode = 'P0001';
  end if;
  if v_q is not null and char_length(v_q) > 100 then
    raise exception 'Search text 100 akshar se chhota rakho' using errcode = '22023';
  end if;

  if v_q is not null then
    v_clean  := regexp_replace(v_q, '[ +-]', '', 'g');
    v_digits := v_clean ~ '^[0-9]+$';
    if v_digits and char_length(v_clean) <= 3 then
      v_seat := v_clean::int;
    end if;
    v_dlike := '%' || v_clean || '%';
    v_like  := '%' || replace(replace(replace(v_q, '\', '\\'), '%', '\%'), '_', '\_') || '%';
  end if;

  return query
  with pay as (
    select p.membership_id as mid, sum(p.amount) as amt
    from public.payments p
    where p.library_id = p_lib and p.status = 'valid'
    group by p.membership_id
  ),
  mb as (
    select m.id as mid, m.student_id as sid, m.fee_amount as fee_amt, coalesce(pay.amt, 0) as paid_amt
    from public.memberships m
    left join pay on pay.mid = m.id
    where m.library_id = p_lib
  ),
  sb as (
    select mb.sid, sum(mb.fee_amt - mb.paid_amt) as total
    from mb
    group by mb.sid
  )
  select
    s.id,
    lm.id,
    s.name,
    s.father_name,
    s.phone,
    s.status,
    seat.seat_no,
    sh.txt,
    lm.start_date,
    lm.end_date,
    (lm.end_date - v_today)::int,
    case when lm.id is null then 'none'
         when lm.status = 'closed' then 'closed'
         when lm.end_date >= v_today then 'running'
         when lm.hold_until >= v_today then 'held'
         else 'lapsed' end,
    lm.fee_amount,
    case when v_money then mbl.paid_amt end,
    case when v_money then lm.fee_amount - mbl.paid_amt end,
    case when v_money then coalesce(sbl.total, 0) end,
    count(*) over()
  from public.students s
  left join lateral (
    select m.*
    from public.memberships m
    where m.student_id = s.id and m.library_id = p_lib
    order by (m.status = 'active') desc, m.end_date desc, m.created_at desc
    limit 1
  ) lm on true
  left join public.seats seat on seat.id = lm.seat_id
  left join lateral (
    select string_agg(ts.name, ', ' order by ts.start_min) as txt
    from public.membership_shifts ms
    join public.time_slots ts on ts.id = ms.slot_id and ts.library_id = ms.library_id
    where ms.membership_id = lm.id
  ) sh on true
  left join mb mbl on mbl.mid = lm.id
  left join sb sbl on sbl.sid = s.id
  where s.library_id = p_lib
    and (p_status = 'all' or s.status = p_status)
    and (v_q is null or (
          (v_digits and v_seat is not null and (seat.seat_no = v_seat or s.phone like v_dlike))
       or (v_digits and v_seat is null and s.phone like v_dlike)
       or (not v_digits and (s.name ilike v_like or s.father_name ilike v_like))
    ))
    and (p_expiry is null or (lm.status = 'active' and (
          case p_expiry
            when 'today'   then lm.end_date = v_today
            when 'next3'   then lm.end_date between v_today and v_today + 3
            when 'next7'   then lm.end_date between v_today and v_today + 7
            when 'next15'  then lm.end_date between v_today and v_today + 15
            when 'running' then lm.end_date >= v_today
            when 'expired' then lm.end_date < v_today
            when 'held'    then lm.end_date < v_today and lm.hold_until >= v_today
            when 'lapsed'  then lm.hold_until < v_today
            else false
          end)))
    and (p_from is null or lm.end_date >= p_from)
    and (p_to   is null or lm.end_date <= p_to)
    and (p_slot_id is null or exists (
          select 1 from public.membership_shifts x
          where x.membership_id = lm.id and x.slot_id = p_slot_id))
    and (p_has_balance is null or ((coalesce(sbl.total, 0) > 0) = p_has_balance))
    and (p_fee_type is null or (lm.id is not null and (
          case p_fee_type
            when 'full'    then (lm.fee_amount - mbl.paid_amt) <= 0
            when 'partial' then mbl.paid_amt > 0 and (lm.fee_amount - mbl.paid_amt) > 0
            when 'unpaid'  then mbl.paid_amt = 0 and lm.fee_amount > 0
            when 'due'     then (lm.fee_amount - mbl.paid_amt) > 0
            else false
          end)))
    and (p_joined_from is null or s.joined_on >= p_joined_from)
    and (p_joined_to   is null or s.joined_on <= p_joined_to)
    and ((p_pd_from is null and p_pd_to is null) or exists (
          select 1
          from mb x join public.memberships m2 on m2.id = x.mid
          where x.sid = s.id and (x.fee_amt - x.paid_amt) > 0
            and (p_pd_from is null or m2.start_date >= p_pd_from)
            and (p_pd_to   is null or m2.start_date <= p_pd_to)))
  order by lm.end_date asc nulls last, s.name, s.id
  limit v_limit offset v_offset;
end;
$$;

revoke all on function public.search_students(uuid,text,text,text,date,date,uuid,boolean,int,int,text,date,date,date,date)
  from public, anon, authenticated;
grant execute on function public.search_students(uuid,text,text,text,date,date,uuid,boolean,int,int,text,date,date,date,date)
  to authenticated;

notify pgrst, 'reload schema';

-- Check: ye 1 row deni chahiye: functions = 1, authenticated_can_run = true, anon_can_run = false
select count(*) as functions,
       bool_and(has_function_privilege('authenticated', p.oid, 'execute')) as authenticated_can_run,
       bool_or(has_function_privilege('anon', p.oid, 'execute')) as anon_can_run
from pg_proc p join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public' and p.proname = 'search_students';
