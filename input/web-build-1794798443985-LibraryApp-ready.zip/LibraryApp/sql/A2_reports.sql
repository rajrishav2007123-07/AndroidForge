-- =====================================================================
-- A2: date_report (future date tak ka hisaab) + period_report (mahina / date range)
-- Dono sirf wahi dekh sakte hain jinke paas paise dekhne ki permission hai (owner hamesha).
-- Ek hi baar me poora Run karein.
-- =====================================================================

create or replace function public.date_report(p_lib uuid, p_to date)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_today date := public.today_ist();
  v_res   jsonb;
begin
  perform public.require_member(p_lib);
  if not public.lib_can_see_money(p_lib) then
    raise exception 'Is report ke liye payment ya report ki permission chahiye' using errcode = '42501';
  end if;
  if p_to is null or p_to < v_today then
    raise exception 'Aaj ya aage ki date chunein' using errcode = '22023';
  end if;
  if p_to > v_today + 366 then
    raise exception 'Date 1 saal se zyada aage ki nahi ho sakti' using errcode = '22023';
  end if;

  with pay as (
    select p.membership_id as mid, sum(p.amount) as amt
    from public.payments p
    where p.library_id = p_lib and p.status = 'valid'
    group by p.membership_id
  ),
  am as (  -- active students ki active memberships
    select m.id, m.student_id, m.end_date, m.hold_until, m.fee_amount,
           coalesce(pay.amt, 0) as paid
    from public.memberships m
    join public.students s on s.id = m.student_id and s.library_id = p_lib and s.status = 'active'
    left join pay on pay.mid = m.id
    where m.library_id = p_lib and m.status = 'active'
  ),
  allbal as ( -- active students ki saari memberships ka bakaya
    select m.student_id, sum(m.fee_amount - coalesce(pay.amt, 0)) as bal
    from public.memberships m
    join public.students s on s.id = m.student_id and s.library_id = p_lib and s.status = 'active'
    left join pay on pay.mid = m.id
    where m.library_id = p_lib
    group by m.student_id
  ),
  tl as (
    select am.end_date as d, count(*) as n
    from am
    where am.end_date between v_today and p_to
    group by am.end_date
  )
  select jsonb_build_object(
    'as_on', v_today,
    'to', p_to,
    'expiring_count',  (select count(*) from am where end_date between v_today and p_to),
    'expiring_fee',    (select coalesce(sum(fee_amount), 0) from am where end_date between v_today and p_to),
    'expired_held',    (select count(*) from am where end_date < v_today and hold_until >= v_today),
    'expired_lapsed',  (select count(*) from am where hold_until < v_today),
    'timeline',        (select coalesce(jsonb_agg(jsonb_build_object('date', d, 'count', n) order by d), '[]'::jsonb) from tl),
    'students_with_balance', (select count(*) from allbal where bal > 0),
    'total_balance',   (select coalesce(sum(bal), 0) from allbal where bal > 0),
    'full_count',      (select count(*) from am where fee_amount - paid <= 0),
    'partial_count',   (select count(*) from am where paid > 0 and fee_amount - paid > 0),
    'partial_due',     (select coalesce(sum(fee_amount - paid), 0) from am where paid > 0 and fee_amount - paid > 0),
    'unpaid_count',    (select count(*) from am where paid = 0 and fee_amount > 0),
    'unpaid_due',      (select coalesce(sum(fee_amount), 0) from am where paid = 0 and fee_amount > 0)
  ) into v_res;

  return v_res;
end;
$$;

create or replace function public.period_report(p_lib uuid, p_from date, p_to date)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_res jsonb;
begin
  perform public.require_member(p_lib);
  if not public.lib_can_see_money(p_lib) then
    raise exception 'Is report ke liye payment ya report ki permission chahiye' using errcode = '42501';
  end if;
  if p_from is null or p_to is null or p_to < p_from then
    raise exception 'Date sahi chunein (se <= tak)' using errcode = '22023';
  end if;
  if p_to - p_from > 366 then
    raise exception 'Period 1 saal se zyada ka nahi ho sakta' using errcode = '22023';
  end if;

  with pay as (
    select p.membership_id as mid, sum(p.amount) as amt
    from public.payments p
    where p.library_id = p_lib and p.status = 'valid'
    group by p.membership_id
  ),
  pm as ( -- is period me shuru hui memberships
    select m.id, m.student_id, m.fee_amount, coalesce(pay.amt, 0) as paid
    from public.memberships m
    left join pay on pay.mid = m.id
    where m.library_id = p_lib and m.start_date between p_from and p_to
  ),
  allbal as (
    select m.student_id, sum(m.fee_amount - coalesce(pay.amt, 0)) as bal
    from public.memberships m
    left join pay on pay.mid = m.id
    where m.library_id = p_lib
    group by m.student_id
  )
  select jsonb_build_object(
    'from', p_from,
    'to', p_to,
    'new_students',      (select count(*) from public.students s
                           where s.library_id = p_lib and s.joined_on between p_from and p_to),
    'period_memberships',(select count(*) from pm),
    'period_fee',        (select coalesce(sum(fee_amount), 0) from pm),
    'period_paid',       (select coalesce(sum(paid), 0) from pm),
    'period_due',        (select coalesce(sum(fee_amount - paid), 0) from pm where fee_amount - paid > 0),
    'period_due_students',(select count(distinct student_id) from pm where fee_amount - paid > 0),
    'full_count',        (select count(*) from pm where fee_amount - paid <= 0),
    'partial_count',     (select count(*) from pm where paid > 0 and fee_amount - paid > 0),
    'unpaid_count',      (select count(*) from pm where paid = 0 and fee_amount > 0),
    'overall_due',       (select coalesce(sum(bal), 0) from allbal where bal > 0),
    'overall_due_students',(select count(*) from allbal where bal > 0)
  ) into v_res;

  return v_res;
end;
$$;

revoke all on function public.date_report(uuid, date) from public, anon, authenticated;
revoke all on function public.period_report(uuid, date, date) from public, anon, authenticated;
grant execute on function public.date_report(uuid, date) to authenticated;
grant execute on function public.period_report(uuid, date, date) to authenticated;

notify pgrst, 'reload schema';

-- Check: functions = 2, authenticated_can_run = true, anon_can_run = false
select count(*) as functions,
       bool_and(has_function_privilege('authenticated', p.oid, 'execute')) as authenticated_can_run,
       bool_or(has_function_privilege('anon', p.oid, 'execute')) as anon_can_run
from pg_proc p join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public' and p.proname in ('date_report', 'period_report');
