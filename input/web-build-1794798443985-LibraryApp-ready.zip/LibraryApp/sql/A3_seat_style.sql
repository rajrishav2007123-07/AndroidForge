-- =====================================================================
-- A3: seat map ka icon style (chair / desk / cabin / number) - poori library ke liye ek
-- =====================================================================

alter table public.libraries
  add column if not exists seat_style text not null default 'chair';

do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'libraries_seat_style_check') then
    alter table public.libraries
      add constraint libraries_seat_style_check check (seat_style in ('chair','desk','cabin','number'));
  end if;
end $$;

grant select (seat_style) on public.libraries to authenticated;

create or replace function public.set_seat_style(p_lib uuid, p_style text)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
begin
  perform public.require_perm(p_lib, 'owner_only');
  if p_style is null or p_style not in ('chair','desk','cabin','number') then
    raise exception 'Style chair, desk, cabin ya number hi ho sakta hai' using errcode = '22023';
  end if;
  update public.libraries set seat_style = p_style where id = p_lib;
  return jsonb_build_object('seat_style', p_style);
end;
$$;

revoke all on function public.set_seat_style(uuid, text) from public, anon, authenticated;
grant execute on function public.set_seat_style(uuid, text) to authenticated;

notify pgrst, 'reload schema';

-- Check: seat_style_column = 1, function_ready = true
select (select count(*) from information_schema.columns
         where table_schema = 'public' and table_name = 'libraries' and column_name = 'seat_style') as seat_style_column,
       (select has_function_privilege('authenticated', 'public.set_seat_style(uuid,text)', 'execute')) as function_ready;
