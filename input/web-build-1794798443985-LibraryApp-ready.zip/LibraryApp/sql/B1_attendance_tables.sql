-- =====================================================================
-- B1: Attendance ke tables
--   attendance        : roz ka ek record (check-in / check-out)
--   library_secrets   : library ka gupt beej (jisse roz ka 6-digit code banta hai) - API se band
--   attendance_fail   : galat code ki koshishein (guess karne se rokne ke liye) - API se band
-- =====================================================================

create table if not exists public.attendance (
  id          uuid primary key default gen_random_uuid(),
  library_id  uuid not null references public.libraries(id) on delete cascade,
  student_id  uuid not null references public.students(id)  on delete cascade,
  att_date    date not null,
  check_in    timestamptz not null default now(),
  check_out   timestamptz,
  method      text not null default 'code' check (method in ('code','manual')),
  created_at  timestamptz not null default now(),
  constraint attendance_one_per_day unique (student_id, att_date),
  constraint attendance_out_after_in check (check_out is null or check_out >= check_in)
);
create index if not exists attendance_lib_date_idx on public.attendance (library_id, att_date);

create table if not exists public.library_secrets (
  library_id  uuid primary key references public.libraries(id) on delete cascade,
  att_secret  text not null default replace(gen_random_uuid()::text || gen_random_uuid()::text, '-', '')
);

create table if not exists public.attendance_fail (
  id          bigint generated always as identity primary key,
  student_id  uuid not null references public.students(id) on delete cascade,
  at          timestamptz not null default now()
);
create index if not exists attendance_fail_idx on public.attendance_fail (student_id, at);

alter table public.attendance       enable row level security;
alter table public.library_secrets  enable row level security;
alter table public.attendance_fail  enable row level security;

drop policy if exists attendance_select on public.attendance;
create policy attendance_select on public.attendance for select to authenticated
  using (public.lib_role(library_id) is not null or public.is_my_student(student_id));

revoke all on public.attendance      from public, anon, authenticated;
revoke all on public.library_secrets from public, anon, authenticated;
revoke all on public.attendance_fail from public, anon, authenticated;
grant select on public.attendance to authenticated;

-- Check: 3 tables, sirf attendance par authenticated ko select, baaki par kuch nahi
select
  (select count(*) from pg_tables where schemaname = 'public'
     and tablename in ('attendance','library_secrets','attendance_fail')) as tables_created,
  has_table_privilege('authenticated', 'public.attendance', 'select')        as att_select_ok,
  has_table_privilege('authenticated', 'public.attendance', 'insert')        as att_insert_must_be_false,
  has_table_privilege('authenticated', 'public.library_secrets', 'select')   as secrets_select_must_be_false,
  has_table_privilege('anon', 'public.attendance', 'select')                 as anon_select_must_be_false;
