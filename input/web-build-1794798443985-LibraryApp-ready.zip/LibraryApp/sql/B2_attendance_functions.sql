-- =====================================================================
-- B2: Attendance ke functions
--   attendance_code(lib)           : owner/staff ko aaj ka 6-digit code
--   mark_attendance(lib, code, in/out) : student apna check-in / check-out lagata hai
--   attendance_today(lib, date)    : kaun present, kaun absent
--   attendance_report(lib, from, to): din-wise aur student-wise
-- Ek hi baar me poora Run karein.
-- =====================================================================

-- andar ka helper (app se seedha nahi bulaya ja sakta)
create or replace function public.att_code(p_lib uuid, p_date date)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_secret text;
begin
  select att_secret into v_secret from public.library_secrets where library_id = p_lib;
  if v_secret is null then
    insert into public.library_secrets (library_id) values (p_lib) on conflict (library_id) do nothing;
    select att_secret into v_secret from public.library_secrets where library_id = p_lib;
  end if;
  return lpad(((('x' || substr(md5(v_secret || p_date::text), 1, 7))::bit(28)::int) % 1000000)::text, 6, '0');
end;
$$;

create or replace function public.attendance_code(p_lib uuid)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_today date := public.today_ist();
begin
  perform public.require_member(p_lib);
  return jsonb_build_object('date', v_today, 'code', public.att_code(p_lib, v_today));
end;
$$;

create or replace function public.mark_attendance(p_lib uuid, p_code text, p_action text default 'in')
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid   uuid := auth.uid();
  v_today date := public.today_ist();
  v_sid   uuid;
  v_stat  text;
  v_fails int;
  v_row   public.attendance%rowtype;
begin
  if v_uid is null then
    raise exception 'Login zaroori hai' using errcode = '28000';
  end if;
  if p_action is null or p_action not in ('in','out') then
    raise exception 'Action in ya out hi ho sakta hai' using errcode = '22023';
  end if;

  select s.id, s.status into v_sid, v_stat
  from public.students s
  where s.library_id = p_lib and s.user_id = v_uid
  limit 1;
  if v_sid is null then
    raise exception 'Aap is library ke student nahi hain' using errcode = '42501';
  end if;
  if v_stat <> 'active' then
    raise exception 'Aapka account active nahi hai' using errcode = '42501';
  end if;
  if not exists (select 1 from public.memberships m
                  where m.student_id = v_sid and m.library_id = p_lib and m.status = 'active'
                    and v_today between m.start_date and m.end_date) then
    raise exception 'Aapki membership abhi chalu nahi hai' using errcode = 'P0001';
  end if;

  delete from public.attendance_fail where at < now() - interval '1 day';
  select count(*) into v_fails from public.attendance_fail f
   where f.student_id = v_sid and f.at > now() - interval '10 minutes';
  if v_fails >= 5 then
    return jsonb_build_object('ok', false, 'error', 'Bahut galat code lage. 10 minute baad dobara koshish karein.');
  end if;

  if coalesce(trim(p_code), '') <> public.att_code(p_lib, v_today) then
    insert into public.attendance_fail (student_id) values (v_sid);
    return jsonb_build_object('ok', false, 'error', 'Code galat hai. Library me lage code se milayein.');
  end if;

  select * into v_row from public.attendance a where a.student_id = v_sid and a.att_date = v_today;

  if p_action = 'in' then
    if found then
      raise exception 'Aaj ka check-in ho chuka hai' using errcode = 'P0001';
    end if;
    insert into public.attendance (library_id, student_id, att_date) values (p_lib, v_sid, v_today)
    returning * into v_row;
    return jsonb_build_object('ok', true, 'action', 'in', 'at', v_row.check_in);
  end if;

  -- out
  if not found then
    raise exception 'Pehle check-in karein' using errcode = 'P0001';
  end if;
  if v_row.check_out is not null then
    raise exception 'Aaj ka check-out ho chuka hai' using errcode = 'P0001';
  end if;
  update public.attendance set check_out = now() where id = v_row.id returning * into v_row;
  return jsonb_build_object('ok', true, 'action', 'out', 'at', v_row.check_out);
end;
$$;

create or replace function public.attendance_today(p_lib uuid, p_date date default null)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_d    date := coalesce(p_date, public.today_ist());
  v_pres jsonb;
  v_np   int;
  v_abs  jsonb;
  v_na   int;
begin
  perform public.require_member(p_lib);

  select coalesce(jsonb_agg(jsonb_build_object(
           'student_id', s.id, 'name', s.name, 'phone', s.phone,
           'check_in', a.check_in, 'check_out', a.check_out) order by a.check_in), '[]'::jsonb),
         count(*)
    into v_pres, v_np
  from public.attendance a
  join public.students s on s.id = a.student_id
  where a.library_id = p_lib and a.att_date = v_d;

  with ab as (
    select distinct s.id, s.name, s.phone
    from public.students s
    join public.memberships m on m.student_id = s.id and m.library_id = p_lib
         and m.status = 'active' and v_d between m.start_date and m.end_date
    where s.library_id = p_lib and s.status = 'active'
      and not exists (select 1 from public.attendance a
                       where a.student_id = s.id and a.att_date = v_d)
  )
  select (select count(*) from ab),
         (select coalesce(jsonb_agg(jsonb_build_object('student_id', x.id, 'name', x.name, 'phone', x.phone)
                  order by x.name), '[]'::jsonb)
            from (select * from ab order by name limit 300) x)
    into v_na, v_abs;

  return jsonb_build_object('date', v_d, 'present', v_np, 'absent', v_na,
                            'present_rows', v_pres, 'absent_rows', v_abs);
end;
$$;

create or replace function public.attendance_report(p_lib uuid, p_from date, p_to date)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_days jsonb;
  v_stu  jsonb;
  v_tot  int;
begin
  perform public.require_member(p_lib);
  if p_from is null or p_to is null or p_to < p_from or p_to - p_from > 92 then
    raise exception 'Date sahi chunein (zyada se zyada 93 din)' using errcode = '22023';
  end if;

  select coalesce(jsonb_agg(jsonb_build_object('date', d, 'present', n) order by d), '[]'::jsonb),
         coalesce(sum(n), 0)
    into v_days, v_tot
  from (select a.att_date as d, count(*) as n
          from public.attendance a
         where a.library_id = p_lib and a.att_date between p_from and p_to
         group by a.att_date) x;

  select coalesce(jsonb_agg(jsonb_build_object(
           'student_id', y.id, 'name', y.name, 'days', y.dp, 'last', y.last_day)
           order by y.dp desc, y.name), '[]'::jsonb)
    into v_stu
  from (select s.id, s.name, count(*) as dp, max(a.att_date) as last_day
          from public.attendance a
          join public.students s on s.id = a.student_id
         where a.library_id = p_lib and a.att_date between p_from and p_to
         group by s.id, s.name
         order by count(*) desc, s.name
         limit 200) y;

  return jsonb_build_object('from', p_from, 'to', p_to, 'total_checkins', v_tot,
                            'days', v_days, 'students', v_stu);
end;
$$;

revoke all on function public.att_code(uuid, date) from public, anon, authenticated;
revoke all on function public.attendance_code(uuid) from public, anon, authenticated;
revoke all on function public.mark_attendance(uuid, text, text) from public, anon, authenticated;
revoke all on function public.attendance_today(uuid, date) from public, anon, authenticated;
revoke all on function public.attendance_report(uuid, date, date) from public, anon, authenticated;
grant execute on function public.attendance_code(uuid) to authenticated;
grant execute on function public.mark_attendance(uuid, text, text) to authenticated;
grant execute on function public.attendance_today(uuid, date) to authenticated;
grant execute on function public.attendance_report(uuid, date, date) to authenticated;

notify pgrst, 'reload schema';

-- Check: functions = 5, app_callable = 4 (att_code band hona chahiye), anon_can_run = false
select count(*) as functions,
       count(*) filter (where has_function_privilege('authenticated', p.oid, 'execute')) as app_callable,
       bool_or(has_function_privilege('anon', p.oid, 'execute')) as anon_can_run
from pg_proc p join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public'
  and p.proname in ('att_code','attendance_code','mark_attendance','attendance_today','attendance_report');
