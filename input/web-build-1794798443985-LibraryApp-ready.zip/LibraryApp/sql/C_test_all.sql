-- =====================================================================
-- C: Test. A1, A2, A3, B1, B2 chalane ke BAAD ek hi baar me poora Run karein.
-- Owner ban kar naye functions bulata hai (kuch badalta nahi). Aakhir me ek table aayegi:
-- har test ka result "OK ..." ya "ERROR: ...". Poori table mujhe bhej dein.
-- =====================================================================
create temp table test_results (no int, test text, result text);

create or replace function pg_temp.run(n int, t text, q text) returns void
language plpgsql as $$
declare v_out text;
begin
  execute q into v_out;
  insert into test_results values (n, t, 'OK ' || left(coalesce(v_out, 'null'), 400));
exception when others then
  insert into test_results values (n, t, 'ERROR: ' || sqlerrm);
end $$;

do $$
declare
  v_uid uuid := (select id from auth.users where email = 'pantarantar2007@gmail.com');
  v_lib text := 'eb63eb1e-5ce9-4582-b8ad-13027d0f445a';
begin
  perform set_config('request.jwt.claims',
    json_build_object('sub', v_uid::text, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', v_uid::text, true);

  perform pg_temp.run(1,  'search basic (rows)',
    format('select count(*)::text from public.search_students(%L)', v_lib));
  perform pg_temp.run(2,  'fee type: due (rows)',
    format('select count(*)::text from public.search_students(%L, p_fee_type => ''due'')', v_lib));
  perform pg_temp.run(3,  'fee type: full (rows)',
    format('select count(*)::text from public.search_students(%L, p_fee_type => ''full'')', v_lib));
  perform pg_temp.run(4,  'fee type: partial (rows)',
    format('select count(*)::text from public.search_students(%L, p_fee_type => ''partial'')', v_lib));
  perform pg_temp.run(5,  'fee type: unpaid (rows)',
    format('select count(*)::text from public.search_students(%L, p_fee_type => ''unpaid'')', v_lib));
  perform pg_temp.run(6,  'joined last 30 days (rows)',
    format('select count(*)::text from public.search_students(%L, p_status => ''all'', p_joined_from => current_date - 30, p_joined_to => current_date)', v_lib));
  perform pg_temp.run(7,  'period-due filter (rows)',
    format('select count(*)::text from public.search_students(%L, p_pd_from => current_date - 30, p_pd_to => current_date)', v_lib));
  perform pg_temp.run(8,  'date_report +30 days',
    format('select public.date_report(%L, current_date + 30)::text', v_lib));
  perform pg_temp.run(9,  'period_report this month',
    format('select public.period_report(%L, date_trunc(''month'', current_date)::date, current_date)::text', v_lib));
  perform pg_temp.run(10, 'attendance_code',
    format('select public.attendance_code(%L)::text', v_lib));
  perform pg_temp.run(11, 'attendance_today',
    format('select public.attendance_today(%L)::text', v_lib));
  perform pg_temp.run(12, 'attendance_report 7 days',
    format('select public.attendance_report(%L, current_date - 7, current_date)::text', v_lib));
  perform pg_temp.run(13, 'mark_attendance as owner (must be BLOCKED: not a student)',
    format('select public.mark_attendance(%L, ''000000'', ''in'')::text', v_lib));
  perform pg_temp.run(14, 'bad fee type (must be ERROR)',
    format('select count(*)::text from public.search_students(%L, p_fee_type => ''xyz'')', v_lib));
end $$;

select * from test_results order by no;
