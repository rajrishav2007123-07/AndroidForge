# Tuition App (React + Vite + Supabase)

## Important
Ye **web app** hai. Android Studio se APK **nahi** banega.
Phone pe chalane ke liye browser me open karo, ya baad me Capacitor se wrap kar sakte ho.

## Supabase (already connected)
- URL: https://iaknxhluczcrbfrxkywi.supabase.co
- Key: `.env` me set hai

## Run (computer pe)
```bash
cd tuition-app
npm install
npm run dev
```
Browser me http://localhost:5173 khulega.

## Build (static site)
```bash
npm run build
```
Output: `dist/` folder — kisi bhi static host pe daal sakte ho (Netlify, Vercel, etc.)

## Required Supabase tables (RLS ke saath)
App in tables ko use karti hai:
- profiles (id, institute_id, role, name, phone)
- students
- batches
- attendance
- fee_payments
- tests
- test_results
- notices

Agar tables nahi hain to pehle Supabase SQL Editor me schema create karo.

## Login
Pehle signup/login karo. `profiles` me us user ki row honi chahiye with role = admin | teacher | parent.
