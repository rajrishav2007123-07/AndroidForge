import type { ReactElement } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './lib';
import {
  Login, AdminHome, ParentHome, StudentsPage,
  AttendancePage, FeesPage, TestsPage, NoticesPage,
} from './pages';

function Protected({
  children, roles,
}: {
  children: ReactElement;
  roles?: ('admin' | 'teacher' | 'parent')[];
}) {
  const { profile, loading } = useAuth();
  if (loading) return <div className="p-8 text-center text-gray-500">Loading…</div>;
  if (!profile) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(profile.role)) return <Navigate to="/" replace />;
  return children;
}

function Home() {
  const { profile, loading } = useAuth();
  if (loading) return <div className="p-8 text-center">Loading…</div>;
  if (!profile) return <Navigate to="/login" replace />;
  return profile.role === 'parent' ? <ParentHome /> : <AdminHome />;
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<Home />} />
        <Route path="/students"   element={<Protected roles={['admin','teacher']}><StudentsPage /></Protected>} />
        <Route path="/attendance" element={<Protected roles={['admin','teacher']}><AttendancePage /></Protected>} />
        <Route path="/fees"       element={<Protected roles={['admin','teacher']}><FeesPage /></Protected>} />
        <Route path="/tests"      element={<Protected roles={['admin','teacher']}><TestsPage /></Protected>} />
        <Route path="/notices"    element={<Protected roles={['admin','teacher']}><NoticesPage /></Protected>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}