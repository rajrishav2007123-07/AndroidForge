import { createClient } from '@supabase/supabase-js';
import { useEffect, useState } from 'react';

export const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY,
);

// ---------- TYPES ----------
export type Role = 'admin' | 'teacher' | 'parent';

export interface Profile {
  id: string;
  institute_id: string | null;
  role: Role;
  name: string;
  phone: string | null;
}

export interface Student {
  id: string;
  institute_id: string;
  batch_id: string | null;
  name: string;
  phone: string | null;
  parent_phone: string;
  parent_email: string | null;
  admission_date: string;
  monthly_fee: number;
  active: boolean;
}

export interface Batch {
  id: string;
  institute_id: string;
  name: string;
  subject: string | null;
  timing: string | null;
}

export interface Test {
  id: string;
  institute_id: string;
  batch_id: string | null;
  name: string;
  subject: string | null;
  max_marks: number;
  test_date: string;
}

export interface FeePayment {
  id: string;
  student_id: string;
  amount: number;
  month: string;
  mode: 'cash' | 'upi' | 'online' | null;
  receipt_no: string | null;
  notes: string | null;
  paid_at: string;
}

export interface Notice {
  id: string;
  institute_id: string;
  title: string;
  body: string | null;
  created_at: string;
}

// ---------- AUTH HOOK ----------
export function useAuth() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  async function fetchProfile() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setProfile(null); setLoading(false); return; }
    const { data } = await supabase
      .from('profiles').select('*').eq('id', user.id).single();
    setProfile((data as Profile) ?? null);
    setLoading(false);
  }

  useEffect(() => {
    fetchProfile();
    const { data: sub } = supabase.auth.onAuthStateChange(() => fetchProfile());
    return () => sub.subscription.unsubscribe();
  }, []);

  return {
    profile,
    loading,
    signOut: () => supabase.auth.signOut(),
  };
}

// ---------- HELPERS ----------
export function currentMonth(): string {
  return new Date().toISOString().slice(0, 7); // 'YYYY-MM'
}

export function monthLabel(m: string): string {
  const [y, mm] = m.split('-');
  const names = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  return `${names[parseInt(mm) - 1]} ${y}`;
}

// Admission date se aaj tak ke saare month strings
export function monthsFrom(startDate: string): string[] {
  const start = new Date(startDate + 'T00:00:00');
  const end = new Date();
  const out: string[] = [];
  const cur = new Date(start.getFullYear(), start.getMonth(), 1);
  while (cur <= end) {
    const y = cur.getFullYear();
    const m = String(cur.getMonth() + 1).padStart(2, '0');
    out.push(`${y}-${m}`);
    cur.setMonth(cur.getMonth() + 1);
  }
  return out;
}

// Kitne months pending hain (fees due)
export function pendingMonths(
  admission_date: string,
  monthly_fee: number,
  paid: { month: string; amount: number }[],
): { month: string; due: number }[] {
  if (monthly_fee <= 0) return [];
  const all = monthsFrom(admission_date);
  const paidByMonth: Record<string, number> = {};
  for (const p of paid) {
    paidByMonth[p.month] = (paidByMonth[p.month] ?? 0) + Number(p.amount);
  }
  return all
    .filter((m) => (paidByMonth[m] ?? 0) < monthly_fee)
    .map((m) => ({ month: m, due: monthly_fee - (paidByMonth[m] ?? 0) }));
}

export function formatINR(n: number): string {
  return '₹' + new Intl.NumberFormat('en-IN').format(n);
}

export function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}