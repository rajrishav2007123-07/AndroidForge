import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  supabase, useAuth,
  type Student, type Batch, type Test, type FeePayment, type Notice,
  currentMonth, monthLabel, pendingMonths, formatINR, todayISO,
} from './lib';

// ============================================
// LOGIN
// ============================================
export function Login() {
  const nav = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSignup, setIsSignup] = useState(false);
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setMsg(''); setBusy(true);
    try {
      if (isSignup) {
        const { error } = await supabase.auth.signUp({
          email, password,
          options: { data: { role: 'parent' } },
        });
        setMsg(error ? error.message : 'Signup done! Email verify karein, phir login karein.');
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) setMsg(error.message);
        else nav('/');
      }
    } finally { setBusy(false); }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <form onSubmit={submit} className="bg-white p-6 rounded-xl shadow w-full max-w-sm space-y-3">
        <h1 className="text-xl font-bold text-center">
          {isSignup ? 'Parent Signup' : 'Login'}
        </h1>
        <input className="w-full border p-2 rounded" placeholder="Email" type="email"
               value={email} onChange={e => setEmail(e.target.value)} required />
        <input className="w-full border p-2 rounded" placeholder="Password" type="password"
               value={password} onChange={e => setPassword(e.target.value)} required />
        <button disabled={busy}
          className="w-full bg-indigo-600 text-white py-2 rounded font-medium disabled:opacity-50">
          {busy ? 'Please wait…' : isSignup ? 'Sign up' : 'Login'}
        </button>
        {msg && <p className="text-sm text-red-600">{msg}</p>}
        <button type="button" onClick={() => setIsSignup(!isSignup)}
                className="text-sm text-indigo-600 w-full">
          {isSignup ? 'Already have account? Login' : 'New parent? Sign up'}
        </button>
      </form>
    </div>
  );
}

// ============================================
// ADMIN HOME
// ============================================
export function AdminHome() {
  const { profile, signOut } = useAuth();
  const cards = [
    { to: '/attendance', label: '📋 Attendance', desc: 'Daily mark karo' },
    { to: '/students',   label: '👨‍🎓 Students',   desc: 'Add / edit students' },
    { to: '/fees',       label: '💰 Fees',        desc: 'Payment entry + list' },
    { to: '/tests',      label: '📝 Tests',       desc: 'Create + marks entry' },
    { to: '/notices',    label: '📢 Notices',     desc: 'Announcements' },
  ];
  return (
    <div className="max-w-2xl mx-auto p-4 space-y-3">
      <div className="flex justify-between items-center">
        <h1 className="text-xl font-bold">Admin — {profile?.name}</h1>
        <button onClick={signOut} className="text-sm text-red-600">Logout</button>
      </div>
      {cards.map(c => (
        <Link key={c.to} to={c.to}
              className="block bg-white p-4 rounded-xl shadow-sm hover:shadow">
          <p className="font-medium">{c.label}</p>
          <p className="text-xs text-gray-500">{c.desc}</p>
        </Link>
      ))}
    </div>
  );
}

// ============================================
// STUDENTS (admin)
// ============================================
export function StudentsPage() {
  const { profile, signOut } = useAuth();
  const [list, setList] = useState<Student[]>([]);
  const [batches, setBatches] = useState<Batch[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: '', parent_phone: '', parent_email: '', batch_id: '', monthly_fee: 0 });

  async function load() {
    const [s, b] = await Promise.all([
      supabase.from('students').select('*').order('name'),
      supabase.from('batches').select('*').order('name'),
    ]);
    setList((s.data ?? []) as Student[]);
    setBatches((b.data ?? []) as Batch[]);
  }
  useEffect(() => { load(); }, []);

  async function add(e: React.FormEvent) {
    e.preventDefault();
    if (!profile?.institute_id) return;
    const { error } = await supabase.from('students').insert({
      institute_id: profile.institute_id,
      name: form.name,
      parent_phone: form.parent_phone,
      parent_email: form.parent_email || null,
      batch_id: form.batch_id || null,
      monthly_fee: Number(form.monthly_fee) || 0,
    });
    if (error) { alert(error.message); return; }
    setForm({ name: '', parent_phone: '', parent_email: '', batch_id: '', monthly_fee: 0 });
    setShowForm(false);
    load();
  }

  async function toggle(s: Student) {
    await supabase.from('students').update({ active: !s.active }).eq('id', s.id);
    load();
  }

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-3">
      <div className="flex justify-between items-center">
        <Link to="/" className="text-sm text-indigo-600">← Back</Link>
        <button onClick={signOut} className="text-sm text-red-600">Logout</button>
      </div>
      <div className="flex justify-between items-center">
        <h1 className="text-xl font-bold">Students ({list.length})</h1>
        <button onClick={() => setShowForm(!showForm)}
                className="bg-indigo-600 text-white px-3 py-1 rounded text-sm">
          {showForm ? 'Cancel' : '+ Add'}
        </button>
      </div>

      {showForm && (
        <form onSubmit={add} className="bg-white p-4 rounded-xl shadow-sm space-y-2">
          <input className="w-full border p-2 rounded" placeholder="Student name" required
                 value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
          <input className="w-full border p-2 rounded" placeholder="Parent phone (WhatsApp)" required
                 value={form.parent_phone} onChange={e => setForm({ ...form, parent_phone: e.target.value })} />
          <input className="w-full border p-2 rounded" placeholder="Parent email (for login)" type="email"
                 value={form.parent_email} onChange={e => setForm({ ...form, parent_email: e.target.value })} />
          <select className="w-full border p-2 rounded"
                  value={form.batch_id} onChange={e => setForm({ ...form, batch_id: e.target.value })}>
            <option value="">— No batch —</option>
            {batches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
          </select>
          <input className="w-full border p-2 rounded" placeholder="Monthly fee (₹)" type="number"
                 value={form.monthly_fee || ''}
                 onChange={e => setForm({ ...form, monthly_fee: Number(e.target.value) })} />
          <button className="w-full bg-green-600 text-white py-2 rounded">Save</button>
        </form>
      )}

      {list.map(s => (
        <div key={s.id} className="bg-white p-3 rounded-xl shadow-sm flex justify-between items-center">
          <div>
            <p className="font-medium">{s.name} {!s.active && <span className="text-xs text-red-500">(inactive)</span>}</p>
            <p className="text-xs text-gray-500">
              {s.parent_phone} · ₹{s.monthly_fee}/mo
              {s.parent_email && <> · {s.parent_email}</>}
            </p>
          </div>
          <button onClick={() => toggle(s)} className="text-xs text-gray-500 underline">
            {s.active ? 'Deactivate' : 'Activate'}
          </button>
        </div>
      ))}
    </div>
  );
}

// ============================================
// ATTENDANCE (admin)
// ============================================
export function AttendancePage() {
  const [students, setStudents] = useState<Student[]>([]);
  const [marks, setMarks] = useState<Record<string, 'present' | 'absent' | 'leave'>>({});
  const [date, setDate] = useState(todayISO());
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    supabase.from('students').select('*').eq('active', true).order('name')
      .then(({ data }) => setStudents((data ?? []) as Student[]));
  }, []);

  // Load existing attendance for selected date
  useEffect(() => {
    supabase.from('attendance').select('student_id,status').eq('date', date)
      .then(({ data }) => {
        const m: Record<string, any> = {};
        (data ?? []).forEach((r: any) => { m[r.student_id] = r.status; });
        setMarks(m);
      });
  }, [date]);

  async function save() {
    const rows = students
      .filter(s => marks[s.id])
      .map(s => ({ student_id: s.id, date, status: marks[s.id] }));
    if (!rows.length) return;
    const { error } = await supabase.from('attendance')
      .upsert(rows, { onConflict: 'student_id,date' });
    if (error) { alert(error.message); return; }
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-3 pb-24">
      <div className="flex justify-between items-center">
        <Link to="/" className="text-sm text-indigo-600">← Back</Link>
        <input type="date" value={date} onChange={e => setDate(e.target.value)}
               className="border p-1 rounded" />
      </div>
      <h1 className="text-xl font-bold">Attendance</h1>
      {students.map(s => (
        <div key={s.id} className="flex items-center justify-between bg-white p-3 rounded shadow-sm">
          <span>{s.name}</span>
          <div className="flex gap-1">
            {(['present', 'absent', 'leave'] as const).map(st => (
              <button key={st} onClick={() => setMarks({ ...marks, [s.id]: st })}
                className={`px-2 py-1 rounded text-sm ${
                  marks[s.id] === st
                    ? st === 'present' ? 'bg-green-600 text-white'
                      : st === 'absent' ? 'bg-red-600 text-white'
                      : 'bg-yellow-500 text-white'
                    : 'bg-gray-100'
                }`}>
                {st[0].toUpperCase()}
              </button>
            ))}
          </div>
        </div>
      ))}
      <button onClick={save}
        className="fixed bottom-4 left-1/2 -translate-x-1/2 bg-indigo-600 text-white px-8 py-3 rounded-full shadow-lg font-medium">
        {saved ? '✓ Saved' : 'Save Attendance'}
      </button>
    </div>
  );
}

// ============================================
// FEES (admin)
// ============================================
export function FeesPage() {
  const { profile, signOut } = useAuth();
  const [students, setStudents] = useState<Student[]>([]);
  const [selected, setSelected] = useState<string>('');
  const [payments, setPayments] = useState<FeePayment[]>([]);
  const [form, setForm] = useState({ amount: 0, month: currentMonth(), mode: 'cash', receipt_no: '', notes: '' });

  useEffect(() => {
    supabase.from('students').select('*').eq('active', true).order('name')
      .then(({ data }) => setStudents((data ?? []) as Student[]));
  }, []);

  async function loadPayments() {
    if (!selected) { setPayments([]); return; }
    const { data } = await supabase.from('fee_payments')
      .select('*').eq('student_id', selected).order('paid_at', { ascending: false });
    setPayments((data ?? []) as FeePayment[]);
  }
  useEffect(() => { loadPayments(); }, [selected]);

  async function addPayment(e: React.FormEvent) {
    e.preventDefault();
    const { error } = await supabase.from('fee_payments').insert({
      student_id: selected,
      amount: Number(form.amount),
      month: form.month,
      mode: form.mode,
      receipt_no: form.receipt_no || null,
      notes: form.notes || null,
      recorded_by: profile?.id,
    });
    if (error) { alert(error.message); return; }
    setForm({ amount: 0, month: currentMonth(), mode: 'cash', receipt_no: '', notes: '' });
    loadPayments();
  }

  const stu = students.find(s => s.id === selected);
  const pending = useMemo(() => {
    if (!stu) return [];
    return pendingMonths(stu.admission_date, stu.monthly_fee, payments);
  }, [stu, payments]);

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-3">
      <div className="flex justify-between items-center">
        <Link to="/" className="text-sm text-indigo-600">← Back</Link>
        <button onClick={signOut} className="text-sm text-red-600">Logout</button>
      </div>
      <h1 className="text-xl font-bold">Fees</h1>

      <select className="w-full border p-2 rounded" value={selected}
              onChange={e => setSelected(e.target.value)}>
        <option value="">— Select student —</option>
        {students.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
      </select>

      {stu && (
        <>
          <div className="bg-white p-4 rounded-xl shadow-sm">
            <p className="font-medium">{stu.name}</p>
            <p className="text-xs text-gray-500">Monthly ₹{stu.monthly_fee} · Since {stu.admission_date}</p>
            {pending.length > 0 ? (
              <p className="mt-2 text-sm text-red-600">
                Pending: {pending.length} month(s) — {formatINR(pending.reduce((a, b) => a + b.due, 0))}
              </p>
            ) : (
              <p className="mt-2 text-sm text-green-600">All clear ✓</p>
            )}
            {pending.length > 0 && (
              <div className="mt-2 text-xs text-gray-600 space-y-1">
                {pending.slice(-6).reverse().map(p => (
                  <div key={p.month} className="flex justify-between">
                    <span>{monthLabel(p.month)}</span>
                    <span>{formatINR(p.due)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <form onSubmit={addPayment} className="bg-white p-4 rounded-xl shadow-sm space-y-2">
            <p className="font-medium text-sm">New Payment</p>
            <div className="grid grid-cols-2 gap-2">
              <input className="border p-2 rounded" type="number" placeholder="Amount ₹" required
                     value={form.amount || ''}
                     onChange={e => setForm({ ...form, amount: Number(e.target.value) })} />
              <input className="border p-2 rounded" type="month" required
                     value={form.month}
                     onChange={e => setForm({ ...form, month: e.target.value })} />
            </div>
            <select className="w-full border p-2 rounded"
                    value={form.mode}
                    onChange={e => setForm({ ...form, mode: e.target.value })}>
              <option value="cash">Cash</option>
              <option value="upi">UPI</option>
              <option value="online">Online</option>
            </select>
            <input className="w-full border p-2 rounded" placeholder="Receipt no (optional)"
                   value={form.receipt_no}
                   onChange={e => setForm({ ...form, receipt_no: e.target.value })} />
            <button className="w-full bg-green-600 text-white py-2 rounded">Add Payment</button>
          </form>

          <div className="bg-white p-4 rounded-xl shadow-sm space-y-2">
            <p className="font-medium text-sm">Payment History ({payments.length})</p>
            {payments.length === 0 && <p className="text-sm text-gray-500">No payments yet</p>}
            {payments.map(p => (
              <div key={p.id} className="flex justify-between text-sm border-b py-1">
                <span>{monthLabel(p.month)} · {p.mode}</span>
                <span className="font-medium">{formatINR(Number(p.amount))}</span>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

// ============================================
// TESTS (admin)
// ============================================
export function TestsPage() {
  const { profile, signOut } = useAuth();
  const [tests, setTests] = useState<Test[]>([]);
  const [batches, setBatches] = useState<Batch[]>([]);
  const [selected, setSelected] = useState<string>('');
  const [students, setStudents] = useState<Student[]>([]);
  const [marks, setMarks] = useState<Record<string, number>>({});
  const [form, setForm] = useState({ name: '', subject: '', max_marks: 100, batch_id: '', test_date: todayISO() });
  const [showCreate, setShowCreate] = useState(false);

  async function load() {
    const [t, b] = await Promise.all([
      supabase.from('tests').select('*').order('test_date', { ascending: false }),
      supabase.from('batches').select('*').order('name'),
    ]);
    setTests((t.data ?? []) as Test[]);
    setBatches((b.data ?? []) as Batch[]);
  }
  useEffect(() => { load(); }, []);

  async function createTest(e: React.FormEvent) {
    e.preventDefault();
    if (!profile?.institute_id) return;
    const { error } = await supabase.from('tests').insert({
      institute_id: profile.institute_id,
      name: form.name,
      subject: form.subject || null,
      max_marks: Number(form.max_marks),
      batch_id: form.batch_id || null,
      test_date: form.test_date,
    });
    if (error) { alert(error.message); return; }
    setForm({ name: '', subject: '', max_marks: 100, batch_id: '', test_date: todayISO() });
    setShowCreate(false);
    load();
  }

  // When a test is selected, load students of its batch + existing marks
  useEffect(() => {
    if (!selected) { setStudents([]); setMarks({}); return; }
    const t = tests.find(x => x.id === selected);
    if (!t) return;
    (async () => {
      let q = supabase.from('students').select('*').eq('active', true).order('name');
      if (t.batch_id) q = q.eq('batch_id', t.batch_id);
      const { data: s } = await q;
      setStudents((s ?? []) as Student[]);
      const { data: r } = await supabase.from('test_results').select('student_id,marks').eq('test_id', selected);
      const m: Record<string, number> = {};
      (r ?? []).forEach((x: any) => { m[x.student_id] = x.marks; });
      setMarks(m);
    })();
  }, [selected, tests]);

  async function saveMarks() {
    if (!selected) return;
    const rows = students
      .filter(s => marks[s.id] !== undefined && marks[s.id] !== null && !isNaN(marks[s.id]))
      .map(s => ({ test_id: selected, student_id: s.id, marks: marks[s.id] }));
    if (!rows.length) return;
    const { error } = await supabase.from('test_results')
      .upsert(rows, { onConflict: 'test_id,student_id' });
    if (error) alert(error.message);
    else alert('Saved!');
  }

  const activeTest = tests.find(t => t.id === selected);

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-3">
      <div className="flex justify-between items-center">
        <Link to="/" className="text-sm text-indigo-600">← Back</Link>
        <button onClick={signOut} className="text-sm text-red-600">Logout</button>
      </div>
      <div className="flex justify-between items-center">
        <h1 className="text-xl font-bold">Tests</h1>
        <button onClick={() => setShowCreate(!showCreate)}
                className="bg-indigo-600 text-white px-3 py-1 rounded text-sm">
          {showCreate ? 'Cancel' : '+ New Test'}
        </button>
      </div>

      {showCreate && (
        <form onSubmit={createTest} className="bg-white p-4 rounded-xl shadow-sm space-y-2">
          <input className="w-full border p-2 rounded" placeholder="Test name" required
                 value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
          <input className="w-full border p-2 rounded" placeholder="Subject"
                 value={form.subject} onChange={e => setForm({ ...form, subject: e.target.value })} />
          <div className="grid grid-cols-2 gap-2">
            <input className="border p-2 rounded" type="number" placeholder="Max marks" required
                   value={form.max_marks}
                   onChange={e => setForm({ ...form, max_marks: Number(e.target.value) })} />
            <input className="border p-2 rounded" type="date" required
                   value={form.test_date}
                   onChange={e => setForm({ ...form, test_date: e.target.value })} />
          </div>
          <select className="w-full border p-2 rounded"
                  value={form.batch_id}
                  onChange={e => setForm({ ...form, batch_id: e.target.value })}>
            <option value="">— No batch (all students) —</option>
            {batches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
          </select>
          <button className="w-full bg-green-600 text-white py-2 rounded">Create Test</button>
        </form>
      )}

      <select className="w-full border p-2 rounded"
              value={selected} onChange={e => setSelected(e.target.value)}>
        <option value="">— Select a test to enter marks —</option>
        {tests.map(t => (
          <option key={t.id} value={t.id}>
            {t.name} ({t.test_date}) — /{t.max_marks}
          </option>
        ))}
      </select>

      {activeTest && (
        <>
          <div className="bg-white p-3 rounded-xl shadow-sm text-sm">
            <p className="font-medium">{activeTest.name}</p>
            <p className="text-gray-500">
              {activeTest.subject || '—'} · Max {activeTest.max_marks} · {activeTest.test_date}
            </p>
          </div>
          {students.map(s => (
            <div key={s.id} className="flex items-center justify-between bg-white p-3 rounded shadow-sm">
              <span>{s.name}</span>
              <input type="number" className="border p-1 rounded w-20 text-right"
                     placeholder="—" min={0} max={activeTest.max_marks}
                     value={marks[s.id] ?? ''}
                     onChange={e => setMarks({ ...marks, [s.id]: Number(e.target.value) })} />
            </div>
          ))}
          <button onClick={saveMarks}
                  className="w-full bg-indigo-600 text-white py-3 rounded font-medium">
            Save Marks
          </button>
        </>
      )}
    </div>
  );
}

// ============================================
// NOTICES
// ============================================
export function NoticesPage() {
  const { profile, signOut } = useAuth();
  const [list, setList] = useState<Notice[]>([]);
  const [form, setForm] = useState({ title: '', body: '' });

  async function load() {
    const { data } = await supabase.from('notices').select('*').order('created_at', { ascending: false });
    setList((data ?? []) as Notice[]);
  }
  useEffect(() => { load(); }, []);

  async function add(e: React.FormEvent) {
    e.preventDefault();
    if (!profile?.institute_id) return;
    const { error } = await supabase.from('notices').insert({
      institute_id: profile.institute_id,
      title: form.title, body: form.body || null,
    });
    if (error) { alert(error.message); return; }
    setForm({ title: '', body: '' });
    load();
  }

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-3">
      <div className="flex justify-between items-center">
        <Link to="/" className="text-sm text-indigo-600">← Back</Link>
        <button onClick={signOut} className="text-sm text-red-600">Logout</button>
      </div>
      <h1 className="text-xl font-bold">Notices</h1>
      <form onSubmit={add} className="bg-white p-4 rounded-xl shadow-sm space-y-2">
        <input className="w-full border p-2 rounded" placeholder="Title" required
               value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} />
        <textarea className="w-full border p-2 rounded" placeholder="Message" rows={3}
                  value={form.body} onChange={e => setForm({ ...form, body: e.target.value })} />
        <button className="w-full bg-green-600 text-white py-2 rounded">Post</button>
      </form>
      {list.map(n => (
        <div key={n.id} className="bg-white p-3 rounded shadow-sm">
          <p className="font-medium">{n.title}</p>
          {n.body && <p className="text-sm text-gray-600 mt-1">{n.body}</p>}
          <p className="text-xs text-gray-400 mt-1">{new Date(n.created_at).toLocaleString('en-IN')}</p>
        </div>
      ))}
    </div>
  );
}

// ============================================
// PARENT HOME
// ============================================
export function ParentHome() {
  const { signOut, profile } = useAuth();
  const [kids, setKids] = useState<any[]>([]);
  const [activeId, setActiveId] = useState<string>('');
  const [stats, setStats] = useState<any>(null);
  const [notices, setNotices] = useState<Notice[]>([]);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from('parent_students')
        .select('student_id, students(id,name,admission_date,monthly_fee,parent_email)');
      const list = (data ?? []).map((x: any) => x.students).filter(Boolean);
      setKids(list);
      if (list.length) setActiveId(list[0].id);
    })();
    supabase.from('notices').select('*').order('created_at', { ascending: false }).limit(5)
      .then(({ data }) => setNotices((data ?? []) as Notice[]));
  }, []);

  useEffect(() => {
    if (!activeId) return;
    (async () => {
      const [att, fees, results] = await Promise.all([
        supabase.from('attendance').select('status,date').eq('student_id', activeId),
        supabase.from('fee_payments').select('amount,month,paid_at').eq('student_id', activeId),
        supabase.from('test_results').select('marks, tests(name,max_marks,test_date)').eq('student_id', activeId),
      ]);
      const total = att.data?.length ?? 0;
      const present = att.data?.filter((a: any) => a.status === 'present').length ?? 0;
      const paid = (fees.data ?? []).reduce((s: number, f: any) => s + Number(f.amount), 0);
      const kid = kids.find(k => k.id === activeId);
      const pend = kid ? pendingMonths(kid.admission_date, kid.monthly_fee, fees.data ?? []) : [];
      setStats({
        attendancePct: total ? Math.round((present / total) * 100) : 0,
        totalPaid: paid,
        pendingCount: pend.length,
        pendingAmount: pend.reduce((a, b) => a + b.due, 0),
        results: results.data ?? [],
        recentAttendance: (att.data ?? []).slice(-10).reverse(),
      });
    })();
  }, [activeId, kids]);

  const kid = kids.find(k => k.id === activeId);

  return (
    <div className="max-w-md mx-auto p-4 space-y-4 pb-12">
      <div className="flex justify-between items-center">
        <h1 className="text-xl font-bold">Parent — {profile?.name}</h1>
        <button onClick={signOut} className="text-sm text-red-600">Logout</button>
      </div>

      {kids.length === 0 && (
        <div className="bg-yellow-50 p-4 rounded-xl text-sm">
          <p className="font-medium">Koi student linked nahi mila.</p>
          <p className="text-gray-600 mt-1">
            Tuition admin se apna email <b>{profile?.name}</b> ke saath register karwayein.
          </p>
        </div>
      )}

      {kids.length > 1 && (
        <select className="w-full border p-2 rounded" value={activeId}
                onChange={e => setActiveId(e.target.value)}>
          {kids.map(k => <option key={k.id} value={k.id}>{k.name}</option>)}
        </select>
      )}

      {kid && (
        <>
          <div className="bg-white p-4 rounded-xl shadow-sm">
            <p className="text-xs text-gray-500">Student</p>
            <p className="text-lg font-bold">{kid.name}</p>
          </div>

          {stats && (
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white p-4 rounded-xl shadow-sm">
                <p className="text-2xl font-bold">{stats.attendancePct}%</p>
                <p className="text-xs text-gray-500">Attendance</p>
              </div>
              <div className="bg-white p-4 rounded-xl shadow-sm">
                <p className="text-2xl font-bold">{formatINR(stats.totalPaid)}</p>
                <p className="text-xs text-gray-500">Fees Paid</p>
              </div>
              <div className="col-span-2 bg-white p-4 rounded-xl shadow-sm">
                <p className="text-sm font-medium">Pending Fees</p>
                {stats.pendingCount > 0 ? (
                  <p className="text-red-600">
                    {stats.pendingCount} month(s) — {formatINR(stats.pendingAmount)}
                  </p>
                ) : (
                  <p className="text-green-600">All clear ✓</p>
                )}
                <p className="text-xs text-gray-500 mt-1">
                  Payment tuition office mein jaakar karein. Online payment jald aa raha hai.
                </p>
              </div>
            </div>
          )}

          <div className="bg-white p-4 rounded-xl shadow-sm space-y-2">
            <p className="font-medium">Test Results</p>
            {stats?.results?.length ? (
              stats.results.map((r: any, i: number) => (
                <div key={i} className="flex justify-between text-sm border-b py-1">
                  <span>{r.tests?.name}</span>
                  <span className="font-medium">{r.marks}/{r.tests?.max_marks}</span>
                </div>
              ))
            ) : <p className="text-sm text-gray-500">Koi result nahi</p>}
          </div>

          <div className="bg-white p-4 rounded-xl shadow-sm space-y-2">
            <p className="font-medium">Recent Attendance</p>
            {stats?.recentAttendance?.length ? (
              stats.recentAttendance.map((a: any, i: number) => (
                <div key={i} className="flex justify-between text-sm border-b py-1">
                  <span>{a.date}</span>
                  <span className={
                    a.status === 'present' ? 'text-green-600'
                    : a.status === 'absent' ? 'text-red-600' : 'text-yellow-600'
                  }>{a.status}</span>
                </div>
              ))
            ) : <p className="text-sm text-gray-500">Koi data nahi</p>}
          </div>
        </>
      )}

      <div className="bg-white p-4 rounded-xl shadow-sm space-y-2">
        <p className="font-medium">Notices</p>
        {notices.length === 0 && <p className="text-sm text-gray-500">Koi notice nahi</p>}
        {notices.map(n => (
          <div key={n.id} className="border-b py-1 text-sm">
            <p className="font-medium">{n.title}</p>
            {n.body && <p className="text-gray-600">{n.body}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}