# Tuition App

React + Vite + Supabase

## Structure
```
tuition-app/
├── supabase/schema.sql
├── .env
├── package.json
├── tsconfig.json
├── vite.config.ts
├── tailwind.config.js
├── postcss.config.js
├── index.html
└── src/
    ├── main.tsx
    ├── index.css
    ├── lib.ts
    ├── pages.tsx
    ├── App.tsx
    └── vite-env.d.ts
```

## Setup
1. Supabase Dashboard → SQL Editor → `supabase/schema.sql` poora run karo
2. `.env` me URL + key already set hai:
   - VITE_SUPABASE_URL=https://iaknxhluczcrbfrxkywi.supabase.co
   - VITE_SUPABASE_ANON_KEY=sb_publishable_...
3. Terminal:
```bash
cd tuition-app
npm install
npm run dev
```
4. Browser: http://localhost:5173

## Notes
- Ye **web app** hai. Android Studio se APK nahi banega.
- Signup ke baad `profiles` row auto banegi (role default parent).
- Admin/teacher banana ho to SQL se:
```sql
update public.profiles set role = 'admin', name = 'Owner' where id = 'USER_UUID';
```
