Tuition App — Android (WebView)
================================

APK BANANE KE STEPS
1. Android Studio > File > Open > yeh TuitionAndroid folder
2. Gradle sync (internet chahiye, pehli baar)
3. Build > Build Bundle(s) / APK(s) > Build APK(s)
4. APK: app/build/outputs/apk/debug/app-debug.apk

SUPABASE
- URL + key already assets/www/index.html me set hai
- Pehle SQL Editor me schema run karo (tuition-app/supabase/schema.sql se)

FEATURES
- Login / Signup
- Admin/Teacher: Students, Attendance, Fees, Notices
- Parent: Home + Notices
- Role profiles table me set karein (admin/teacher/parent)

NOTE
- Internet permission on hai (Supabase ke liye)
- Schema tables: profiles, students, attendance, fee_payments, notices, ...
