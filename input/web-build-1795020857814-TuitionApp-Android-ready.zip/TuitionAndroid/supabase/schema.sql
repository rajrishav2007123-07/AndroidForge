-- Tuition App schema
-- Supabase SQL Editor me poora run karo (ek baar)

-- Extensions
create extension if not exists "pgcrypto";

-- Institutes (optional multi-tenant)
create table if not exists public.institutes (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);

-- Profiles (1:1 with auth.users)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  institute_id uuid references public.institutes(id) on delete set null,
  role text not null check (role in ('admin', 'teacher', 'parent')),
  name text not null default '',
  phone text,
  created_at timestamptz not null default now()
);

-- Batches
create table if not exists public.batches (
  id uuid primary key default gen_random_uuid(),
  institute_id uuid references public.institutes(id) on delete cascade,
  name text not null,
  subject text,
  timing text,
  created_at timestamptz not null default now()
);

-- Students
create table if not exists public.students (
  id uuid primary key default gen_random_uuid(),
  institute_id uuid references public.institutes(id) on delete cascade,
  batch_id uuid references public.batches(id) on delete set null,
  name text not null,
  phone text,
  parent_phone text not null default '',
  parent_email text,
  admission_date date not null default current_date,
  monthly_fee numeric(10,2) not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

-- Attendance
create table if not exists public.attendance (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  date date not null,
  status text not null check (status in ('present', 'absent', 'leave')),
  created_at timestamptz not null default now(),
  unique (student_id, date)
);

-- Fee payments
create table if not exists public.fee_payments (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  amount numeric(10,2) not null,
  month text not null, -- 'YYYY-MM'
  mode text check (mode in ('cash', 'upi', 'online')),
  receipt_no text,
  notes text,
  paid_at timestamptz not null default now()
);

-- Tests
create table if not exists public.tests (
  id uuid primary key default gen_random_uuid(),
  institute_id uuid references public.institutes(id) on delete cascade,
  batch_id uuid references public.batches(id) on delete set null,
  name text not null,
  subject text,
  max_marks int not null default 100,
  test_date date not null default current_date,
  created_at timestamptz not null default now()
);

-- Test results
create table if not exists public.test_results (
  id uuid primary key default gen_random_uuid(),
  test_id uuid not null references public.tests(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  marks numeric(6,2) not null default 0,
  unique (test_id, student_id)
);

-- Notices
create table if not exists public.notices (
  id uuid primary key default gen_random_uuid(),
  institute_id uuid references public.institutes(id) on delete cascade,
  title text not null,
  body text,
  created_at timestamptz not null default now()
);

-- Auto-create profile on signup (optional helper)
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, role, name)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'role', 'parent'),
    coalesce(new.raw_user_meta_data->>'name', split_part(new.email, '@', 1))
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Basic RLS
alter table public.profiles enable row level security;
alter table public.institutes enable row level security;
alter table public.batches enable row level security;
alter table public.students enable row level security;
alter table public.attendance enable row level security;
alter table public.fee_payments enable row level security;
alter table public.tests enable row level security;
alter table public.test_results enable row level security;
alter table public.notices enable row level security;

-- Simple policies (logged-in users can read/write — tighten later for production)
create policy "profiles_select_own" on public.profiles for select using (auth.uid() = id);
create policy "profiles_update_own" on public.profiles for update using (auth.uid() = id);

create policy "authenticated_all_institutes" on public.institutes for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "authenticated_all_batches" on public.batches for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "authenticated_all_students" on public.students for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "authenticated_all_attendance" on public.attendance for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "authenticated_all_fees" on public.fee_payments for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "authenticated_all_tests" on public.tests for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "authenticated_all_results" on public.test_results for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "authenticated_all_notices" on public.notices for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

-- Seed one institute (optional)
-- insert into public.institutes (name) values ('My Tuition Center');
