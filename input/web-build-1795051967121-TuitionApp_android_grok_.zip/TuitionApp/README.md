# Tuition Manager — Android App

Complete tuition management + parent portal for Indian coaching classes.

Built with **Kotlin + Jetpack Compose + Material 3 + Supabase**.

## Features

### Admin / Teacher
- Students: add, toggle active/inactive
- Attendance: mark Present / Absent / Leave by date
- Fees: record payments, auto pending-dues calculation
- Tests: create tests, enter marks
- Notices: post announcements

### Parent Portal
- View linked children
- Attendance % + recent history
- Total paid + pending fee dues
- Notices

## Setup (Android Studio)

1. **Open the project**
   - Android Studio → Open → select the `TuitionApp` folder

2. **Configure Supabase**
   - Create a Supabase project (region: Mumbai recommended)
   - Run the SQL schema (same as web version — see `schema.sql` below or use the one from tuition-app web ZIP)
   - Create `local.properties` in the project root (same level as `settings.gradle.kts`):

   ```properties
   sdk.dir=/path/to/your/Android/sdk
   SUPABASE_URL=https://YOUR_PROJECT.supabase.co
   SUPABASE_ANON_KEY=your-anon-key
   ```

3. **Sync & Run**
   - Let Gradle sync
   - Run on emulator or device (minSdk 26)

## Create first admin

Same as web version:
1. Run schema → `select id from institutes;` → copy UUID
2. Supabase Auth → Add User:
   - Email: `admin@mytuition.com`
   - Password: strong password
   - Auto Confirm: YES
   - User Metadata:
     ```json
     {"role":"admin","name":"Your Name","institute_id":"<uuid>"}
     ```

## Parent signup
Parents can sign up from the Login screen. After signup, set their email as `parent_email` on the student record so they get auto-linked (or the trigger does it).

## Project structure

```
TuitionApp/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/tuition/manager/
│       │   ├── MainActivity.kt
│       │   ├── TuitionApp.kt
│       │   ├── data/          # Models, Supabase, Repositories
│       │   ├── ui/screens/    # All Compose screens
│       │   ├── ui/theme/
│       │   └── util/
│       └── res/
├── build.gradle.kts
├── settings.gradle.kts
└── README.md
```

## Notes
- Icons: Android Studio will generate default launcher icons on first sync, or add your own in `res/mipmap-*`.
- Same Supabase backend works for both Web and Android versions.
- Free tier: keep the project active (ping) and export data weekly.
