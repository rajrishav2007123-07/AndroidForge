# Keep Supabase models
-keep class com.tuition.manager.data.** { *; }
