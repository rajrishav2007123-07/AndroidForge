package com.tuition.manager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.tuition.manager.data.AuthRepository
import com.tuition.manager.data.Profile
import com.tuition.manager.ui.screens.*
import com.tuition.manager.ui.theme.TuitionTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TuitionTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppNavigation()
                }
            }
        }
    }
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    var profile by remember { mutableStateOf<Profile?>(null) }
    var checking by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        val user = AuthRepository.currentUser()
        if (user != null) {
            profile = AuthRepository.fetchProfile(user.id)
        }
        checking = false
    }

    if (checking) {
        // Simple splash
        androidx.compose.foundation.layout.Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = androidx.compose.ui.Alignment.Center
        ) {
            androidx.compose.material3.CircularProgressIndicator()
        }
        return
    }

    val start = if (profile != null) "home" else "login"

    NavHost(navController = navController, startDestination = start) {
        composable("login") {
            LoginScreen(
                onLoginSuccess = {
                    scope.launch {
                        val user = AuthRepository.currentUser()
                        if (user != null) {
                            profile = AuthRepository.fetchProfile(user.id)
                            navController.navigate("home") {
                                popUpTo("login") { inclusive = true }
                            }
                        }
                    }
                }
            )
        }

        composable("home") {
            val p = profile
            if (p == null) {
                navController.navigate("login") { popUpTo(0) }
            } else if (p.role == "parent") {
                ParentHomeScreen(
                    profile = p,
                    onLogout = {
                        scope.launch {
                            AuthRepository.signOut()
                            profile = null
                            navController.navigate("login") { popUpTo(0) }
                        }
                    }
                )
            } else {
                AdminHomeScreen(
                    profile = p,
                    onNavigate = { route -> navController.navigate(route) },
                    onLogout = {
                        scope.launch {
                            AuthRepository.signOut()
                            profile = null
                            navController.navigate("login") { popUpTo(0) }
                        }
                    }
                )
            }
        }

        composable("students") {
            profile?.let { StudentsScreen(it) { navController.popBackStack() } }
        }
        composable("attendance") {
            profile?.let { AttendanceScreen(it) { navController.popBackStack() } }
        }
        composable("fees") {
            profile?.let { FeesScreen(it) { navController.popBackStack() } }
        }
        composable("tests") {
            profile?.let { TestsScreen(it) { navController.popBackStack() } }
        }
        composable("notices") {
            profile?.let { NoticesScreen(it) { navController.popBackStack() } }
        }
    }
}
