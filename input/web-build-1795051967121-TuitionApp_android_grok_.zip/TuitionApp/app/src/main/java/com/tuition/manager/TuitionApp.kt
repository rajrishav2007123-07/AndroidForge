package com.tuition.manager

import android.app.Application
import com.tuition.manager.data.SupabaseClient

class TuitionApp : Application() {
    override fun onCreate() {
        super.onCreate()
        SupabaseClient.init(this)
    }
}
