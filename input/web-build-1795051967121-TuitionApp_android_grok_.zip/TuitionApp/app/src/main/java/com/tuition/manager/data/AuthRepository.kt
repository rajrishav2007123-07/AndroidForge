package com.tuition.manager.data

import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.gotrue.providers.builtin.Email
import io.github.jan.supabase.gotrue.user.UserInfo
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object AuthRepository {

    suspend fun signIn(email: String, password: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            SupabaseClient.auth.signInWith(Email) {
                this.email = email
                this.password = password
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun signUpParent(email: String, password: String, name: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                SupabaseClient.auth.signUpWith(Email) {
                    this.email = email
                    this.password = password
                    data = buildMap {
                        put("role", "parent")
                        put("name", name)
                    }
                }
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun signOut() = withContext(Dispatchers.IO) {
        try {
            SupabaseClient.auth.signOut()
        } catch (_: Exception) {}
    }

    suspend fun currentUser(): UserInfo? = withContext(Dispatchers.IO) {
        try {
            SupabaseClient.auth.currentUserOrNull()
        } catch (_: Exception) {
            null
        }
    }

    suspend fun fetchProfile(userId: String): Profile? = withContext(Dispatchers.IO) {
        try {
            SupabaseClient.from("profiles")
                .select {
                    filter { eq("id", userId) }
                }
                .decodeSingleOrNull<Profile>()
        } catch (_: Exception) {
            null
        }
    }
}
