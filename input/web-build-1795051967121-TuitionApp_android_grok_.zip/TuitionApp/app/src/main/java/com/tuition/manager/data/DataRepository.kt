package com.tuition.manager.data

import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Columns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object DataRepository {

    // ---------- Students ----------
    suspend fun getStudents(instituteId: String): List<Student> = withContext(Dispatchers.IO) {
        try {
            SupabaseClient.from("students")
                .select {
                    filter { eq("institute_id", instituteId) }
                }
                .decodeList<Student>()
                .sortedBy { it.name }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun addStudent(student: Student): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            SupabaseClient.from("students").insert(student)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun toggleStudentActive(id: String, active: Boolean): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                SupabaseClient.from("students").update({
                    set("active", active)
                }) {
                    filter { eq("id", id) }
                }
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    // ---------- Attendance ----------
    suspend fun getAttendanceForDate(date: String, studentIds: List<String>): Map<String, String> =
        withContext(Dispatchers.IO) {
            if (studentIds.isEmpty()) return@withContext emptyMap()
            try {
                SupabaseClient.from("attendance")
                    .select {
                        filter {
                            eq("date", date)
                            isIn("student_id", studentIds)
                        }
                    }
                    .decodeList<Attendance>()
                    .associate { it.studentId to it.status }
            } catch (_: Exception) {
                emptyMap()
            }
        }

    suspend fun upsertAttendance(records: List<Attendance>): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                SupabaseClient.from("attendance").upsert(records)
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    // ---------- Fees ----------
    suspend fun getPayments(studentId: String): List<FeePayment> = withContext(Dispatchers.IO) {
        try {
            SupabaseClient.from("fee_payments")
                .select {
                    filter { eq("student_id", studentId) }
                }
                .decodeList<FeePayment>()
                .sortedByDescending { it.paidAt }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun addPayment(payment: FeePayment): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            SupabaseClient.from("fee_payments").insert(payment)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------- Tests ----------
    suspend fun getTests(instituteId: String): List<Test> = withContext(Dispatchers.IO) {
        try {
            SupabaseClient.from("tests")
                .select {
                    filter { eq("institute_id", instituteId) }
                }
                .decodeList<Test>()
                .sortedByDescending { it.testDate }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun createTest(test: Test): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            SupabaseClient.from("tests").insert(test)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getResults(testId: String): Map<String, Int> = withContext(Dispatchers.IO) {
        try {
            SupabaseClient.from("test_results")
                .select {
                    filter { eq("test_id", testId) }
                }
                .decodeList<TestResult>()
                .associate { it.studentId to it.marks }
        } catch (_: Exception) {
            emptyMap()
        }
    }

    suspend fun upsertResults(results: List<TestResult>): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                SupabaseClient.from("test_results").upsert(results)
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    // ---------- Notices ----------
    suspend fun getNotices(instituteId: String): List<Notice> = withContext(Dispatchers.IO) {
        try {
            SupabaseClient.from("notices")
                .select {
                    filter { eq("institute_id", instituteId) }
                }
                .decodeList<Notice>()
                .sortedByDescending { it.createdAt }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun postNotice(notice: Notice): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            SupabaseClient.from("notices").insert(notice)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------- Parent ----------
    suspend fun getChildren(parentId: String): List<Student> = withContext(Dispatchers.IO) {
        try {
            // First get linked student ids
            val links = SupabaseClient.from("parent_students")
                .select {
                    filter { eq("parent_id", parentId) }
                }
                .decodeList<ParentStudent>()

            if (links.isEmpty()) return@withContext emptyList()

            val ids = links.map { it.studentId }
            SupabaseClient.from("students")
                .select {
                    filter { isIn("id", ids) }
                }
                .decodeList<Student>()
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun getStudentAttendance(studentId: String): List<Attendance> =
        withContext(Dispatchers.IO) {
            try {
                SupabaseClient.from("attendance")
                    .select {
                        filter { eq("student_id", studentId) }
                    }
                    .decodeList<Attendance>()
                    .sortedByDescending { it.date }
            } catch (_: Exception) {
                emptyList()
            }
        }
}
