package com.tuition.manager.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Profile(
    val id: String,
    @SerialName("institute_id") val instituteId: String? = null,
    val role: String,
    val name: String,
    val phone: String? = null,
    @SerialName("created_at") val createdAt: String? = null
)

@Serializable
data class Student(
    val id: String = "",
    @SerialName("institute_id") val instituteId: String = "",
    @SerialName("batch_id") val batchId: String? = null,
    val name: String = "",
    val phone: String? = null,
    @SerialName("parent_phone") val parentPhone: String = "",
    @SerialName("parent_email") val parentEmail: String? = null,
    @SerialName("admission_date") val admissionDate: String = "",
    @SerialName("monthly_fee") val monthlyFee: Double = 0.0,
    val active: Boolean = true,
    @SerialName("created_at") val createdAt: String? = null
)

@Serializable
data class Batch(
    val id: String = "",
    @SerialName("institute_id") val instituteId: String = "",
    val name: String = "",
    val subject: String? = null,
    val timing: String? = null
)

@Serializable
data class Attendance(
    val id: String = "",
    @SerialName("student_id") val studentId: String = "",
    val date: String = "",
    val status: String = "",
    @SerialName("marked_by") val markedBy: String? = null
)

@Serializable
data class FeePayment(
    val id: String = "",
    @SerialName("student_id") val studentId: String = "",
    val amount: Double = 0.0,
    val month: String = "",
    val mode: String? = null,
    @SerialName("receipt_no") val receiptNo: String? = null,
    val notes: String? = null,
    @SerialName("paid_at") val paidAt: String? = null,
    @SerialName("recorded_by") val recordedBy: String? = null
)

@Serializable
data class Test(
    val id: String = "",
    @SerialName("institute_id") val instituteId: String = "",
    @SerialName("batch_id") val batchId: String? = null,
    val name: String = "",
    val subject: String? = null,
    @SerialName("max_marks") val maxMarks: Int = 100,
    @SerialName("test_date") val testDate: String = ""
)

@Serializable
data class TestResult(
    val id: String = "",
    @SerialName("test_id") val testId: String = "",
    @SerialName("student_id") val studentId: String = "",
    val marks: Int = 0
)

@Serializable
data class Notice(
    val id: String = "",
    @SerialName("institute_id") val instituteId: String = "",
    val title: String = "",
    val body: String? = null,
    @SerialName("created_at") val createdAt: String? = null
)

@Serializable
data class ParentStudent(
    @SerialName("parent_id") val parentId: String = "",
    @SerialName("student_id") val studentId: String = ""
)
