package com.tuition.manager.data

import android.content.Context
import com.tuition.manager.BuildConfig
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.Auth
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Columns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object SupabaseClient {
    private var client: SupabaseClient? = null

    fun init(context: Context) {
        val url = BuildConfig.SUPABASE_URL.ifBlank {
            // Fallback: read from local.properties style or hardcode for testing
            ""
        }
        val key = BuildConfig.SUPABASE_ANON_KEY.ifBlank { "" }

        if (url.isBlank() || key.isBlank()) {
            // Will be configured via gradle.properties or local.properties
            return
        }

        client = createSupabaseClient(
            supabaseUrl = url,
            supabaseKey = key
        ) {
            install(Auth)
            install(Postgrest)
        }
    }

    fun get(): SupabaseClient {
        return client ?: throw IllegalStateException(
            "Supabase not initialized. Set SUPABASE_URL and SUPABASE_ANON_KEY in gradle.properties or local.properties"
        )
    }

    val auth get() = get().auth
    fun from(table: String) = get().from(table)
}
