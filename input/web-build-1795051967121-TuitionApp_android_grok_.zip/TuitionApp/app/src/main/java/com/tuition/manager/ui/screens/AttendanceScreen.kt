package com.tuition.manager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tuition.manager.data.Attendance
import com.tuition.manager.data.DataRepository
import com.tuition.manager.data.Profile
import com.tuition.manager.data.Student
import com.tuition.manager.util.Helpers
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttendanceScreen(profile: Profile, onBack: () -> Unit) {
    var date by remember { mutableStateOf(Helpers.todayISO()) }
    var students by remember { mutableStateOf<List<Student>>(emptyList()) }
    var statusMap by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var loading by remember { mutableStateOf(true) }
    var saving by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    fun load() {
        scope.launch {
            loading = true
            val instId = profile.instituteId ?: return@launch
            val all = DataRepository.getStudents(instId).filter { it.active }
            students = all
            statusMap = DataRepository.getAttendanceForDate(date, all.map { it.id })
            loading = false
        }
    }

    LaunchedEffect(date) { load() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Attendance") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                actions = {
                    TextButton(
                        onClick = {
                            saving = true
                            msg = null
                            scope.launch {
                                val records = students.mapNotNull { s ->
                                    statusMap[s.id]?.let {
                                        Attendance(studentId = s.id, date = date, status = it, markedBy = profile.id)
                                    }
                                }
                                if (records.isEmpty()) {
                                    msg = "Mark at least one"
                                    saving = false
                                    return@launch
                                }
                                val r = DataRepository.upsertAttendance(records)
                                saving = false
                                msg = r.fold({ "Saved ${records.size}" }, { it.message })
                            }
                        },
                        enabled = !saving
                    ) {
                        Text(if (saving) "Saving..." else "Save")
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            OutlinedTextField(
                value = date,
                onValueChange = { date = it },
                label = { Text("Date (YYYY-MM-DD)") },
                modifier = Modifier.padding(16.dp).fillMaxWidth(),
                singleLine = true
            )
            msg?.let {
                Text(it, modifier = Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.bodySmall)
            }
            if (loading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(students, key = { it.id }) { s ->
                        Card(Modifier.fillMaxWidth()) {
                            Row(
                                Modifier.padding(12.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(s.name, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    listOf("present" to "P", "absent" to "A", "leave" to "L").forEach { (st, label) ->
                                        FilterChip(
                                            selected = statusMap[s.id] == st,
                                            onClick = {
                                                statusMap = statusMap.toMutableMap().apply { put(s.id, st) }
                                            },
                                            label = { Text(label) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
