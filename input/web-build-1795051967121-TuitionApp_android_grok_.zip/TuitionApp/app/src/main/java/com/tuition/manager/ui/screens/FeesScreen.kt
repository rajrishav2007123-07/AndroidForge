package com.tuition.manager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tuition.manager.data.DataRepository
import com.tuition.manager.data.FeePayment
import com.tuition.manager.data.Profile
import com.tuition.manager.data.Student
import com.tuition.manager.util.Helpers
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FeesScreen(profile: Profile, onBack: () -> Unit) {
    var students by remember { mutableStateOf<List<Student>>(emptyList()) }
    var selectedId by remember { mutableStateOf("") }
    var payments by remember { mutableStateOf<List<FeePayment>>(emptyList()) }
    var pending by remember { mutableStateOf<List<Pair<String, Double>>>(emptyList()) }
    var amount by remember { mutableStateOf("") }
    var month by remember { mutableStateOf(Helpers.currentMonth()) }
    var mode by remember { mutableStateOf("cash") }
    var saving by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    var expanded by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val instId = profile.instituteId ?: return@LaunchedEffect
        students = DataRepository.getStudents(instId).filter { it.active }
    }

    fun loadPayments(sid: String) {
        scope.launch {
            val pays = DataRepository.getPayments(sid)
            payments = pays
            val student = students.find { it.id == sid }
            if (student != null) {
                pending = Helpers.pendingMonths(
                    student.admissionDate.ifBlank { Helpers.todayISO() },
                    student.monthlyFee,
                    pays.map { it.month to it.amount }
                )
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Fees") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                    OutlinedTextField(
                        value = students.find { it.id == selectedId }?.name ?: "Select student",
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        students.forEach { s ->
                            DropdownMenuItem(
                                text = { Text("${s.name} — ${Helpers.formatINR(s.monthlyFee)}/mo") },
                                onClick = {
                                    selectedId = s.id
                                    expanded = false
                                    loadPayments(s.id)
                                }
                            )
                        }
                    }
                }
            }

            if (selectedId.isNotBlank()) {
                if (pending.isNotEmpty()) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f))) {
                            Column(Modifier.padding(14.dp)) {
                                Text("Pending dues", fontWeight = FontWeight.SemiBold)
                                pending.forEach { (m, due) ->
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(Helpers.monthLabel(m))
                                        Text(Helpers.formatINR(due), fontWeight = FontWeight.Medium)
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Card {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Record Payment", fontWeight = FontWeight.SemiBold)
                            OutlinedTextField(value = amount, onValueChange = { amount = it }, label = { Text("Amount") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(value = month, onValueChange = { month = it }, label = { Text("Month (YYYY-MM)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("cash", "upi", "online").forEach { m ->
                                    FilterChip(selected = mode == m, onClick = { mode = m }, label = { Text(m.replaceFirstChar { it.uppercase() }) })
                                }
                            }
                            msg?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                            Button(
                                onClick = {
                                    saving = true
                                    msg = null
                                    scope.launch {
                                        val r = DataRepository.addPayment(
                                            FeePayment(
                                                studentId = selectedId,
                                                amount = amount.toDoubleOrNull() ?: 0.0,
                                                month = month,
                                                mode = mode,
                                                recordedBy = profile.id
                                            )
                                        )
                                        saving = false
                                        r.onSuccess {
                                            amount = ""
                                            msg = "Payment recorded"
                                            loadPayments(selectedId)
                                        }.onFailure { msg = it.message }
                                    }
                                },
                                enabled = !saving && amount.isNotBlank(),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(if (saving) "Saving..." else "Save Payment")
                            }
                        }
                    }
                }

                item { Text("Payment History", fontWeight = FontWeight.SemiBold) }
                items(payments, key = { it.id }) { p ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(Helpers.formatINR(p.amount), fontWeight = FontWeight.Medium)
                                Text("${Helpers.monthLabel(p.month)} · ${p.mode ?: ""}", style = MaterialTheme.typography.bodySmall)
                            }
                            Text(p.paidAt?.take(10) ?: "", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}
