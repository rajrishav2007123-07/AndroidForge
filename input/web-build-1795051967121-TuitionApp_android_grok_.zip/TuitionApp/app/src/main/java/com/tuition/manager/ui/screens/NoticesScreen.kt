package com.tuition.manager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tuition.manager.data.DataRepository
import com.tuition.manager.data.Notice
import com.tuition.manager.data.Profile
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoticesScreen(profile: Profile, onBack: () -> Unit) {
    var notices by remember { mutableStateOf<List<Notice>>(emptyList()) }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun load() {
        scope.launch {
            val instId = profile.instituteId ?: return@launch
            notices = DataRepository.getNotices(instId)
        }
    }

    LaunchedEffect(Unit) { load() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Notices") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text("Body") }, modifier = Modifier.fillMaxWidth().height(100.dp))
                        Button(
                            onClick = {
                                saving = true
                                scope.launch {
                                    DataRepository.postNotice(
                                        Notice(
                                            instituteId = profile.instituteId ?: "",
                                            title = title.trim(),
                                            body = body.trim().ifBlank { null }
                                        )
                                    )
                                    title = ""; body = ""
                                    saving = false
                                    load()
                                }
                            },
                            enabled = !saving && title.isNotBlank(),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (saving) "Posting..." else "Post Notice")
                        }
                    }
                }
            }

            items(notices, key = { it.id }) { n ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text(n.title, fontWeight = FontWeight.SemiBold)
                        n.body?.let {
                            Text(it, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 4.dp))
                        }
                        Text(
                            n.createdAt?.take(16)?.replace("T", " ") ?: "",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
            }
        }
    }
}
