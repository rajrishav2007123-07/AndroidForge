package com.tuition.manager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tuition.manager.data.*
import com.tuition.manager.util.Helpers
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ParentHomeScreen(profile: Profile, onLogout: () -> Unit) {
    var children by remember { mutableStateOf<List<Student>>(emptyList()) }
    var selectedId by remember { mutableStateOf("") }
    var attendancePct by remember { mutableStateOf<Int?>(null) }
    var totalPaid by remember { mutableStateOf(0.0) }
    var pending by remember { mutableStateOf<List<Pair<String, Double>>>(emptyList()) }
    var recentAtt by remember { mutableStateOf<List<Attendance>>(emptyList()) }
    var notices by remember { mutableStateOf<List<Notice>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        loading = true
        children = DataRepository.getChildren(profile.id)
        if (children.isNotEmpty()) selectedId = children.first().id
        loading = false
    }

    LaunchedEffect(selectedId) {
        if (selectedId.isBlank()) return@LaunchedEffect
        val student = children.find { it.id == selectedId } ?: return@LaunchedEffect
        scope.launch {
            val att = DataRepository.getStudentAttendance(selectedId)
            recentAtt = att.take(10)
            attendancePct = if (att.isNotEmpty()) {
                ((att.count { it.status == "present" }.toDouble() / att.size) * 100).toInt()
            } else null

            val pays = DataRepository.getPayments(selectedId)
            totalPaid = pays.sumOf { it.amount }
            pending = Helpers.pendingMonths(
                student.admissionDate.ifBlank { Helpers.todayISO() },
                student.monthlyFee,
                pays.map { it.month to it.amount }
            )

            val instId = profile.instituteId ?: student.instituteId
            notices = DataRepository.getNotices(instId).take(5)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Parent Portal", fontWeight = FontWeight.Bold)
                        Text(profile.name, style = MaterialTheme.typography.labelSmall)
                    }
                },
                actions = {
                    IconButton(onClick = onLogout) {
                        Icon(Icons.AutoMirrored.Filled.Logout, "Logout")
                    }
                }
            )
        }
    ) { padding ->
        if (loading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else if (children.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("No children linked yet.\nAsk institute to set your email as parent_email.", style = MaterialTheme.typography.bodyMedium)
            }
        } else {
            LazyColumn(
                Modifier.padding(padding).fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (children.size > 1) {
                    item {
                        var expanded by remember { mutableStateOf(false) }
                        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                            OutlinedTextField(
                                value = children.find { it.id == selectedId }?.name ?: "",
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                                modifier = Modifier.menuAnchor().fillMaxWidth()
                            )
                            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                children.forEach { c ->
                                    DropdownMenuItem(text = { Text(c.name) }, onClick = { selectedId = c.id; expanded = false })
                                }
                            }
                        }
                    }
                }

                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatCard("Attendance", attendancePct?.let { "$it%" } ?: "—", Modifier.weight(1f))
                        StatCard("Paid", Helpers.formatINR(totalPaid), Modifier.weight(1f))
                        StatCard("Pending", Helpers.formatINR(pending.sumOf { it.second }), Modifier.weight(1f))
                    }
                }

                if (pending.isNotEmpty()) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f))) {
                            Column(Modifier.padding(14.dp)) {
                                Text("Fee Dues", fontWeight = FontWeight.SemiBold)
                                pending.forEach { (m, due) ->
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(Helpers.monthLabel(m))
                                        Text(Helpers.formatINR(due))
                                    }
                                }
                            }
                        }
                    }
                }

                if (recentAtt.isNotEmpty()) {
                    item { Text("Recent Attendance", fontWeight = FontWeight.SemiBold) }
                    items(recentAtt) { a ->
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(a.date)
                                Text(
                                    a.status.replaceFirstChar { it.uppercase() },
                                    color = when (a.status) {
                                        "present" -> MaterialTheme.colorScheme.primary
                                        "absent" -> MaterialTheme.colorScheme.error
                                        else -> MaterialTheme.colorScheme.tertiary
                                    },
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                if (notices.isNotEmpty()) {
                    item { Text("Notices", fontWeight = FontWeight.SemiBold) }
                    items(notices) { n ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text(n.title, fontWeight = FontWeight.Medium)
                                n.body?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}
