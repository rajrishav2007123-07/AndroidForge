package com.tuition.manager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tuition.manager.data.DataRepository
import com.tuition.manager.data.Profile
import com.tuition.manager.data.Student
import com.tuition.manager.util.Helpers
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentsScreen(profile: Profile, onBack: () -> Unit) {
    var students by remember { mutableStateOf<List<Student>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var showForm by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var parentPhone by remember { mutableStateOf("") }
    var parentEmail by remember { mutableStateOf("") }
    var monthlyFee by remember { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    fun load() {
        scope.launch {
            loading = true
            val instId = profile.instituteId ?: return@launch
            students = DataRepository.getStudents(instId)
            loading = false
        }
    }

    LaunchedEffect(Unit) { load() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Students") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showForm = !showForm }) {
                        Icon(Icons.Default.Add, "Add")
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (showForm) {
                Card(Modifier.padding(16.dp).fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Student name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(value = parentPhone, onValueChange = { parentPhone = it }, label = { Text("Parent phone") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(value = parentEmail, onValueChange = { parentEmail = it }, label = { Text("Parent email") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(value = monthlyFee, onValueChange = { monthlyFee = it }, label = { Text("Monthly fee (₹)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        msg?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                        Button(
                            onClick = {
                                saving = true
                                msg = null
                                scope.launch {
                                    val result = DataRepository.addStudent(
                                        Student(
                                            instituteId = profile.instituteId ?: "",
                                            name = name.trim(),
                                            parentPhone = parentPhone.trim(),
                                            parentEmail = parentEmail.trim().ifBlank { null },
                                            monthlyFee = monthlyFee.toDoubleOrNull() ?: 0.0
                                        )
                                    )
                                    saving = false
                                    result.onSuccess {
                                        name = ""; parentPhone = ""; parentEmail = ""; monthlyFee = ""
                                        showForm = false
                                        load()
                                    }.onFailure { msg = it.message }
                                }
                            },
                            enabled = !saving && name.isNotBlank() && parentPhone.isNotBlank(),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (saving) "Saving..." else "Save Student")
                        }
                    }
                }
            }

            if (loading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(students, key = { it.id }) { s ->
                        Card(Modifier.fillMaxWidth()) {
                            Row(
                                Modifier.padding(14.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(s.name, fontWeight = FontWeight.Medium)
                                    Text(
                                        "Fee: ${Helpers.formatINR(s.monthlyFee)}/mo · ${s.parentPhone}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                    )
                                }
                                FilterChip(
                                    selected = s.active,
                                    onClick = {
                                        scope.launch {
                                            DataRepository.toggleStudentActive(s.id, !s.active)
                                            load()
                                        }
                                    },
                                    label = { Text(if (s.active) "Active" else "Inactive") }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
