package com.tuition.manager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tuition.manager.data.*
import com.tuition.manager.util.Helpers
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TestsScreen(profile: Profile, onBack: () -> Unit) {
    var tests by remember { mutableStateOf<List<Test>>(emptyList()) }
    var students by remember { mutableStateOf<List<Student>>(emptyList()) }
    var selectedTest by remember { mutableStateOf("") }
    var marksMap by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var showCreate by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var maxMarks by remember { mutableStateOf("100") }
    var testDate by remember { mutableStateOf(Helpers.todayISO()) }
    var saving by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var expanded by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun loadTests() {
        scope.launch {
            val instId = profile.instituteId ?: return@launch
            tests = DataRepository.getTests(instId)
            students = DataRepository.getStudents(instId).filter { it.active }
        }
    }

    LaunchedEffect(Unit) { loadTests() }

    LaunchedEffect(selectedTest) {
        if (selectedTest.isNotBlank()) {
            marksMap = DataRepository.getResults(selectedTest).mapValues { it.value.toString() }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Tests") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showCreate = !showCreate }) {
                        Icon(Icons.Default.Add, "New Test")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (showCreate) {
                item {
                    Card {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Test name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(value = maxMarks, onValueChange = { maxMarks = it }, label = { Text("Max marks") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(value = testDate, onValueChange = { testDate = it }, label = { Text("Date") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            Button(
                                onClick = {
                                    saving = true
                                    scope.launch {
                                        val r = DataRepository.createTest(
                                            Test(
                                                instituteId = profile.instituteId ?: "",
                                                name = name.trim(),
                                                maxMarks = maxMarks.toIntOrNull() ?: 100,
                                                testDate = testDate
                                            )
                                        )
                                        saving = false
                                        r.onSuccess {
                                            name = ""; showCreate = false; loadTests()
                                        }.onFailure { msg = it.message }
                                    }
                                },
                                enabled = !saving && name.isNotBlank(),
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Create Test") }
                        }
                    }
                }
            }

            item {
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                    OutlinedTextField(
                        value = tests.find { it.id == selectedTest }?.let { "${it.name} (${it.testDate})" } ?: "Select a test",
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        tests.forEach { t ->
                            DropdownMenuItem(
                                text = { Text("${t.name} — max ${t.maxMarks}") },
                                onClick = { selectedTest = t.id; expanded = false }
                            )
                        }
                    }
                }
            }

            if (selectedTest.isNotBlank()) {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Enter Marks", fontWeight = FontWeight.SemiBold)
                        Button(onClick = {
                            saving = true
                            scope.launch {
                                val rows = marksMap.filter { it.value.isNotBlank() }.map {
                                    TestResult(testId = selectedTest, studentId = it.key, marks = it.value.toIntOrNull() ?: 0)
                                }
                                val r = DataRepository.upsertResults(rows)
                                saving = false
                                msg = r.fold({ "Saved ${rows.size}" }, { it.message })
                            }
                        }, enabled = !saving) {
                            Text(if (saving) "Saving..." else "Save Marks")
                        }
                    }
                }
                msg?.let { item { Text(it, style = MaterialTheme.typography.bodySmall) } }

                items(students, key = { it.id }) { s ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(s.name, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                            OutlinedTextField(
                                value = marksMap[s.id] ?: "",
                                onValueChange = { v -> marksMap = marksMap.toMutableMap().apply { put(s.id, v) } },
                                modifier = Modifier.width(90.dp),
                                singleLine = true,
                                label = { Text("Marks") }
                            )
                        }
                    }
                }
            }
        }
    }
}
