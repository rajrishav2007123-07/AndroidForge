package com.tuition.manager.util

import java.text.NumberFormat
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

object Helpers {

    fun currentMonth(): String {
        val now = YearMonth.now()
        return "%04d-%02d".format(now.year, now.monthValue)
    }

    fun todayISO(): String = LocalDate.now().toString()

    fun monthLabel(month: String): String {
        return try {
            val ym = YearMonth.parse(month)
            val formatter = DateTimeFormatter.ofPattern("MMM yyyy", Locale.ENGLISH)
            ym.format(formatter)
        } catch (_: Exception) {
            month
        }
    }

    fun formatINR(amount: Double): String {
        val nf = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
        nf.maximumFractionDigits = 0
        return nf.format(amount)
    }

    fun monthsFrom(startDate: String): List<String> {
        val result = mutableListOf<String>()
        try {
            var current = YearMonth.from(LocalDate.parse(startDate))
            val now = YearMonth.now()
            while (!current.isAfter(now)) {
                result.add("%04d-%02d".format(current.year, current.monthValue))
                current = current.plusMonths(1)
            }
        } catch (_: Exception) {}
        return result
    }

    fun pendingMonths(
        admissionDate: String,
        monthlyFee: Double,
        payments: List<Pair<String, Double>>
    ): List<Pair<String, Double>> {
        if (monthlyFee <= 0) return emptyList()
        val paidMap = mutableMapOf<String, Double>()
        payments.forEach { (m, amt) ->
            paidMap[m] = (paidMap[m] ?: 0.0) + amt
        }
        return monthsFrom(admissionDate).mapNotNull { m ->
            val paid = paidMap[m] ?: 0.0
            if (paid < monthlyFee) m to (monthlyFee - paid) else null
        }
    }
}
