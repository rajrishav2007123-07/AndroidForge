-- Tuition Management App Schema
-- Idempotent: safe to re-run

-- Enable UUID extension if needed
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 1. institutes
CREATE TABLE IF NOT EXISTS institutes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  phone text,
  address text,
  created_at timestamptz DEFAULT now()
);

-- 2. profiles
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  institute_id uuid REFERENCES institutes ON DELETE SET NULL,
  role text CHECK (role IN ('admin','teacher','parent')) NOT NULL,
  name text NOT NULL,
  phone text,
  created_at timestamptz DEFAULT now()
);

-- 3. batches
CREATE TABLE IF NOT EXISTS batches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  institute_id uuid REFERENCES institutes ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  subject text,
  timing text,
  created_at timestamptz DEFAULT now()
);

-- 4. students
CREATE TABLE IF NOT EXISTS students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  institute_id uuid REFERENCES institutes ON DELETE CASCADE NOT NULL,
  batch_id uuid REFERENCES batches ON DELETE SET NULL,
  name text NOT NULL,
  phone text,
  parent_phone text NOT NULL,
  parent_email text,
  admission_date date DEFAULT current_date,
  monthly_fee numeric(10,2) DEFAULT 0,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- 5. parent_students
CREATE TABLE IF NOT EXISTS parent_students (
  parent_id uuid REFERENCES profiles ON DELETE CASCADE,
  student_id uuid REFERENCES students ON DELETE CASCADE,
  PRIMARY KEY (parent_id, student_id)
);

-- 6. attendance
CREATE TABLE IF NOT EXISTS attendance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid REFERENCES students ON DELETE CASCADE NOT NULL,
  date date NOT NULL,
  status text CHECK (status IN ('present','absent','leave')) NOT NULL,
  marked_by uuid REFERENCES profiles,
  created_at timestamptz DEFAULT now(),
  UNIQUE (student_id, date)
);

-- 7. fee_payments
CREATE TABLE IF NOT EXISTS fee_payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid REFERENCES students ON DELETE CASCADE NOT NULL,
  amount numeric(10,2) NOT NULL,
  month text NOT NULL,
  mode text CHECK (mode IN ('cash','upi','online')),
  receipt_no text,
  notes text,
  paid_at timestamptz DEFAULT now(),
  recorded_by uuid REFERENCES profiles
);

-- 8. tests
CREATE TABLE IF NOT EXISTS tests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  institute_id uuid REFERENCES institutes ON DELETE CASCADE NOT NULL,
  batch_id uuid REFERENCES batches ON DELETE CASCADE,
  name text NOT NULL,
  subject text,
  max_marks int NOT NULL,
  test_date date DEFAULT current_date,
  created_at timestamptz DEFAULT now()
);

-- 9. test_results
CREATE TABLE IF NOT EXISTS test_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  test_id uuid REFERENCES tests ON DELETE CASCADE NOT NULL,
  student_id uuid REFERENCES students ON DELETE CASCADE NOT NULL,
  marks int NOT NULL,
  UNIQUE (test_id, student_id)
);

-- 10. notices
CREATE TABLE IF NOT EXISTS notices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  institute_id uuid REFERENCES institutes ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  body text,
  created_at timestamptz DEFAULT now()
);

-- Seed a default institute (for first admin setup)
INSERT INTO institutes (name, phone, address)
SELECT 'My Tuition Centre', '9876543210', 'Patna, Bihar'
WHERE NOT EXISTS (SELECT 1 FROM institutes LIMIT 1);

-- TRIGGER: after insert on auth.users → profiles + auto-link parents
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role text;
  v_name text;
  v_institute_id uuid;
  v_student record;
BEGIN
  v_role := COALESCE(NEW.raw_user_meta_data->>'role', 'parent');
  v_name := COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1));
  v_institute_id := (NEW.raw_user_meta_data->>'institute_id')::uuid;

  INSERT INTO public.profiles (id, institute_id, role, name, phone)
  VALUES (
    NEW.id,
    v_institute_id,
    v_role,
    v_name,
    NEW.raw_user_meta_data->>'phone'
  );

  -- Auto-link parent to students matching parent_email
  IF v_role = 'parent' THEN
    FOR v_student IN
      SELECT id FROM public.students
      WHERE lower(parent_email) = lower(NEW.email)
    LOOP
      INSERT INTO public.parent_students (parent_id, student_id)
      VALUES (NEW.id, v_student.id)
      ON CONFLICT DO NOTHING;
    END LOOP;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Helper functions for RLS
CREATE OR REPLACE FUNCTION public.my_inst()
RETURNS uuid
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
  SELECT institute_id FROM public.profiles WHERE id = auth.uid();
$$;

CREATE OR REPLACE FUNCTION public.my_role()
RETURNS text
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
  SELECT role FROM public.profiles WHERE id = auth.uid();
$$;

CREATE OR REPLACE FUNCTION public.parent_of(sid uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.parent_students
    WHERE parent_id = auth.uid() AND student_id = sid
  );
$$;

-- Enable RLS on all tables
ALTER TABLE institutes ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE batches ENABLE ROW LEVEL SECURITY;
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE parent_students ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE fee_payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE tests ENABLE ROW LEVEL SECURITY;
ALTER TABLE test_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE notices ENABLE ROW LEVEL SECURITY;

-- ===== POLICIES =====

-- institutes: readable by members of the institute; admins can update
DROP POLICY IF EXISTS "institutes_select" ON institutes;
CREATE POLICY "institutes_select" ON institutes
  FOR SELECT USING (
    id = public.my_inst() OR public.my_role() IN ('admin','teacher')
  );

DROP POLICY IF EXISTS "institutes_update" ON institutes;
CREATE POLICY "institutes_update" ON institutes
  FOR UPDATE USING (public.my_role() = 'admin' AND id = public.my_inst());

-- profiles
DROP POLICY IF EXISTS "profiles_select_own" ON profiles;
CREATE POLICY "profiles_select_own" ON profiles
  FOR SELECT USING (id = auth.uid());

DROP POLICY IF EXISTS "profiles_select_institute" ON profiles;
CREATE POLICY "profiles_select_institute" ON profiles
  FOR SELECT USING (
    institute_id = public.my_inst() AND public.my_role() IN ('admin','teacher')
  );

DROP POLICY IF EXISTS "profiles_update_own" ON profiles;
CREATE POLICY "profiles_update_own" ON profiles
  FOR UPDATE USING (id = auth.uid());

-- batches
DROP POLICY IF EXISTS "batches_select" ON batches;
CREATE POLICY "batches_select" ON batches
  FOR SELECT USING (institute_id = public.my_inst());

DROP POLICY IF EXISTS "batches_write" ON batches;
CREATE POLICY "batches_write" ON batches
  FOR ALL USING (
    institute_id = public.my_inst() AND public.my_role() = 'admin'
  );

-- students
DROP POLICY IF EXISTS "students_admin_teacher" ON students;
CREATE POLICY "students_admin_teacher" ON students
  FOR ALL USING (
    institute_id = public.my_inst() AND public.my_role() IN ('admin','teacher')
  );

DROP POLICY IF EXISTS "students_parent_read" ON students;
CREATE POLICY "students_parent_read" ON students
  FOR SELECT USING (public.parent_of(id));

-- parent_students
DROP POLICY IF EXISTS "parent_students_parent_read" ON parent_students;
CREATE POLICY "parent_students_parent_read" ON parent_students
  FOR SELECT USING (parent_id = auth.uid());

DROP POLICY IF EXISTS "parent_students_admin" ON parent_students;
CREATE POLICY "parent_students_admin" ON parent_students
  FOR ALL USING (public.my_role() = 'admin');

-- attendance
DROP POLICY IF EXISTS "attendance_admin_teacher" ON attendance;
CREATE POLICY "attendance_admin_teacher" ON attendance
  FOR ALL USING (
    public.my_role() IN ('admin','teacher')
    AND EXISTS (
      SELECT 1 FROM students s
      WHERE s.id = attendance.student_id AND s.institute_id = public.my_inst()
    )
  );

DROP POLICY IF EXISTS "attendance_parent_read" ON attendance;
CREATE POLICY "attendance_parent_read" ON attendance
  FOR SELECT USING (public.parent_of(student_id));

-- fee_payments
DROP POLICY IF EXISTS "fee_payments_admin_teacher" ON fee_payments;
CREATE POLICY "fee_payments_admin_teacher" ON fee_payments
  FOR ALL USING (
    public.my_role() IN ('admin','teacher')
    AND EXISTS (
      SELECT 1 FROM students s
      WHERE s.id = fee_payments.student_id AND s.institute_id = public.my_inst()
    )
  );

DROP POLICY IF EXISTS "fee_payments_parent_read" ON fee_payments;
CREATE POLICY "fee_payments_parent_read" ON fee_payments
  FOR SELECT USING (public.parent_of(student_id));

-- tests
DROP POLICY IF EXISTS "tests_select" ON tests;
CREATE POLICY "tests_select" ON tests
  FOR SELECT USING (institute_id = public.my_inst());

DROP POLICY IF EXISTS "tests_write" ON tests;
CREATE POLICY "tests_write" ON tests
  FOR ALL USING (
    institute_id = public.my_inst() AND public.my_role() IN ('admin','teacher')
  );

-- test_results
DROP POLICY IF EXISTS "test_results_admin_teacher" ON test_results;
CREATE POLICY "test_results_admin_teacher" ON test_results
  FOR ALL USING (
    public.my_role() IN ('admin','teacher')
    AND EXISTS (
      SELECT 1 FROM tests t
      WHERE t.id = test_results.test_id AND t.institute_id = public.my_inst()
    )
  );

DROP POLICY IF EXISTS "test_results_parent_read" ON test_results;
CREATE POLICY "test_results_parent_read" ON test_results
  FOR SELECT USING (public.parent_of(student_id));

-- notices
DROP POLICY IF EXISTS "notices_select" ON notices;
CREATE POLICY "notices_select" ON notices
  FOR SELECT USING (institute_id = public.my_inst());

DROP POLICY IF EXISTS "notices_write" ON notices;
CREATE POLICY "notices_write" ON notices
  FOR ALL USING (
    institute_id = public.my_inst() AND public.my_role() IN ('admin','teacher')
  );
