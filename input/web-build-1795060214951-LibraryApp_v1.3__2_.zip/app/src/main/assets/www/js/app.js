(function () {
  var $ = U.$;

  function loginError(msg) { $('login-error').textContent = msg; U.show($('login-error'), !!msg); }
  function busy(on, label) {
    $('login-btn').disabled = on;
    U.show($('login-btn').querySelector('.spinner'), on);
    $('login-btn').querySelector('.btn-label').textContent = on ? (label || 'Logging in…') : 'Login';
  }

  var STAFF_TABS = [
    { id: 'home', label: 'Home', icon: '🏠', render: function (v, a) { Views.Home(v, a); } },
    { id: 'students', label: 'Students', icon: '👥', render: function (v, a) { Views.Students(v, a); } },
    { id: 'seats', label: 'Seats', icon: '🪑', render: function (v, a) { Views.Seats(v, a); } },
    { id: 'dues', label: 'Dues', icon: '₹', render: function (v, a) { Views.Dues(v, a); } },
    { id: 'more', label: 'More', icon: '☰', render: function (v, a) { Views.More(v, a); } }
  ];
  var STUDENT_TABS = [
    { id: 'home', label: 'Home', icon: '🏠', render: function (v, a) { Views.StudentHome(v, a); } },
    { id: 'att', label: 'Attendance', icon: '🕘', render: function (v, a) { Views.StudentAttendance(v, a); } },
    { id: 'pays', label: 'Payments', icon: '₹', render: function (v, a) { Views.StudentPayments(v, a); } },
    { id: 'me', label: 'Profile', icon: '👤', render: function (v, a) { Views.StudentProfile(v, a); } }
  ];

  function showLogin() {
    U.show($('screen-app'), false); U.show($('screen-login'), true); Nav.sheetClose();
  }

  function enterApp() {
    busy(true, 'Opening your account…');
    return App.bootstrap().then(function (mode) {
      busy(false);
      U.show($('screen-login'), false); U.show($('screen-app'), true);
      Nav.init(mode === 'staff' ? STAFF_TABS : STUDENT_TABS);
      Nav.tab('home');
    }, function (e) {
      busy(false);
      if (e.status === 401) { Auth.forget(); } else { Auth.logout(); }
      App.reset(); showLogin(); loginError(e.message);
    });
  }

  window.AppMain = {
    logout: function (expired) {
      Auth.logout().then(function () {
        App.reset(); showLogin();
        U.toast(expired ? 'Session expired, please log in again' : 'Logged out');
      });
    }
  };

  $('toggle-pass').addEventListener('click', function () {
    var p = $('password'), show = p.type === 'password';
    p.type = show ? 'text' : 'password';
    this.textContent = show ? 'Hide' : 'Show';
  });

  $('login-form').addEventListener('submit', function (ev) {
    ev.preventDefault();
    loginError('');
    var email = $('email').value.trim(), pass = $('password').value;
    if (!/^\S+@\S+\.\S+$/.test(email)) return loginError('Enter a valid email address.');
    if (pass.length < 6) return loginError('Password must be at least 6 characters.');
    if (!U.configured()) return loginError('App setup is incomplete: add the Supabase URL and key in js/config.js.');
    busy(true);
    Auth.login(email, pass).then(function () { $('password').value = ''; enterApp(); },
      function (e) { busy(false); loginError(e.message); });
  });

  // Android back button
  window.__onNativeBack = function () { return U.$('screen-app').classList.contains('hidden') ? 'exit' : Nav.onBack(); };

  // Start
  if (!U.configured()) { U.show($('screen-login'), true); return; }
  Auth.restore().then(function (s) { if (s) enterApp(); else showLogin(); });
})();
