// Forms: register student, add payment, renew, edit student, edit membership, remove, cancel payment
(function () {
  var $ = U.$, esc = U.esc;
  var MODES = [['cash', 'Cash'], ['upi', 'UPI'], ['other', 'Other']];

  function errTo(id, msg) { $(id).innerHTML = msg ? U.errBox(msg) : ''; }
  function guard(btn, fn) { // prevents double tap on submit
    btn.addEventListener('click', function () {
      if (btn.disabled) return;
      btn.disabled = true; var t = btn.textContent; btn.textContent = 'Please wait…';
      fn(function () { btn.disabled = false; btn.textContent = t; });
    });
  }
  function num(id) { var s = U.val(id); return s === '' ? NaN : Number(s); }

  // ---------------- Register ----------------
  function register(v) {
    var c = v.el, t = U.today();
    var selSlots = {}, feeTouched = false;
    c.innerHTML = '<div class="card">' + U.field('Name', 'n-name', 'text', { req: 1, maxlength: 120, autocomplete: 'off' }) +
      U.field("Father's name", 'n-father', 'text', { maxlength: 120 }) +
      U.field('Phone (10 digits)', 'n-phone', 'tel', { req: 1, inputmode: 'numeric', maxlength: 15 }) +
      U.field('Email (optional)', 'n-email', 'email', { inputmode: 'email' }) +
      U.field('Address', 'n-addr', 'textarea', { maxlength: 500 }) + '</div>' +
      '<h3 class="sec">Shift and seat</h3><div class="card"><div class="muted small">Select shift (you can choose more than one)</div>' +
      '<div class="chips wrap" id="n-slots">' + U.skeleton(1) + '</div>' +
      '<div class="seatrow">' + U.field('Seat no.', 'n-seat', 'number', { inputmode: 'numeric', min: 1, max: 150, placeholder: 'optional' }) +
      '<button class="ghost-btn" data-act="free">View vacant seats</button></div></div>' +
      '<h3 class="sec">Dates and fee</h3><div class="card"><div class="two">' + U.field('Start', 'n-start', 'date', { value: t }) +
      U.field('Expiry', 'n-end', 'date', { value: U.addMonths(t, 1) }) + '</div>' +
      '<div class="presets"><button class="pill" data-act="m" data-v="1">1 month</button><button class="pill" data-act="m" data-v="3">3 months</button>' +
      '<button class="pill" data-act="m" data-v="6">6 months</button><button class="pill" data-act="m" data-v="12">1 year</button></div>' +
      '<div class="two">' + U.field('Total fee (₹)', 'n-fee', 'number', { req: 1, inputmode: 'decimal', min: 0 }) +
      U.field('Paid now (₹)', 'n-paid', 'number', { inputmode: 'decimal', min: 0, value: '0' }) + '</div>' +
      '<div class="balline" id="n-bal"></div>' +
      '<div class="two">' + U.field('Mode', 'n-mode', 'select', { options: MODES, value: 'cash' }) + U.field('Reference/UPI id', 'n-ref', 'text', { maxlength: 60 }) + '</div>' +
      U.field('Notes', 'n-notes', 'textarea', { maxlength: 1000 }) + '</div>' +
      '<div id="n-err"></div><button class="primary" id="n-go">Register student</button>';

    function bal() {
      var f = num('n-fee'), p = num('n-paid');
      $('n-bal').innerHTML = !isNaN(f) ? 'Due: <b class="' + ((f - (p || 0)) > 0 ? 'neg' : 'pos') + '">' + U.money(f - (p || 0)) + '</b>' : '';
    }
    ['n-fee', 'n-paid'].forEach(function (i) { $(i).addEventListener('input', bal); });
    $('n-fee').addEventListener('input', function () { feeTouched = true; });

    App.slots().then(function (sl) {
      sl = sl.filter(function (s) { return s.is_active; });
      $('n-slots').innerHTML = sl.length ? sl.map(function (s) {
        return '<button class="pill" data-act="slot" data-id="' + esc(s.id) + '">' + esc(App.slotLabel(s)) + '</button>'; }).join('')
        : '<span class="muted small">The owner must create shifts first.</span>';
      v.slotList = sl;
    }, function (e) { $('n-slots').innerHTML = U.errBox(e.message); });

    v.on('slot', function (el) {
      var id = el.getAttribute('data-id');
      if (selSlots[id]) delete selSlots[id]; else selSlots[id] = 1;
      el.classList.toggle('on', !!selSlots[id]);
      if (!feeTouched) {
        var sum = 0, any = false;
        (v.slotList || []).forEach(function (s) { if (selSlots[s.id] && s.default_price !== null && s.default_price !== undefined) { sum += Number(s.default_price); any = true; } });
        if (any) { $('n-fee').value = sum; bal(); }
      }
    });
    v.on('m', function (el) { $('n-end').value = U.addMonths($('n-start').value || t, parseInt(el.getAttribute('data-v'), 10)); });
    v.on('free', function () {
      var ids = Object.keys(selSlots);
      if (!ids.length) { U.toast('Select a shift first'); return; }
      Nav.sheet('<h3>Vacant seats</h3>' + U.skeleton(1));
      Promise.all(ids.map(function (i) { return Api.rpc('vacant_seats', { p_lib: App.libId, p_slot_id: i }); })).then(function (lists) {
        var common = null;
        lists.forEach(function (l) {
          var m = {}; (l || []).forEach(function (r) { m[r.seat_no] = r; });
          if (common === null) common = m; else Object.keys(common).forEach(function (k) { if (!m[k]) delete common[k]; });
        });
        var nos = Object.keys(common || {}).map(Number).sort(function (a, b) { return a - b; });
        Nav.sheet('<h3>Vacant seats (' + nos.length + ')</h3><p class="muted small">Vacant in all selected shifts. Tap a seat to choose it.</p>' +
          (nos.length ? '<div class="seatgrid">' + nos.map(function (n) { return '<button class="seat free" data-n="' + n + '">' + n + '</button>'; }).join('') + '</div>' : U.empty('🪑', 'No seat is vacant in all of these shifts.')));
        Array.prototype.forEach.call(document.querySelectorAll('#sheet-root .seat'), function (b) {
          b.addEventListener('click', function () { $('n-seat').value = b.getAttribute('data-n'); Nav.sheetClose(); });
        });
      }, function (e) { Nav.sheet('<h3>Error</h3>' + U.errBox(e.message)); });
    });

    guard($('n-go'), function (done) {
      var name = U.val('n-name'), phone = U.digits(U.val('n-phone')), fee = num('n-fee'), paid = num('n-paid');
      var start = U.val('n-start'), end = U.val('n-end'), seat = U.val('n-seat'), slots = Object.keys(selSlots);
      var m = null;
      if (name.length < 2) m = 'Enter a name.';
      else if (!/^[0-9]{10,15}$/.test(phone)) m = 'Phone must be 10 to 15 digits.';
      else if (isNaN(fee) || fee < 0) m = 'Enter the total fee.';
      else if (isNaN(paid) ? false : paid < 0) m = 'The paid amount is invalid.';
      else if (!isNaN(paid) && paid > fee) m = 'The paid amount cannot be more than the fee.';
      else if (!start || !end || end < start) m = 'Expiry must be after the start date.';
      else if (seat && !slots.length) m = 'Select a shift along with the seat.';
      if (m) { errTo('n-err', m); done(); return; }
      errTo('n-err', '');
      Api.rpc('register_student', {
        p_lib: App.libId, p_name: name, p_phone: phone, p_fee: fee, p_start: start, p_end: end,
        p_father: U.val('n-father') || null, p_address: U.val('n-addr') || null, p_email: U.val('n-email') || null,
        p_seat_no: seat ? parseInt(seat, 10) : null, p_slot_ids: slots.length ? slots : null,
        p_paid: isNaN(paid) ? 0 : paid, p_mode: U.val('n-mode'), p_reference: U.val('n-ref') || null, p_notes: U.val('n-notes') || null
      }).then(function (r) {
        U.toast('Student registered');
        Nav.back();
        if (r && r.student_id) Nav.push('Student', window.Views.Detail, { id: r.student_id });
      }, function (e) { done(); errTo('n-err', e.message); });
    });
  }

  // ---------------- Payment sheet ----------------
  function payment(v, m, b) {
    var due = b ? Number(b.balance) : null;
    Nav.sheet('<h3>Add payment</h3>' + (due !== null ? '<p class="muted small">Current due: <b class="' + (due > 0 ? 'neg' : 'pos') + '">' + U.money(due) + '</b></p>' : '') +
      '<div class="two">' + U.field('Amount (₹)', 'p-amt', 'number', { req: 1, inputmode: 'decimal', min: 1, value: due > 0 ? due : '' }) +
      U.field('Mode', 'p-mode', 'select', { options: MODES, value: 'cash' }) + '</div>' +
      '<div class="two">' + U.field('Date', 'p-date', 'date', { value: U.today() }) + U.field('Reference', 'p-ref', 'text', { maxlength: 60 }) + '</div>' +
      U.field('Note', 'p-note', 'text', { maxlength: 300 }) + '<div id="p-err"></div><button class="primary" id="p-go">Save payment</button>');
    guard($('p-go'), function (done) {
      var a = num('p-amt');
      if (isNaN(a) || a <= 0) { errTo('p-err', 'Enter an amount greater than 0.'); done(); return; }
      if (due !== null && a > due) { errTo('p-err', 'Amount is more than the due (' + U.money(due) + ').'); done(); return; }
      Api.rpc('add_payment', { p_lib: App.libId, p_membership_id: m.id, p_amount: a, p_mode: U.val('p-mode'),
        p_reference: U.val('p-ref') || null, p_received_on: U.val('p-date') || null, p_note: U.val('p-note') || null })
        .then(function () { Nav.sheetClose(); U.toast('Payment added'); v.reload(); }, function (e) { done(); errTo('p-err', e.message); });
    });
  }

  function cancelPayment(v, id) {
    Nav.sheet('<h3>Cancel payment</h3><p class="muted small">The due amount will increase again after cancelling. A reason is required.</p>' +
      U.field('Reason', 'c-why', 'text', { req: 1, maxlength: 300 }) + '<div id="c-err"></div><button class="primary danger" id="c-go">Cancel payment</button>');
    guard($('c-go'), function (done) {
      var why = U.val('c-why');
      if (why.length < 3) { errTo('c-err', 'Enter a reason of at least 3 characters.'); done(); return; }
      Api.rpc('cancel_payment', { p_lib: App.libId, p_payment_id: id, p_reason: why })
        .then(function () { Nav.sheetClose(); U.toast('Payment cancelled'); v.reload(); }, function (e) { done(); errTo('c-err', e.message); });
    });
  }

  // ---------------- Renew ----------------
  function renew(v, a) {
    var s = a.student, cur = a.cur, c = v.el, t = U.today();
    var base = cur && cur.end_date >= t ? U.addDays(cur.end_date, 1) : t;
    c.innerHTML = '<div class="card"><b>' + esc(s.name) + '</b><div class="muted small">' +
      (cur ? 'Current expiry: ' + U.date(cur.end_date) + ' • seat and shift stay the same' : '') + '</div>' +
      '<p class="muted small">If you renew before expiry, the old seat and shift stay active until the old expiry date.</p>' +
      '<div class="two">' + U.field('New start', 'r-start', 'date', { value: base }) + U.field('New expiry', 'r-end', 'date', { value: U.addMonths(base, 1) }) + '</div>' +
      '<div class="presets"><button class="pill" data-act="m" data-v="1">1 month</button><button class="pill" data-act="m" data-v="3">3 months</button>' +
      '<button class="pill" data-act="m" data-v="6">6 months</button></div>' +
      '<div class="two">' + U.field('Fee (₹)', 'r-fee', 'number', { req: 1, inputmode: 'decimal', min: 0, value: cur ? cur.fee_amount : '' }) +
      U.field('Paid now (₹)', 'r-paid', 'number', { inputmode: 'decimal', min: 0, value: '0' }) + '</div>' +
      '<div class="two">' + U.field('Mode', 'r-mode', 'select', { options: MODES, value: 'cash' }) + U.field('Reference', 'r-ref', 'text', { maxlength: 60 }) + '</div>' +
      U.field('Notes', 'r-notes', 'text', { maxlength: 1000 }) + '</div><div id="r-err"></div><button class="primary" id="r-go">Renew</button>';
    v.on('m', function (el) { $('r-end').value = U.addMonths($('r-start').value || base, parseInt(el.getAttribute('data-v'), 10)); });
    guard($('r-go'), function (done) {
      var fee = num('r-fee'), paid = num('r-paid'), st = U.val('r-start'), en = U.val('r-end'), m = null;
      if (isNaN(fee) || fee < 0) m = 'Enter the fee.';
      else if (!isNaN(paid) && paid > fee) m = 'The paid amount cannot be more than the fee.';
      else if (!en || (st && en < st)) m = 'Expiry must be after the start date.';
      if (m) { errTo('r-err', m); done(); return; }
      Api.rpc('renew_membership', { p_lib: App.libId, p_student_id: s.id, p_end: en, p_fee: fee, p_start: st || null,
        p_paid: isNaN(paid) ? 0 : paid, p_mode: U.val('r-mode'), p_reference: U.val('r-ref') || null, p_notes: U.val('r-notes') || null })
        .then(function () { U.toast('Renewed'); Nav.back(); }, function (e) { done(); errTo('r-err', e.message); });
    });
  }

  // ---------------- Edit student / membership / remove ----------------
  function editStudent(v, s) {
    Nav.sheet('<h3>Edit student</h3>' + U.field('Name', 'e-name', 'text', { value: s.name, maxlength: 120 }) +
      U.field('Father', 'e-father', 'text', { value: s.father_name || '', maxlength: 120 }) +
      U.field('Phone', 'e-phone', 'tel', { value: s.phone, inputmode: 'numeric', maxlength: 15 }) +
      U.field('Email', 'e-email', 'email', { value: s.email || '' }) + U.field('Address', 'e-addr', 'textarea', { value: s.address || '', maxlength: 500 }) +
      U.field('Notes', 'e-notes', 'textarea', { value: s.notes || '', maxlength: 1000 }) + '<div id="e-err"></div><button class="primary" id="e-go">Save</button>');
    guard($('e-go'), function (done) {
      var ch = {}, name = U.val('e-name'), phone = U.digits(U.val('e-phone'));
      if (name.length < 2) { errTo('e-err', 'Enter a name.'); done(); return; }
      if (!/^[0-9]{10,15}$/.test(phone)) { errTo('e-err', 'Phone must be 10 to 15 digits.'); done(); return; }
      var map = { name: name, father_name: U.val('e-father'), phone: phone, email: U.val('e-email'), address: U.val('e-addr'), notes: U.val('e-notes') };
      Object.keys(map).forEach(function (k) { if (String(map[k]) !== String(s[k] || '')) ch[k] = map[k] === '' ? null : map[k]; });
      if (!Object.keys(ch).length) { Nav.sheetClose(); return; }
      Api.rpc('edit_student', { p_lib: App.libId, p_student_id: s.id, p_changes: ch })
        .then(function () { Nav.sheetClose(); U.toast('Saved'); v.reload(); }, function (e) { done(); errTo('e-err', e.message); });
    });
  }

  function editMembership(v, m) {
    Nav.sheet('<h3>Change expiry / fee</h3><p class="muted small">This change is saved in the history.</p><div class="two">' +
      U.field('Start', 'm-start', 'date', { value: m.start_date }) + U.field('Expiry', 'm-end', 'date', { value: m.end_date }) + '</div>' +
      U.field('Fee (₹)', 'm-fee', 'number', { value: m.fee_amount, inputmode: 'decimal', min: 0 }) + '<div id="m-err"></div><button class="primary" id="m-go">Save</button>');
    guard($('m-go'), function (done) {
      var a = { p_lib: App.libId, p_membership_id: m.id }, st = U.val('m-start'), en = U.val('m-end'), fee = num('m-fee');
      if (!st || !en || en < st) { errTo('m-err', 'Expiry must be after the start date.'); done(); return; }
      if (isNaN(fee) || fee < 0) { errTo('m-err', 'Enter a valid fee.'); done(); return; }
      if (st !== m.start_date) a.p_start = st;
      if (en !== m.end_date) a.p_end = en;
      if (fee !== Number(m.fee_amount)) a.p_fee = fee;
      if (Object.keys(a).length === 2) { Nav.sheetClose(); return; }
      Api.rpc('edit_membership', a).then(function () { Nav.sheetClose(); U.toast('Saved'); v.reload(); }, function (e) { done(); errTo('m-err', e.message); });
    });
  }

  function remove(v, s) {
    Nav.sheet('<h3>' + esc(s.name) + ' — remove this student?</h3><p class="muted small">The seat becomes vacant immediately. The student\'s record and history are kept.</p>' +
      U.field('Reason (optional)', 'x-why', 'text', { maxlength: 300 }) + '<div id="x-err"></div><button class="primary danger" id="x-go">Yes, remove</button>');
    guard($('x-go'), function (done) {
      Api.rpc('remove_student', { p_lib: App.libId, p_student_id: s.id, p_reason: U.val('x-why') || null })
        .then(function () { Nav.sheetClose(); U.toast('Student removed'); v.reload(); }, function (e) { done(); errTo('x-err', e.message); });
    });
  }

  // ---------------- Change seat / shift ----------------
  function changeSeat(v, s, cur, shifts, slots, seatNo) {
    var sel = {};
    shifts.filter(function (x) { return x.membership_id === cur.id && x.is_active !== false; }).forEach(function (x) { sel[x.slot_id] = 1; });
    var act = slots.filter(function (x) { return x.is_active; });
    Nav.sheet('<h3>Change seat / shift</h3><p class="muted small">Current seat: <b>' + esc(cur.seat_id && seatNo[cur.seat_id] ? seatNo[cur.seat_id] : 'none') +
      '</b>. The new seat must be vacant in every selected shift.</p><div class="pills-wrap" id="cs-slots">' + act.map(function (x) {
        return '<button class="pill' + (sel[x.id] ? ' on' : '') + '" data-id="' + esc(x.id) + '">' + esc(App.slotLabel(x)) + '</button>'; }).join('') + '</div>' +
      U.field('New seat number', 'cs-seat', 'number', { inputmode: 'numeric', min: 1, max: 150, value: cur.seat_id && seatNo[cur.seat_id] ? seatNo[cur.seat_id] : '' }) +
      '<div id="cs-err"></div><button class="primary" id="cs-go">Save</button>');
    Array.prototype.forEach.call(document.querySelectorAll('#cs-slots .pill'), function (b) {
      b.addEventListener('click', function () { var id = b.getAttribute('data-id'); if (sel[id]) delete sel[id]; else sel[id] = 1; b.classList.toggle('on', !!sel[id]); });
    });
    guard($('cs-go'), function (done) {
      var seat = parseInt(U.val('cs-seat'), 10), ids = Object.keys(sel);
      if (isNaN(seat) || seat < 1 || seat > 150) { errTo('cs-err', 'Enter a seat number between 1 and 150.'); done(); return; }
      if (!ids.length) { errTo('cs-err', 'Select at least one shift.'); done(); return; }
      Api.rpc('change_seat', { p_lib: App.libId, p_student_id: s.id, p_seat_no: seat, p_slot_ids: ids })
        .then(function () { App.clearCaches(); Nav.sheetClose(); U.toast('Seat updated'); v.reload(); }, function (e) {
          done(); errTo('cs-err', /schema cache|Could not find|does not exist/i.test(e.message) ? 'The change-seat SQL (D1) has not been run on the database yet.' : e.message); });
    });
  }

  // ---------------- Edit library profile (owner) ----------------
  function editLibrary(l, onSaved) {
    var t = function (x) { return x ? String(x).slice(0, 5) : ''; };
    Nav.sheet('<h3>Library profile</h3>' + U.field('Library name', 'l-name', 'text', { value: l.name || '', maxlength: 120 }) +
      U.field('Address', 'l-addr', 'textarea', { value: l.address || '', maxlength: 500 }) +
      U.field('Phone', 'l-phone', 'tel', { value: l.phone || '', inputmode: 'numeric', maxlength: 15 }) +
      '<div class="two">' + U.field('Opens at', 'l-open', 'time', { value: t(l.open_time) }) + U.field('Closes at', 'l-close', 'time', { value: t(l.close_time) }) + '</div>' +
      '<div id="l-err"></div><button class="primary" id="l-go">Save</button>');
    guard($('l-go'), function (done) {
      var name = U.val('l-name');
      if (name.length < 2) { errTo('l-err', 'Enter the library name.'); done(); return; }
      Api.rpc('update_library', { p_lib: App.libId, p_name: name, p_address: U.val('l-addr') || null, p_phone: U.val('l-phone') || null,
        p_open: U.val('l-open') || null, p_close: U.val('l-close') || null })
        .then(function () { Nav.sheetClose(); U.toast('Library profile saved'); if (onSaved) onSaved(name); }, function (e) {
          done(); errTo('l-err', /schema cache|Could not find|does not exist/i.test(e.message) ? 'The profile SQL (D2) has not been run on the database yet.' : e.message); });
    });
  }

  function themeSheet(after) {
    var cur = Theme.get();
    Nav.sheet('<h3>Theme</h3><div class="themegrid">' + [['auto', 'Automatic'], ['light', 'Light'], ['dark', 'Dark']].map(function (x) {
      return '<button class="themebtn' + (cur === x[0] ? ' on' : '') + '" data-t="' + x[0] + '">' + x[1] + '</button>'; }).join('') + '</div>');
    Array.prototype.forEach.call(document.querySelectorAll('#sheet-root .themebtn'), function (b) {
      b.addEventListener('click', function () { Theme.set(b.getAttribute('data-t')); Nav.sheetClose(); if (after) after(); });
    });
  }

  window.Forms = { changeSeat: changeSeat, editLibrary: editLibrary, themeSheet: themeSheet, register: register, payment: payment, cancelPayment: cancelPayment, renew: renew, editStudent: editStudent, editMembership: editMembership, remove: remove };
})();
