// Seat icons (inline SVG, colour follows the seat state via currentColor)
(function () {
  var open = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">';
  var P = {
    chair: open + '<path d="M7 3h10v8H7z"/><path d="M5 11h14v4H5z"/><path d="M7 15v6M17 15v6"/></svg>',
    desk: open + '<rect x="3" y="9" width="18" height="3" rx="1"/><path d="M5 12v8M19 12v8"/><path d="M8 9V5h6v4"/></svg>',
    cabin: open + '<path d="M4 21V5a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v16"/><path d="M3 21h18"/><path d="M8 21v-6h8v6"/><path d="M9 9h6"/></svg>',
    number: ''
  };
  var WA = '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2c-1.5 0-2.9-.4-4.1-1.1l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.200zm4.500-6.100c-.2-.1-1.500-.7-1.700-.8-.2-.1-.4-.1-.6.1l-.8 1c-.1.200-.3.200-.5.100-1.500-.7-2.400-1.300-3.400-2.900-.3-.4.300-.4.800-1.300.1-.2 0-.3 0-.5l-.8-1.800c-.2-.5-.4-.4-.6-.4h-.5c-.2 0-.5.1-.7.300-.7.700-1 1.500-1 2.400.1 1.200.6 2.300 1.400 3.200 1.500 1.800 3.400 2.800 5.800 3.300.9.200 1.700.1 2.300-.5.300-.3.600-.8.700-1.300.1-.3.100-.5 0-.6l-.5-.3z"/></svg>';
  window.Icons = {
    wa: WA,
    styles: [['chair', 'Chair'], ['desk', 'Study desk'], ['cabin', 'Cabin'], ['number', 'Number only']],
    seat: function (style) { return P[style] !== undefined ? P[style] : P.chair; }
  };
})();
