// Theme: auto (follows phone) / light / dark. Choice is remembered on the phone via the native bridge.
(function () {
  var native = typeof window.NativeApp !== 'undefined' && window.NativeApp.getTheme;
  var pref = 'auto';
  try { if (native) pref = window.NativeApp.getTheme() || 'auto'; } catch (e) {}
  var mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
  function apply() {
    var dark = pref === 'dark' || (pref === 'auto' && mq && mq.matches);
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
  }
  if (mq && mq.addEventListener) mq.addEventListener('change', apply);
  window.Theme = {
    get: function () { return pref; },
    set: function (v) {
      if (v !== 'light' && v !== 'dark') v = 'auto';
      pref = v; apply(); if (window.Theme && window.Theme.repaint) window.Theme.repaint();
      try { if (native) window.NativeApp.setTheme(v); } catch (e) {}
    },
    label: function () { return pref === 'auto' ? 'Automatic' : pref === 'dark' ? 'Dark' : 'Light'; }
  };
  apply();

  // Always-visible light/dark switch button (top-right on every screen).
  function isDark() { return document.documentElement.getAttribute('data-theme') === 'dark'; }
  function mount() {
    if (document.getElementById('theme-fab')) return;
    var b = document.createElement('button');
    b.id = 'theme-fab'; b.className = 'theme-fab'; b.type = 'button';
    function paint() { b.textContent = isDark() ? '☀️' : '🌙'; b.setAttribute('aria-label', isDark() ? 'Switch to light mode' : 'Switch to dark mode'); }
    b.addEventListener('click', function () { window.Theme.set(isDark() ? 'light' : 'dark'); paint(); });
    document.body.appendChild(b); paint();
    window.Theme.repaint = paint;
  }
  if (document.body) mount(); else document.addEventListener('DOMContentLoaded', mount);
})();
