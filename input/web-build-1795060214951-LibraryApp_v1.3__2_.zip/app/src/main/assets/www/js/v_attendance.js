// ATTENDANCE: staff page (daily code, present/absent, report) + student check-in card & tab
(function () {
  var $ = U.$, esc = U.esc;

  function sqlMissing(m) {
    return /schema cache|Could not find|does not exist|function public\./i.test(m)
      ? 'The attendance SQL (B1 and B2) has not been run on the database yet. Please run it first.' : m;
  }
  function hm(iso) {
    if (!iso) return '—';
    return new Date(iso).toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit', hour12: true, timeZone: 'Asia/Kolkata' });
  }
  function dur(a, b) {
    if (!a || !b) return '';
    var m = Math.round((new Date(b) - new Date(a)) / 60000);
    return m >= 60 ? Math.floor(m / 60) + ' hr ' + (m % 60) + ' min' : m + ' min';
  }
  function istDate(iso) { return new Date(new Date(iso).getTime() + 330 * 60000).toISOString().slice(0, 10); }

  // ---------------- STAFF ----------------
  function Staff(v) {
    var c = v.el, t = U.today(), mode = 'today', date = t;
    c.innerHTML = '<div class="seg"><button class="on" data-act="seg" data-v="today">Today / Day</button><button data-act="seg" data-v="report">Report</button></div><div id="att-body">' + U.skeleton(3) + '</div>';
    v.on('seg', function (el) {
      mode = el.getAttribute('data-v');
      Array.prototype.forEach.call(c.querySelectorAll('.seg button'), function (b) { b.classList.toggle('on', b === el); });
      mode === 'today' ? day() : report(7);
    });

    function day() {
      $('att-body').innerHTML = U.skeleton(3);
      Promise.all([date === t ? Api.rpc('attendance_code', { p_lib: App.libId }) : Promise.resolve(null), Api.rpc('attendance_today', { p_lib: App.libId, p_date: date })]).then(function (r) {
        var code = r[0], d = r[1], h = '';
        if (code) h += '<section class="codecard"><div class="k">Today\'s attendance code</div><div class="code" id="code-v">' + esc(code.code) +
          '</div><div class="small">Show or tell students this code at the library. It changes every day. ' +
          'The code is only available at the library, so attendance cannot be marked from home.</div>' +
          '<button class="ghost-btn light" data-act="big">Show in large size</button></section>';
        h += '<div class="card"><div class="two">' + U.field('Day', 'a-date', 'date', { value: date, max: t }) +
          '<div class="trio2"><div><b class="pos">' + d.present + '</b><small>present</small></div><div><b class="neg">' + d.absent + '</b><small>absent</small></div></div></div></div>';
        h += '<h3 class="sec">Present (' + d.present + ')</h3>';
        h += d.present_rows.length ? '<section class="card list">' + d.present_rows.map(function (x) {
          return '<div class="row"><div><b>' + esc(x.name) + '</b><div class="muted small">In ' + hm(x.check_in) + (x.check_out ? ' • Out ' + hm(x.check_out) + ' • ' + dur(x.check_in, x.check_out) : ' • still inside') + '</div></div>' +
            '<a class="callbtn" href="tel:' + esc(x.phone) + '">☎</a></div>'; }).join('') + '</section>' : U.empty('🕘', 'No one has marked attendance yet.');
        h += '<h3 class="sec">Absent (' + d.absent + ')</h3>';
        h += d.absent_rows.length ? '<section class="card list">' + d.absent_rows.map(function (x) {
          return '<div class="row"><b>' + esc(x.name) + '</b><div class="acts"><a class="callbtn" href="tel:' + esc(x.phone) + '">☎</a>' + U.waBtn(x.phone, 'Hello ' + x.name + ', we did not see you at ' + App.libName + ' today. Hope everything is fine. See you soon!') + '</div></div>'; }).join('') + '</section>' +
          (d.absent > d.absent_rows.length ? '<p class="foot">Showing the first ' + d.absent_rows.length + '.</p>' : '') : U.empty('🎉', 'Everyone is present!');
        $('att-body').innerHTML = h;
        $('a-date').addEventListener('change', function () { date = this.value || t; day(); });
      }, function (e) { $('att-body').innerHTML = U.errBox(sqlMissing(e.message)); });
    }
    v.on('big', function () {
      Nav.sheet('<div class="bigcode"><div class="k">Today\'s code</div><div class="code huge">' + esc(U.$('code-v').textContent) + '</div><div class="small muted">' + U.date(t) + '</div></div>');
    });

    function report(days) {
      var to = t, from = U.addDays(t, -(days - 1));
      $('att-body').innerHTML = '<div class="presets"><button class="pill' + (days === 7 ? ' on' : '') + '" data-act="rp" data-v="7">7 days</button><button class="pill' + (days === 30 ? ' on' : '') + '" data-act="rp" data-v="30">30 days</button><button class="pill' + (days === 90 ? ' on' : '') + '" data-act="rp" data-v="90">90 days</button></div><div id="rp-body">' + U.skeleton(3) + '</div>';
      Api.rpc('attendance_report', { p_lib: App.libId, p_from: from, p_to: to }).then(function (r) {
        var max = 1; (r.days || []).forEach(function (x) { if (x.present > max) max = x.present; });
        var h = '<section class="stat accent big"><div class="k">Total check-ins (' + U.date(r.from) + ' – ' + U.date(r.to) + ')</div><div class="v">' + U.num(r.total_checkins) + '</div></section>';
        h += (r.days || []).length ? '<h3 class="sec">By day</h3><section class="card list">' + r.days.slice().reverse().map(function (x) {
          return '<div class="row bar"><span>' + U.date(x.date) + '</span><span class="barwrap"><i class="barfill w' + Math.max(5, Math.round(x.present / max * 20) * 5) + '"></i></span><b>' + x.present + '</b></div>'; }).join('') + '</section>' : U.empty('📅', 'No attendance in this period.');
        if ((r.students || []).length) h += '<h3 class="sec">By student (days attended)</h3><section class="card list">' + r.students.map(function (x) {
          return '<div class="row"><span>' + esc(x.name) + '</span><b>' + x.days + ' days</b></div>'; }).join('') + '</section>';
        $('rp-body').innerHTML = h;
      }, function (e) { $('rp-body').innerHTML = U.errBox(sqlMissing(e.message)); });
    }
    v.on('rp', function (el) { report(parseInt(el.getAttribute('data-v'), 10)); });
    day();
  }

  // ---------------- STUDENT: check-in card (used on student Home) ----------------
  function studentCard(host, onChange) {
    var t = U.today();
    host.innerHTML = '<div class="card attcard"><div class="muted small">Loading attendance…</div></div>';
    Api.get('attendance?' + Api.q({ select: 'att_date,check_in,check_out', student_id: 'eq.' + App.student.id, att_date: 'eq.' + t })).then(function (rows) {
      var a = rows && rows[0], h = '<div class="card attcard"><div class="k">Today\'s attendance</div>';
      if (!a) h += '<div class="attstate">Not marked yet</div><button class="primary" data-act="att" data-v="in">✅ Check in</button>';
      else if (!a.check_out) h += '<div class="attstate ok">Check-in: ' + hm(a.check_in) + '</div><button class="primary out" data-act="att" data-v="out">🚪 Check out</button>';
      else h += '<div class="attstate ok">In ' + hm(a.check_in) + ' • Out ' + hm(a.check_out) + '</div><div class="muted small">Studied ' + dur(a.check_in, a.check_out) + ' today. Well done! 🎉</div>';
      host.innerHTML = h + '</div>';
    }, function (e) { host.innerHTML = '<div class="card attcard">' + U.errBox(sqlMissing(e.message)) + '</div>'; });

    if (host._attBound) return;
    host._attBound = true;
    host.addEventListener('click', function (ev) {
      var b = ev.target.closest('[data-act="att"]'); if (!b) return;
      var act = b.getAttribute('data-v');
      Nav.sheet('<h3>' + (act === 'in' ? 'Check-in' : 'Check-out') + '</h3><p class="muted small">Enter today\'s 6-digit code displayed at the library.</p>' +
        U.field("Today's code", 'att-code', 'text', { inputmode: 'numeric', maxlength: 6, placeholder: '------', autocomplete: 'off' }) +
        '<div id="att-err"></div><button class="primary" id="att-go">Confirm</button>');
      $('att-go').addEventListener('click', function () {
        var code = U.val('att-code'), btn = this;
        if (!/^[0-9]{6}$/.test(code)) { $('att-err').innerHTML = U.errBox('Enter the 6-digit code.'); return; }
        btn.disabled = true; btn.textContent = 'Please wait…';
        Api.rpc('mark_attendance', { p_lib: App.libId, p_code: code, p_action: act }).then(function (r) {
          if (r && r.ok === false) { btn.disabled = false; btn.textContent = 'Confirm'; $('att-err').innerHTML = U.errBox(r.error); return; }
          Nav.sheetClose(); U.toast(act === 'in' ? 'Checked in ✅' : 'Checked out'); studentCard(host, onChange); if (onChange) onChange();
        }, function (e) { btn.disabled = false; btn.textContent = 'Confirm'; $('att-err').innerHTML = U.errBox(sqlMissing(e.message)); });
      });
    });
  }

  // ---------------- STUDENT: attendance tab ----------------
  function StudentTab(v) {
    var c = v.el;
    c.innerHTML = '<div class="topbar"><div class="lib-name">My attendance</div></div><div id="att-card"></div><div id="att-list">' + U.skeleton(3) + '</div>';
    function load() {
      studentCard($('att-card'), load);
      var from = U.addDays(U.today(), -89);
      Api.get('attendance?' + Api.q({ select: 'att_date,check_in,check_out', student_id: 'eq.' + App.student.id, 'att_date': 'gte.' + from, order: 'att_date.desc', limit: 100 })).then(function (rows) {
        rows = rows || [];
        var t = U.today(), set = {}; rows.forEach(function (r) { set[r.att_date] = 1; });
        var month = rows.filter(function (r) { return r.att_date.slice(0, 7) === t.slice(0, 7); }).length;
        var streak = 0, d = set[t] ? t : U.addDays(t, -1);
        while (set[d] && streak < 90) { streak++; d = U.addDays(d, -1); }
        var h = '<section class="grid2 mt">' + '<div class="stat accent"><div class="k">This month</div><div class="v">' + month + ' days</div></div>' +
          '<div class="stat"><div class="k">Current streak</div><div class="v">' + streak + ' 🔥</div></div></section>';
        h += rows.length ? '<h3 class="sec">Previous days</h3><section class="card list">' + rows.map(function (r) {
          return '<div class="row"><div><b>' + U.date(r.att_date) + '</b><div class="muted small">In ' + hm(r.check_in) + (r.check_out ? ' • Out ' + hm(r.check_out) + ' • ' + dur(r.check_in, r.check_out) : ' • no check-out') + '</div></div></div>'; }).join('') + '</section>'
          : U.empty('📅', 'No attendance records yet.');
        $('att-list').innerHTML = h;
      }, function (e) { $('att-list').innerHTML = U.errBox(sqlMissing(e.message)); });
    }
    load();
  }

  window.Views = window.Views || {};
  window.Views.AttendanceStaff = Staff; window.Views.StudentAttendance = StudentTab; window.AttCard = studentCard;
})();
