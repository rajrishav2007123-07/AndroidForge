// HOME tab (owner / staff) + MORE tab + COLLECTION REPORT page
(function () {
  var $ = U.$, esc = U.esc;

  function statCard(k, v, sub, cls, act, val) {
    return '<div class="stat ' + (cls || '') + '"' + (act ? ' data-act="' + act + '" data-v="' + val + '"' : '') + '><div class="k">' + k +
      '</div><div class="v">' + v + '</div>' + (sub ? '<div class="sub">' + sub + '</div>' : '') + '</div>';
  }

  function Home(v) {
    var c = v.el;
    c.innerHTML = '<div class="topbar"><div><div class="small muted">' + (App.role === 'owner' ? 'Owner' : 'Staff') +
      '</div><div class="lib-name">' + esc(App.libName) + '</div></div><button class="icon-btn" data-act="refresh" aria-label="Refresh">⟳</button></div>' +
      '<div id="home-body">' + U.skeleton(4) + '</div>';
    v.on('refresh', function () { v.reload(); });
    v.on('go', function (el) { Nav.tab(el.getAttribute('data-v')); });
    v.on('new', function () { Nav.push('New student', window.Forms.register); });
    v.on('exp', function (el) { Nav.tab('students', { expiry: el.getAttribute('data-v') }); });
    v.on('report', function () { Nav.push('Report', window.Views.Report); });
    v.on('dues', function () { Nav.tab('dues'); });
    v.on('att', function () { Nav.push('Attendance', window.Views.AttendanceStaff); });
    v.on('drep', function () { Nav.push('Date report', window.Views.DateReport); });

    Api.rpc('dashboard', { p_lib: App.libId }).then(function (d) {
      var qa = '';
      if (App.can('can_register_students')) qa += '<button class="qa" data-act="new"><span>＋</span>New student</button>';
      qa += '<button class="qa" data-act="go" data-v="students"><span>⌕</span>Search</button>';
      qa += '<button class="qa" data-act="dues"><span>₹</span>Dues</button>';
      qa += '<button class="qa" data-act="att"><span>🕘</span>Attendance</button>';
      if (App.can('can_view_reports')) qa += '<button class="qa" data-act="report"><span>▤</span>Report</button><button class="qa" data-act="drep"><span>📅</span>Date report</button>';
      var money = d.total_balance !== null && d.total_balance !== undefined;
      var h = '<div class="qa-row">' + qa + '</div><div id="home-att"></div>' +
        '<section class="grid2">' + statCard('Active students', U.num(d.active_students), 'Running: ' + U.num(d.running_memberships), 'accent', 'exp', 'running') +
        statCard('Fully vacant seats', U.num(d.seats_completely_free), 'total seats: ' + U.num(d.seats_total), '', 'go', 'seats') + '</section>' +
        '<h3 class="sec">Expiring (tap to view the list)</h3><section class="grid4">' +
        '<div class="chip warn" data-act="exp" data-v="today"><div class="v">' + U.num(d.expiring_today) + '</div><div class="k">Today</div></div>' +
        '<div class="chip" data-act="exp" data-v="next3"><div class="v">' + U.num(d.expiring_in_3_days) + '</div><div class="k">3 days</div></div>' +
        '<div class="chip" data-act="exp" data-v="next7"><div class="v">' + U.num(d.expiring_in_7_days) + '</div><div class="k">7 days</div></div>' +
        '<div class="chip" data-act="exp" data-v="next15"><div class="v">' + U.num(d.expiring_in_15_days) + '</div><div class="k">15 days</div></div></section>' +
        '<section class="card list">' +
        '<div class="row tap" data-act="exp" data-v="held"><span>Expired, seat on hold</span><b>' + U.num(d.expired_seat_held) + '</b></div>' +
        '<div class="row tap" data-act="exp" data-v="lapsed"><span>Seat released (lapsed)</span><b>' + U.num(d.lapsed_seat_released) + '</b></div></section>';
      if (money) {
        var modes = d.today_by_mode || {};
        var ml = Object.keys(modes).map(function (k) { return esc(k) + ' ' + U.money(modes[k]); }).join(' • ');
        h += '<h3 class="sec">Money</h3><section class="grid2">' +
          statCard("Today's collection", U.money(d.today_collection), U.num(d.today_payments_count) + ' payments' + (ml ? '<br>' + ml : '')) +
          statCard('This month', U.money(d.month_collection)) + '</section>' +
          '<section class="stat due tap" data-act="dues"><div class="k">Total dues</div><div class="v">' + U.money(d.total_balance) +
          '</div><div class="sub">' + U.num(d.students_with_balance) + ' students with dues • view list ›</div></section>';
        if (d.today_cancelled_count) h += '<p class="foot">' + d.today_cancelled_count + ' payment(s) cancelled today</p>';
      }
      h += '<p class="foot">Data as on ' + U.date(d.as_on) + '</p>';
      $('home-body').innerHTML = h;
      Api.rpc('attendance_today', { p_lib: App.libId }).then(function (a) {
        $('home-att').innerHTML = '<section class="stat tap attsum" data-act="att"><div class="k">Today\'s attendance</div><div class="v"><span class="pos">' + a.present + '</span> present • <span class="neg">' + a.absent + '</span> absent</div><div class="sub">view code and list ›</div></section>';
      }, function () {});
    }, function (e) {
      if (e.status === 401) { window.AppMain.logout(true); return; }
      $('home-body').innerHTML = U.errBox(e.message, true);
    });
  }

  // ---------------- MORE tab ----------------
  function More(v) {
    var c = v.el, u = Auth.current().user;
    var h = '<div class="topbar"><div class="lib-name">More</div></div>' +
      '<section class="card profile"><div class="avatar">' + esc((u.email || '?').charAt(0).toUpperCase()) + '</div><div><b>' + esc(u.email) +
      '</b><div class="muted small">' + (App.role === 'owner' ? 'Library owner' : 'Staff') + ' • ' + esc(App.libName) + '</div></div></section>' +
      '<section class="card list">';
    h += '<div class="row tap" data-act="att"><span>🕘 &nbsp;Attendance</span><b>›</b></div>';
    if (App.can('can_view_reports')) h += '<div class="row tap" data-act="report"><span>▤ &nbsp;Reports (month / dates)</span><b>›</b></div><div class="row tap" data-act="drep"><span>📅 &nbsp;Date report (future dates)</span><b>›</b></div>';
    if (App.role === 'owner') h += '<div class="row tap" data-act="sstyle"><span>🪑 &nbsp;Seat icon style</span><b>›</b></div>';
    h += '<div class="row tap" data-act="theme"><span>🌓 &nbsp;Theme: ' + Theme.label() + '</span><b>›</b></div>';
    h += '<div class="row tap" data-act="lib"><span>🏛 &nbsp;Library details</span><b>›</b></div>';
    if (App.role === 'owner') h += '<div class="row tap" data-act="seatcount"><span>▦ &nbsp;Change number of seats</span><b>›</b></div>';
    h += '<div class="row tap" data-act="perm"><span>🔑 &nbsp;My permissions</span><b>›</b></div></section>' +
      '<button class="danger-btn" data-act="logout">Logout</button><p class="foot soft">Library Manager • v1.3</p>';
    c.innerHTML = h;
    v.on('report', function () { Nav.push('Report', window.Views.Report); });
    v.on('att', function () { Nav.push('Attendance', window.Views.AttendanceStaff); });
    v.on('drep', function () { Nav.push('Date report', window.Views.DateReport); });
    v.on('sstyle', function () {
      Nav.sheet('<h3>Seat icon style</h3><p class="muted small">This style will show on the seat map for the whole library.</p><div class="stylegrid">' + Icons.styles.map(function (x) {
        return '<button class="stylebtn' + (App.seatStyle === x[0] ? ' on' : '') + '" data-style="' + x[0] + '"><div class="seat free">' + Icons.seat(x[0]) + '<b>12</b></div><span>' + x[1] + '</span></button>'; }).join('') + '</div><div id="ss-err"></div>');
      Array.prototype.forEach.call(document.querySelectorAll('#sheet-root .stylebtn'), function (b) {
        b.addEventListener('click', function () {
          var sty = b.getAttribute('data-style');
          Api.rpc('set_seat_style', { p_lib: App.libId, p_style: sty }).then(function () { App.seatStyle = sty; Nav.sheetClose(); U.toast('Seat style updated'); }, function (e) {
            $('ss-err').innerHTML = U.errBox(/schema cache|Could not find|does not exist/i.test(e.message) ? 'The seat style SQL (A3) has not been run on the database yet.' : e.message); });
        });
      });
    });
    v.on('logout', function () { window.AppMain.logout(); });
    v.on('theme', function () { window.Forms.themeSheet(function () { v.reload(); }); });
    v.on('perm', function () {
      var names = { can_register_students: 'Register / edit students', can_add_payments: 'Add / cancel payments', can_edit_expiry: 'Change expiry / fee',
        can_remove_students: 'Remove students', can_view_reports: 'View reports and money' };
      Nav.sheet('<h3>My permissions</h3>' + Object.keys(names).map(function (k) {
        return '<div class="row"><span>' + names[k] + '</span><b>' + (App.can(k) ? '✅' : '—') + '</b></div>'; }).join(''));
    });
    v.on('lib', function () {
      Nav.sheet('<h3>Library details</h3><p class="muted">Loading…</p>');
      Api.get('libraries?' + Api.q({ select: 'name,address,phone,open_time,close_time,seat_capacity,grace_days', id: 'eq.' + App.libId })).then(function (r) {
        var l = r[0] || {};
        Nav.sheet('<h3>' + esc(l.name) + '</h3><div class="row"><span>Address</span><b>' + esc(l.address || '—') + '</b></div>' +
          '<div class="row"><span>Phone</span><b>' + esc(l.phone || '—') + '</b></div>' +
          '<div class="row"><span>Timing</span><b>' + (l.open_time ? App.hhmm(l.open_time) + ' – ' + App.hhmm(l.close_time) : '—') + '</b></div>' +
          '<div class="row"><span>Seats</span><b>' + U.num(l.seat_capacity) + '</b></div>' +
          '<div class="row"><span>Seat hold after expiry</span><b>' + U.num(l.grace_days) + ' days</b></div>' +
          (App.role === 'owner' ? '<button class="primary" id="lib-edit">Edit library profile</button>' : ''));
        if ($('lib-edit')) $('lib-edit').addEventListener('click', function () { window.Forms.editLibrary(l, function (nm) { App.libName = nm; v.reload(); }); });
      }, function (e) { Nav.sheet('<h3>Error</h3>' + U.errBox(e.message)); });
    });
    v.on('seatcount', function () {
      Nav.sheet('<h3>Number of seats</h3><p class="muted small">0 to 150. Seats that currently have a student will not be closed.</p>' +
        U.field('Total seats', 'sc-n', 'number', { inputmode: 'numeric', min: 0, max: 150, placeholder: 'e.g. 60' }) +
        '<div id="sc-err"></div><button class="primary" id="sc-go">Save</button>');
      $('sc-go').addEventListener('click', function () {
        var n = parseInt($('sc-n').value, 10);
        if (isNaN(n) || n < 0 || n > 150) { $('sc-err').innerHTML = U.errBox('Enter a number between 0 and 150.'); return; }
        this.disabled = true;
        Api.rpc('set_seat_count', { p_lib: App.libId, p_count: n }).then(function () {
          App.clearCaches(); Nav.sheetClose(); U.toast('Seats updated'); }, function (e) {
          $('sc-go').disabled = false; $('sc-err').innerHTML = U.errBox(e.message); });
      });
    });
  }

  window.Views = window.Views || {};
  window.Views.Home = Home; window.Views.More = More;
})();
