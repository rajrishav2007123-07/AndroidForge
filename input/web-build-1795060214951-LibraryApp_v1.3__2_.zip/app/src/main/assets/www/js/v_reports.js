// DATE REPORT (up to a future date) and PERIOD REPORT (month / date range) with tappable lists
(function () {
  var $ = U.$, esc = U.esc;

  function sqlMissing(m) {
    return /schema cache|Could not find|does not exist|function public\./i.test(m)
      ? 'The new SQL (A2_reports.sql) has not been run on the database yet. Please run it first.' : m;
  }
  function stat(k, v, sub, act, data, cls) {
    var d = ''; Object.keys(data || {}).forEach(function (x) { d += ' data-' + x + '="' + esc(data[x]) + '"'; });
    return '<div class="stat ' + (cls || '') + '"' + (act ? ' data-act="' + act + '"' + d : '') + '><div class="k">' + k + '</div><div class="v">' + v + '</div>' +
      (sub ? '<div class="sub">' + sub + '</div>' : '') + '</div>';
  }
  function openList(title, args) {
    args.page = true; args.title = title;
    Nav.push(title, window.Views.Students, args);
  }

  // ---------------- DATE REPORT ----------------
  function DateReport(v) {
    var c = v.el, t = U.today(), st = { to: U.addDays(t, 7) };
    c.innerHTML = '<div class="presets"><button class="pill" data-act="p" data-v="1">Tomorrow</button><button class="pill on" data-act="p" data-v="7">7 days</button>' +
      '<button class="pill" data-act="p" data-v="15">15 days</button><button class="pill" data-act="p" data-v="30">30 days</button>' +
      '<button class="pill" data-act="p" data-v="eom">Until month end</button></div>' +
      '<div class="card">' + U.field('View the report up to this date', 'dr-to', 'date', { value: st.to, min: t }) +
      '<button class="primary sm" data-act="go">View report</button></div><div id="dr-body"></div>';
    v.on('p', function (el) {
      var k = el.getAttribute('data-v');
      st.to = k === 'eom' ? new Date(Date.UTC(+t.slice(0, 4), +t.slice(5, 7), 0)).toISOString().slice(0, 10) : U.addDays(t, parseInt(k, 10));
      $('dr-to').value = st.to;
      Array.prototype.forEach.call(c.querySelectorAll('.pill'), function (b) { b.classList.toggle('on', b === el); });
      run();
    });
    v.on('go', function () { st.to = $('dr-to').value; run(); });
    v.on('list', function (el) {
      var k = el.getAttribute('data-k'), d = st.to;
      if (k === 'exp') openList('Expiring (' + U.date(t) + ' – ' + U.date(d) + ')', { expiry: 'running', from: t, to: d });
      else if (k === 'held') openList('Expired, seat on hold', { expiry: 'held' });
      else if (k === 'lapsed') openList('Lapsed (seat released)', { expiry: 'lapsed' });
      else if (k === 'day') openList(U.date(el.getAttribute('data-d')) + ' expiring', { expiry: 'running', from: el.getAttribute('data-d'), to: el.getAttribute('data-d') });
      else openList(el.getAttribute('data-title'), { fee: k });
    });
    function run() {
      if (!st.to || st.to < t) { $('dr-body').innerHTML = U.errBox('Choose today or a future date.'); return; }
      $('dr-body').innerHTML = U.skeleton(4);
      Api.rpc('date_report', { p_lib: App.libId, p_to: st.to }).then(function (r) {
        var h = '<section class="stat accent big" data-act="list" data-k="exp"><div class="k">' + U.date(t) + ' se ' + U.date(r.to) + ' expiring</div><div class="v">' +
          U.num(r.expiring_count) + ' students</div><div class="sub">Their total fee: ' + U.money(r.expiring_fee) + ' • view list ›</div></section>';
        h += '<section class="grid2 mt">' + stat('Expired, seat on hold', U.num(r.expired_held), 'tap to view ›', 'list', { k: 'held' }) +
          stat('Lapsed (seat released)', U.num(r.expired_lapsed), 'tap to view ›', 'list', { k: 'lapsed' }) + '</section>';
        h += '<h3 class="sec">Pending dues (up to today)</h3><section class="stat due" data-act="list" data-k="due" data-title="Students with dues"><div class="k">Total dues</div><div class="v">' + U.money(r.total_balance) +
          '</div><div class="sub">' + U.num(r.students_with_balance) + ' students • view list ›</div></section>';
        h += '<section class="grid3 mt">' +
          stat('Fully paid', U.num(r.full_count), '', 'list', { k: 'full', title: 'Fully paid students' }, 'mini') +
          stat('Partial', U.num(r.partial_count), U.money(r.partial_due) + ' due', 'list', { k: 'partial', title: 'Partially paid students' }, 'mini') +
          stat('Nothing paid', U.num(r.unpaid_count), U.money(r.unpaid_due) + ' due', 'list', { k: 'unpaid', title: 'Students who have paid nothing' }, 'mini') + '</section>';
        var tl = r.timeline || [];
        if (tl.length) h += '<h3 class="sec">By day expiry</h3><section class="card list">' + tl.map(function (x) {
          return '<div class="row tap" data-act="list" data-k="day" data-d="' + esc(x.date) + '"><span>' + U.date(x.date) + '</span><b>' + x.count + ' ›</b></div>'; }).join('') + '</section>';
        else h += '<p class="foot">No membership expires in this period.</p>';
        $('dr-body').innerHTML = h;
      }, function (e) { $('dr-body').innerHTML = U.errBox(sqlMissing(e.message)); });
    }
    run();
  }

  // ---------------- PERIOD / COLLECTION REPORT ----------------
  function monthRange(t, back) {
    var y = +t.slice(0, 4), m = +t.slice(5, 7) - 1 - back;
    var f = new Date(Date.UTC(y, m, 1)), l = new Date(Date.UTC(y, m + 1, 0));
    return [f.toISOString().slice(0, 10), l.toISOString().slice(0, 10)];
  }

  function Report(v) {
    var c = v.el, t = U.today();
    var st = { from: U.monthStart(t), to: t };
    c.innerHTML = '<div class="presets"><button class="pill" data-act="p" data-v="today">Today</button><button class="pill" data-act="p" data-v="7">7 days</button>' +
      '<button class="pill on" data-act="p" data-v="month">This month</button><button class="pill" data-act="p" data-v="prev">Last month</button><button class="pill" data-act="p" data-v="30">30 days</button></div>' +
      '<div class="card"><div class="two">' + U.field('From', 'r-from', 'date', { value: st.from }) + U.field('To', 'r-to', 'date', { value: st.to }) +
      '</div><button class="primary sm" data-act="go">View report</button></div><div id="rep-body"></div>';
    v.on('p', function (el) {
      var k = el.getAttribute('data-v');
      if (k === 'prev') { var r = monthRange(t, 1); st.from = r[0]; st.to = r[1]; }
      else { st.to = t; st.from = k === 'today' ? t : k === 'month' ? U.monthStart(t) : U.addDays(t, -(parseInt(k, 10) - 1)); }
      $('r-from').value = st.from; $('r-to').value = st.to;
      Array.prototype.forEach.call(c.querySelectorAll('.pill'), function (b) { b.classList.toggle('on', b === el); });
      run();
    });
    v.on('go', function () { st.from = $('r-from').value; st.to = $('r-to').value; run(); });
    v.on('list', function (el) {
      var k = el.getAttribute('data-k'), per = U.date(st.from) + ' – ' + U.date(st.to);
      if (k === 'new') openList('New registrations (' + per + ')', { status: 'all', joinedFrom: st.from, joinedTo: st.to });
      else if (k === 'pdue') openList('Dues for this period (' + per + ')', { pdFrom: st.from, pdTo: st.to, status: 'all' });
      else if (k === 'all') openList('All students with dues', { fee: 'due' });
    });

    function run() {
      if (!st.from || !st.to || st.from > st.to) { $('rep-body').innerHTML = U.errBox('Choose a valid date range (From ≤ To).'); return; }
      $('rep-body').innerHTML = U.skeleton(3);
      var a = { p_lib: App.libId, p_from: st.from, p_to: st.to };
      Promise.all([Api.rpc('collection_report', a), Api.rpc('period_report', a).catch(function (e) { return { _err: e.message }; })]).then(function (res) {
        var r = res[0], p = res[1] || {};
        var modes = r.by_mode || {}, days = r.by_day || [];
        var mh = Array.isArray(modes) ? modes.map(function (m) { return [m.mode, m.amount]; }) : Object.keys(modes).map(function (k) { return [k, modes[k]]; });
        var h = '<section class="stat accent big"><div class="k">Total collection</div><div class="v">' + U.money(r.received_total) +
          '</div><div class="sub">' + U.num(r.received_count) + ' payments • ' + U.date(r.from) + ' – ' + U.date(r.to) + '</div></section>';
        if (!p._err) h += '<section class="grid2 mt">' + stat('Dues in this period', U.money(p.period_due), U.num(p.period_due_students) + ' students ›', 'list', { k: 'pdue' }, 'due') +
          stat('Total outstanding dues', U.money(p.overall_due), U.num(p.overall_due_students) + ' students ›', 'list', { k: 'all' }, 'due') + '</section>';
        h += '<section class="grid2 mt">' + stat('New registrations', U.num(r.new_students), 'view list ›', 'list', { k: 'new' }) +
          stat('Cancelled payments', U.num(r.cancelled_count), U.money(r.cancelled_amount)) + '</section>';
        if (p._err) {
          h += '<div class="notice">To show the fee details: ' + esc(sqlMissing(p._err)) + '</div>';
        } else {
          h += '<h3 class="sec">Fees for this period</h3><section class="card list">' +
            '<div class="row"><span>Memberships started</span><b>' + U.num(p.period_memberships) + '</b></div>' +
            '<div class="row"><span>Total fee</span><b>' + U.money(p.period_fee) + '</b></div>' +
            '<div class="row"><span>Paid so far</span><b>' + U.money(p.period_paid) + '</b></div>' +
            '<div class="row"><span>Due</span><b class="neg">' + U.money(p.period_due) + '</b></div></section>';
          h += '<section class="stat due tap mt" data-act="list" data-k="pdue"><div class="k">Students with dues in this period</div><div class="v">' + U.num(p.period_due_students) +
            ' students</div><div class="sub">view list ›</div></section>';
          h += '<section class="grid3 mt">' + stat('Fully paid', U.num(p.full_count), '', '', {}, 'mini') + stat('Partial', U.num(p.partial_count), '', '', {}, 'mini') +
            stat('Nothing paid', U.num(p.unpaid_count), '', '', {}, 'mini') + '</section>';
          h += '<section class="stat tap mt" data-act="list" data-k="all"><div class="k">Total outstanding dues (all memberships)</div><div class="v">' + U.money(p.overall_due) +
            '</div><div class="sub">' + U.num(p.overall_due_students) + ' students • view list ›</div></section>';
        }
        if (mh.length) h += '<h3 class="sec">By payment mode</h3><section class="card list">' + mh.map(function (m) {
          return '<div class="row"><span class="cap">' + esc(m[0]) + '</span><b>' + U.money(m[1]) + '</b></div>'; }).join('') + '</section>';
        if (r.expected_renewals) h += '<h3 class="sec">Upcoming renewals</h3><section class="stat"><div class="v">' + U.num(r.expected_renewals.memberships) +
          '</div><div class="sub">expected fee: ' + U.money(r.expected_renewals.fee_total) + '</div></section>';
        if (days.length) h += '<h3 class="sec">By day</h3><section class="card list">' + days.slice().reverse().map(function (d) {
          return '<div class="row"><span>' + U.date(d.date) + ' <small class="muted">(' + d.count + ')</small></span><b>' + U.money(d.amount) + '</b></div>'; }).join('') + '</section>';
        $('rep-body').innerHTML = h;
      }, function (e) { $('rep-body').innerHTML = U.errBox(e.message); });
    }
    run();
  }

  window.Views = window.Views || {};
  window.Views.DateReport = DateReport; window.Views.Report = Report;
})();
