// STUDENTS tab: search + filters; STUDENT DETAIL page
(function () {
  var $ = U.$, esc = U.esc;

  var EXP = [[null, 'All'], ['today', 'Today'], ['next3', '3 days'], ['next7', '7 days'], ['next15', '15 days'],
    ['running', 'Running'], ['expired', 'Expired'], ['held', 'On hold'], ['lapsed', 'Lapsed']];

  // Default WhatsApp message, chosen by situation: dues -> expired -> expiring -> general.
  function waText(r) {
    var lib = App.libName || 'the library', hi = 'Hello ' + (r.name || '') + ', ';
    if (r.balance !== null && r.balance !== undefined && Number(r.balance) > 0)
      return hi + 'this is a reminder from ' + lib + ': your fee of ' + U.money(r.balance) + ' is pending. Please pay at your earliest convenience. Thank you.';
    if (r.end_date && r.days_left !== null && r.days_left !== undefined && r.days_left < 0)
      return hi + 'your membership at ' + lib + ' expired on ' + U.date(r.end_date) + '. Please renew to keep your seat. Thank you.';
    if (r.end_date && r.days_left !== null && r.days_left !== undefined && r.days_left <= 7)
      return hi + 'your membership at ' + lib + ' expires on ' + U.date(r.end_date) + '. Please renew on time. Thank you.';
    return hi + 'this is a message from ' + lib + '.';
  }
  window.waText = waText;

  function card(r) {
    var money = r.balance !== null && r.balance !== undefined;
    var dl = r.days_left;
    var dlTxt = dl === null || dl === undefined ? '' : (dl >= 0 ? dl + ' days left' : 'expired ' + Math.abs(dl) + ' days ago');
    return '<div class="scard" data-act="open" data-id="' + esc(r.student_id) + '">' +
      '<div class="avatar sm">' + esc((r.name || '?').charAt(0).toUpperCase()) + '</div>' +
      '<div class="sc-main"><div class="sc-top"><b>' + esc(r.name) + '</b>' + U.badge(r.student_status === 'left' ? 'left' : r.state) + '</div>' +
      '<div class="muted small">' + (r.father_name ? esc(r.father_name) + ' • ' : '') + esc(r.phone) + '</div>' +
      '<div class="sc-meta">' + (r.seat_no ? '<span class="tag">Seat ' + r.seat_no + '</span>' : '') +
      (r.shifts ? '<span class="tag">' + esc(r.shifts) + '</span>' : '') +
      (r.end_date ? '<span class="tag">until ' + U.date(r.end_date) + '</span>' : '') + '</div>' +
      '<div class="sc-foot"><span class="small muted">' + esc(dlTxt) + '</span>' +
      (money && Number(r.balance) > 0 ? '<span class="due-tag">Due ' + U.money(r.balance) + '</span>' : '') + '</div></div>' +
      '<div class="acts"><a class="callbtn" href="tel:' + esc(r.phone) + '" data-stop="1" aria-label="Call">☎</a>' + U.waBtn(r.phone, waText(r)) + '</div></div>';
  }

  var FEE = [[null, 'All'], ['full', 'Fully paid'], ['partial', 'Partial'], ['unpaid', 'Nothing paid'], ['due', 'All dues']];

  function Students(v, args) {
    args = args || {};
    var c = v.el;
    var st = { q: '', status: args.status || 'active', expiry: args.expiry || null, fee: args.fee || (args.hasBalance ? 'due' : null), slot: '',
      from: args.from || '', to: args.to || '', jf: args.joinedFrom || '', jt: args.joinedTo || '', pf: args.pdFrom || '', pt: args.pdTo || '',
      offset: 0, rows: [], total: 0, tbal: null, busy: false };
    var canNew = App.can('can_register_students') && !args.page;
    c.innerHTML = (args.page ? '' : '<div class="topbar"><div class="lib-name">Students</div><button class="icon-btn wide" data-act="drep">📅 Date report</button></div>') +
      (args.title ? '<div class="filterbanner">' + esc(args.title) + '</div>' : '') +
      '<div class="searchbar"><span>⌕</span><input id="q" type="search" placeholder="Name, phone, seat no. or father&#39;s name" autocomplete="off"></div>' +
      '<div class="chips" id="exp-chips"></div><div class="chips tight" id="fee-chips"></div>' +
      '<div class="filters"><select id="f-status"><option value="active">Active</option><option value="left">Left</option><option value="all">All</option></select>' +
      '<select id="f-slot"><option value="">All shifts</option></select>' +
      '<button class="pill" id="f-date" data-act="dt">📅 Expiry date</button></div>' +
      '<div id="date-box" class="card hidden"><div class="two">' + U.field('Expiry from', 'f-from', 'date', { value: st.from }) + U.field('Expiry to', 'f-to', 'date', { value: st.to }) +
      '</div><div class="muted small">You can pick a future date too — students expiring up to that date will be shown.</div>' +
      '<button class="primary sm" data-act="applydate">Apply</button> <button class="linkbtn" data-act="cleardate">Clear</button></div>' +
      '<div id="sum" class="sumline"></div><div id="list"></div><div id="more"></div>' +
      (canNew ? '<button class="fab" data-act="new" aria-label="New student">＋</button>' : '');
    $('f-status').value = st.status;

    function paintChips() {
      $('exp-chips').innerHTML = EXP.map(function (e) {
        return '<button class="pill' + (st.expiry === e[0] ? ' on' : '') + '" data-act="exp" data-v="' + (e[0] || '') + '">' + e[1] + '</button>';
      }).join('');
      $('fee-chips').innerHTML = '<span class="chiplbl">Fee:</span>' + FEE.map(function (e) {
        return '<button class="pill' + (st.fee === e[0] ? ' on' : '') + '" data-act="fee" data-v="' + (e[0] || '') + '">' + e[1] + '</button>';
      }).join('');
      $('f-date').classList.toggle('on', !!(st.from || st.to));
    }
    function load(reset) {
      if (reset) { st.offset = 0; st.rows = []; $('list').innerHTML = U.skeleton(4); $('more').innerHTML = ''; }
      st.busy = true;
      var a = { p_lib: App.libId, p_q: st.q || null, p_status: st.status, p_expiry: st.expiry, p_from: st.from || null, p_to: st.to || null,
        p_slot_id: st.slot || null, p_limit: 30, p_offset: st.offset };
      // New filters are sent only when used, so the app still works before the new SQL is installed.
      if (st.fee) a.p_fee_type = st.fee;
      if (st.jf) a.p_joined_from = st.jf;
      if (st.jt) a.p_joined_to = st.jt;
      if (st.pf) a.p_pd_from = st.pf;
      if (st.pt) a.p_pd_to = st.pt;
      Api.rpc('search_students', a).then(function (rows) {
        st.busy = false; rows = rows || [];
        if (rows.length) { st.total = rows[0].total_count; st.tbal = rows[0].total_balance; }
        else if (reset) { st.total = 0; st.tbal = null; }
        st.rows = st.rows.concat(rows); st.offset = st.rows.length;
        paintList();
      }, function (e) {
        st.busy = false;
        var m = e.message;
        if (/p_fee_type|p_joined|p_pd_|schema cache|Could not find/i.test(m)) m = 'The new SQL (A1_search_students.sql) has not been run on the database yet. Please run it first.';
        $('list').innerHTML = U.errBox(m, true);
      });
    }
    function paintList() {
      var s = st.total + ' student' + (st.total === 1 ? '' : 's');
      if (st.tbal !== null && st.tbal !== undefined && st.fee) s += ' • total dues of these students: ' + U.money(st.tbal);
      $('sum').textContent = st.rows.length || st.total ? s : '';
      $('list').innerHTML = st.rows.length ? st.rows.map(card).join('') : U.empty('🔍', 'No students found. Try changing the filters.');
      $('more').innerHTML = st.rows.length < st.total ? '<button class="ghost-btn" data-act="more">Show more (' + (st.total - st.rows.length) + ')</button>' : '';
    }

    App.slots().then(function (sl) {
      $('f-slot').innerHTML = '<option value="">All shifts</option>' + sl.filter(function (s) { return s.is_active; }).map(function (s) {
        return '<option value="' + esc(s.id) + '">' + esc(App.slotLabel(s)) + '</option>'; }).join('');
    }, function () {});

    $('q').addEventListener('input', U.debounce(function () { st.q = $('q').value.trim(); load(true); }, 350));
    $('f-status').addEventListener('change', function () { st.status = this.value; load(true); });
    $('f-slot').addEventListener('change', function () { st.slot = this.value; load(true); });
    c.addEventListener('click', function (e) { if (e.target.closest('[data-stop]')) e.stopPropagation(); }, true);

    v.on('exp', function (el) { st.expiry = el.getAttribute('data-v') || null; paintChips(); load(true); });
    v.on('fee', function (el) { st.fee = el.getAttribute('data-v') || null; paintChips(); load(true); });
    v.on('dt', function () { $('date-box').classList.toggle('hidden'); });
    v.on('applydate', function () { st.from = $('f-from').value; st.to = $('f-to').value; paintChips(); load(true); });
    v.on('cleardate', function () { st.from = st.to = ''; $('f-from').value = $('f-to').value = ''; paintChips(); load(true); });
    v.on('more', function () { if (!st.busy) load(false); });
    v.on('open', function (el, ev) {
      if (ev.target.closest('.callbtn,.wabtn')) return;
      Nav.push('Student', Detail, { id: el.getAttribute('data-id') });
    });
    v.on('new', function () { Nav.push('New student', window.Forms.register); });
    v.on('drep', function () { Nav.push('Date report', window.Views.DateReport); });
    if (st.from || st.to) $('date-box').classList.remove('hidden');
    paintChips(); load(true);
  }

  // ---------------- Student detail ----------------
  function Detail(v, args) {
    var c = v.el, id = args.id;
    c.innerHTML = U.skeleton(4);
    var idf = 'eq.' + id;
    Promise.all([
      Api.get('students?' + Api.q({ select: '*', id: idf })),
      Api.get('memberships?' + Api.q({ select: '*', student_id: idf, order: 'start_date.desc,created_at.desc' })),
      Api.get('membership_balances?' + Api.q({ select: 'membership_id,fee_amount,paid_amount,balance', student_id: idf })).catch(function () { return null; }),
      Api.get('payments?' + Api.q({ select: 'id,membership_id,amount,mode,reference_no,received_on,note,status,cancel_reason', student_id: idf, order: 'received_on.desc,created_at.desc', limit: 100 })).catch(function () { return null; }),
      Api.get('membership_shifts?' + Api.q({ select: 'membership_id,slot_id,is_active', student_id: idf })).catch(function () { return []; }),
      App.slots().catch(function () { return []; }),
      App.seats().catch(function () { return []; })
    ]).then(function (res) {
      var s = (res[0] || [])[0];
      if (!s) { c.innerHTML = U.empty('❔', 'Student not found.'); return; }
      paint(s, res[1] || [], res[2], res[3], res[4] || [], res[5] || [], res[6] || []);
    }, function (e) { c.innerHTML = U.errBox(e.message, true); });

    function paint(s, ms, bals, pays, shifts, slots, seats) {
      var seatNo = {}; seats.forEach(function (x) { seatNo[x.id] = x.seat_no; });
      var slotName = {}; slots.forEach(function (x) { slotName[x.id] = x.name; });
      var bal = {}; (bals || []).forEach(function (b) { bal[b.membership_id] = b; });
      var cur = ms.filter(function (m) { return m.status === 'active'; })[0] || ms[0];
      var today = U.today();
      function shiftsOf(mid) {
        return shifts.filter(function (x) { return x.membership_id === mid && x.is_active !== false; })
          .map(function (x) { return slotName[x.slot_id] || '?'; }).join(', ');
      }
      var h = '<section class="card hero-card"><div class="avatar big">' + esc(s.name.charAt(0).toUpperCase()) + '</div><div class="hc-main"><h2>' + esc(s.name) + '</h2>' +
        '<div class="muted small">' + (s.father_name ? 'S/o ' + esc(s.father_name) : '') + '</div>' + U.badge(s.status) + '</div></section>' +
        '<div class="qa-row">' +
        '<a class="qa" href="tel:' + esc(s.phone) + '"><span>☎</span>Call</a>' +
        (U.waLink(s.phone, '') ? '<a class="qa wa" href="' + esc(U.waLink(s.phone, waText({ name: s.name, end_date: cur && cur.end_date, days_left: cur ? Math.round((new Date(cur.end_date) - new Date(today)) / 86400000) : null, balance: cur && bal[cur.id] ? bal[cur.id].balance : null }))) + '"><span>' + Icons.wa + '</span>WhatsApp</a>' : '');
      if (s.status === 'active' && cur && App.can('can_add_payments')) h += '<button class="qa" data-act="pay"><span>₹</span>Payment</button>';
      if (s.status === 'active' && App.can('can_register_students')) h += '<button class="qa" data-act="renew"><span>↻</span>Renew</button>';
      if (App.can('can_register_students')) h += '<button class="qa" data-act="edit"><span>✎</span>Edit</button>';
      h += '</div>';

      if (cur) {
        var b = bal[cur.id], left = Math.round((new Date(cur.end_date) - new Date(today)) / 86400000);
        h += '<h3 class="sec">Current membership</h3><section class="card list">' +
          '<div class="row"><span>Seat</span><b>' + (cur.seat_id && seatNo[cur.seat_id] ? seatNo[cur.seat_id] : 'No seat') + '</b></div>' +
          '<div class="row"><span>Shift</span><b>' + esc(shiftsOf(cur.id) || '—') + '</b></div>' +
          '<div class="row"><span>Start</span><b>' + U.date(cur.start_date) + '</b></div>' +
          '<div class="row"><span>Expiry</span><b>' + U.date(cur.end_date) + ' <small class="' + (left < 0 ? 'neg' : 'muted') + '">(' + (left >= 0 ? left + ' days left' : 'expired ' + Math.abs(left) + ' days ago') + ')</small></b></div>' +
          '<div class="row"><span>Seat held until</span><b>' + U.date(cur.hold_until) + '</b></div>' +
          (b ? '<div class="row"><span>Fee</span><b>' + U.money(b.fee_amount) + '</b></div><div class="row"><span>Paid</span><b>' + U.money(b.paid_amount) + '</b></div>' +
            '<div class="row"><span>Due</span><b class="' + (Number(b.balance) > 0 ? 'neg' : 'pos') + '">' + U.money(b.balance) + '</b></div>' : '') + '</section>';
        var adm = '';
        if (App.can('can_edit_expiry')) adm += '<button class="ghost-btn" data-act="editm">Change expiry / fee</button>';
        if (s.status === 'active' && App.can('can_register_students')) adm += '<button class="ghost-btn" data-act="chseat">Change seat / shift</button>';
        if (s.status === 'active' && App.can('can_remove_students')) adm += '<button class="ghost-btn warnb" data-act="remove">Remove student</button>';
        if (adm) h += '<div class="stack">' + adm + '</div>';
      } else h += U.empty('📭', 'No membership.');

      h += '<h3 class="sec">Details</h3><section class="card list">' +
        '<div class="row"><span>Phone</span><b>' + esc(s.phone) + '</b></div>' +
        (s.email ? '<div class="row"><span>Email</span><b>' + esc(s.email) + '</b></div>' : '') +
        (s.address ? '<div class="row"><span>Address</span><b class="wrap">' + esc(s.address) + '</b></div>' : '') +
        '<div class="row"><span>Joined</span><b>' + U.date(s.joined_on) + '</b></div>' +
        (s.status === 'left' ? '<div class="row"><span>Left</span><b>' + U.date(s.left_on) + (s.left_reason ? ' • ' + esc(s.left_reason) : '') + '</b></div>' : '') +
        (s.notes ? '<div class="row"><span>Notes</span><b class="wrap">' + esc(s.notes) + '</b></div>' : '') + '</section>';

      if (pays) {
        h += '<h3 class="sec">Payments</h3>';
        h += pays.length ? '<section class="card list">' + pays.map(function (p) {
          var bad = p.status === 'cancelled';
          return '<div class="row pay' + (bad ? ' cancelled' : '') + '"><div><b>' + U.money(p.amount) + '</b> <span class="tag">' + esc(p.mode) + '</span>' +
            '<div class="muted small">' + U.date(p.received_on) + (p.reference_no ? ' • ' + esc(p.reference_no) : '') + (p.note ? ' • ' + esc(p.note) : '') +
            (bad ? '<br>Cancel: ' + esc(p.cancel_reason || '') : '') + '</div></div>' +
            (!bad && App.can('can_add_payments') ? '<button class="linkbtn" data-act="cpay" data-id="' + esc(p.id) + '">Cancel</button>' : '') + '</div>';
        }).join('') + '</section>' : U.empty('💸', 'No payments yet.');
      }
      if (ms.length > 1) {
        h += '<h3 class="sec">Past memberships</h3><section class="card list">' + ms.filter(function (m) { return m !== cur; }).map(function (m) {
          var b = bal[m.id];
          return '<div class="row"><span>' + U.date(m.start_date) + ' → ' + U.date(m.end_date) + '</span><b>' + U.money(m.fee_amount) +
            (b && Number(b.balance) > 0 ? ' <small class="neg">(due ' + U.money(b.balance) + ')</small>' : '') + '</b></div>'; }).join('') + '</section>';
      }
      c.innerHTML = h;

      v.on('pay', function () { window.Forms.payment(v, cur, bal[cur.id]); });
      v.on('renew', function () { Nav.push('Renew', window.Forms.renew, { student: s, cur: cur, bal: bal[cur && cur.id] }); });
      v.on('edit', function () { window.Forms.editStudent(v, s); });
      v.on('editm', function () { window.Forms.editMembership(v, cur); });
      v.on('remove', function () { window.Forms.remove(v, s); });
      v.on('chseat', function () { window.Forms.changeSeat(v, s, cur, shifts, slots, seatNo); });
      v.on('cpay', function (el) { window.Forms.cancelPayment(v, el.getAttribute('data-id')); });
    }
  }

  window.Views = window.Views || {};
  window.Views.Students = Students; window.Views.Detail = Detail;
})();
