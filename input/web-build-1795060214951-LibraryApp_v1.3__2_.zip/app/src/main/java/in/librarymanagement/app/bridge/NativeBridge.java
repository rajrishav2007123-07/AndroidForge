package in.librarymanagement.app.bridge;

import android.webkit.JavascriptInterface;

import in.librarymanagement.app.security.SecureStore;

/**
 * The ONLY door between the web page and the phone.
 * It can save, read and clear the login session, and remember the theme choice.
 * No file access, no shell, no arbitrary calls.
 */
public final class NativeBridge {
    private static final int MAX_LEN = 20000;
    private final SecureStore store;

    public NativeBridge(SecureStore store) {
        this.store = store;
    }

    @JavascriptInterface
    public void saveSession(String json) {
        if (json == null || json.length() > MAX_LEN) return;
        store.save(json);
    }

    @JavascriptInterface
    public String getSession() {
        String s = store.load();
        return s == null ? "" : s;
    }

    @JavascriptInterface
    public void clearSession() {
        store.clear();
    }

    @JavascriptInterface
    public void setTheme(String v) {
        if ("light".equals(v) || "dark".equals(v) || "auto".equals(v)) store.savePref("theme", v);
    }

    @JavascriptInterface
    public String getTheme() {
        String v = store.loadPref("theme");
        return v == null || v.isEmpty() ? "auto" : v;
    }
}
