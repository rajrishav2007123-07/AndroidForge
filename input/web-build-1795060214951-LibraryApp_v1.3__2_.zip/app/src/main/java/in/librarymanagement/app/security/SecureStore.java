package in.librarymanagement.app.security;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Stores a small secret string (the login session) encrypted with an
 * AES-GCM key that lives inside the Android Keystore (never leaves the chip).
 */
public final class SecureStore {
    private static final String KEY_ALIAS = "library_session_key";
    private static final String PREFS = "secure_prefs";
    private static final String ITEM = "session";

    private final SharedPreferences prefs;

    public SecureStore(Context ctx) {
        this.prefs = ctx.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public synchronized void save(String plain) {
        try {
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, key());
            byte[] iv = c.getIV();
            byte[] enc = c.doFinal(plain.getBytes(StandardCharsets.UTF_8));
            String out = Base64.encodeToString(iv, Base64.NO_WRAP) + ":"
                    + Base64.encodeToString(enc, Base64.NO_WRAP);
            prefs.edit().putString(ITEM, out).apply();
        } catch (Exception e) {
            prefs.edit().remove(ITEM).apply();
        }
    }

    public synchronized String load() {
        try {
            String s = prefs.getString(ITEM, null);
            if (s == null) return null;
            String[] p = s.split(":");
            if (p.length != 2) return null;
            byte[] iv = Base64.decode(p[0], Base64.NO_WRAP);
            byte[] enc = Base64.decode(p[1], Base64.NO_WRAP);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
            return new String(c.doFinal(enc), StandardCharsets.UTF_8);
        } catch (Exception e) {
            clear();
            return null;
        }
    }

    public synchronized void clear() {
        prefs.edit().remove(ITEM).apply();
    }

    private SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(KEY_ALIAS)) {
            return ((KeyStore.SecretKeyEntry) ks.getEntry(KEY_ALIAS, null)).getSecretKey();
        }
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build());
        return kg.generateKey();
    }

    // Non-secret UI preference (theme). Whitelisted key/values only.
    public synchronized void savePref(String key, String val) {
        prefs.edit().putString("ui_" + key, val).apply();
    }

    public synchronized String loadPref(String key) {
        return prefs.getString("ui_" + key, "");
    }
}
