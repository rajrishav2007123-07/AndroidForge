-- D0 part 1 (read-only, changes nothing): shows the columns of the tables the next SQL needs.
-- Paste the OUTPUT back to me.
select table_name, string_agg(column_name || ' ' || data_type, ', ' order by ordinal_position) as columns
from information_schema.columns
where table_schema = 'public'
  and table_name in ('libraries', 'library_members', 'memberships', 'membership_shifts')
group by table_name
order by table_name;
-- END PART 1
