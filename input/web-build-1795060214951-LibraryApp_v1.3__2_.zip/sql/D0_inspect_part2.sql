-- D0 part 2 (read-only): shows how seat/shift syncing and editing work today.
-- Paste the OUTPUT back to me. (If it is very long, paste only the first 60 lines.)
select p.proname, left(pg_get_functiondef(p.oid), 3500) as definition
from pg_proc p join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public' and p.proname in ('memberships_sync_shifts', 'edit_membership');
-- END PART 2
