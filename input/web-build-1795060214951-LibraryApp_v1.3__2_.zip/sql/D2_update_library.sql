-- D2: lets the OWNER edit the library profile (name, address, phone, opening/closing time).
-- Staff cannot use it. Changes are written to the audit history by the existing trigger.
create or replace function public.update_library(
  p_lib uuid, p_name text, p_address text default null, p_phone text default null,
  p_open time default null, p_close time default null)
returns void
language plpgsql security definer set search_path = ''
as $$
begin
  if auth.uid() is null then raise exception 'Login required' using errcode = '28000'; end if;
  if not exists (select 1 from public.library_members m
                 where m.library_id = p_lib and m.user_id = auth.uid() and m.role = 'owner' and m.is_active) then
    raise exception 'Only the library owner can edit the profile' using errcode = '42501';
  end if;
  if p_name is null or length(btrim(p_name)) < 2 or length(p_name) > 120 then
    raise exception 'Library name must be 2 to 120 characters' using errcode = '22023';
  end if;
  if p_phone is not null and p_phone <> '' and p_phone !~ '^[0-9+ ]{7,15}$' then
    raise exception 'Enter a valid phone number' using errcode = '22023';
  end if;
  update public.libraries
     set name = btrim(p_name), address = nullif(btrim(coalesce(p_address, '')), ''),
         phone = nullif(btrim(coalesce(p_phone, '')), ''), open_time = p_open, close_time = p_close
   where id = p_lib;
end $$;
revoke all on function public.update_library(uuid, text, text, text, time, time) from public, anon;
grant execute on function public.update_library(uuid, text, text, text, time, time) to authenticated;
notify pgrst, 'reload schema';
select 'D2 installed' as result;
-- END
