SQL CHALANE KA ORDER (Supabase > SQL Editor). Har file naye "New query" me paste karke Run karein.
Har file ke end me ek "Check" select hai - uska output mujhe bhej dein.

  1. A1_search_students.sql      (fee type + naye filters)
  2. A2_reports.sql              (date report + period report)
  3. A3_seat_style.sql           (seat icon style)
  4. B1_attendance_tables.sql    (attendance tables)
  5. B2_attendance_functions.sql (attendance functions)
  6. C_test_all.sql              (sab ka test, kuch badalta nahi)

Pehle ye SQL chalayein, tab naya app chalega. App purane database par bhi purane features chalata hai,
par naye screens (attendance, date report, period report, seat style, fee-type filter) ko ye functions chahiye.
Note: SQL maine apne yahan asli Postgres par nahi chalayi (yahan database server nahi hai), isliye
agar koi error aaye to poora error text bhej dein - main turant theek kar dunga.

v1.3 additions
--------------
D0_inspect_part1.sql, D0_inspect_part2.sql : read-only. Run them and send me the output; I need it to write D1 (change seat) and D3 (add a new library owner) safely.
D2_update_library.sql : lets the owner edit the library profile from More > Library details > Edit.
