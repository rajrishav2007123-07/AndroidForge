# TaskZen Study

**Version 2.0.0** · targetSdk 36 · minSdk 26 · Java 17

A focused study productivity app for JEE / NEET / Engineering / Business cohorts.  
Hybrid architecture: battle-tested Web UI (`assets/index.html`) + clean native Android bridge for alarms, widgets, notifications, AdMob and optional Firebase cloud sync.

---

## Features

- **Task timers** with break tracking, single-running-task rule, expected-time warnings
- **Cohorts**: JEE, NEET, B.Tech/Engineering, Startup/Business/Corporate
- **Home-screen widgets**: daily task progress + circular exam countdown
- **Alarms & reminders**: exact alarms, continuous vibration (foreground service), personal alarms, math-challenge stop
- **Library / continuous mode** for long study sessions
- **Optional Firebase Auth + Firestore** cloud backup (offline-first; never forced)
- **Export / import** JSON + auto safety backup to Downloads
- **AdMob** banners, interstitial, rewarded, native (no app-open ads)
- **Themes, reports, hourly motivation**

All workflows above are preserved from the production 1.6.x line.

---

## Project structure

```
app/
  src/main/
    assets/index.html          # Full study UI + business logic
    java/com/jeetracker/app/   # Native bridge, widgets, alarms, ads
    res/                       # Layouts, drawables, widgets, themes
  build.gradle
  google-services.json         # Your Firebase project
  proguard-rules.pro
```

Native responsibilities:
| Class | Role |
|-------|------|
| `MainActivity` | WebView host, permissions, file chooser |
| `AndroidBridge` | `@JavascriptInterface` surface for the Web UI |
| `AdManager` | AdMob banners / interstitial / rewarded / native |
| `VibrationService` | Foreground continuous vibration (Doze-safe) |
| `*WidgetProvider` | Home-screen widgets |
| `*Alarm*` / `*Receiver` | Exact alarms, boot restore, notifications |
| `NotificationHelper` | Channels and notification actions |

---

## Build

```bash
cp local.properties.example local.properties
# edit sdk.dir=...

./gradlew clean bundleRelease
# AAB → app/build/outputs/bundle/release/app-release.aab
```

Debug:
```bash
./gradlew assembleDebug
```

---

## Google Play (API 36 / 2026) checklist

| Requirement | Status in this project |
|-------------|------------------------|
| targetSdk / compileSdk 36 | ✅ |
| 16 KB page size | ✅ (pure Java + WebView) |
| SCHEDULE_EXACT_ALARM only (no USE_EXACT_ALARM) | ✅ |
| WebView debugging only in debug builds | ✅ |
| Cleartext traffic disabled | ✅ |
| R8 minify + shrink for release | ✅ |
| Foreground service `specialUse` declared | ✅ (still declare in Play Console) |
| AAB packaging | Use `bundleRelease` |

**You must still complete in Play Console:**
1. Data safety form (Firebase + AdMob)
2. Privacy policy URL
3. Account deletion path (if using Auth)
4. Special-use FGS declaration
5. Ads / Advertising ID declaration

Replace `privacy_policy_url` in `res/values/strings.xml` with your real policy.

---

## Configuration

- **AdMob App ID** – `AndroidManifest.xml` meta-data  
- **Ad unit IDs** – `AdManager.java` constants  
- **Firebase** – replace `google-services.json` with your project file  

Never embed service-account keys or admin passwords in the APK.

---

## License / notes

Production-ready structure for Play Store submission.  
Business logic lives in `index.html` by design so the proven study workflows remain stable.


## v2.0.4 Language Selector
Added a top-right language selector with 10 languages (English first): English, Hindi, Bengali, Telugu, Marathi, Tamil, Gujarati, Kannada, Malayalam and Punjabi. Selection is persisted locally.

## v58 (versionName 2.0.20) – Focus mode + App blocking
New: Focus & App Blocker (sidebar → "Focus & App Blocker", or the 🛡️ Focus tab).
- Focus session with countdown ring, presets/custom minutes, optional Strict mode.
- Block selected apps during a focus session, while a task timer is running, and on schedules (weekly or one-time).
- Stats (blocked attempts, focus minutes) and a permission setup page.
- Needs: Usage Access + Display over other apps (guided inside the app).
- Native code: FocusController, FocusBlockService, FocusAlarmReceiver, FocusBootReceiver. UI: assets/index.html (#fxApp).

## v62 (versionName 2.0.24)
- Blocking keeps working after TaskZen is swiped out of Recents (1-minute watchdog alarm, restart on task removal, stopWithTask=false).
- Starting a break (global or per-task) auto-stops the running task; starting a task auto-ends all breaks.
- New "Alarms & reminders" permission row in Focus → Stats.

### v62 follow-up – Recents fix (Accessibility blocker)
Blocking now runs in `FocusAccessibilityService` (kept alive by Android itself), so it survives removing TaskZen from Recents. The old Usage-Access + overlay foreground service remains as a fallback when Accessibility is off.

- v62: Study Dashboard calendar now shows weeks as rows (Mon–Sun columns), matching the weekday header.
