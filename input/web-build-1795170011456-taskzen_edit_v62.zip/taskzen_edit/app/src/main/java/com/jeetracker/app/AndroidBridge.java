package com.jeetracker.app;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.SetOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

/**
 * JavaScript ↔ Java bridge.
 * HTML calls these methods via window.AndroidBridge.xxx()
 * Also keeps native AppWidget in sync.
 * Auth + cloud sync added in v1.6.15 – fully optional; app works offline without login.
 */
public class AndroidBridge {

    private final Context context;
    private final SharedPreferences prefs;
    private final WeakReference<Activity> activityRef;
    private final WeakReference<WebView> webViewRef;
    private ConnectivityManager.NetworkCallback networkCallback;

    public AndroidBridge(Activity activity, WebView webView) {
        this.context = activity.getApplicationContext();
        this.prefs = this.context.getSharedPreferences("jee_prefs", Context.MODE_PRIVATE);
        this.activityRef = new WeakReference<>(activity);
        this.webViewRef = new WeakReference<>(webView);
        registerAutoSyncNetworkCallback();
    }

    /** Backward-compatible constructor (no JS callbacks). */
    public AndroidBridge(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = this.context.getSharedPreferences("jee_prefs", Context.MODE_PRIVATE);
        this.activityRef = new WeakReference<>(null);
        this.webViewRef = new WeakReference<>(null);
        registerAutoSyncNetworkCallback();
    }

    private void runJs(final String script) {
        final WebView wv = webViewRef.get();
        final Activity act = activityRef.get();
        if (wv == null || act == null) return;
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    wv.evaluateJavascript(script, null);
                } catch (Exception ignored) {}
            }
        });
    }

    private void notifyAuth(String event, String jsonPayload) {
        String safe = (jsonPayload == null ? "{}" : jsonPayload)
                .replace("\\", "\\\\")
                .replace("'", "\\'");
        runJs("window.__onAuthEvent && window.__onAuthEvent('" + event + "', '" + safe + "');");
    }

    @JavascriptInterface
    public void saveTaskState(String json) {
        SharedPreferences.Editor ed = prefs.edit().putString("task_state", json);
        try {
            JSONObject state = new JSONObject(json == null ? "{}" : json);
            JSONArray dates = state.optJSONArray("taskWidgetDates");
            if (dates != null) {
                for (int i = 0; i < 3 && i < dates.length(); i++) {
                    String d = dates.optString(i, "");
                    if (d != null && !d.isEmpty()) ed.putString("task_widget_date_" + i, d);
                }
            }
        } catch (Exception ignored) {}
        ed.putBoolean("auto_sync_dirty", true).apply();
        StudyWidgetProvider.requestUpdate(context);
        CountdownWidgetProvider.requestUpdate(context);
        NotesWidgetProvider.requestUpdate(context);
        maybeAutoBackup(json);
    }

    @JavascriptInterface
    public void refreshNotesWidgets() {
        NotesWidgetProvider.requestUpdate(context);
    }

    @JavascriptInterface
    public String getTaskState() {
        return prefs.getString("task_state", "");
    }

    @JavascriptInterface
    public void scheduleTaskReminders(String taskJson) {
        try {
            JSONObject task = new JSONObject(taskJson);
            long taskId = task.optLong("id", 0);
            String title = task.optString("title", "Task");
            String date = task.optString("date", "");
            String startTime = task.optString("startTime", "");
            boolean completed = task.optBoolean("completed", false);

            if (completed || startTime.isEmpty() || date.isEmpty()) {
                TaskAlarmHelper.cancelReminders(context, taskId);
                return;
            }

            boolean enabled = prefs.getBoolean("reminders_enabled", true);
            if (!enabled) {
                TaskAlarmHelper.cancelReminders(context, taskId);
                return;
            }

            TaskAlarmHelper.scheduleReminders(context, taskId, title, date, startTime);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @JavascriptInterface
    public void cancelTaskReminders(long taskId) {
        TaskAlarmHelper.cancelReminders(context, taskId);
    }

    @JavascriptInterface
    public void setHourlyMotivationEnabled(boolean enabled) {
        prefs.edit().putBoolean("hourly_motivation_enabled", enabled).apply();
        if (enabled) {
            try { HourlyMotivationReceiver.ensureScheduled(context); } catch (Exception ignored) {}
        }
    }

    @JavascriptInterface
    public boolean isHourlyMotivationEnabled() {
        return prefs.getBoolean("hourly_motivation_enabled", true);
    }

    @JavascriptInterface
    public void setRemindersEnabled(boolean enabled) {
        prefs.edit().putBoolean("reminders_enabled", enabled).apply();
        if (!enabled) {
            cancelAllFromState();
        } else {
            rescheduleAllFromState();
        }
    }

    private void cancelAllFromState() {
        String json = prefs.getString("task_state", "");
        if (json == null || json.isEmpty()) return;
        try {
            JSONObject state = new JSONObject(json);
            JSONArray tasks = state.optJSONArray("tasks");
            if (tasks == null) return;
            for (int i = 0; i < tasks.length(); i++) {
                JSONObject t = tasks.getJSONObject(i);
                long id = t.optLong("id", 0);
                if (id != 0) TaskAlarmHelper.cancelReminders(context, id);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void rescheduleAllFromState() {
        String json = prefs.getString("task_state", "");
        if (json == null || json.isEmpty()) return;
        try {
            JSONObject state = new JSONObject(json);
            JSONArray tasks = state.optJSONArray("tasks");
            if (tasks == null) return;
            for (int i = 0; i < tasks.length(); i++) {
                JSONObject t = tasks.getJSONObject(i);
                boolean completed = t.optBoolean("completed", false);
                String startTime = t.optString("startTime", "");
                String date = t.optString("date", "");
                long taskId = t.optLong("id", 0);
                String title = t.optString("title", "Task");
                if (!completed && !startTime.isEmpty() && !date.isEmpty() && taskId != 0) {
                    TaskAlarmHelper.scheduleReminders(context, taskId, title, date, startTime);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @JavascriptInterface
    public void setCustomAlarmBase64(String base64Data) {
        try {
            if (base64Data == null || base64Data.isEmpty()) {
                clearCustomAlarm();
                return;
            }
            if (base64Data.contains(",")) {
                base64Data = base64Data.substring(base64Data.indexOf(",") + 1);
            }
            byte[] data = Base64.decode(base64Data, Base64.DEFAULT);
            File dir = new File(context.getFilesDir(), "alarms");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, "custom_alarm.mp3");
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(data);
            fos.close();
            prefs.edit()
                    .putString("custom_alarm_path", file.getAbsolutePath())
                    .putBoolean("use_custom_alarm", true)
                    .apply();
            android.os.Handler mainHandler = new android.os.Handler(context.getMainLooper());
            mainHandler.post(() ->
                    Toast.makeText(context, "Custom alarm saved ✓", Toast.LENGTH_SHORT).show());
        } catch (Exception e) {
            e.printStackTrace();
            android.os.Handler mainHandler = new android.os.Handler(context.getMainLooper());
            mainHandler.post(() ->
                    Toast.makeText(context, "Failed to save alarm sound", Toast.LENGTH_SHORT).show());
        }
    }

    @JavascriptInterface
    public void clearCustomAlarm() {
        prefs.edit()
                .remove("custom_alarm_path")
                .putBoolean("use_custom_alarm", false)
                .apply();
        try {
            File file = new File(context.getFilesDir(), "alarms/custom_alarm.mp3");
            if (file.exists()) file.delete();
        } catch (Exception ignored) {}
    }

    @JavascriptInterface
    public void testAlarm() {
        AlarmPlayer.play(context);
    }

    @JavascriptInterface
    public boolean isWidgetEnabled() {
        return prefs.getBoolean("widget_enabled", true);
    }

    @JavascriptInterface
    public void setWidgetEnabled(boolean enabled) {
        prefs.edit().putBoolean("widget_enabled", enabled).apply();
        StudyWidgetProvider.requestUpdate(context);
    }

    @JavascriptInterface
    public boolean isNative() {
        return true;
    }

    @JavascriptInterface
    public void updateWidget() {
        StudyWidgetProvider.requestUpdate(context);
        CountdownWidgetProvider.requestUpdate(context);
        NotesWidgetProvider.requestUpdate(context);
    }

    /** Countdown widget color: purple|red|blue|green|orange|teal */
    @JavascriptInterface
    public void setCountdownWidgetColor(String color) {
        if (color == null || color.isEmpty()) color = "purple";
        prefs.edit().putString("countdown_widget_color", color.toLowerCase()).apply();
        CountdownWidgetProvider.requestUpdate(context);
    }

    @JavascriptInterface
    public String getCountdownWidgetColor() {
        return prefs.getString("countdown_widget_color", "purple");
    }

    /**
     * Silent, throttled safety-net backup written to Downloads every ~24h whenever
     * data changes. This exists because Android does not let any app detect or
     * intercept the system "Uninstall" button in Settings — so instead of relying on
     * that (impossible) hook, we make sure a recent backup already sits in Downloads
     * before the user ever gets there. Same filename is reused/replaced each time so
     * Downloads doesn't fill up with dozens of dated copies.
     */
    private void maybeAutoBackup(String json) {
        try {
            if (json == null || json.isEmpty()) return;
            long last = prefs.getLong("last_auto_backup_at", 0);
            long now = System.currentTimeMillis();
            if (now - last < 24L * 60 * 60 * 1000) return; // once a day is enough
            String result = writeToDownloadsInternal(
                    "StudyTracker_autobackup.json", json, "application/json", false, true);
            if (result != null && !result.startsWith("error")) {
                prefs.edit().putLong("last_auto_backup_at", now).apply();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Opens the system "Uninstall app" confirmation screen for this app.
     * NOTE: this only works when the user taps an in-app "Uninstall" action — Android
     * gives apps no way to detect or hook the Uninstall button inside phone Settings
     * itself, so that path always relies on the silent auto-backup above instead.
     */
    @JavascriptInterface
    public void requestUninstall() {
        try {
            Intent intent = new Intent(Intent.ACTION_DELETE);
            intent.setData(Uri.parse("package:" + context.getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
            android.os.Handler mainHandler = new android.os.Handler(context.getMainLooper());
            mainHandler.post(() ->
                    Toast.makeText(context, "Could not open uninstall screen", Toast.LENGTH_SHORT).show());
        }
    }

    @JavascriptInterface
    public long getLastAutoBackupAt() {
        return prefs.getLong("last_auto_backup_at", 0);
    }


    @JavascriptInterface
    public void shareReportHtml(String html, String filename) {
        try {
            if (filename == null || filename.isEmpty()) filename = "JEE_Study_Report.html";
            if (!filename.endsWith(".html")) filename = filename + ".html";

            File dir = new File(context.getCacheDir(), "reports");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, filename);
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(html.getBytes("UTF-8"));
            fos.close();

            Uri uri = FileProvider.getUriForFile(
                    context,
                    context.getPackageName() + ".fileprovider",
                    file
            );

            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/html");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.putExtra(Intent.EXTRA_SUBJECT, "TaskZen Study Report");
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            share.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            Intent chooser = Intent.createChooser(share, "Save / Share report");
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(chooser);
        } catch (Exception e) {
            e.printStackTrace();
            android.os.Handler mainHandler = new android.os.Handler(context.getMainLooper());
            mainHandler.post(() ->
                    Toast.makeText(context, "Could not share report", Toast.LENGTH_SHORT).show());
        }
    }

    @JavascriptInterface
    public void setLibraryMode(boolean enabled) {
        prefs.edit().putBoolean("library_mode", enabled).apply();
    }

    @JavascriptInterface
    public boolean getLibraryMode() {
        return prefs.getBoolean("library_mode", false);
    }

    @JavascriptInterface
    public void setMathChallengeEnabled(boolean enabled) {
        prefs.edit().putBoolean("math_challenge_enabled", enabled).apply();
    }

    @JavascriptInterface
    public boolean getMathChallengeEnabled() {
        return prefs.getBoolean("math_challenge_enabled", false);
    }

    /** Task widget text size: small | normal | large | xlarge */
    @JavascriptInterface
    public void setTaskWidgetTextSize(String size) {
        if (size == null || size.isEmpty()) size = "normal";
        prefs.edit().putString("task_widget_text_size", size.toLowerCase()).apply();
        StudyWidgetProvider.requestUpdate(context);
    }

    @JavascriptInterface
    public String getTaskWidgetTextSize() {
        return prefs.getString("task_widget_text_size", "normal");
    }

    /** Task widget color: purple|red|blue|green|orange|teal|black|sunlight */
    @JavascriptInterface
    public void setTaskWidgetColor(String color) {
        if (color == null || color.isEmpty()) color = "purple";
        prefs.edit().putString("task_widget_color", color.toLowerCase()).apply();
        StudyWidgetProvider.requestUpdate(context);
    }

    /** Per-day task widget colour: slot 0=today, 1=tomorrow, 2=day-after-tomorrow. */
    @JavascriptInterface
    public void setTaskWidgetSlotColor(int slot, String color) {
        if (slot < 0 || slot > 2) return;
        if (color == null || color.isEmpty()) color = "purple";
        prefs.edit().putString("task_widget_color_" + slot, color.toLowerCase()).apply();
        StudyWidgetProvider.requestUpdate(context);
    }

    @JavascriptInterface
    public String getTaskWidgetSlotColor(int slot) {
        if (slot < 0 || slot > 2) return "purple";
        return prefs.getString("task_widget_color_" + slot, prefs.getString("task_widget_color", "purple"));
    }

    /** Exact calendar date shown by task widget slot 0/1/2. */
    @JavascriptInterface
    public void setTaskWidgetSlotDate(int slot, String date) {
        if (slot < 0 || slot > 2 || date == null || date.isEmpty()) return;
        prefs.edit().putString("task_widget_date_" + slot, date).apply();
        StudyWidgetProvider.requestUpdate(context);
    }

    @JavascriptInterface
    public String getTaskWidgetSlotDate(int slot) {
        if (slot < 0 || slot > 2) return "";
        return prefs.getString("task_widget_date_" + slot, "");
    }

    @JavascriptInterface
    public String getTaskWidgetColor() {
        return prefs.getString("task_widget_color", "purple");
    }


    @JavascriptInterface
    public void setPersonalAlarmsJson(String json) {
        if (json == null) json = "[]";
        PersonalAlarmHelper.saveAlarmsJson(context, json);
        PersonalAlarmHelper.scheduleAll(context);
    }

    @JavascriptInterface
    public String getPersonalAlarmsJson() {
        return PersonalAlarmHelper.getAlarmsJson(context);
    }

    @JavascriptInterface
    public void setContinuousVibration(boolean enabled) {
        prefs.edit().putBoolean("continuous_vibration", enabled).apply();
        if (!enabled) NotificationHelper.stopContinuousVibration(context);
    }

    @JavascriptInterface
    public void setLateWarnVibration(boolean enabled) {
        prefs.edit().putBoolean("late_warn_vibration", enabled).apply();
    }

    @JavascriptInterface
    public void scheduleExpectedWarnings(String taskJson) {
        try {
            JSONObject t=new JSONObject(taskJson);
            if(t.optBoolean("completed",false) || t.optLong("runningAt",0)<=0) return;
            boolean enabled=prefs.getBoolean("late_warn_enabled",true);
            if(!enabled){ TaskAlarmHelper.cancelExpectedWarnings(context,t.optLong("id",0)); return; }
            TaskAlarmHelper.scheduleExpectedWarnings(context,t.optLong("id",0),t.optString("title","Task"),t.optInt("expected",60),t.optLong("runningAt",0));
        }catch(Exception e){e.printStackTrace();}
    }

    @JavascriptInterface
    public void cancelExpectedWarnings(long taskId) { TaskAlarmHelper.cancelExpectedWarnings(context,taskId); }

    @JavascriptInterface
    public void setLateWarnEnabled(boolean enabled) {
        prefs.edit().putBoolean("late_warn_enabled", enabled).apply();
    }

    @JavascriptInterface
    public void setCountdownWidgetSlotColor(int slot, String color) {
        if(slot<0 || slot>2) return;
        if(color==null || color.isEmpty()) color="purple";
        prefs.edit().putString("countdown_slot_"+slot+"_color",color.toLowerCase()).apply();
        CountdownWidgetProvider.requestUpdate(context);
    }

    @JavascriptInterface
    public boolean getContinuousVibration() {
        return prefs.getBoolean("continuous_vibration", true);
    }

    /**
     * Save text/binary content into public Downloads folder.
     * @param filename e.g. backup.json or report.html
     * @param content  plain text or base64 if isBase64=true
     * @param mime     e.g. application/json or text/html
     * @param isBase64 false for JSON/HTML text
     * @return absolute path or "ok" / error message
     */
    @JavascriptInterface
    public String saveToDownloads(String filename, String content, String mime, boolean isBase64) {
        return writeToDownloadsInternal(filename, content, mime, isBase64, false);
    }

    /**
     * Shared implementation behind saveToDownloads() and the silent auto-backup.
     * @param replaceExisting when true, an existing file with the same name in
     *        Downloads is removed first so the backup is overwritten in place
     *        instead of piling up as "name (1).json", "name (2).json", etc.
     */
    private String writeToDownloadsInternal(String filename, String content, String mime,
                                              boolean isBase64, boolean replaceExisting) {
        try {
            if (filename == null || filename.isEmpty()) filename = "download.txt";
            if (mime == null || mime.isEmpty()) mime = "text/plain";
            byte[] data;
            if (isBase64) {
                String b64 = content;
                if (b64 != null && b64.contains(",")) b64 = b64.substring(b64.indexOf(",") + 1);
                data = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
            } else {
                data = (content != null ? content : "").getBytes("UTF-8");
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentResolver resolver = context.getContentResolver();
                if (replaceExisting) {
                    deleteExistingDownload(resolver, filename);
                }
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
                values.put(MediaStore.Downloads.MIME_TYPE, mime);
                values.put(MediaStore.Downloads.IS_PENDING, 1);
                android.net.Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) return "error: insert failed";
                java.io.OutputStream os = resolver.openOutputStream(uri);
                if (os == null) return "error: stream null";
                os.write(data);
                os.close();
                values.clear();
                values.put(MediaStore.Downloads.IS_PENDING, 0);
                resolver.update(uri, values, null, null);
                return "Downloads/" + filename;
            } else {
                java.io.File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists()) dir.mkdirs();
                java.io.File file = new java.io.File(dir, filename);
                java.io.FileOutputStream fos = new java.io.FileOutputStream(file);
                fos.write(data);
                fos.close();
                // notify media scanner
                Intent scan = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                scan.setData(android.net.Uri.fromFile(file));
                context.sendBroadcast(scan);
                return file.getAbsolutePath();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "error: " + e.getMessage();
        }
    }

    /** Best-effort delete of a prior Downloads entry with the same display name (API 29+). */
    private void deleteExistingDownload(ContentResolver resolver, String filename) {
        try {
            android.database.Cursor cursor = resolver.query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    new String[]{MediaStore.Downloads._ID},
                    MediaStore.Downloads.DISPLAY_NAME + "=?",
                    new String[]{filename},
                    null);
            if (cursor == null) return;
            while (cursor.moveToNext()) {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Downloads._ID));
                Uri itemUri = android.content.ContentUris.withAppendedId(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI, id);
                try {
                    resolver.delete(itemUri, null, null);
                } catch (Exception ignored) {}
            }
            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Firebase Auth + Cloud Sync (v1.6.15)
    // All methods are optional. App works 100% offline without login.
    // Core study timers / break logic / widgets are never blocked.
    // ─────────────────────────────────────────────────────────────

    @JavascriptInterface
    public String getCurrentUser() {
        try {
            FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
            if (u == null) return "";
            JSONObject o = new JSONObject();
            o.put("uid", u.getUid());
            o.put("email", u.getEmail() != null ? u.getEmail() : "");
            o.put("displayName", u.getDisplayName() != null ? u.getDisplayName() : "");
            return o.toString();
        } catch (Exception e) {
            return "";
        }
    }

    @JavascriptInterface
    public boolean isLoggedIn() {
        try {
            return FirebaseAuth.getInstance().getCurrentUser() != null;
        } catch (Exception e) {
            return false;
        }
    }

    /** Password must be at least 8 characters and contain both a letter and a digit. */
    private String validatePassword(String password) {
        if (password == null || password.length() < 8) {
            return "Password must be at least 8 characters";
        }
        boolean hasLetter = false, hasDigit = false;
        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);
            if (Character.isLetter(c)) hasLetter = true;
            if (Character.isDigit(c)) hasDigit = true;
        }
        if (!hasLetter || !hasDigit) {
            return "Password must contain both letters and numbers";
        }
        return null;
    }

    /** Max 5 failed sign-in attempts per rolling 1-hour window. */
    private boolean isRateLimited() {
        long now = System.currentTimeMillis();
        long windowStart = prefs.getLong("auth_fail_window_start", 0);
        int count = prefs.getInt("auth_fail_count", 0);
        if (now - windowStart > 60L * 60L * 1000L) {
            prefs.edit().putLong("auth_fail_window_start", now).putInt("auth_fail_count", 0).apply();
            return false;
        }
        return count >= 5;
    }

    private void recordFailedAttempt() {
        long now = System.currentTimeMillis();
        long windowStart = prefs.getLong("auth_fail_window_start", 0);
        int count = prefs.getInt("auth_fail_count", 0);
        if (now - windowStart > 60L * 60L * 1000L) {
            windowStart = now;
            count = 0;
        }
        count++;
        prefs.edit().putLong("auth_fail_window_start", windowStart).putInt("auth_fail_count", count).apply();
    }

    private void clearFailedAttempts() {
        prefs.edit().putInt("auth_fail_count", 0).apply();
    }

    @JavascriptInterface
    public void signUp(String email, String password) {
        if (email == null || email.trim().isEmpty()) {
            notifyAuth("error", "{\"message\":\"Email is required\"}");
            return;
        }
        String pwdErr = validatePassword(password);
        if (pwdErr != null) {
            notifyAuth("error", "{\"message\":\"" + pwdErr + "\"}");
            return;
        }
        if (isRateLimited()) {
            notifyAuth("error", "{\"message\":\"Too many attempts. Try again after 1 hour.\"}");
            return;
        }
        try {
            FirebaseAuth.getInstance()
                    .createUserWithEmailAndPassword(email.trim(), password)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            clearFailedAttempts();
                            FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
                            try {
                                JSONObject o = new JSONObject();
                                o.put("uid", u != null ? u.getUid() : "");
                                o.put("email", u != null && u.getEmail() != null ? u.getEmail() : email.trim());
                                notifyAuth("signedIn", o.toString());
                            } catch (Exception e) {
                                notifyAuth("signedIn", "{}");
                            }
                        } else {
                            recordFailedAttempt();
                            String msg = task.getException() != null ? task.getException().getMessage() : "Sign up failed";
                            notifyAuth("error", "{\"message\":\"" + msg.replace("\"", "'") + "\"}");
                        }
                    });
        } catch (Exception e) {
            String m = e.getMessage() != null ? e.getMessage().replace("\"", "'") : "Error";
            notifyAuth("error", "{\"message\":\"" + m + "\"}");
        }
    }

    @JavascriptInterface
    public void signIn(String email, String password) {
        if (email == null || email.trim().isEmpty() || password == null || password.isEmpty()) {
            notifyAuth("error", "{\"message\":\"Email and password required\"}");
            return;
        }
        if (isRateLimited()) {
            notifyAuth("error", "{\"message\":\"Too many failed attempts. Try again after 1 hour.\"}");
            return;
        }
        try {
            FirebaseAuth.getInstance()
                    .signInWithEmailAndPassword(email.trim(), password)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            clearFailedAttempts();
                            FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
                            try {
                                JSONObject o = new JSONObject();
                                o.put("uid", u != null ? u.getUid() : "");
                                o.put("email", u != null && u.getEmail() != null ? u.getEmail() : email.trim());
                                notifyAuth("signedIn", o.toString());
                            } catch (Exception e) {
                                notifyAuth("signedIn", "{}");
                            }
                        } else {
                            recordFailedAttempt();
                            String msg = task.getException() != null ? task.getException().getMessage() : "Sign in failed";
                            if (msg != null && (msg.toLowerCase().contains("password") || msg.toLowerCase().contains("credential") || msg.toLowerCase().contains("user") || msg.toLowerCase().contains("no user"))) {
                                msg = "Incorrect email or password";
                            }
                            notifyAuth("error", "{\"message\":\"" + msg.replace("\"", "'") + "\"}");
                        }
                    });
        } catch (Exception e) {
            String m = e.getMessage() != null ? e.getMessage().replace("\"", "'") : "Error";
            notifyAuth("error", "{\"message\":\"" + m + "\"}");
        }
    }


    @JavascriptInterface
    public void signOut() {
        try {
            FirebaseAuth.getInstance().signOut();
            notifyAuth("signedOut", "{}");
        } catch (Exception e) {
            notifyAuth("error", "{\"message\":\"" + e.getMessage().replace("\"", "'") + "\"}");
        }
    }

    @JavascriptInterface
    public void sendPasswordReset(String email) {
        if (email == null || email.trim().isEmpty()) {
            notifyAuth("error", "{\"message\":\"Email required\"}");
            return;
        }
        try {
            FirebaseAuth.getInstance()
                    .sendPasswordResetEmail(email.trim())
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            notifyAuth("resetSent", "{\"email\":\"" + email.trim() + "\"}");
                        } else {
                            String msg = task.getException() != null ? task.getException().getMessage() : "Reset failed";
                            notifyAuth("error", "{\"message\":\"" + msg.replace("\"", "'") + "\"}");
                        }
                    });
        } catch (Exception e) {
            notifyAuth("error", "{\"message\":\"" + e.getMessage().replace("\"", "'") + "\"}");
        }
    }

    private boolean isNetworkAvailable() {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            Network n = cm.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities caps = cm.getNetworkCapabilities(n);
            return caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
        } catch (Exception e) { return false; }
    }

    private void registerAutoSyncNetworkCallback() {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return;
            networkCallback = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network network) { autoSyncStoredState(); }
                @Override public void onCapabilitiesChanged(Network network, NetworkCapabilities caps) {
                    if (caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) autoSyncStoredState();
                }
            };
            cm.registerDefaultNetworkCallback(networkCallback);
        } catch (Exception ignored) {}
    }

    private void autoSyncStoredState() {
        if (!isNetworkAvailable()) return;
        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        if (u == null) return;
        if (!prefs.getBoolean("auto_sync_dirty", false)) return;
        String json = prefs.getString("task_state", "");
        if (json == null || json.isEmpty()) return;
        uploadStoredStateSilently(json);
    }

    private void uploadStoredStateSilently(String stateJson) {
        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        if (u == null || stateJson == null || stateJson.isEmpty()) return;
        try {
            Map<String, Object> data = new HashMap<>();
            data.put("stateJson", stateJson);
            data.put("updatedAt", System.currentTimeMillis());
            data.put("version", "1.6.22");
            FirebaseFirestore.getInstance().collection("users").document(u.getUid())
                    .collection("data").document("study").set(data, SetOptions.merge())
                    .addOnSuccessListener(v -> prefs.edit().putBoolean("auto_sync_dirty", false).apply());
        } catch (Exception ignored) {}
    }

    @JavascriptInterface
    public void autoSyncNow() { autoSyncStoredState(); }

    /**
     * Upload full local state JSON to Firestore under users/{uid}/data.
     * Never overwrites without the caller deciding; this is pure upload.
     */
    @JavascriptInterface
    public void uploadStateToCloud(String stateJson) {
        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        if (u == null) {
            notifyAuth("error", "{\"message\":\"Not logged in\"}");
            return;
        }
        if (stateJson == null || stateJson.isEmpty()) {
            notifyAuth("error", "{\"message\":\"No data to upload\"}");
            return;
        }
        try {
            Map<String, Object> data = new HashMap<>();
            data.put("stateJson", stateJson);
            data.put("updatedAt", System.currentTimeMillis());
            data.put("version", "1.6.15");

            FirebaseFirestore.getInstance()
                    .collection("users")
                    .document(u.getUid())
                    .collection("data")
                    .document("study")
                    .set(data, SetOptions.merge())
                    .addOnSuccessListener(aVoid -> { prefs.edit().putBoolean("auto_sync_dirty", false).apply(); notifyAuth("uploadOk", "{}"); })
                    .addOnFailureListener(e -> notifyAuth("error", "{\"message\":\"" + e.getMessage().replace("\"", "'") + "\"}"));
        } catch (Exception e) {
            notifyAuth("error", "{\"message\":\"" + e.getMessage().replace("\"", "'") + "\"}");
        }
    }

    /**
     * Download cloud state. Result is delivered via __onAuthEvent('cloudData', json)
     * or 'noCloudData' if nothing exists yet.
     */
    @JavascriptInterface
    public void downloadStateFromCloud() {
        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        if (u == null) {
            notifyAuth("error", "{\"message\":\"Not logged in\"}");
            return;
        }
        // Firestore reads can fail offline even when Firebase Authentication has already
        // succeeded. That must NOT block the user from entering the app.
        if (!isNetworkAvailable()) {
            notifyAuth("cloudOffline", "{\"message\":\"Cloud unavailable offline\"}");
            return;
        }
        try {
            FirebaseFirestore.getInstance()
                    .collection("users")
                    .document(u.getUid())
                    .collection("data")
                    .document("study")
                    .get()
                    .addOnSuccessListener(snap -> {
                        if (snap != null && snap.exists() && snap.contains("stateJson")) {
                            String json = snap.getString("stateJson");
                            notifyAuth("cloudData", json != null ? json : "{}");
                        } else {
                            notifyAuth("noCloudData", "{}");
                        }
                    })
                    .addOnFailureListener(e -> {
                        String msg = e != null && e.getMessage() != null ? e.getMessage() : "Cloud read failed";
                        notifyAuth("cloudError", "{\"message\":\"" + msg.replace("\"", "'") + "\"}");
                    });
        } catch (Exception e) {
            String msg = e.getMessage() != null ? e.getMessage() : "Cloud read failed";
            notifyAuth("cloudError", "{\"message\":\"" + msg.replace("\"", "'") + "\"}");
        }
    }

    /**
     * Permanently delete the Firebase account. Password is mandatory (re-auth).
     * Also deletes the Firestore study document best-effort.
     */
    @JavascriptInterface
    public void deleteAccount(String password) {
        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        if (u == null) {
            notifyAuth("error", "{\"message\":\"Not logged in\"}");
            return;
        }
        if (password == null || password.isEmpty()) {
            notifyAuth("error", "{\"message\":\"Password is required to delete account\"}");
            return;
        }
        if (isRateLimited()) {
            notifyAuth("error", "{\"message\":\"Too many attempts. Try again after 1 hour.\"}");
            return;
        }
        String email = u.getEmail();
        if (email == null || email.isEmpty()) {
            notifyAuth("error", "{\"message\":\"Account has no email; cannot re-authenticate\"}");
            return;
        }
        try {
            com.google.firebase.auth.AuthCredential cred =
                    EmailAuthProvider.getCredential(email, password);
            u.reauthenticate(cred)
                    .addOnCompleteListener(reauth -> {
                        if (!reauth.isSuccessful()) {
                            recordFailedAttempt();
                            String msg = reauth.getException() != null
                                    ? reauth.getException().getMessage() : "Wrong password";
                            if (msg != null && (msg.toLowerCase().contains("password")
                                    || msg.toLowerCase().contains("credential")
                                    || msg.toLowerCase().contains("invalid"))) {
                                msg = "Incorrect password. Account not deleted.";
                            }
                            notifyAuth("error", "{\"message\":\"" + msg.replace("\"", "'") + "\"}");
                            return;
                        }
                        clearFailedAttempts();
                        // Best-effort delete cloud data first
                        try {
                            FirebaseFirestore.getInstance()
                                    .collection("users")
                                    .document(u.getUid())
                                    .collection("data")
                                    .document("study")
                                    .delete();
                        } catch (Exception ignored) {}

                        u.delete()
                                .addOnCompleteListener(del -> {
                                    if (del.isSuccessful()) {
                                        notifyAuth("accountDeleted", "{}");
                                    } else {
                                        String msg = del.getException() != null
                                                ? del.getException().getMessage() : "Delete failed";
                                        notifyAuth("error", "{\"message\":\"" + msg.replace("\"", "'") + "\"}");
                                    }
                                });
                    });
        } catch (Exception e) {
            String m = e.getMessage() != null ? e.getMessage().replace("\"", "'") : "Error";
            notifyAuth("error", "{\"message\":\"" + m + "\"}");
        }
    }


    // ===== Running task notification (status bar) =====
    @JavascriptInterface
    public void updateRunningNotification(String payloadJson) {
        try {
            if (payloadJson == null || payloadJson.isEmpty()) {
                try { FocusController.setTaskRunning(context, false); } catch (Exception ignored) {}
                NotificationHelper.cancelRunningTask(context);
                return;
            }
            JSONObject o = new JSONObject(payloadJson);
            boolean hasRunning = o.optBoolean("hasRunning", false);
            boolean isBreak = o.optBoolean("isBreak", false);
            try { FocusController.setTaskRunning(context, hasRunning); } catch (Exception ignored) {}
            if (!hasRunning && !isBreak) {
                NotificationHelper.cancelRunningTask(context);
                return;
            }
            long taskId = o.optLong("taskId", 0);
            String title = o.optString("title", "Study");
            String subject = o.optString("subject", "");
            long elapsed = o.optLong("elapsedSec", 0);
            NotificationHelper.showRunningTask(context, taskId, title, subject, elapsed, isBreak);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @JavascriptInterface
    public void clearRunningNotification() {
        try { FocusController.setTaskRunning(context, false); } catch (Exception ignored) {}
        NotificationHelper.cancelRunningTask(context);
    }

    // ===== Unique username + ranking (Firestore) =====
    /**
     * Atomically claim a unique username under usernames/{name}.
     * Only the first UID wins. Then stores username on users/{uid}/profile.
     */
    @JavascriptInterface
    public void claimUsername(String username, double coins) {
        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        if (u == null) {
            runJs("window.__onUsernameClaim && window.__onUsernameClaim(false, 'Please login first', '');");
            return;
        }
        if (username == null) username = "";
        final String name = username.trim().toLowerCase().replaceAll("[^a-z0-9_]", "");
        if (name.length() < 3 || name.length() > 20) {
            runJs("window.__onUsernameClaim && window.__onUsernameClaim(false, 'Invalid username', '');");
            return;
        }
        final String uid = u.getUid();
        final long coinVal = (long) Math.max(0, coins);
        try {
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            db.collection("usernames").document(name).get()
                    .addOnSuccessListener(snap -> {
                        if (snap.exists()) {
                            String owner = snap.getString("uid");
                            if (uid.equals(owner)) {
                                // Already owned by this user – update coins
                                publishRankingInternal(name, coinVal, uid);
                                runJs("window.__onUsernameClaim && window.__onUsernameClaim(true, 'Username already yours ✓', '" + name + "');");
                            } else {
                                runJs("window.__onUsernameClaim && window.__onUsernameClaim(false, 'Username already taken', '');");
                            }
                            return;
                        }
                        // Claim new
                        java.util.Map<String, Object> data = new java.util.HashMap<>();
                        data.put("uid", uid);
                        data.put("claimedAt", System.currentTimeMillis());
                        db.collection("usernames").document(name).set(data)
                                .addOnSuccessListener(v -> {
                                    publishRankingInternal(name, coinVal, uid);
                                    // Also store on user profile
                                    java.util.Map<String, Object> profile = new java.util.HashMap<>();
                                    profile.put("username", name);
                                    profile.put("coins", coinVal);
                                    profile.put("updatedAt", System.currentTimeMillis());
                                    db.collection("users").document(uid)
                                            .collection("data").document("profile")
                                            .set(profile, SetOptions.merge());
                                    runJs("window.__onUsernameClaim && window.__onUsernameClaim(true, 'Username claimed ✓', '" + name + "');");
                                })
                                .addOnFailureListener(e -> {
                                    String msg = e.getMessage() != null ? e.getMessage().replace("'", "") : "Failed";
                                    if (msg.toLowerCase().contains("offline") || msg.toLowerCase().contains("failed to get document")) {
                                    msg = "Saved on device. Cloud lock when online.";
                                }
                                runJs("window.__onUsernameClaim && window.__onUsernameClaim(false, '" + msg.replace("'", "") + "', '');");
                                });
                    })
                    .addOnFailureListener(e -> {
                        String msg = e.getMessage() != null ? e.getMessage().replace("'", "") : "Network error";
                        if (msg.toLowerCase().contains("offline") || msg.toLowerCase().contains("failed to get document")) {
                                    msg = "Saved on device. Cloud lock when online.";
                                }
                                runJs("window.__onUsernameClaim && window.__onUsernameClaim(false, '" + msg.replace("'", "") + "', '');");
                    });
        } catch (Exception e) {
            runJs("window.__onUsernameClaim && window.__onUsernameClaim(false, 'Error', '');");
        }
    }

    @JavascriptInterface
    public void publishRanking(String username, double coins) {
        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        if (u == null || username == null || username.trim().isEmpty()) return;
        publishRankingInternal(username.trim().toLowerCase(), (long) Math.max(0, coins), u.getUid());
    }

    private void publishRankingInternal(String username, long coins, String uid) {
        try {
            java.util.Map<String, Object> row = new java.util.HashMap<>();
            row.put("username", username);
            row.put("coins", coins);
            row.put("uid", uid);
            row.put("updatedAt", System.currentTimeMillis());
            FirebaseFirestore.getInstance().collection("rankings").document(uid)
                    .set(row, SetOptions.merge());
        } catch (Exception ignored) {}
    }

    @JavascriptInterface
    public void fetchLeaderboard() {
        try {
            FirebaseFirestore.getInstance().collection("rankings")
                    .orderBy("coins", Query.Direction.DESCENDING)
                    .limit(20)
                    .get()
                    .addOnSuccessListener(qs -> {
                        try {
                            JSONArray arr = new JSONArray();
                            for (com.google.firebase.firestore.DocumentSnapshot d : qs.getDocuments()) {
                                JSONObject o = new JSONObject();
                                o.put("username", d.getString("username"));
                                Object c = d.get("coins");
                                o.put("coins", c instanceof Number ? ((Number) c).longValue() : 0);
                                arr.put(o);
                            }
                            String json = arr.toString().replace("\\", "\\\\").replace("'", "\\'");
                            runJs("window.__onLeaderboard && window.__onLeaderboard('" + json + "');");
                        } catch (Exception e) {
                            runJs("window.__onLeaderboard && window.__onLeaderboard('[]');");
                        }
                    })
                    .addOnFailureListener(e -> runJs("window.__onLeaderboard && window.__onLeaderboard('[]');"));
        } catch (Exception e) {
            runJs("window.__onLeaderboard && window.__onLeaderboard('[]');");
        }
    }



    // ========== AdMob bridge (names match AdManager unit constants) ==========
    @JavascriptInterface
    public void showInterstitialAd() {
        final Activity act = activityRef.get();
        if (act == null) return;
        act.runOnUiThread(() -> {
            try {
                AdManager.get(act).showInterstitialNow(shown ->
                    runJs("window.__onInterstitialClosed && window.__onInterstitialClosed(" + (shown ? "true" : "false") + ")")
                );
            } catch (Exception e) {
                runJs("window.__onInterstitialClosed && window.__onInterstitialClosed(false)");
            }
        });
    }

    @JavascriptInterface
    public void showInterstitialForAction() {
        final Activity act = activityRef.get();
        if (act == null) {
            runJs("window.__onInterstitialClosed && window.__onInterstitialClosed(false)");
            return;
        }
        act.runOnUiThread(() -> {
            try {
                AdManager.get(act).maybeShowInterstitialForAction(shown ->
                    runJs("window.__onInterstitialClosed && window.__onInterstitialClosed(" + (shown ? "true" : "false") + ")")
                );
            } catch (Exception e) {
                runJs("window.__onInterstitialClosed && window.__onInterstitialClosed(false)");
            }
        });
    }

    @JavascriptInterface
    public void showRewardedAd() {
        final Activity act = activityRef.get();
        if (act == null) return;
        act.runOnUiThread(() -> {
            try {
                AdManager.get(act).showRewarded(earned ->
                    runJs("window.__onRewardedClosed && window.__onRewardedClosed(" + (earned ? "true" : "false") + ")")
                );
            } catch (Exception e) {
                runJs("window.__onRewardedClosed && window.__onRewardedClosed(false)");
            }
        });
    }

    @JavascriptInterface
    public void showRewardedInterstitialAd() {
        final Activity act = activityRef.get();
        if (act == null) return;
        act.runOnUiThread(() -> {
            try {
                AdManager.get(act).showRewardedInterstitial(earned ->
                    runJs("window.__onRewardedClosed && window.__onRewardedClosed(" + (earned ? "true" : "false") + ")")
                );
            } catch (Exception e) {
                runJs("window.__onRewardedClosed && window.__onRewardedClosed(false)");
            }
        });
    }

    @JavascriptInterface
    public void setAdsEnabled(boolean enabled) {
        final Activity act = activityRef.get();
        if (act == null) return;
        act.runOnUiThread(() -> AdManager.get(act).setAdsEnabled(enabled));
    }

    @JavascriptInterface
    public void setInterstitialEveryN(int n) {
        final Activity act = activityRef.get();
        if (act == null) return;
        act.runOnUiThread(() -> AdManager.get(act).setInterstitialEveryN(n));
    }

    @JavascriptInterface
    public void setBannersEnabled(boolean enabled) {
        final Activity act = activityRef.get();
        if (act == null) return;
        act.runOnUiThread(() -> AdManager.get(act).setBannersEnabled(enabled));
    }

    @JavascriptInterface
    public void setRewardedEnabled(boolean enabled) {
        final Activity act = activityRef.get();
        if (act == null) return;
        act.runOnUiThread(() -> AdManager.get(act).setRewardedEnabled(enabled));
    }

    @JavascriptInterface
    public void setNativeEnabled(boolean enabled) {
        final Activity act = activityRef.get();
        if (act == null) return;
        act.runOnUiThread(() -> AdManager.get(act).setNativeEnabled(enabled));
    }

    @JavascriptInterface
    public boolean isAdsEnabled() {
        final Activity act = activityRef.get();
        if (act == null) return false;
        try {
            return AdManager.get(act).isAdsEnabled();
        } catch (Exception e) {
            return false;
        }
    }


    // ===== Focus mode + App blocking (v58) =====

    @JavascriptInterface
    public String getFocusState() { return FocusController.getStateJson(context); }

    @JavascriptInterface
    public String getFocusConfig() { return FocusController.getConfigJson(context); }

    @JavascriptInterface
    public void setFocusConfig(String json) { FocusController.setConfigJson(context, json); }

    @JavascriptInterface
    public boolean startFocusSession(int minutes, boolean strict) {
        if (!FocusController.isReady(context)) return false;
        FocusController.startSession(context, minutes, strict);
        return true;
    }

    /** @return false if strict mode forbids stopping the running session. */
    @JavascriptInterface
    public boolean stopFocusSession() { return FocusController.stopSession(context); }

    @JavascriptInterface
    public String getFocusStats() { return FocusController.getStatsJson(context); }

    @JavascriptInterface
    public void syncFocus() { FocusController.sync(context); }

    /** Launcher apps the user can pick from (protected/system-critical apps are excluded). */
    @JavascriptInterface
    public String getInstalledApps() {
        JSONArray out = new JSONArray();
        try {
            android.content.pm.PackageManager pm = context.getPackageManager();
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            java.util.List<android.content.pm.ResolveInfo> list = pm.queryIntentActivities(q, 0);
            java.util.Set<String> seen = new java.util.HashSet<>();
            java.util.List<String[]> rows = new java.util.ArrayList<>();
            java.util.Map<String, android.content.pm.ResolveInfo> byPkg = new java.util.HashMap<>();
            for (android.content.pm.ResolveInfo r : list) {
                if (r.activityInfo == null) continue;
                String pkg = r.activityInfo.packageName;
                if (!seen.add(pkg) || FocusController.isProtectedPackage(context, pkg)) continue;
                rows.add(new String[]{String.valueOf(r.loadLabel(pm)), pkg});
                byPkg.put(pkg, r);
            }
            java.util.Collections.sort(rows, (a, b) -> a[0].compareToIgnoreCase(b[0]));
            for (String[] row : rows) {
                JSONObject o = new JSONObject();
                o.put("pkg", row[1]);
                o.put("label", row[0]);
                o.put("icon", iconBase64(byPkg.get(row[1]).loadIcon(pm)));
                out.put(o);
            }
        } catch (Exception ignored) {}
        return out.toString();
    }

    private String iconBase64(android.graphics.drawable.Drawable d) {
        try {
            int size = 72;
            android.graphics.Bitmap bmp = android.graphics.Bitmap.createBitmap(size, size, android.graphics.Bitmap.Config.ARGB_8888);
            android.graphics.Canvas c = new android.graphics.Canvas(bmp);
            d.setBounds(0, 0, size, size);
            d.draw(c);
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 90, bos);
            return "data:image/png;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) { return ""; }
    }

    @JavascriptInterface
    public void openUsageAccessSettings() {
        try {
            Intent i = new Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS);
            i.setData(Uri.parse("package:" + context.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
        } catch (Exception e) {
            try { context.startActivity(new Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Exception ignored) {}
        }
    }

    @JavascriptInterface
    public void openOverlaySettings() {
        try {
            Intent i = new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + context.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
        } catch (Exception ignored) {}
    }

    @JavascriptInterface
    public void openBatterySettings() {
        try {
            context.startActivity(new Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            try { context.startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Exception ignored) {}
        }
    }

    @JavascriptInterface
    public void openNotificationSettings() {
        try {
            Intent i = new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, context.getPackageName())
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
        } catch (Exception ignored) {}
    }

    @JavascriptInterface
    public void openExactAlarmSettings() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                Intent i = new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + context.getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
            }
        } catch (Exception ignored) {}
    }

    @JavascriptInterface
    public void openAccessibilitySettings() {
        try {
            context.startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception ignored) {}
    }

    /** Needed on Android 13+ for sideloaded APKs before Accessibility can be enabled. */
    @JavascriptInterface
    public void openAppInfoSettings() {
        try {
            Intent i = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + context.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
        } catch (Exception ignored) {}
    }
}
