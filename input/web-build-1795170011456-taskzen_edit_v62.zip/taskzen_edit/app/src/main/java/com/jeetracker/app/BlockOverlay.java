package com.jeetracker.app;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Map;

/** Full-screen "app blocked" cover, shared by the Accessibility-based blocker. */
final class BlockOverlay {

    interface Actions { void goHome(); void openTaskZen(); }

    private final Context ctx;
    private final WindowManager wm;
    private final int windowType;
    private final Actions actions;
    private Root root;
    private TextView title, reason, timer;
    private Button endBtn;
    private String shownPkg = "";
    private final Map<String, Long> lastCounted = new HashMap<>();

    BlockOverlay(Context ctx, WindowManager wm, int windowType, Actions actions) {
        this.ctx = ctx; this.wm = wm; this.windowType = windowType; this.actions = actions;
    }

    private final class Root extends FrameLayout {
        Root(Context c) { super(c); }
        @Override public boolean dispatchKeyEvent(KeyEvent ev) {
            if (ev.getKeyCode() == KeyEvent.KEYCODE_BACK) {
                if (ev.getAction() == KeyEvent.ACTION_UP) actions.goHome();
                return true;
            }
            return super.dispatchKeyEvent(ev);
        }
    }

    boolean isShown() { return root != null && root.getParent() != null; }

    private String labelOf(String pkg) {
        try {
            PackageManager pm = ctx.getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            return String.valueOf(pm.getApplicationLabel(ai));
        } catch (Exception e) { return pkg; }
    }

    private String reasonText(FocusController.Decision d) {
        try {
            String r = d.reasons.getString(0);
            if (r.equals("focus")) return "Focus session is running";
            if (r.equals("task")) return "A study task is running. Stop it in TaskZen to unblock.";
            if (r.startsWith("schedule:")) return "Blocked by schedule: " + r.substring(9);
        } catch (Exception ignored) {}
        return "Blocked right now";
    }

    void show(String pkg, FocusController.Decision d) {
        if (root == null) build();
        boolean session = FocusController.isSessionActive(ctx);
        boolean strict = session && ctx.getSharedPreferences(FocusController.PREFS, Context.MODE_PRIVATE).getBoolean("session_strict", false);
        title.setText(labelOf(pkg) + " is blocked");
        reason.setText(reasonText(d));
        if (session) {
            long left = Math.max(0, (ctx.getSharedPreferences(FocusController.PREFS, Context.MODE_PRIVATE).getLong("session_end", 0) - System.currentTimeMillis()) / 1000);
            timer.setText(FocusController.formatClock(left));
            timer.setVisibility(View.VISIBLE);
        } else timer.setVisibility(View.GONE);
        endBtn.setVisibility(session && !strict ? View.VISIBLE : View.GONE);

        if (root.getParent() == null) {
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                    windowType,
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.OPAQUE);
            try { wm.addView(root, lp); } catch (Exception e) { return; }
        }
        if (!pkg.equals(shownPkg)) {
            shownPkg = pkg;
            long now = System.currentTimeMillis();
            Long last = lastCounted.get(pkg);
            if (last == null || now - last > 5000) {
                FocusController.recordBlockedAttempt(ctx, pkg);
                lastCounted.put(pkg, now);
            }
        }
    }

    void hide() {
        shownPkg = "";
        if (root != null && root.getParent() != null) {
            try { wm.removeView(root); } catch (Exception ignored) {}
        }
    }

    private void build() {
        root = new Root(ctx);
        root.setFocusable(true);
        root.setFocusableInTouchMode(true);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(26, 18, 56), Color.rgb(80, 40, 140)}));

        LinearLayout box = new LinearLayout(ctx);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(60, 60, 60, 60);

        TextView lock = new TextView(ctx);
        lock.setText("🔒"); lock.setTextSize(64); lock.setGravity(Gravity.CENTER);
        box.addView(lock);

        title = new TextView(ctx);
        title.setTextColor(Color.WHITE); title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD); title.setGravity(Gravity.CENTER);
        box.addView(title);

        reason = new TextView(ctx);
        reason.setTextColor(Color.rgb(220, 210, 245)); reason.setTextSize(16);
        reason.setGravity(Gravity.CENTER); reason.setPadding(0, 24, 0, 8);
        box.addView(reason);

        timer = new TextView(ctx);
        timer.setTextColor(Color.WHITE); timer.setTextSize(46);
        timer.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        timer.setGravity(Gravity.CENTER); timer.setPadding(0, 16, 0, 16);
        box.addView(timer);

        TextView quote = new TextView(ctx);
        quote.setText("Stay focused. You'll thank yourself later.");
        quote.setTextColor(Color.rgb(200, 190, 230)); quote.setTextSize(14);
        quote.setGravity(Gravity.CENTER); quote.setPadding(0, 8, 0, 36);
        box.addView(quote);

        Button home = new Button(ctx);
        home.setText("Go to Home");
        home.setOnClickListener(v -> actions.goHome());
        box.addView(home, new LinearLayout.LayoutParams(-1, -2));

        Button open = new Button(ctx);
        open.setText("Open TaskZen");
        open.setOnClickListener(v -> actions.openTaskZen());
        box.addView(open, new LinearLayout.LayoutParams(-1, -2));

        endBtn = new Button(ctx);
        endBtn.setText("End focus session");
        endBtn.setOnClickListener(v -> { FocusController.stopSession(ctx); hide(); });
        box.addView(endBtn, new LinearLayout.LayoutParams(-1, -2));

        root.addView(box, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));
    }
}
