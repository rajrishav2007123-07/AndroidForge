package com.jeetracker.app;

import android.accessibilityservice.AccessibilityService;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;

import java.util.HashSet;
import java.util.Set;

/**
 * Accessibility-based app blocker.
 *
 * Why: the system itself starts and keeps this service alive, so blocking keeps working after
 * TaskZen is swiped out of Recents (a normal foreground service gets killed and Android 12+
 * does not allow restarting it from the background).
 *
 * Privacy: canRetrieveWindowContent=false. It only receives "window changed" events
 * (package name of the app that came to the front). No screen text is read.
 */
public class FocusAccessibilityService extends AccessibilityService {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private BlockOverlay overlay;
    private String currentFg = "";
    private boolean wasActive = false;
    private boolean looping = false;
    private Set<String> imePackages = new HashSet<>();
    private long imeLoadedAt = 0;

    private final Runnable loop = new Runnable() {
        @Override public void run() {
            if (!looping) return;
            try { evaluateNow(); } catch (Exception ignored) {}
            handler.postDelayed(this, 1000L);
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        overlay = new BlockOverlay(this, wm, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, new BlockOverlay.Actions() {
            @Override public void goHome() { homeNow(); }
            @Override public void openTaskZen() { openApp(); }
        });
        // The system FGS watcher is not needed while this service is on.
        try { stopService(new Intent(this, FocusBlockService.class)); } catch (Exception ignored) {}
        looping = true;
        handler.removeCallbacksAndMessages(null);
        handler.post(loop);
        try { FocusController.sync(this); } catch (Exception ignored) {}
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence cs = event.getPackageName();
        if (cs == null) return;
        String pkg = cs.toString();
        if (pkg.equals(getPackageName())) return;            // our own overlay / TaskZen
        if (pkg.equals("com.android.systemui") || pkg.equals("android")) return;
        if (isIme(pkg)) return;                              // keyboard windows
        currentFg = pkg;
        try { evaluateNow(); } catch (Exception ignored) {}
    }

    private boolean isIme(String pkg) {
        long now = System.currentTimeMillis();
        if (now - imeLoadedAt > 60_000L) {
            imeLoadedAt = now;
            Set<String> s = new HashSet<>();
            try {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) for (InputMethodInfo i : imm.getInputMethodList()) s.add(i.getPackageName());
            } catch (Exception ignored) {}
            imePackages = s;
        }
        return imePackages.contains(pkg);
    }

    private void evaluateNow() {
        FocusController.Decision d = FocusController.evaluate(this);
        boolean active = d.active() && !d.packages.isEmpty();
        if (!active) {
            if (overlay != null) overlay.hide();
            if (wasActive) {            // blocking just ended: finish session bookkeeping, notify
                wasActive = false;
                try { FocusController.sync(this); } catch (Exception ignored) {}
            }
            return;
        }
        if (!wasActive) {               // blocking just started: learn which app is open right now
            wasActive = true;
            String fg = usageForeground();
            if (!fg.isEmpty() && !fg.equals(getPackageName())) currentFg = fg;
        }
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (pm != null && !pm.isInteractive()) return;
        if (overlay == null) return;
        if (d.packages.contains(currentFg)) overlay.show(currentFg, d);
        else overlay.hide();
    }

    /** Optional helper: works only if Usage Access was granted too. */
    private String usageForeground() {
        try {
            if (!FocusController.hasUsageAccess(this)) return "";
            UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
            if (usm == null) return "";
            long now = System.currentTimeMillis();
            UsageEvents ev = usm.queryEvents(now - 10 * 60 * 1000L, now);
            UsageEvents.Event e = new UsageEvents.Event();
            String last = "";
            while (ev != null && ev.hasNextEvent()) {
                ev.getNextEvent(e);
                boolean fg = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                        ? e.getEventType() == UsageEvents.Event.ACTIVITY_RESUMED
                        : e.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND;
                if (fg && e.getPackageName() != null) last = e.getPackageName();
            }
            return last;
        } catch (Exception e) { return ""; }
    }

    private void homeNow() {
        if (overlay != null) overlay.hide();
        try { performGlobalAction(GLOBAL_ACTION_HOME); } catch (Exception ignored) {}
        currentFg = getPackageName();
    }

    private void openApp() {
        if (overlay != null) overlay.hide();
        try {
            startActivity(new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP));
        } catch (Exception ignored) {}
        currentFg = getPackageName();
    }

    @Override public void onInterrupt() {}

    @Override
    public boolean onUnbind(Intent intent) {
        looping = false;
        handler.removeCallbacksAndMessages(null);
        if (overlay != null) overlay.hide();
        try { FocusController.sync(this); } catch (Exception ignored) {}  // falls back to the foreground-service blocker
        return super.onUnbind(intent);
    }
}
