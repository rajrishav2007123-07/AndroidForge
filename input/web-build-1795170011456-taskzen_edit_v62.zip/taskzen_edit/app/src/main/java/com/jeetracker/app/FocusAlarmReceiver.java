package com.jeetracker.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Fires at every focus/schedule boundary (start or end) and re-evaluates blocking. */
public class FocusAlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        try { FocusController.sync(context); } catch (Exception ignored) {}
    }
}
