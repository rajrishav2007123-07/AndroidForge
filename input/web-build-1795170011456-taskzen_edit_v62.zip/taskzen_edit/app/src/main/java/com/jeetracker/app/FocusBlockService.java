package com.jeetracker.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.app.NotificationCompat;

import java.util.HashMap;
import java.util.Map;

/**
 * Foreground service that watches which app is in the foreground (UsageStatsManager)
 * and covers blocked apps with a full-screen overlay.
 *
 * Limits (Android): needs Usage Access + "Display over other apps". Detection polls
 * every ~700 ms, so a blocked app can flash for a moment. A user can still disable the
 * permissions in system settings; that is an Android rule, not something an app can prevent.
 */
public class FocusBlockService extends Service {

    private static final long TICK_MS = 700L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private OverlayRoot overlay;
    private TextView ovTitle, ovReason, ovTimer;
    private Button ovEnd;
    private String currentFg = "";
    private long lastQuery = 0;
    private String overlayPkg = "";
    private final Map<String, Long> lastCounted = new HashMap<>();
    private boolean running = false;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!running) return;
            try { doTick(); } catch (Exception ignored) {}
            handler.postDelayed(this, TICK_MS);
        }
    };

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startAsForeground("Focus blocker active", "Watching blocked apps");
        if (!running) {
            running = true;
            lastQuery = 0;
            currentFg = "";
            handler.post(tick);
        }
        return START_STICKY;
    }

    private void startAsForeground(String title, String text) {
        FocusController.ensureChannel(this);
        Intent open = new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(this, 9205, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new NotificationCompat.Builder(this, FocusController.CHANNEL_FOCUS)
                .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                .setContentTitle(title).setContentText(text)
                .setOngoing(true).setContentIntent(pi)
                .setPriority(NotificationCompat.PRIORITY_LOW).build();
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(FocusController.NOTIF_SERVICE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(FocusController.NOTIF_SERVICE, n);
            }
        } catch (Exception e) {
            stopSelf();
        }
    }

    private void doTick() {
        // Re-evaluate every tick so session end / schedule end / task stop are picked up instantly.
        if (FocusController.isAccessibilityEnabled(this)) { hideOverlay(); stopSelf(); return; }
        FocusController.Decision d = FocusController.evaluate(this);
        if (!d.active() || d.packages.isEmpty() || !FocusController.hasUsageAccess(this) || !FocusController.canDrawOverlay(this)) {
            hideOverlay();
            FocusController.sync(this); // also finishes a due session and stops this service
            if (!FocusController.evaluate(this).active()) { stopSelf(); }
            return;
        }
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (pm != null && !pm.isInteractive()) return; // screen off: save battery

        updateForeground();
        if (d.packages.contains(currentFg)) {
            showOverlay(currentFg, d);
        } else {
            hideOverlay();
        }
    }

    private void updateForeground() {
        UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
        if (usm == null) return;
        long now = System.currentTimeMillis();
        long from = lastQuery == 0 ? now - 2 * 60 * 60 * 1000L : lastQuery - 1000L;
        UsageEvents events = usm.queryEvents(from, now);
        UsageEvents.Event e = new UsageEvents.Event();
        while (events != null && events.hasNextEvent()) {
            events.getNextEvent(e);
            int t = e.getEventType();
            boolean fg = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                    ? t == UsageEvents.Event.ACTIVITY_RESUMED
                    : t == UsageEvents.Event.MOVE_TO_FOREGROUND;
            if (fg && e.getPackageName() != null) currentFg = e.getPackageName();
        }
        lastQuery = now;
    }

    // ------------------------------------------------------------------ overlay

    /** FrameLayout that sends BACK to the home screen instead of the blocked app. */
    private final class OverlayRoot extends FrameLayout {
        OverlayRoot(Context c) { super(c); }
        @Override public boolean dispatchKeyEvent(KeyEvent ev) {
            if (ev.getKeyCode() == KeyEvent.KEYCODE_BACK) {
                if (ev.getAction() == KeyEvent.ACTION_UP) goHome();
                return true;
            }
            return super.dispatchKeyEvent(ev);
        }
    }

    private String labelOf(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            return String.valueOf(pm.getApplicationLabel(ai));
        } catch (Exception e) { return pkg; }
    }

    private String reasonText(FocusController.Decision d) {
        try {
            String r = d.reasons.getString(0);
            if (r.equals("focus")) return "Focus session is running";
            if (r.equals("task")) return "A study task is running. Stop it in TaskZen to unblock.";
            if (r.startsWith("schedule:")) return "Blocked by schedule: " + r.substring(9);
        } catch (Exception ignored) {}
        return "Blocked right now";
    }

    private void showOverlay(String pkg, FocusController.Decision d) {
        if (!FocusController.canDrawOverlay(this)) return;
        boolean strict = getSharedPreferences(FocusController.PREFS, MODE_PRIVATE).getBoolean("session_strict", false)
                && FocusController.isSessionActive(this);
        if (overlay == null) buildOverlay();
        ovTitle.setText(labelOf(pkg) + " is blocked");
        ovReason.setText(reasonText(d));
        long left = Math.max(0, (getSharedPreferences(FocusController.PREFS, MODE_PRIVATE).getLong("session_end", 0) - System.currentTimeMillis()) / 1000);
        if (FocusController.isSessionActive(this)) {
            ovTimer.setText(FocusController.formatClock(left));
            ovTimer.setVisibility(View.VISIBLE);
        } else {
            ovTimer.setVisibility(View.GONE);
        }
        boolean canEnd = FocusController.isSessionActive(this) && !strict;
        ovEnd.setVisibility(canEnd ? View.VISIBLE : View.GONE);

        if (overlay.getParent() == null) {
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                            : WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    android.graphics.PixelFormat.OPAQUE);
            try { wm.addView(overlay, lp); } catch (Exception e) { return; }
        }
        if (!pkg.equals(overlayPkg)) {
            overlayPkg = pkg;
            Long last = lastCounted.get(pkg);
            long now = System.currentTimeMillis();
            if (last == null || now - last > 5000) {
                FocusController.recordBlockedAttempt(this, pkg);
                lastCounted.put(pkg, now);
            }
        }
    }

    private void buildOverlay() {
        overlay = new OverlayRoot(this);
        overlay.setFocusable(true);
        overlay.setFocusableInTouchMode(true);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(26, 18, 56), Color.rgb(80, 40, 140)});
        overlay.setBackground(bg);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(60, 60, 60, 60);

        TextView lock = new TextView(this);
        lock.setText("🔒");
        lock.setTextSize(64);
        lock.setGravity(Gravity.CENTER);
        box.addView(lock);

        ovTitle = new TextView(this);
        ovTitle.setTextColor(Color.WHITE);
        ovTitle.setTextSize(24);
        ovTitle.setTypeface(Typeface.DEFAULT_BOLD);
        ovTitle.setGravity(Gravity.CENTER);
        box.addView(ovTitle);

        ovReason = new TextView(this);
        ovReason.setTextColor(Color.rgb(220, 210, 245));
        ovReason.setTextSize(16);
        ovReason.setGravity(Gravity.CENTER);
        ovReason.setPadding(0, 24, 0, 8);
        box.addView(ovReason);

        ovTimer = new TextView(this);
        ovTimer.setTextColor(Color.WHITE);
        ovTimer.setTextSize(46);
        ovTimer.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        ovTimer.setGravity(Gravity.CENTER);
        ovTimer.setPadding(0, 16, 0, 16);
        box.addView(ovTimer);

        TextView quote = new TextView(this);
        quote.setText("Stay focused. You'll thank yourself later.");
        quote.setTextColor(Color.rgb(200, 190, 230));
        quote.setTextSize(14);
        quote.setGravity(Gravity.CENTER);
        quote.setPadding(0, 8, 0, 36);
        box.addView(quote);

        Button home = new Button(this);
        home.setText("Go to Home");
        home.setOnClickListener(v -> goHome());
        box.addView(home, new LinearLayout.LayoutParams(-1, -2));

        Button open = new Button(this);
        open.setText("Open TaskZen");
        open.setOnClickListener(v -> openTaskZen());
        box.addView(open, new LinearLayout.LayoutParams(-1, -2));

        ovEnd = new Button(this);
        ovEnd.setText("End focus session");
        ovEnd.setOnClickListener(v -> {
            FocusController.stopSession(this);
            hideOverlay();
        });
        box.addView(ovEnd, new LinearLayout.LayoutParams(-1, -2));

        FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
        overlay.addView(box, flp);
    }

    private void hideOverlay() {
        overlayPkg = "";
        if (overlay != null && overlay.getParent() != null) {
            try { wm.removeView(overlay); } catch (Exception ignored) {}
        }
    }

    private void goHome() {
        hideOverlay();
        try {
            Intent h = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(h);
        } catch (Exception ignored) {}
        currentFg = getPackageName();
    }

    private void openTaskZen() {
        hideOverlay();
        try {
            Intent i = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(i);
        } catch (Exception ignored) {}
        currentFg = getPackageName();
    }

    /** User swiped TaskZen away from Recents: keep blocking by re-arming a quick wake-up. */
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        try {
            FocusController.sync(this);
            FocusController.armWatchdog(this, 1500L);
        } catch (Exception ignored) {}
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        // If we are destroyed while blocking should still be on (killed by the system), come back quickly.
        try {
            FocusController.Decision d = FocusController.evaluate(this);
            if (running && d.active() && !d.packages.isEmpty()) FocusController.armWatchdog(this, 2000L);
        } catch (Exception ignored) {}
        running = false;
        handler.removeCallbacksAndMessages(null);
        hideOverlay();
        super.onDestroy();
    }
}
