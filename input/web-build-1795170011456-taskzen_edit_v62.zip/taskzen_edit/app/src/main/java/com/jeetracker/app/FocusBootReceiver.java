package com.jeetracker.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Restores focus sessions, schedules and the blocker service after reboot or app update. */
public class FocusBootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;
        try { FocusController.onBoot(context); } catch (Exception ignored) {}
    }
}
