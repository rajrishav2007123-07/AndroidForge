package com.jeetracker.app;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.usage.UsageStatsManager;
import android.app.AppOpsManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.provider.Settings;

import androidx.core.app.NotificationCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Central logic for Focus mode + App blocking (added in v58).
 *
 * Blocking is active when ANY of these is true:
 *   1. A focus session (countdown) is running.
 *   2. A task is running in TaskZen and "block while task running" is enabled.
 *   3. A recurring or one-time schedule is active right now.
 *
 * All state lives in SharedPreferences "focus_prefs" so it survives process death and reboot.
 * Detection uses UsageStatsManager (Usage Access) and the block screen is drawn with a
 * "display over other apps" overlay. Nothing here uses root or hidden APIs.
 */
public final class FocusController {

    public static final String PREFS = "focus_prefs";
    public static final String ACTION_FOCUS_TICK = "com.jeetracker.app.FOCUS_TICK";
    public static final String CHANNEL_FOCUS = "jee_focus_blocker";
    public static final int NOTIF_SERVICE = 9201;
    public static final int NOTIF_DONE = 9202;
    private static final int ALARM_REQ = 9203;
    private static final long WATCHDOG_MS = 60_000L;

    private FocusController() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    // ---------------------------------------------------------------- config

    public static Set<String> getBlockedApps(Context c) {
        Set<String> out = new LinkedHashSet<>();
        try {
            JSONArray a = new JSONArray(sp(c).getString("blocked_apps", "[]"));
            for (int i = 0; i < a.length(); i++) {
                String p = a.optString(i, "");
                if (!p.isEmpty()) out.add(p);
            }
        } catch (Exception ignored) {}
        return out;
    }

    public static boolean isBlockOnTask(Context c) {
        return sp(c).getBoolean("block_on_task", true);
    }

    public static JSONArray getSchedules(Context c) {
        try { return new JSONArray(sp(c).getString("schedules", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    /** Config JSON: {blockedApps:[], blockOnTask:bool, schedules:[]} */
    public static String getConfigJson(Context c) {
        try {
            JSONObject o = new JSONObject();
            o.put("blockedApps", new JSONArray(getBlockedApps(c)));
            o.put("blockOnTask", isBlockOnTask(c));
            o.put("schedules", getSchedules(c));
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }

    public static void setConfigJson(Context c, String json) {
        try {
            JSONObject o = new JSONObject(json);
            SharedPreferences.Editor ed = sp(c).edit();
            if (o.has("blockedApps")) {
                JSONArray in = o.getJSONArray("blockedApps");
                JSONArray clean = new JSONArray();
                Set<String> seen = new HashSet<>();
                for (int i = 0; i < in.length(); i++) {
                    String p = in.optString(i, "");
                    if (!p.isEmpty() && !isProtectedPackage(c, p) && seen.add(p)) clean.put(p);
                }
                ed.putString("blocked_apps", clean.toString());
            }
            if (o.has("blockOnTask")) ed.putBoolean("block_on_task", o.optBoolean("blockOnTask", true));
            if (o.has("schedules")) ed.putString("schedules", o.getJSONArray("schedules").toString());
            ed.apply();
        } catch (Exception ignored) {}
        sync(c);
    }

    /** Apps that can never be blocked, so the user cannot lock themselves out of the phone. */
    public static boolean isProtectedPackage(Context c, String pkg) {
        if (pkg == null) return true;
        if (pkg.equals(c.getPackageName())) return true;
        if (pkg.equals("android") || pkg.equals("com.android.systemui")
                || pkg.equals("com.android.settings") || pkg.equals("com.google.android.packageinstaller")
                || pkg.equals("com.android.packageinstaller") || pkg.equals("com.google.android.permissioncontroller")
                || pkg.equals("com.android.permissioncontroller")) return true;
        if (pkg.contains("dialer") || pkg.equals("com.android.phone") || pkg.equals("com.android.emergency")
                || pkg.equals("com.google.android.apps.safetyhub")) return true;
        return homePackages(c).contains(pkg);
    }

    public static Set<String> homePackages(Context c) {
        Set<String> s = new HashSet<>();
        try {
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            for (ResolveInfo r : c.getPackageManager().queryIntentActivities(i, 0)) {
                if (r.activityInfo != null) s.add(r.activityInfo.packageName);
            }
        } catch (Exception ignored) {}
        return s;
    }

    // ----------------------------------------------------------- task running

    public static void setTaskRunning(Context c, boolean running) {
        boolean prev = sp(c).getBoolean("task_running", false);
        if (prev == running) return;
        sp(c).edit().putBoolean("task_running", running).apply();
        sync(c);
    }

    public static boolean isTaskRunning(Context c) {
        return sp(c).getBoolean("task_running", false);
    }

    /** After reboot: rebuild the running flag from the saved TaskZen state. */
    public static void restoreTaskRunningFromState(Context c) {
        try {
            String json = c.getSharedPreferences("jee_prefs", Context.MODE_PRIVATE).getString("task_state", "");
            boolean running = false;
            if (json != null && !json.isEmpty()) {
                JSONArray tasks = new JSONObject(json).optJSONArray("tasks");
                if (tasks != null) {
                    for (int i = 0; i < tasks.length(); i++) {
                        JSONObject t = tasks.getJSONObject(i);
                        if (!t.optBoolean("completed", false) && !t.isNull("runningAt") && t.optLong("runningAt", 0) > 0) {
                            running = true; break;
                        }
                    }
                }
            }
            sp(c).edit().putBoolean("task_running", running).apply();
        } catch (Exception ignored) {}
    }

    // ------------------------------------------------------------ focus session

    public static boolean isSessionActive(Context c) {
        long end = sp(c).getLong("session_end", 0);
        return end > System.currentTimeMillis();
    }

    public static void startSession(Context c, int minutes, boolean strict) {
        if (minutes < 1) minutes = 1;
        if (minutes > 720) minutes = 720;
        long now = System.currentTimeMillis();
        sp(c).edit()
                .putLong("session_start", now)
                .putLong("session_end", now + minutes * 60_000L)
                .putInt("session_minutes", minutes)
                .putBoolean("session_strict", strict)
                .putBoolean("session_counted", false)
                .apply();
        sync(c);
    }

    /** Returns false when strict mode forbids stopping. */
    public static boolean stopSession(Context c) {
        SharedPreferences p = sp(c);
        if (isSessionActive(c) && p.getBoolean("session_strict", false)) return false;
        long start = p.getLong("session_start", 0);
        if (isSessionActive(c) && start > 0) {
            long mins = Math.max(0, (System.currentTimeMillis() - start) / 60_000L);
            addStatMinutes(c, mins);
        }
        p.edit().putLong("session_end", 0).putBoolean("session_counted", true).apply();
        sync(c);
        return true;
    }

    private static void finishSessionIfDue(Context c) {
        SharedPreferences p = sp(c);
        long end = p.getLong("session_end", 0);
        if (end <= 0 || end > System.currentTimeMillis()) return;
        if (!p.getBoolean("session_counted", false)) {
            addStatMinutes(c, p.getInt("session_minutes", 0));
            p.edit().putBoolean("session_counted", true).apply();
            notifyDone(c, p.getInt("session_minutes", 0));
        }
    }

    // ----------------------------------------------------------------- schedules

    private static int dayBit(Calendar cal) { return cal.get(Calendar.DAY_OF_WEEK) - 1; } // 0=Sun..6=Sat (JS getDay)

    private static boolean scheduleActive(JSONObject s, long nowMs) {
        if (!s.optBoolean("enabled", true)) return false;
        if ("once".equals(s.optString("type", "weekly"))) {
            long a = s.optLong("startAt", 0), b = s.optLong("endAt", 0);
            return a > 0 && nowMs >= a && nowMs < b;
        }
        JSONArray days = s.optJSONArray("days");
        if (days == null || days.length() == 0) return false;
        int start = s.optInt("startMin", 0), end = s.optInt("endMin", 0);
        if (start == end) return false;
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(nowMs);
        int m = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE);
        int today = dayBit(cal);
        int yesterday = (today + 6) % 7;
        boolean tOn = false, yOn = false;
        for (int i = 0; i < days.length(); i++) {
            int d = days.optInt(i, -1);
            if (d == today) tOn = true;
            if (d == yesterday) yOn = true;
        }
        if (start < end) return tOn && m >= start && m < end;
        return (tOn && m >= start) || (yOn && m < end); // overnight
    }

    // ------------------------------------------------------------ effective state

    public static final class Decision {
        public final Set<String> packages = new LinkedHashSet<>();
        public final JSONArray reasons = new JSONArray();
        public boolean active() { return reasons.length() > 0; }
    }

    public static Decision evaluate(Context c) {
        Decision d = new Decision();
        long now = System.currentTimeMillis();
        Set<String> global = getBlockedApps(c);
        if (isSessionActive(c)) {
            d.reasons.put("focus");
            d.packages.addAll(global);
        }
        if (isBlockOnTask(c) && isTaskRunning(c)) {
            d.reasons.put("task");
            d.packages.addAll(global);
        }
        JSONArray sch = getSchedules(c);
        for (int i = 0; i < sch.length(); i++) {
            JSONObject s = sch.optJSONObject(i);
            if (s == null || !scheduleActive(s, now)) continue;
            d.reasons.put("schedule:" + s.optString("name", "Schedule"));
            JSONArray apps = s.optJSONArray("apps");
            if (apps != null && apps.length() > 0) {
                for (int k = 0; k < apps.length(); k++) d.packages.add(apps.optString(k, ""));
            } else {
                d.packages.addAll(global);
            }
        }
        d.packages.remove("");
        Iterator<String> it = d.packages.iterator();
        while (it.hasNext()) if (isProtectedPackage(c, it.next())) it.remove();
        return d;
    }

    // ------------------------------------------------------------------ sync

    /**
     * Re-evaluates everything: starts/stops the foreground service and re-arms the
     * next boundary alarm. Safe to call any time (UI, alarm, boot, bridge).
     */
    public static void sync(Context ctx) {
        final Context c = ctx.getApplicationContext();
        try { finishSessionIfDue(c); } catch (Exception ignored) {}
        Decision d = evaluate(c);
        boolean a11y = isAccessibilityEnabled(c);
        boolean ready = a11y || (hasUsageAccess(c) && canDrawOverlay(c));
        try {
            if (a11y) {
                // Accessibility service does the blocking by itself; no foreground service needed.
                c.stopService(new Intent(c, FocusBlockService.class));
            } else if (d.active() && !d.packages.isEmpty() && ready) {
                Intent i = new Intent(c, FocusBlockService.class);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) c.startForegroundService(i);
                else c.startService(i);
            } else {
                c.stopService(new Intent(c, FocusBlockService.class));
            }
        } catch (Exception ignored) {
            // Background-start restrictions: service will start next time the app/alarm runs in foreground.
        }
        try { scheduleNextBoundary(c); } catch (Exception ignored) {}
    }

    private static void scheduleNextBoundary(Context c) {
        long now = System.currentTimeMillis();
        long next = Long.MAX_VALUE;
        long end = sp(c).getLong("session_end", 0);
        if (end > now) next = Math.min(next, end);

        JSONArray sch = getSchedules(c);
        for (int i = 0; i < sch.length(); i++) {
            JSONObject s = sch.optJSONObject(i);
            if (s == null || !s.optBoolean("enabled", true)) continue;
            if ("once".equals(s.optString("type", "weekly"))) {
                long a = s.optLong("startAt", 0), b = s.optLong("endAt", 0);
                if (a > now) next = Math.min(next, a);
                if (b > now) next = Math.min(next, b);
            } else {
                int[] mins = {s.optInt("startMin", 0), s.optInt("endMin", 0)};
                for (int day = 0; day <= 8; day++) {
                    for (int m : mins) {
                        Calendar cal = Calendar.getInstance();
                        cal.add(Calendar.DAY_OF_YEAR, day);
                        cal.set(Calendar.HOUR_OF_DAY, m / 60);
                        cal.set(Calendar.MINUTE, m % 60);
                        cal.set(Calendar.SECOND, 0);
                        cal.set(Calendar.MILLISECOND, 0);
                        long t = cal.getTimeInMillis();
                        if (t > now) next = Math.min(next, t);
                    }
                }
            }
        }

        // Watchdog: while blocking is active, wake up every minute and make sure the service
        // is still alive (it can be killed when the user swipes TaskZen out of Recents).
        try {
            Decision dd = evaluate(c);
            if (dd.active() && !dd.packages.isEmpty() && !isAccessibilityEnabled(c)) next = Math.min(next, now + WATCHDOG_MS);
        } catch (Exception ignored) {}

        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = new Intent(c, FocusAlarmReceiver.class).setAction(ACTION_FOCUS_TICK);
        PendingIntent pi = PendingIntent.getBroadcast(c, ALARM_REQ, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.cancel(pi);
        if (next == Long.MAX_VALUE) return;
        long at = next + 1000L;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }

    /** Re-arm the wake-up alarm after `delayMs` (used when the app is removed from Recents). */
    public static void armWatchdog(Context c, long delayMs) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            Intent i = new Intent(c, FocusAlarmReceiver.class).setAction(ACTION_FOCUS_TICK);
            PendingIntent pi = PendingIntent.getBroadcast(c, ALARM_REQ, i,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            long at = System.currentTimeMillis() + delayMs;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            }
        } catch (Exception ignored) {}
    }

    public static boolean canExactAlarms(Context c) {
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            return am != null && am.canScheduleExactAlarms();
        } catch (Exception e) { return true; }
    }

    public static void onBoot(Context c) {
        restoreTaskRunningFromState(c);
        sync(c);
    }

    // ----------------------------------------------------------- permissions

    public static boolean hasUsageAccess(Context c) {
        try {
            AppOpsManager ops = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
            int mode = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                    ? ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), c.getPackageName())
                    : ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), c.getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) { return false; }
    }

    /** True when the user enabled the TaskZen accessibility blocker in Android settings. */
    public static boolean isAccessibilityEnabled(Context c) {
        try {
            int on = Settings.Secure.getInt(c.getContentResolver(), Settings.Secure.ACCESSIBILITY_ENABLED, 0);
            if (on != 1) return false;
            String list = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (list == null || list.isEmpty()) return false;
            android.content.ComponentName mine = new android.content.ComponentName(c, FocusAccessibilityService.class);
            for (String part : list.split(":")) {
                android.content.ComponentName cn = android.content.ComponentName.unflattenFromString(part);
                if (cn != null && cn.equals(mine)) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    /** Blocking can run: accessibility blocker, or Usage Access + Display over apps. */
    public static boolean isReady(Context c) {
        return isAccessibilityEnabled(c) || (hasUsageAccess(c) && canDrawOverlay(c));
    }

    public static boolean canDrawOverlay(Context c) {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(c);
    }

    // ----------------------------------------------------------------- stats

    private static String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }

    public static synchronized void recordBlockedAttempt(Context c, String pkg) {
        try {
            SharedPreferences p = sp(c);
            JSONObject days = new JSONObject(p.getString("stat_attempts", "{}"));
            String k = today();
            days.put(k, days.optInt(k, 0) + 1);
            trim(days, 30);
            JSONObject apps = new JSONObject(p.getString("stat_apps", "{}"));
            apps.put(pkg, apps.optInt(pkg, 0) + 1);
            p.edit().putString("stat_attempts", days.toString()).putString("stat_apps", apps.toString()).apply();
        } catch (Exception ignored) {}
    }

    private static synchronized void addStatMinutes(Context c, long mins) {
        if (mins <= 0) return;
        try {
            SharedPreferences p = sp(c);
            JSONObject days = new JSONObject(p.getString("stat_minutes", "{}"));
            String k = today();
            days.put(k, days.optLong(k, 0) + mins);
            trim(days, 30);
            p.edit().putString("stat_minutes", days.toString()).apply();
        } catch (Exception ignored) {}
    }

    private static void trim(JSONObject o, int keep) {
        try {
            java.util.List<String> keys = new java.util.ArrayList<>();
            Iterator<String> it = o.keys();
            while (it.hasNext()) keys.add(it.next());
            java.util.Collections.sort(keys);
            while (keys.size() > keep) o.remove(keys.remove(0));
        } catch (Exception ignored) {}
    }

    public static String getStatsJson(Context c) {
        try {
            SharedPreferences p = sp(c);
            JSONObject a = new JSONObject(p.getString("stat_attempts", "{}"));
            JSONObject m = new JSONObject(p.getString("stat_minutes", "{}"));
            JSONArray week = new JSONArray();
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_YEAR, -6);
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            for (int i = 0; i < 7; i++) {
                String k = f.format(cal.getTime());
                JSONObject row = new JSONObject();
                row.put("date", k);
                row.put("dow", cal.get(Calendar.DAY_OF_WEEK) - 1);
                row.put("attempts", a.optInt(k, 0));
                row.put("minutes", m.optLong(k, 0));
                week.put(row);
                cal.add(Calendar.DAY_OF_YEAR, 1);
            }
            JSONObject o = new JSONObject();
            o.put("week", week);
            o.put("apps", new JSONObject(p.getString("stat_apps", "{}")));
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }

    // ---------------------------------------------------------- notifications

    public static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            if (nm != null && nm.getNotificationChannel(CHANNEL_FOCUS) == null) {
                NotificationChannel ch = new NotificationChannel(CHANNEL_FOCUS, "Focus & App Blocker",
                        NotificationManager.IMPORTANCE_LOW);
                ch.setDescription("Shown while apps are being blocked");
                ch.setShowBadge(false);
                nm.createNotificationChannel(ch);
            }
        }
    }

    private static void notifyDone(Context c, int minutes) {
        try {
            ensureChannel(c);
            Intent open = new Intent(c, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            PendingIntent pi = PendingIntent.getActivity(c, 9204, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            NotificationCompat.Builder b = new NotificationCompat.Builder(c, CHANNEL_FOCUS)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("Focus session complete 🎉")
                    .setContentText(minutes + " min of focused study. Apps are unblocked.")
                    .setAutoCancel(true)
                    .setContentIntent(pi);
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIF_DONE, b.build());
        } catch (Exception ignored) {}
    }

    // ------------------------------------------------------------ state for UI

    public static String getStateJson(Context c) {
        try {
            SharedPreferences p = sp(c);
            long now = System.currentTimeMillis();
            long end = p.getLong("session_end", 0);
            Decision d = evaluate(c);
            JSONObject o = new JSONObject();
            o.put("now", now);
            o.put("sessionActive", end > now);
            o.put("sessionEnd", end);
            o.put("sessionStart", p.getLong("session_start", 0));
            o.put("sessionMinutes", p.getInt("session_minutes", 0));
            o.put("strict", p.getBoolean("session_strict", false) && end > now);
            o.put("remainingSec", Math.max(0, (end - now) / 1000));
            o.put("taskRunning", isTaskRunning(c));
            o.put("blocking", d.active() && !d.packages.isEmpty());
            o.put("reasons", d.reasons);
            o.put("activeCount", d.packages.size());
            o.put("hasAccessibility", isAccessibilityEnabled(c));
            o.put("ready", isReady(c));
            o.put("hasUsageAccess", hasUsageAccess(c));
            o.put("hasOverlay", canDrawOverlay(c));
            o.put("hasNotifications", androidx.core.app.NotificationManagerCompat.from(c).areNotificationsEnabled());
            o.put("canExact", canExactAlarms(c));
            o.put("sdk", Build.VERSION.SDK_INT);
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }

    public static String formatClock(long sec) {
        long h = sec / 3600, m = (sec % 3600) / 60, s = sec % 60;
        return h > 0 ? String.format(Locale.US, "%d:%02d:%02d", h, m, s) : String.format(Locale.US, "%02d:%02d", m, s);
    }
}
