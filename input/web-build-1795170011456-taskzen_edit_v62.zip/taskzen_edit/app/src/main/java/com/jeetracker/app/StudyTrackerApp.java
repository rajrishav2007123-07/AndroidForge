package com.jeetracker.app;

import android.app.Application;

import com.google.firebase.FirebaseApp;

/**
 * Application entry point.
 * Initializes Firebase once for the process lifetime.
 * All study state, timers and UI live in the WebView layer (assets/index.html)
 * and communicate with native Android via {@link AndroidBridge}.
 */
public class StudyTrackerApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        try {
            FirebaseApp.initializeApp(this);
        } catch (Exception ignored) {
            // Already initialized or google-services.json missing in debug setups
        }
    }
}
